﻿Imports System.Text

Module Mod_Log

    Friend isDebugOn As Boolean = False
    Private txtDebugOn As New StringBuilder()
    Friend Sub addDebugTxt(ByVal txt As String)
        If isDebugOn = False Then Return
        Try
            txtDebugOn.Append(txt)

            If Not IsNothing(frmUserUIObj) Then
                frmUserUIObj.txtdebug.Text = txtDebugOn.ToString()
            End If
        Catch ex As Exception
        End Try

    End Sub

    Friend Sub clearDebugTxt()
        Try
            txtDebugOn.Clear()
        Catch ex As Exception
        End Try
    End Sub

    Private lastLogDay As DayOfWeek = 10
    Private isDirectoryFound As Boolean = False
    Private filepath As String = ""
    Friend Sub writeLogLine(ByVal txt As String)
        Return
        Try
            frmStartObj.BeginInvoke(Sub()
                                        Try

                                            Dim d As Date = Now

                                            If isDirectoryFound = False Then
                                                isDirectoryFound = True
                                                If Not My.Computer.FileSystem.DirectoryExists(LogFile_DirPath) Then
                                                    My.Computer.FileSystem.CreateDirectory(LogFile_DirPath)
                                                End If
                                            End If


                                            Dim isAppendLog As Boolean = True
                                            If d.DayOfWeek <> lastLogDay Then
                                                Dim strbpath As New StringBuilder
                                                lastLogDay = d.DayOfWeek
                                                isAppendLog = False
                                                strbpath.Append(LogFile_DirPath).Append("\log_")
                                                strbpath.Append(d.Year).Append(d.Month).Append(d.Day)
                                                strbpath.Append(".txt")
                                                filepath = strbpath.ToString
                                            End If

                                            Dim strb As New StringBuilder
                                            strb.Append(d.Hour)
                                            strb.Append(":")
                                            strb.Append(d.Minute)
                                            strb.Append(":")
                                            strb.Append(d.Second)
                                            strb.Append(" - ")
                                            strb.Append(txt)
                                            strb.Append(vbCrLf)

                                            Try
                                                My.Computer.FileSystem.WriteAllText(filepath, strb.ToString, isAppendLog)
                                            Catch ex As Exception
                                            End Try
                                        Catch ex As Exception

                                        End Try
                                    End Sub)

        Catch ex As Exception
        End Try

    End Sub

End Module
