﻿Imports System.Runtime.InteropServices

Module Mod_Resize

    Private GlobalFontSizeSubtract As Double = 0
    Private GlobalZoomSize As Double = 1


    Private isscrnZoomtested As Boolean = False
    Friend Sub GenerateFontSizefromScreenDPI(ByRef g As Graphics, ByVal frmTestControl1 As Control, ByVal frmTestControl2 As Control)

        Try

            ' GlobalFontSize = Math.Round(96 / g.DpiX, 1)

            If Not isscrnZoomtested Then
                isscrnZoomtested = True
                originalTestSize = frmTestControl1.Font.Size
                For i As Integer = 0 To 40
                    If frmTestControl1.Location.X + frmTestControl1.Size.Width > frmTestControl2.Location.X - 17 Then
                        GlobalFontSizeSubtract += 0.2
                        resizeControlFont(frmTestControl1, True)
                    Else
                        frmTestControl1.Font = New Font(frmTestControl1.Font.FontFamily, originalTestSize, frmTestControl1.Font.Style, frmTestControl1.Font.Unit, frmTestControl1.Font.GdiCharSet, frmTestControl1.Font.GdiVerticalFont)

                        Exit For
                    End If
                Next
                GlobalZoomSize = getScalingFactor()

            End If

        Catch ex As Exception

        End Try

    End Sub

    Friend Sub resizeAllChildControls(ByVal frmControl As Control)
        resizeControlFont(frmControl, False)

        Dim len As Integer = frmControl.Controls.Count - 1
        For i As Integer = 0 To len
            resizeAllChildControls(frmControl.Controls(i))
        Next

    End Sub

    Private Sub resizeControlFont(ByRef frmControl As Control, istest As Boolean)
        If isAllowedResizeType(frmControl) Then
            Try

                Dim cntrlOriginalFntSize As Single = 0
                If istest Then
                    cntrlOriginalFntSize = originalTestSize
                Else
                    cntrlOriginalFntSize = frmControl.Font.Size
                End If


                frmControl.Font = New Font(frmControl.Font.FontFamily, cntrlOriginalFntSize - GlobalFontSizeSubtract, frmControl.Font.Style, frmControl.Font.Unit, frmControl.Font.GdiCharSet, frmControl.Font.GdiVerticalFont)

            Catch ex As Exception
            End Try
        End If
    End Sub

    'Friend isWin7 As Boolean = Not (My.Computer.Info.OSFullName.IndexOf("10") > -1 Or My.Computer.Info.OSFullName.IndexOf("8") > -1)

    Private Type_TextBox As Type = GetType(TextBox)
    Private Type_CheckBox As Type = GetType(CheckBox)
    Private Type_RadioButton As Type = GetType(RadioButton)
    Private Type_Label As Type = GetType(Label)
    Private Type_TreeView As Type = GetType(TreeView)
    Private Type_button As Type = GetType(Button)
    Private Type_ComboBox As Type = GetType(ComboBox)

    Private Function isAllowedResizeType(ByRef frmControl As Control) As Boolean
        Dim isAllowed As Boolean = False
        Try
            If frmControl.GetType = Type_TextBox Then Return True
            If frmControl.GetType = Type_CheckBox Then Return True
            If frmControl.GetType = Type_RadioButton Then Return True
            If frmControl.GetType = Type_Label Then Return True
            If frmControl.GetType = Type_TreeView Then Return True
            If frmControl.GetType = Type_button Then Return True
            If frmControl.GetType = Type_ComboBox Then Return True
        Catch ex As Exception

        End Try
        Return isAllowed
    End Function

    Private originalTestSize As Single = 0


    <DllImport("gdi32.dll")>
    Friend Function GetDeviceCaps(hdc As IntPtr, nIndex As Integer) As Integer
    End Function

    Friend Enum DeviceCap
        VERTRES = 10
        HORZRES = 8
        DESKTOPVERTRES = 117
        DESKTOPHORZRES = 118
    End Enum

    Private Function getScalingFactor() As Single
        Dim g As Graphics = Graphics.FromHwnd(IntPtr.Zero)
        Dim desktop As IntPtr = g.GetHdc()
        Dim LogicalScreenHeight As Integer = GetDeviceCaps(desktop, CInt(DeviceCap.VERTRES))
        Dim PhysicalScreenHeight As Integer = GetDeviceCaps(desktop, CInt(DeviceCap.DESKTOPVERTRES))
        Dim ScreenScalingFactor As Single = CSng(PhysicalScreenHeight) / CSng(LogicalScreenHeight)


        Return ScreenScalingFactor
    End Function

End Module
