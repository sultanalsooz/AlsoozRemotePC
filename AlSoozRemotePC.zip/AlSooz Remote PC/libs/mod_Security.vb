﻿Imports System.IO
Imports System.Management
Imports System.Runtime.InteropServices
Imports System.Security.Cryptography
Imports System.Text

Module mod_Security

    Friend Function encodeTextToBase64(ByVal plainText As String) As String
        Return Convert.ToBase64String(Text.Encoding.UTF8.GetBytes(plainText))
    End Function

    Friend Function decodeTextFromBase64(ByVal encodedText As String) As String
        Return Text.Encoding.UTF8.GetString(Convert.FromBase64String(encodedText))
    End Function



    Friend Function getCurrentLoggedOnUserName() As String
        Dim username As String = ""
        Using searcher As ManagementObjectSearcher = New ManagementObjectSearcher("SELECT UserName FROM Win32_ComputerSystem")
            Using Collection2 As ManagementObjectCollection = searcher.Get()
                username = DirectCast(Collection2(0), ManagementBaseObject).GetPropertyValue("UserName")
            End Using
        End Using

        Return username
    End Function


    Private AESIV As Byte() = Encoding.ASCII.GetBytes("0987654321123456")
    Private infoKey As String = "06396208"
    Private AesKey As String = "56273654"

    Private AESOfflineKey As Byte() = Nothing
    Friend Function EncryptStringToBase64(ByVal plainText As String) As String

        If IsNothing(AESOfflineKey) Then AESOfflineKey = Encoding.ASCII.GetBytes(infoKey & AesKey)
        ' DebugSetText(System.Text.Encoding.ASCII.GetChars(AESKey))

        Dim encrypted() As Byte
        Try
            Using EncAES = Aes.Create()

                EncAES.Key = AESOfflineKey
                EncAES.IV = AESIV

                Dim encryptor As ICryptoTransform = EncAES.CreateEncryptor(EncAES.Key, EncAES.IV)

                Using msEncrypt As New MemoryStream()
                    Using csEncrypt As New CryptoStream(msEncrypt, encryptor, CryptoStreamMode.Write)
                        Using swEncrypt As New StreamWriter(csEncrypt)

                            swEncrypt.Write(plainText)

                        End Using
                        encrypted = msEncrypt.ToArray()
                    End Using
                End Using
            End Using
            Return Convert.ToBase64String(encrypted)
        Catch ex As Exception

        End Try
        Return "err"

    End Function

    Friend Function DecryptStringFromBase64(ByVal base64_Cipher As String) As String

        Dim cipherText As Byte() = Convert.FromBase64String(base64_Cipher)

        Dim plaintext As String = Nothing

        If IsNothing(AESOfflineKey) Then AESOfflineKey = Encoding.ASCII.GetBytes(infoKey & AesKey)

        Using EncAES = Aes.Create()
            EncAES.Key = AESOfflineKey
            EncAES.IV = AESIV


            Dim decryptor As ICryptoTransform = EncAES.CreateDecryptor(EncAES.Key, EncAES.IV)


            Using msDecrypt As New MemoryStream(cipherText)

                Using csDecrypt As New CryptoStream(msDecrypt, decryptor, CryptoStreamMode.Read)

                    Using srDecrypt As New StreamReader(csDecrypt)

                        plaintext = srDecrypt.ReadToEnd()
                    End Using
                End Using
            End Using
        End Using

        Return plaintext

    End Function


    '<DllImport("Advapi32.dll", CharSet:=CharSet.Auto,
    '       SetLastError:=True, ExactSpelling:=False)>
    'Private Function ConvertStringSecurityDescriptorToSecurityDescriptor(
    '       ByVal StringSecurityDescriptor As String,
    '       ByVal StringSDRevision As UInt32,
    '       ByRef SecurityDescriptor As IntPtr,
    '       ByRef SecurityDescriptorSize As Integer
    '       ) As Boolean
    'End Function
    '<StructLayout(LayoutKind.Sequential)>
    'Private Structure SECURITY_ATTRIBUTES
    '    Public Length As Integer
    '    Public lpSecurityDescriptor As IntPtr
    '    Public bInheritHandle As Boolean
    'End Structure
    '<DllImport("advapi32.dll", CharSet:=CharSet.Ansi, SetLastError:=True)>
    'Private Function SetKernelObjectSecurity(
    '          ByVal hObject As IntPtr,
    '          ByVal SecurityInformation As Integer,
    '          ByVal pSecurityDescriptor As IntPtr) _
    '          As Integer
    'End Function

    'Friend Function setDenyAdminShutdownAccess_HideOnly(ByVal isStartProtect As Boolean)
    '    Dim ssdl As String
    '    If isStartProtect Then
    '        ssdl = "D:"                       '// Discretionary ACL
    '        ssdl &= "(D;OICI;GA;;;BG)"        '// Deny access to built-in guests
    '        ssdl &= "(D;OICI;GA;;;AN)"        '// Deny access to anonymous logon
    '        ssdl &= "(D;OICI;GA;;;AU)"        '// Deny access to authenticated users
    '        ssdl &= "(D;OICI;GA;;;BA)"        '// Deny access to administrators

    '    Else
    '        ssdl = "D:"                       '// Discretionary ACL
    '        ssdl &= "(D;OICI;GA;;;BG)"        '// Deny access to built-in guests
    '        ssdl &= "(D;OICI;GA;;;AN)"        '// Deny access to anonymous logon

    '    End If

    '    Const SDDL_REVISION_1 As Integer = 1

    '    Dim sa As New SECURITY_ATTRIBUTES
    '    sa.bInheritHandle = False
    '    sa.lpSecurityDescriptor = IntPtr.Zero
    '    sa.Length = Marshal.SizeOf(sa)

    '    Dim result As Boolean
    '    result = ConvertStringSecurityDescriptorToSecurityDescriptor(ssdl, SDDL_REVISION_1, sa.lpSecurityDescriptor, Nothing)
    '    If Not result Then
    '        ' Console.WriteLine("Fail to convert SD to string SD:")
    '        Return False
    '    End If


    '    Dim myProcessHandle As IntPtr
    '    myProcessHandle = System.Diagnostics.Process.GetCurrentProcess.Handle

    '    Const DACL_SECURITY_INFORMATION As Integer = &H4

    '    Dim iResult As Integer

    '    iResult = SetKernelObjectSecurity(myProcessHandle, DACL_SECURITY_INFORMATION, sa.lpSecurityDescriptor)
    '    If iResult = 0 Then
    '        Return False
    '    End If

    '    Return True
    'End Function


    '<DllImport("ntdll.dll", SetLastError:=True)>
    'Private Sub RtlSetProcessIsCritical(ByVal v1 As UInt32, ByVal v2 As UInt32, ByVal v3 As UInt32)
    'End Sub

    'Friend isAppProtectedFromAdmins As Boolean = False
    'Friend Function setDenyAdminShutdownAccess_ForceShutdown(ByVal isStartProtect As Boolean) As Boolean

    '    Try
    '        If isStartProtect Then
    '            Process.EnterDebugMode()
    '            RtlSetProcessIsCritical(1, 0, 0)
    '        Else
    '            RtlSetProcessIsCritical(0, 0, 0)
    '            Process.LeaveDebugMode()
    '        End If

    '        isAppProtectedFromAdmins = isStartProtect

    '        Return True
    '    Catch ex As Exception
    '    End Try

    '    Return False
    'End Function

End Module
