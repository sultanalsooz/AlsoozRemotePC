﻿ 
Imports System.Net
Imports System.Text
Imports Microsoft.Win32


Module modAppEngine

    Friend myApp As myAppClass = Nothing

    Friend Class myAppClass

        ' --------- Customize Default Settings Start --------- 

        Friend Password_MyPC As String = "pass" ' adaapcpass for ADAA

        Friend AutoDiscoverKeyword As String = "new"

        Friend Password_UIAccess As String = "" '"ADAAadmin-123" 'new  ADAAadmin-123 for ADAA
        Friend Password_UIAccess_chk As String = "no" '"yes" 'yes for ADAA

        Friend Password_ExitApp As String = "exit"
        Friend Password_ExitApp_chk As String = "no" 'yes for ADAA


        Friend Password_Config As String = "pass-098"
        Friend Password_Config_chk As String = "yes" 'yes for ADAA

        Friend RemotePcAccessApproval As String = "no" ' yes for ADAA
        Friend RemotePcAccessApproveAtLocked As String = "no"

        Friend AfterConnectAutoStartActions As String = "control" ' "control" to start PC control after connected

        Friend Controller_Quality As String = "1" ' 2= high quality
        Friend Controller_FullScreen As String = "no"
        Friend Controller_RemoteMouse As String = "no"
        Friend Controller_ControlPC As String = "yes"
        Friend Controller_CloseConnection As String = "yes"
        Friend Controller_AllowFilesSend As String = "yes"
        Friend Controller_AllowFilesReceive As String = "yes"
        Friend Controller_AllowClipboardSend As String = "yes"
        Friend Controller_AllowClipboardReceive As String = "yes"
        Friend Controller_AllowAutoDiscoveryNotification As String = "no"

        ' --------- Customize Default Settings End ---------


        Friend Password_CurrentRequest As PasswordType = PasswordType.NA
        Friend AppVersion As String = Application.ProductVersion

        Friend MyInstallationID As UInt64 = 0
        Private LastUniqueID As UInt64 = 1
        Friend MyComputerSerial As String = ""


        Friend myService As myServiceClass

        Friend MyConn As InternetConnectionClass
        Friend myScreen As MyScreenRecorderClass
        Friend myFileShare As fileShareClass

        ' Friend isService_ScreenControlOn As Boolean = False
        Friend isService_ScreenViewOn As Boolean = False
        Friend isService_MouseOn As Boolean = False
        ' Friend isService_AudioOn As Boolean = False
        Friend isService_FileOn As Boolean = False
        Friend isService_CommandOn As Boolean = False

        Private reconnectionThread As Threading.Thread
        Private reconnectionThread_IsContinue As Boolean = True
        Friend reconnectionThread_IsSkip As Boolean = False

        Friend Enum PasswordType
            NA
            UIAccess
            Config
            TaskMgr
            ExitApp
            Uninstall
        End Enum

        Friend Enum Gbl_DiskVariables As Integer
            IsTrayFormObjNull = 0
        End Enum

        Private DiskVariablesLock As New Object()
        Friend Sub initDiskVariablesState()
            Dim lst As String() = [Enum].GetNames(GetType(Gbl_DiskVariables))
            Dim strb As New StringBuilder
            For i As Integer = 0 To lst.Count - 1
                strb.Append("0").Append(vbCrLf)
            Next
            Try
                Threading.Monitor.Enter(DiskVariablesLock)
                My.Computer.FileSystem.WriteAllText(Gbl_DiskValuesPath, strb.ToString, False)
            Catch ex As Exception : End Try
            Try
                Threading.Monitor.Exit(DiskVariablesLock)
            Catch ex As Exception : End Try
        End Sub

        Friend Sub writeDiskVariablesState(diskVariable As Gbl_DiskVariables, diskValue As String)
            Try
                Threading.Monitor.Enter(DiskVariablesLock)
                Dim lst As String() = readDiskVariables(False)
                lst(Convert.ToInt32(diskVariable)) = diskValue
                Dim str As String = String.Join(vbCrLf, lst)
                My.Computer.FileSystem.WriteAllText(Gbl_DiskValuesPath, str, False)
            Catch ex As Exception : End Try
            Try
                Threading.Monitor.Exit(DiskVariablesLock)
            Catch ex As Exception : End Try
        End Sub

        Friend Function readDiskVariablesState(diskVariable As Gbl_DiskVariables, withLock As Boolean) As String
            Try
                Dim lst As String() = readDiskVariables(withLock)
                Return lst(Convert.ToInt32(diskVariable))
            Catch ex As Exception
            End Try
            Return "0"
        End Function

        Private Function readDiskVariables(withLock As Boolean) As String()
            Dim lst As String() = Nothing
            Try
                If withLock Then Threading.Monitor.Enter(DiskVariablesLock)
                lst = My.Computer.FileSystem.ReadAllText(Gbl_DiskValuesPath).Split(New String() {vbCrLf}, StringSplitOptions.RemoveEmptyEntries)
            Catch ex As Exception : End Try
            Try
                If withLock Then Threading.Monitor.Exit(DiskVariablesLock)
            Catch ex As Exception : End Try

            Return lst
        End Function

        Friend Sub showPasswordForm(PassRequest As PasswordType)
            myApp.Password_CurrentRequest = PassRequest

            If Not IsNothing(frmPasswordObj) Then
                Try
                    frmPasswordObj.Close()
                Catch ex As Exception
                End Try
            End If

            frmPasswordObj = New frmPassword()
            frmPasswordObj.Show()

        End Sub

        Friend Sub ReConnectionThread_Start()

            ReConnectionThread_Stop()

            reconnectionThread = New Threading.Thread(Sub()
                                                          Try
                                                              Threading.Thread.Sleep(2000)
                                                              reconnectionThread_IsContinue = True
                                                              ReConnectionThread_Proc()
                                                          Catch ex As Exception
                                                          End Try
                                                      End Sub)
            reconnectionThread.Start()
        End Sub

        Friend Sub ReConnectionThread_Stop()
            reconnectionThread_IsContinue = False
            If Not IsNothing(reconnectionThread) AndAlso reconnectionThread.IsAlive Then
                Try
                    reconnectionThread.Interrupt()
                    reconnectionThread.Abort()
                Catch ex As Exception
                End Try
            End If
        End Sub

        Private Sub ReConnectionThread_Proc()

            Do While reconnectionThread_IsContinue
                Try
                    If reconnectionThread_IsSkip = False AndAlso
                                      myService.UnattendedConnectionType = "auto" AndAlso
                                     My.Computer.Network.IsAvailable Then

                        If MyConn.IsMyPCConnected Then
                            If myService.UnattendedType = Enum_UnAttendedType.Online_ID Then
                                If IsNothing(MyConn.MyWS) Then
                                    MyConn.IsMyPCConnected = False
                                ElseIf IsNothing(MyConn.MyWS.wsArry) Then
                                    MyConn.IsMyPCConnected = False
                                ElseIf MyConn.MyWS.wsArry(0).State <> Net.WebSockets.WebSocketState.Open AndAlso
                                    MyConn.MyWS.wsArry(0).State <> Net.WebSockets.WebSocketState.Connecting Then
                                    MyConn.Disconnect()
                                End If

                            End If
                        Else
                            If myService.UnattendedType = Enum_UnAttendedType.Online_ID Then
                                MyConn.Connect_WS_Server()
                            Else
                                MyConn.Connect_UDP_Server()
                            End If
                        End If

                    End If
                Catch ex As Exception
                End Try

                Threading.Thread.Sleep(4000)
            Loop
        End Sub

        Friend Sub SendScreenRequest()
            If isService_ScreenViewOn Then
                Service_ScreenStop(False)
            Else
                MyConn.SendRequestAsText("CMD_ClickShareBtn:")
            End If

        End Sub

        Friend Function getDateTime() As String
            Return Format(Now, "yyyy-MM-dd HH:mm:ss")
        End Function

        Friend Function getTime() As String
            Return Format(Now, "HH:mm:ss")
        End Function

        Friend Sub ShowRemoteScreenController()

            frmUserUIObj.BeginInvoke(Sub()

                                         frmScreenControlObj = New frmScreenControl()
                                         frmScreenControlObj.Show()
                                         ShowFormOnTop(frmScreenControlObj)

                                         UpdateUI()
                                     End Sub)

        End Sub
        Friend Sub CloseRemoteScreenController()
            Try
                If Not IsNothing(frmScreenControlObj) Then
                    frmScreenControlObj.Close()
                End If
            Catch ex As Exception
            End Try
            frmScreenControlObj = Nothing
        End Sub
        Friend Sub Service_ScreenStart(isSender As Boolean)

            isService_ScreenViewOn = True

            If isSender Then
                myScreen.Record_framenumber = 0
                ' myScreen.StartRecording()
            Else
                ShowRemoteScreenController()
                MyConn.SendRequestAsText("CMD_RequestToShareAccepted:")
            End If

        End Sub

        Friend Sub Service_ScreenStop(ByVal isSkipUiUpdate As Boolean)
            If isService_ScreenViewOn Then
                isService_ScreenViewOn = False
                If MyConn.isServiceOpen_WS_Mouse Then
                    Try
                        MyConn.WS_Service_Close(wsArry_MouseIndex, True)
                    Catch ex As Exception
                    End Try
                End If

                myScreen.StopRecording()

                MyConn.SendRequestAsText("CMD_RequestToShareStopped")
                If isSkipUiUpdate = False Then UpdateUI()
                Try
                    MyConn.WS_Service_Close(wsArry_ScreenIndex, True)
                Catch ex As Exception
                End Try

            End If
        End Sub
        Private Sub createNewInstallationID()
            MyInstallationID = CULng(Format(Now, "yyMMddHHmmssfff"))
            MyComputerSerial = getComputerSerialNumber().Replace("&", "").Replace("=", "").Replace("?", "").Replace("%", "").Replace(":", "")
            saveSettings()
        End Sub

        Friend isReadFromUserProfile As Boolean = False
        Sub New()

            myService = New myServiceClass
            MyConn = New InternetConnectionClass
            myScreen = New MyScreenRecorderClass
            myFileShare = New fileShareClass

            If isGodPower Then
                isScreenLocked = True
                Try
                    If My.Computer.FileSystem.FileExists(Gbl_Config_Path) Then
                        readSettings()
                    Else
                        'Dim username As String = getCurrentLoggedOnUserName()

                        'If username.IndexOf("\") > -1 Then
                        '    username = username.Split("\")(1).Trim
                        'End If

                        If My.Computer.FileSystem.DirectoryExists(Gbl_FolderPath_User) Then
                            If My.Computer.FileSystem.FileExists(Gbl_Config_Path_User) Then
                                isReadFromUserProfile = True
                                readSettings()
                                isReadFromUserProfile = False
                                saveSettings()
                            End If
                        Else
                            myFileShare.ReceivePath = Gbl_FolderPath_User

                            My.Computer.FileSystem.CreateDirectory(Gbl_FolderPath_User)
                            createNewInstallationID()
                        End If
                    End If

                Catch ex As Exception
                End Try

                If MyInstallationID < 100000 Then
                    createNewInstallationID()
                End If

            Else

                isScreenLocked = False

                If My.Computer.FileSystem.DirectoryExists(Gbl_FolderPath_User) Then
                    If My.Computer.FileSystem.FileExists(Gbl_Config_Path_User) Then
                        readSettings()
                    Else
                        createNewInstallationID()
                    End If
                Else
                    myFileShare.ReceivePath = My.Computer.FileSystem.SpecialDirectories.Desktop

                    My.Computer.FileSystem.CreateDirectory(Gbl_FolderPath_User)
                    createNewInstallationID()
                End If

            End If

        End Sub

        Private SessionSwitchHandlerAdded As Boolean = False
        Friend Sub LockScreenListener_Add()
            If SessionSwitchHandlerAdded = False Then
                SessionSwitchHandlerAdded = True
                Try
                    AddHandler SystemEvents.SessionSwitch, AddressOf Handler_SessionLoginLogoff

                Catch ex As Exception
                End Try
            End If

        End Sub
        Friend Sub LockScreenListener_Remove()
            If SessionSwitchHandlerAdded Then
                Try
                    RemoveHandler SystemEvents.SessionSwitch, AddressOf Handler_SessionLoginLogoff
                Catch ex As Exception
                End Try
            End If

        End Sub

        Friend isScreenLocked As Boolean = False
        Private Sub Handler_SessionLoginLogoff(ByVal sender As Object, ByVal e As SessionSwitchEventArgs)
            Try
                If e.Reason = Microsoft.Win32.SessionSwitchReason.SessionLock Then
                    isScreenLocked = True
                ElseIf e.Reason = Microsoft.Win32.SessionSwitchReason.SessionUnlock Then
                    isScreenLocked = False
                End If
            Catch ex As Exception
            End Try

        End Sub

        Friend Function get_NextUniqueID() As UInt64
            LastUniqueID += 1

            Return LastUniqueID
        End Function

        Friend Sub saveSettings()

            Dim strb As New StringBuilder
            strb.Append("My Installation ID = ").Append(MyInstallationID).Append(vbCrLf)
            strb.Append("yes;").Append(Password_MyPC)
            strb.Append(";").Append(Password_UIAccess_chk).Append(";").Append(Password_UIAccess)
            strb.Append(";").Append(Password_Config_chk).Append(";").Append(Password_Config)
            strb.Append(";").Append("free").Append(";").Append("free")
            strb.Append(";").Append(Password_ExitApp_chk).Append(";").Append(Password_ExitApp)
            strb.Append(vbCrLf)
            strb.Append("Auto Listener On = ").Append(myService.UnattendedType).Append(vbCrLf)
            strb.Append("Unattended Type = ").Append(myService.UnattendedConnectionType).Append(vbCrLf)
            strb.Append("Clients Unique ID Count = ").Append(LastUniqueID).Append(vbCrLf)
            strb.Append("Online Server Protocol = ").Append(MyConn.WS_URLProtocol).Append(vbCrLf)
            strb.Append("Online Server URL = ").Append(MyConn.WS_URLDomain).Append(vbCrLf)
            strb.Append("free= ").Append("free").Append(vbCrLf)

            strb.Append("Receive Path | ").Append(myFileShare.ReceivePath).Append(vbCrLf) '8
            strb.Append("free = ").Append("free").Append(vbCrLf) '9
            strb.Append("free = ").Append("free").Append(vbCrLf) '10
            strb.Append("BufferCapacity = ").Append("free").Append(vbCrLf) '11
            strb.Append("RemotePcAccessApproval = ").Append(RemotePcAccessApproval).Append(vbCrLf) '12
            strb.Append("AfterConnectAutoStartActions = ").Append(AfterConnectAutoStartActions).Append(vbCrLf) '13
            strb.Append("RemotePcAccessApproveAtLocked = ").Append(RemotePcAccessApproveAtLocked).Append(vbCrLf) '14
            strb.Append("AutoDiscoverKeyword = ").Append(AutoDiscoverKeyword).Append(vbCrLf) '15
            strb.Append("MyComputerSerial = ").Append(MyComputerSerial).Append(vbCrLf) '16
            strb.Append("Controller_Quality = ").Append(Controller_Quality).Append(vbCrLf) '17
            strb.Append("Controller_FullScreen = ").Append(Controller_FullScreen).Append(vbCrLf) '18
            strb.Append("Controller_RemoteMouse = ").Append(Controller_RemoteMouse).Append(vbCrLf) '19
            strb.Append("Controller_ControlPC = ").Append(Controller_ControlPC).Append(vbCrLf) '20
            strb.Append("Controller_CloseConnection = ").Append(Controller_CloseConnection).Append(vbCrLf) '21
            strb.Append("Controller_AllowFilesSend = ").Append("").Append(Controller_AllowFilesSend).Append(vbCrLf) ' 22
            strb.Append("Controller_AllowFilesReceive = ").Append("").Append(Controller_AllowFilesReceive).Append(vbCrLf) ' 23
            strb.Append("Controller_AllowClipboardSend = ").Append("").Append(Controller_AllowClipboardSend).Append(vbCrLf) '24
            strb.Append("Controller_AllowClipboardReceive = ").Append("").Append(Controller_AllowClipboardReceive).Append(vbCrLf) '25
            strb.Append("Controller_AllowAutoDiscoveryNotification = ").Append(Controller_AllowAutoDiscoveryNotification).Append(vbCrLf) ' 26
            strb.Append("Reserve1 = ").Append("").Append(vbCrLf) ' 27
            strb.Append("Reserve1 = ").Append("").Append(vbCrLf) ' 28
            strb.Append("Reserve1 = ").Append("").Append(vbCrLf) ' 29
            strb.Append("Reserve1 = ").Append("").Append(vbCrLf) ' 30
            strb.Append("Reserve1 = ").Append("").Append(vbCrLf) ' 31
            strb.Append("Reserve1 = ").Append("").Append(vbCrLf) ' 32
            strb.Append("Reserve1 = ").Append("").Append(vbCrLf) ' 33
            strb.Append("f=").Append(gbl_Tree.getSerializedObj_folders).Append(vbCrLf) '34
            strb.Append("p=").Append(gbl_Tree.getSerializedObj_PCs).Append(vbCrLf) '35

            Dim encroptedFile As String = EncryptStringToBase64(strb.ToString)
            Try
                If isGodPower Then
                    My.Computer.FileSystem.WriteAllText(Gbl_Config_Path, encroptedFile, False)
                Else
                    My.Computer.FileSystem.WriteAllText(Gbl_Config_Path_User, encroptedFile, False)
                End If

            Catch ex As Exception
            End Try

        End Sub

        Friend Sub readSettings()

            Try
                Dim strArry As String() = Nothing
                If isGodPower AndAlso isReadFromUserProfile = False Then
                    Dim fileContent As String = My.Computer.FileSystem.ReadAllText(Gbl_Config_Path)
                    If fileContent.StartsWith("My") Then
                    Else
                        fileContent = DecryptStringFromBase64(fileContent)
                    End If
                    strArry = fileContent.Split(New String() {vbCrLf}, StringSplitOptions.RemoveEmptyEntries)
                Else
                    Dim fileContent As String = My.Computer.FileSystem.ReadAllText(Gbl_Config_Path_User)
                    If fileContent.StartsWith("My") Then
                    Else
                        fileContent = DecryptStringFromBase64(fileContent)
                    End If
                    strArry = fileContent.Split(New String() {vbCrLf}, StringSplitOptions.RemoveEmptyEntries)
                End If

                If Not IsNothing(strArry) AndAlso strArry.Length > 0 Then
                    MyInstallationID = CULng(strArry(0).Split("=")(1).Trim)

                    Dim passArry As String() = strArry(1).Split(";")
                    Try
                        Password_MyPC = passArry(1).Trim
                        If Password_MyPC.IndexOf("==") > -1 Then
                            Password_MyPC = decodeTextFromBase64(Password_MyPC)
                        End If
                    Catch ex As Exception
                    End Try

                    If passArry.Length > 2 Then
                        Password_UIAccess_chk = passArry(2).Trim
                        Password_UIAccess = passArry(3).Trim
                        Password_Config_chk = passArry(4).Trim
                        Password_Config = passArry(5).Trim
                        'free = passArry(6).Trim
                        'free = passArry(7).Trim
                        Password_ExitApp_chk = passArry(8).Trim
                        Password_ExitApp = passArry(9).Trim
                    End If

                    myService.UnattendedType = CInt(strArry(2).Split("=")(1).Trim)
                    myService.UnattendedConnectionType = strArry(3).Split("=")(1).Trim
                    LastUniqueID = CULng(strArry(4).Split("=")(1).Trim)
                    MyConn.WS_URLProtocol = strArry(5).Split("=")(1).Trim
                    MyConn.WS_URLDomain = strArry(6).Split("=")(1).Trim

                    'free = CInt(strArry(7).Split("=")(1).Trim)

                    myFileShare.ReceivePath = strArry(8).Split("|")(1).Trim
                    ' free = IIf(strArry(9).Split("=")(1).Trim = "on", True, False)

                    'free = CInt(strArry(10).Split("=")(1).Trim)

                    'free = CInt(strArry(11).Split("=")(1).Trim)


                    Try
                        Dim savedValue As String = strArry(12).Split("=")(1).Trim
                        If savedValue.Length > 0 Then
                            RemotePcAccessApproval = savedValue
                        End If
                    Catch ex As Exception : End Try
                    Try
                        AfterConnectAutoStartActions = strArry(13).Split("=")(1).Trim
                    Catch ex As Exception : End Try

                    RemotePcAccessApproveAtLocked = strArry(14).Split("=")(1).Trim

                    AutoDiscoverKeyword = strArry(15).Split("=")(1).Trim

                    MyComputerSerial = strArry(16).Split("=")(1).Trim

                    Controller_Quality = strArry(17).Split("=")(1).Trim
                    If (Controller_Quality = "") Then Controller_Quality = "1"
                    Controller_FullScreen = strArry(18).Split("=")(1).Trim
                    Controller_RemoteMouse = strArry(19).Split("=")(1).Trim
                    Controller_ControlPC = strArry(20).Split("=")(1).Trim
                    If (Controller_ControlPC = "") Then Controller_ControlPC = "yes"
                    Controller_CloseConnection = strArry(21).Split("=")(1).Trim
                    If (Controller_CloseConnection = "") Then Controller_CloseConnection = "yes"

                    Controller_AllowFilesSend = strArry(22).Split("=")(1).Trim
                    If (Controller_AllowFilesSend = "") Then Controller_AllowFilesSend = "yes"

                    Controller_AllowFilesReceive = strArry(23).Split("=")(1).Trim
                    If (Controller_AllowFilesReceive = "") Then Controller_AllowFilesReceive = "yes"

                    Controller_AllowClipboardSend = strArry(24).Split("=")(1).Trim
                    If (Controller_AllowClipboardSend = "") Then Controller_AllowClipboardSend = "yes"

                    Controller_AllowClipboardReceive = strArry(25).Split("=")(1).Trim
                    If (Controller_AllowClipboardReceive = "") Then Controller_AllowClipboardReceive = "yes"

                    Controller_AllowAutoDiscoveryNotification = strArry(26).Split("=")(1).Trim
                    If (Controller_AllowAutoDiscoveryNotification = "") Then Controller_AllowAutoDiscoveryNotification = "no"


                    gbl_Tree.setSerializedObjs_Folders(strArry(34).Substring(2).Trim)
                    gbl_Tree.setSerializedObjs_PCs(strArry(35).Substring(2).Trim)
                End If

            Catch ex As Exception
            End Try

        End Sub

        Friend Sub UpdateUI()
            If Not IsNothing(frmTrayObj) Then
                frmTrayObj.BeginInvoke(Sub()
                                           If MyConn.IsRemotePCConnected = True Then
                                               frmTrayObj.MyTrayIcon.Icon = My.Resources.newgreen
                                           ElseIf MyConn.IsMyPCConnected = True Then
                                               frmTrayObj.MyTrayIcon.Icon = My.Resources.neworange
                                           Else
                                               frmTrayObj.MyTrayIcon.Icon = My.Resources.newred
                                           End If
                                       End Sub)

            End If


            If Not IsNothing(frmUserUIObj) Then
                frmUserUIObj.UpdateUI_FromAppClass()
            End If
        End Sub

        Private gbl_processObj As Process

        Friend Sub InstallAppWithRemoteUsernamePassword(ByVal remotedomain As String, ByVal remoteuser As String, ByVal remotepass As String)
            InstallProcessErr = False
            gbl_processObj = New Process
            Try

                If My.Computer.FileSystem.FileExists(Gbl_MainAppCopy_Path_User) Then
                    If Application.ExecutablePath.ToLower <> Gbl_MainAppCopy_Path_User.ToLower Then
                        Try
                            My.Computer.FileSystem.DeleteFile(Gbl_MainAppCopy_Path_User)
                            My.Computer.FileSystem.CopyFile(Application.ExecutablePath, Gbl_MainAppCopy_Path_User)
                        Catch ex As Exception
                        End Try
                    End If
                Else
                    My.Computer.FileSystem.CopyFile(Application.ExecutablePath, Gbl_MainAppCopy_Path_User)
                End If

                If My.Computer.FileSystem.FileExists(Gbl_InstallSerivce_Path_User) Then
                    Try
                        My.Computer.FileSystem.DeleteFile(Gbl_InstallSerivce_Path_User)
                        My.Computer.FileSystem.WriteAllBytes(Gbl_InstallSerivce_Path_User, My.Resources.AlSoozRemotePCService, False)

                    Catch ex As Exception
                    End Try

                Else
                    My.Computer.FileSystem.WriteAllBytes(Gbl_InstallSerivce_Path_User, My.Resources.AlSoozRemotePCService, False)

                End If

                If My.Computer.FileSystem.FileExists(Gbl_BrokerApp_Path_User) Then
                    Try
                        My.Computer.FileSystem.DeleteFile(Gbl_BrokerApp_Path_User)
                        My.Computer.FileSystem.WriteAllBytes(Gbl_BrokerApp_Path_User, My.Resources.AlSoozRemotePCBroker, False)
                    Catch ex As Exception
                    End Try

                Else
                    My.Computer.FileSystem.WriteAllBytes(Gbl_BrokerApp_Path_User, My.Resources.AlSoozRemotePCBroker, False)

                End If

                If My.Computer.FileSystem.FileExists(Gbl_BrokerApp_Path_User) Then

                    Dim psi As New ProcessStartInfo

                    Dim userPwd As System.Security.SecureString = New System.Security.SecureString()
                    For i As Integer = 0 To remotepass.Length - 1
                        userPwd.AppendChar(remotepass(i))
                    Next


                    With psi
                        '.LoadUserProfile = True
                        .UseShellExecute = False ' only true if no username and password, and false must incude workingdirectory
                        .Domain = remotedomain
                        .UserName = remoteuser
                        .Password = userPwd
                        .WorkingDirectory = Gbl_FolderPath_User '"C:\tmp\"
                        .FileName = Gbl_BrokerApp_Path_User '"C:\tmp\AlSoozRemotePCBroker.exe"
                        .RedirectStandardOutput = False ' must make UseShellExecute = false
                        .RedirectStandardError = False
                        .RedirectStandardInput = False

                    End With

                    ' gbl_processObj.EnableRaisingEvents = True ' very dangerous , will give access denied

                    ' AddHandler ps.OutputDataReceived, AddressOf ProcessOutputHandler

                    ' AddHandler gbl_processObj.Exited, New EventHandler(AddressOf ProcessExitedHandler)

                    Dim err As String = ""

                    Try

                        gbl_processObj.StartInfo = psi
                        gbl_processObj.Start()

                    Catch ex As Exception
                        err = ex.Message
                    End Try

                    userPwd.Dispose()

                    If err.Length > 1 Then
                        InstallProcessErr = True
                        MsgBox("Error occurred, service was not installed. " & err)
                        'If err.IndexOf("canceled") > -1 Then

                        'End If
                    Else
                        For i As Int16 = 0 To 120
                            If gbl_processObj.HasExited Then
                                Threading.Thread.Sleep(500)
                                ' MsgBox("Process Exited")
                                Exit For
                            Else
                                Threading.Thread.Sleep(500)
                            End If
                        Next

                        If My.Computer.FileSystem.FileExists(Gbl_Serivce_Path) Then
                            App_Close()
                        Else
                            MsgBox("Did not Install Service")
                        End If
                    End If

                Else
                    InstallProcessErr = True
                    MsgBox("File Not Found")

                End If

            Catch ex As Exception
                InstallProcessErr = True
                MsgBox("Error: " & ex.Message)
            End Try
        End Sub

        'Dim remoteinstallOutput As New StringBuilder
        'Private Sub ProcessOutputHandler(sendingProcess As Object, outLine As DataReceivedEventArgs)
        '    remoteinstallOutput.AppendLine(outLine.Data)
        'End Sub

        Private InstallProcessErr As Boolean = False

        Friend Sub installService()
            InstallProcessErr = False
            gbl_processObj = New Process
            Try

                If My.Computer.FileSystem.FileExists(Gbl_MainAppCopy_Path_User) Then
                    If Application.ExecutablePath.ToLower <> Gbl_MainAppCopy_Path_User.ToLower Then
                        Try
                            My.Computer.FileSystem.DeleteFile(Gbl_MainAppCopy_Path_User)
                            My.Computer.FileSystem.CopyFile(Application.ExecutablePath, Gbl_MainAppCopy_Path_User)
                        Catch ex As Exception
                        End Try
                    End If
                Else
                    My.Computer.FileSystem.CopyFile(Application.ExecutablePath, Gbl_MainAppCopy_Path_User)
                End If

                If My.Computer.FileSystem.FileExists(Gbl_InstallSerivce_Path_User) Then
                    My.Computer.FileSystem.DeleteFile(Gbl_InstallSerivce_Path_User)
                    My.Computer.FileSystem.WriteAllBytes(Gbl_InstallSerivce_Path_User, My.Resources.AlSoozRemotePCService, False)

                Else
                    My.Computer.FileSystem.WriteAllBytes(Gbl_InstallSerivce_Path_User, My.Resources.AlSoozRemotePCService, False)

                End If

                If My.Computer.FileSystem.FileExists(Gbl_InstallSerivce_Path_User) Then

                    Dim psi As New ProcessStartInfo

                    With psi

                        .UseShellExecute = True
                        ' .RedirectStandardOutput = True ' must make UseShellExecute = false
                        .FileName = Gbl_InstallSerivce_Path_User
                        .Arguments = "/i"
                        .WindowStyle = ProcessWindowStyle.Normal
                        .Verb = "runas" ' for admin
                    End With

                    gbl_processObj.StartInfo = psi

                    ' ps.EnableRaisingEvents = True

                    '   AddHandler ps.OutputDataReceived, AddressOf ProcessOutputHandler

                    ' AddHandler ps.Exited, New EventHandler(AddressOf ProcessExitedHandler)

                    Dim err As String = ""
                    Try
                        gbl_processObj.Start()
                    Catch ex As Exception
                        err = ex.Message
                    End Try

                    If err.Length > 1 Then
                        InstallProcessErr = True
                        MsgBox("Error occurred, service was not installed. " & err)

                        'If err.IndexOf("canceled") > -1 Then

                        'End If

                    Else

                        For i As Int16 = 0 To 120
                            If gbl_processObj.HasExited Then
                                ' MsgBox("Process Exited")
                                Threading.Thread.Sleep(500)
                                Exit For
                            Else

                                Threading.Thread.Sleep(500)
                            End If
                        Next

                        If My.Computer.FileSystem.FileExists(Gbl_Serivce_Path) Then
                            App_Close()
                        Else
                            MsgBox("Did not Install Service")
                        End If
                    End If

                Else
                    InstallProcessErr = True
                    MsgBox("File Not Found")

                End If

            Catch ex As Exception
                InstallProcessErr = True
                MsgBox("Error: " & ex.Message)

            End Try
        End Sub

        Friend Sub unInstallServiceWithApp(ByVal isSilent As Boolean)

            If isSilent Then

            Else

            End If
            Try
                If My.Computer.FileSystem.FileExists(Gbl_Uninstall_Path_User) Then
                    My.Computer.FileSystem.DeleteFile(Gbl_Uninstall_Path_User)
                End If

            Catch ex As Exception
            End Try

            Try
                My.Computer.FileSystem.WriteAllBytes(Gbl_Uninstall_Path_User, My.Resources.AlSoozRemotePCUninstall, False)
            Catch ex As Exception
            End Try

            If My.Computer.FileSystem.FileExists(Gbl_Uninstall_Path_User) Then
                If StartAppFromName(Gbl_Uninstall_Path_User) Then
                    App_Close()
                End If
            Else

            End If

        End Sub


        Friend Sub App_DownloadUpdatedClient(ByVal isTest As Boolean)

            Dim strb As New StringBuilder

            If MyConn.WS_URLProtocol.ToLower.IndexOf("wss") > -1 Then
                strb.Append("https://")
            Else
                strb.Append("http://")
            End If
            strb.Append(MyConn.WS_URLDomain)
            strb.Append("/remotecontrol")
            If isTest Then strb.Append("/test")
            strb.Append("/AlSoozRemotePC.exe")

            If isGodPower Then
                sendUDPToService("WS_ClientApp_Update|" & strb.ToString)
                App_Close()

            Else

                App__DeleteUpdateClientFile()
                Try
                    Using wc As New WebClient
                        wc.DownloadFile(strb.ToString, Gbl_UpdateAppCopy_Path_User)
                    End Using
                Catch ex As Exception
                    Dim m As String = ex.Message
                End Try
                runAppWithoutGodPower(Gbl_UpdateAppCopy_Path_User, True)
            End If

        End Sub

        Friend Sub App__DeleteUpdateClientFile()
            Try
                If My.Computer.FileSystem.FileExists(Gbl_UpdateAppCopy_Path_User) Then
                    My.Computer.FileSystem.DeleteFile(Gbl_UpdateAppCopy_Path_User)

                End If
            Catch ex As Exception

            End Try

        End Sub


        Friend Sub App_Close()
            Try
                frmStartObj.BeginInvoke(Sub()
                                            ' If isGodPower Then setDenyAdminShutdownAccess(False)
                                            frmStartObj.Close()
                                        End Sub)

            Catch ex As Exception
            End Try
        End Sub
    End Class

    Friend Sub runAppWithoutGodPower(ByVal exePath As String, ByVal withCloseThisInstance As Boolean)
        If My.Computer.FileSystem.FileExists(exePath) Then

            Dim psi As New ProcessStartInfo
            Dim ps As New Process

            With psi
                .UseShellExecute = True
                .FileName = exePath

                .WindowStyle = ProcessWindowStyle.Normal
                '.Verb = "runas" ' for admin
            End With

            ps.StartInfo = psi

            Dim err As String = ""
            Try
                ps.Start()
                If withCloseThisInstance Then
                    frmStartObj.BeginInvoke(Sub()
                                                frmStartObj.Close()
                                            End Sub)
                End If
            Catch ex As Exception
                ' .BeginInvoke(Sub()
                '                            MsgBox("3 : " & ex.Message)
                '                        End Sub)
            End Try

        End If
    End Sub
End Module
