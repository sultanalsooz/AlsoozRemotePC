﻿Imports System.Management
Imports System.Runtime.InteropServices
Imports System.Text

Module Mod_WinCommands



    <DllImport("user32.dll", SetLastError:=False)>
    Private Function GetKeyboardState(ByVal keyState() As Byte) As Boolean
    End Function

    <DllImport("user32.dll")>
    Private Function GetAsyncKeyState(ByVal vKey As System.Windows.Forms.Keys) As Short
    End Function
    <DllImport("user32.dll", SetLastError:=True, CharSet:=CharSet.Unicode)>
    Private Function GetKeyState(ByVal nVirtKey As Short) As Integer
    End Function

    Friend Function isKeyboardNumLockOn() As Integer()
        Dim returnValues As Integer() = {0, 0}
        Try
            ' Dim keyState As Byte() = New Byte(256) {}
            ' Dim result As Boolean = GetKeyboardState(keyState)

            returnValues(0) = IIf(GetKeyState(Keys.NumLock) And &H1 <> 0, 1, -1)
            returnValues(1) = IIf(GetKeyState(Keys.CapsLock) And &H1 <> 0, 1, -1)


            Return returnValues
        Catch ex As Exception
        End Try
        Return returnValues
    End Function

    <DllImport("user32.dll", EntryPoint:="SystemParametersInfo", CharSet:=CharSet.Auto)>
    Friend Function SetSystemParametersInfo(ByVal uAction As Integer, ByVal uParam As Integer, ByVal lpvParam As Integer, ByVal fuWinIni As Integer)
    End Function

    Friend Const SPI_SETDRAGFULLWINDOWS As Integer = 37

    Friend Enum CMD_ComputerShutdown_Options
        Logoff
        Reboot
        Shutdown
    End Enum
    Friend Sub CMD_ComputerShutdown(ByVal options As CMD_ComputerShutdown_Options)
        Dim outParameters As ManagementBaseObject = Nothing
        Dim sysOS As New ManagementClass("Win32_OperatingSystem")
        sysOS.[Get]()
        ' enables required security privilege.
        sysOS.Scope.Options.EnablePrivileges = True
        ' get our in parameters
        Dim inParameters As ManagementBaseObject = sysOS.GetMethodParameters("Win32Shutdown")
        ' 5= forceshutdown,12=forced power off
        If options = CMD_ComputerShutdown_Options.Reboot Then
            inParameters("Flags") = "6"
        ElseIf options = CMD_ComputerShutdown_Options.Logoff Then
            inParameters("Flags") = "4"
        ElseIf options = CMD_ComputerShutdown_Options.Shutdown Then
            inParameters("Flags") = "5"
        End If
        '4= force logoff 5 = Force Shutdown , 6 = Force Reboot
        inParameters("Reserved") = "0"
        For Each manObj As ManagementObject In sysOS.GetInstances()
            outParameters = manObj.InvokeMethod("Win32Shutdown", inParameters, Nothing)
        Next
    End Sub

    Private Function getWMIInfo(ByVal WINString As String, ByVal Parms As String()()) As String
        Try

            Dim q As New SelectQuery(WINString)
            Dim search As New ManagementObjectSearcher(q)
            Dim info As New ManagementObject
            Dim strb As New StringBuilder

            Dim len As Integer = Parms.Length - 1

            For Each info In search.Get
                For i As Integer = 0 To len
                    Try
                        ' strb.Append(Parms(i)(0).ToString)
                        ' strb.Append(":")

                        If Parms(i)(0).ToString = "OS" And Parms(i)(1).ToString = "Name" Then
                            Dim OSname As String = info(Parms(i)(1).ToString).ToString.Split("|")(0)
                            OSname = OSname.Replace("Microsoft", "")
                            OSname = OSname.Replace("Windows", "")
                            strb.Append(OSname.Trim)

                        ElseIf Parms(i)(0).ToString = "OSDate" Then
                            strb.Append(info(Parms(i)(1).ToString).ToString.Substring(0, 8))

                        ElseIf Parms(i)(0).ToString = "LastBootUpTime" Then
                            strb.Append(info(Parms(i)(1).ToString).ToString.Substring(0, 12))

                        ElseIf Parms(i)(0).ToString = "Size" Or Parms(i)(0).ToString = "FreeSpace" Then
                            strb.Append(Math.Round((info(Parms(i)(1)) / 1073741824), 1))

                        Else
                            strb.Append(info(Parms(i)(1).ToString).ToString)
                        End If

                        strb.Append(",")
                    Catch ex As Exception
                        strb.Append(",")
                    End Try

                Next
            Next
            strb.Append("")

            Return strb.ToString
        Catch ex As Exception

        End Try
        Return "Error_" & WINString & ","

    End Function

    Private Function getTotalRAM()
        Dim strb As New StringBuilder

        'strb.Append("RAMTotal:")
        strb.Append(Math.Round(My.Computer.Info.TotalPhysicalMemory / (1073741824), 1))
        strb.Append(",")
        'strb.Append("RAMFree:")
        strb.Append(Math.Round(My.Computer.Info.AvailablePhysicalMemory / (1073741824), 1))
        Return strb.ToString
    End Function
    Friend Function getComputerSerialNumber() As String
        Dim Parms1 As String() = {"Serial", "serialnumber"}
        Return getWMIInfo("Win32_bios", {Parms1})
    End Function

    Private Function getComputerPRocessor() As String
        Dim Parms1 As String() = {"CurrentCPU", "CurrentClockSpeed"}
        Dim Parms2 As String() = {"MaxCPU", "MaxClockSpeed"}
        Return getWMIInfo("Win32_Processor", {Parms1, Parms2})
    End Function

    Private Function getComputerBattery() As String
        Dim Parms1 As String() = {"BatteryStatus", "BatteryStatus"}
        Dim Parms2 As String() = {"BatteryLevel", "EstimatedChargeRemaining"}
        Return getWMIInfo("Win32_Battery", {Parms1, Parms2})
    End Function

    Private Function getComputerOS() As String
        Dim Parms1 As String() = {"OS", "Name"}
        Dim Parms2 As String() = {"ServicePack", "ServicePackMajorVersion"}
        Dim Parms3 As String() = {"LastBootUpTime", "LastBootUpTime"}

        Return getWMIInfo("Win32_OperatingSystem", {Parms1, Parms2, Parms3})
    End Function

    Private Function getComputerModel() As String
        Dim Parms1 As String() = {"Model", "Model"}
        Return getWMIInfo("Win32_ComputerSystem", {Parms1})
    End Function

    Private Function getComputerDrives() As String
        Dim Parms1 As String() = {"DeviceID", "DeviceID"}
        Dim Parms2 As String() = {"DriveType", "DriveType"}
        Dim Parms3 As String() = {"Size", "Size"}
        Dim Parms4 As String() = {"FreeSpace", "FreeSpace"}
        Return getWMIInfo("Win32_LogicalDisk", {Parms1, Parms2, Parms3, Parms4})
    End Function

End Module
