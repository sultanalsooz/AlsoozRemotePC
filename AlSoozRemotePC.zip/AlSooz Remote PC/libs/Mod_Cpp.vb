﻿'Imports System.Runtime.InteropServices
'Imports System.Text

Module Mod_Cpp

    '<DllImport("cPlusPlusDll2.dll", CallingConvention:=CallingConvention.Cdecl)>
    'Private Sub getCPPStr_DisplayMyName(ByVal strb As StringBuilder, ByVal strlen As Integer)
    'End Sub

    'Friend Sub TestCPP_Func1()
    '    Dim textvar As New StringBuilder(255)
    '    getCPPStr_DisplayMyName(textvar, textvar.Capacity)
    '    MsgBox("CPP Says: " & textvar.ToString)
    'End Sub
End Module
