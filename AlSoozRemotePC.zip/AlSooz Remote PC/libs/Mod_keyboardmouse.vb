﻿Imports System.Runtime.InteropServices
Imports System.Threading

Module Mod_keyboardmouse


    Friend Declare Sub SendSAS Lib "SAS.DLL" (ByVal fAsUser As Boolean)


    <DllImport("user32.dll", SetLastError:=True)>
    Private Function SendInput(ByVal nInputs As UInteger, <MarshalAs(UnmanagedType.LPArray)> ByVal pInputs() As INPUT, ByVal cbSize As Integer) As UInteger
    End Function

    <DllImport("user32.dll", SetLastError:=True)>
    Private Function MapVirtualKeyEx(uCode As UInteger, uMapType As UInteger, dwhkl As IntPtr) As UInteger
    End Function

    <DllImport("user32.dll", SetLastError:=True)>
    Private Function GetKeyboardLayout(idThread As UInteger) As IntPtr
    End Function


    <DllImport("user32.dll", CharSet:=CharSet.Unicode, CallingConvention:=CallingConvention.StdCall)>
    Private Sub mouse_event(ByVal dwFlags As Integer, ByVal dx As Integer, ByVal dy As Integer, ByVal cButtons As Integer, ByVal dwExtraInfo As IntPtr)
    End Sub

    Private Structure mouseEventsF
        Public Const MOVE As Integer = &H1        ' mouse move 
        Public Const LEFTDOWN As Integer = &H2        ' left button down 
        Public Const LEFTUP As Integer = &H4        ' left button up 
        Public Const RIGHTDOWN As Integer = &H8        ' right button down 
        Public Const RIGHTUP As Integer = 16        ' right button up 
        Public Const MIDDLEDOWN As Integer = &H20        ' middle button down 
        Public Const MIDDLEUP As Integer = &H40        ' middle button up 
        Public Const XDOWN As Integer = &H80        ' x button down 
        Public Const XUP As Integer = &H100        ' x button down 
        Public Const WHEEL As Integer = &H800        ' wheel button rolled 
        Public Const VIRTUALDESK As Integer = &H4000        ' map to entire virtual desktop 
        Public Const ABSOLUTE As Integer = &H8000        ' absolute move 
    End Structure

    '<DllImport("user32.dll", SetLastError:=True)>
    'Private Function SendInput(ByVal nInputs As UInteger, <MarshalAs(UnmanagedType.LPArray)> ByVal pInputs() As INPUT, ByVal cbSize As Integer) As UInteger
    'End Function 

    Private Sub Introp_MouseMove(x As UInteger, y As UInteger)

        mouse_event(mouseEventsF.ABSOLUTE Or mouseEventsF.MOVE, x, y, 0, IntPtr.Zero)

    End Sub

    Private Sub Introp_MouseScroll(scrollDirection As Integer)

        mouse_event(mouseEventsF.WHEEL, 0, 0, scrollDirection, IntPtr.Zero)

    End Sub

    Private Const MOVE As UInteger = &H1        ' mouse move 
    Private Const LEFTDOWN As UInteger = &H2
    Private Const LEFTUP As UInteger = &H4
    Private Const RIGHTDOWN As UInteger = &H8
    Private Const RIGHTUP As UInteger = &H10

    Private Const KEYDOWN As UInteger = 0
    Private Const KEYUP As UInteger = &H2
    Private Const EXTENDEDKEY As UInteger = &H1


    Private Sub Mouse_Move(x As UInteger, y As UInteger)
        'Last_MouseX = x
        'Last_MouseY = y

        Introp_MouseMove(x, y)
    End Sub


    Friend Sub Key_Send_Up(key As UInteger)

        SimulateKeyInput(key, False)


    End Sub


    Friend Sub Key_Send_Down(key As UInteger)

        SimulateKeyInput(key, True)
    End Sub


    Private mouselock As New Object

    Friend Sub WS_OnMessageMouseMove(ByRef msg As Byte())
        Try

            If Threading.Monitor.IsEntered(mouselock) Then Return
            If Threading.Monitor.TryEnter(mouselock, 50) Then


                If DesktopThread_SwitchSignal_Mouse Then
                    DesktopThread_SwitchSignal_Mouse = False
                    setThreadTo_InputDesktop()
                End If

                Dim mLocX As UInteger = BitConverter.ToUInt32(msg, 2)
                Dim mLocY As UInteger = BitConverter.ToUInt32(msg, 6)


                Mouse_Move(mLocX, mLocY)
            End If
        Catch ex As Exception
        End Try
        Try
            Threading.Monitor.Exit(mouselock)
        Catch ex As Exception
        End Try
    End Sub

    Private Enum INPUTTYPE As UInteger
        MOUSE = 0
        KEYBOARD = 1
        HARDWARE = 2
    End Enum

    <StructLayout(LayoutKind.Explicit)>
    Private Structure INPUTUNION
        <FieldOffset(0)> Public mi As MOUSEINPUT
        <FieldOffset(0)> Public ki As KEYBDINPUT
        <FieldOffset(0)> Public hi As HARDWAREINPUT
    End Structure

    <StructLayout(LayoutKind.Sequential)>
    Private Structure INPUT
        Public type As INPUTTYPE
        Public U As INPUTUNION
    End Structure

    <StructLayout(LayoutKind.Sequential)>
    Private Structure MOUSEINPUT
        Public dx As Integer
        Public dy As Integer
        Public mouseData As UInteger
        Public dwFlags As UInteger
        Public time As UInteger
        Public dwExtraInfo As IntPtr
    End Structure

    <StructLayout(LayoutKind.Sequential)>
    Private Structure KEYBDINPUT
        Public wVk As UShort
        Public wScan As UShort
        Public dwFlags As UInteger
        Public time As UInteger
        Public dwExtraInfo As UIntPtr
    End Structure

    <StructLayout(LayoutKind.Sequential)>
    Private Structure HARDWAREINPUT
        Public uMsg As UInteger
        Public wParamL As UShort
        Public wParamH As UShort
    End Structure

    <Flags()>
    Private Enum MOUSEEVENTF As UInteger

        ABSOLUTE = &H8000

        HWHEEL = &H1000

        MOVE = &H1

        MOVE_NOCOALESCE = &H2000

        LEFTDOWN = &H2

        LEFTUP = &H4

        RIGHTDOWN = &H8

        RIGHTUP = &H10

        MIDDLEDOWN = &H20

        MIDDLEUP = &H40

        VIRTUALDESK = &H4000

        WHEEL = &H800

        XDOWN = &H80

        XUP = &H100
    End Enum

    <Flags()>
    Private Enum KEYEVENTF As UInteger

        EXTENDEDKEY = &H1
        KEYUP = &H2
        SCANCODE = &H8
        UNICODE = &H4
    End Enum

    Private Enum MouseXButton As UInteger
        XBUTTON1 = &H1
        XBUTTON2 = &H2
    End Enum
    Private Function GetMouseClickInputStructure(ByVal Button As MouseButtons, ByVal MouseDown As Boolean) As INPUT
        Dim Position As Point = Cursor.Position
        Dim MouseFlags As MOUSEEVENTF
        Dim MouseData As UInteger = 0

        If Button = MouseButtons.Left Then
            If MouseDown Then
                MouseFlags = MOUSEEVENTF.LEFTDOWN
            Else
                MouseFlags = MOUSEEVENTF.LEFTUP
            End If
        ElseIf Button = MouseButtons.Right Then
            If MouseDown Then
                MouseFlags = MOUSEEVENTF.RIGHTDOWN
            Else
                MouseFlags = MOUSEEVENTF.RIGHTUP
            End If

        Else
            If MouseDown Then
                MouseFlags = MOUSEEVENTF.MIDDLEDOWN
            Else
                MouseFlags = MOUSEEVENTF.MIDDLEUP
            End If
        End If

        Dim MouseInput As New MOUSEINPUT With {
                .dx = Position.X,
                .dy = Position.Y,
                .mouseData = MouseData,
                .dwFlags = MouseFlags,
                .time = 0,
                .dwExtraInfo = IntPtr.Zero
            }

        Dim Union As New INPUTUNION With {.mi = MouseInput}
        Dim Input As New INPUT With {
                .type = INPUTTYPE.MOUSE,
                .U = Union
            }

        Return Input
    End Function

    Private Sub SetButtonState(ByVal Button As MouseButtons, ByVal MouseDown As Boolean)
        Dim InputList As INPUT() = New INPUT(0) {GetMouseClickInputStructure(Button, MouseDown)}
        SendInput(CType(InputList.Length, UInteger), InputList, Marshal.SizeOf(GetType(INPUT)))
    End Sub

    Friend Sub WS_OnMessageMouseClick(ByVal msg As Byte())
        Try
            'Threading.Monitor.Enter(mouselock)

            Dim msBtn As UShort = BitConverter.ToUInt16(msg, 2)

            Thread.Sleep(10)
            If msBtn = 1 Then ' left down
                SetButtonState(MouseButtons.Left, True)
            ElseIf msBtn = 2 Then ' left up
                SetButtonState(MouseButtons.Left, False)
            ElseIf msBtn = 3 Then ' right click

                SetButtonState(MouseButtons.Left, True)
                Thread.Sleep(30)
                SetButtonState(MouseButtons.Left, False)

            ElseIf msBtn = 4 Then 'right click
                SetButtonState(MouseButtons.Right, True)
                Thread.Sleep(30)
                SetButtonState(MouseButtons.Right, False)

            End If
            ' Thread.Sleep(10)
            ' Thread.Sleep(50)
        Catch ex As Exception
        End Try

        'Try
        '    Threading.Monitor.Exit(mouselock)
        'Catch ex As Exception

        'End Try
        ' Introp_MouseClick(LEFTDOWN)
    End Sub

    Friend Sub WS_OnMessageMouseScroll(ByVal msg As Byte())
        Try
            Dim scrollDirection As UShort = BitConverter.ToUInt16(msg, 2)
            Dim scrollSpeed As UShort = BitConverter.ToUInt16(msg, 4)
            Dim speed As Integer = 2 * scrollSpeed
            If scrollDirection = 1 Then
                Introp_MouseScroll(-speed)
            Else
                Introp_MouseScroll(speed)
            End If
        Catch ex As Exception
        End Try

    End Sub


    Private keyInputsSize As Integer = Marshal.SizeOf(GetType(INPUT))

    Private Sub SimulateKeyInput(ByVal key As UInteger, ByVal isKeyDown As Boolean)
        Dim Input As INPUT = New INPUT()
        Input.type = INPUTTYPE.KEYBOARD
        Input.U = New INPUTUNION()
        Input.U.ki = New KEYBDINPUT()
        Input.U.ki.wScan = MapVirtualKeyEx(key, 0, GetKeyboardLayout(0)) And UShort.MaxValue

        If isKeyDown = False Then
            Input.U.ki.dwFlags = KEYEVENTF.KEYUP Or KEYEVENTF.SCANCODE
        Else
            Input.U.ki.dwFlags = KEYEVENTF.SCANCODE
        End If

        Dim keyInputs As INPUT() = New INPUT() {Input}

        SendInput(1, keyInputs, keyInputsSize)

    End Sub



End Module
