﻿Imports System.IO
Imports System.Reflection
Imports System.Security.Policy
Imports System.ServiceProcess

Module Mod_Service

    Friend Enum Enum_UnAttendedType
        IP_Address
        Online_ID
    End Enum

    Friend Enum Enum_Servicestate
        NotInstalled
        Installed
        Running
        Uninstalled
        NoPermission
        ErrorInFunction
        Unknown
    End Enum

    Friend Class myServiceClass


        Friend Property UnattendedType As Enum_UnAttendedType
            Get
                Return UnattendedType_p
            End Get
            Set

                UnattendedType_p = Value

                If Not IsNothing(myApp) Then
                    myApp.saveSettings()
                End If

            End Set
        End Property

        Friend UnattendedConnectionType As String = "auto"
        Friend currentServiceState As Enum_Servicestate = Enum_Servicestate.NotInstalled
        Private UnattendedType_p As Enum_UnAttendedType = Enum_UnAttendedType.Online_ID

        Sub New()
            If isGodPower Then
                currentServiceState = Enum_Servicestate.Running
            Else
                If My.Computer.FileSystem.DirectoryExists(Gbl_FolderPath_God) Then

                    currentServiceState = getServiceState()

                Else
                    currentServiceState = Enum_Servicestate.NotInstalled
                End If
            End If

        End Sub

        Friend Function getUpdatedServiceState() As Enum_Servicestate
            currentServiceState = getServiceState()
            Return currentServiceState
        End Function
        Friend Function getServiceState() As Enum_Servicestate
            Try
                Dim services As ServiceController() = ServiceController.GetServices()
                Dim len As Integer = services.Count - 1
                For i As Integer = 0 To len
                    Dim serviceName As String = services(i).ServiceName
                    If serviceName.IndexOf("AlSoozRemotePCService") > -1 Then

                        If services(i).Status = ServiceControllerStatus.Running Then
                            Return Enum_Servicestate.Running
                        Else
                            Return Enum_Servicestate.Installed
                        End If

                    End If
                Next


                Return Enum_Servicestate.NotInstalled
            Catch ex As Exception
                Return Enum_Servicestate.NoPermission
            End Try
            Return Enum_Servicestate.Unknown


        End Function



        Friend Function Service_Stop() As Boolean
            Try
                Dim services As ServiceController() = ServiceController.GetServices()
                Dim len As Integer = services.Count - 1
                For i As Integer = 0 To len
                    Dim serviceName As String = services(i).ServiceName
                    If serviceName.IndexOf("AlSoozRemotePCService") > -1 Then
                        services(i).Stop()
                        Threading.Thread.Sleep(1500)
                        Return True
                    End If
                Next

            Catch ex As Exception
            End Try
            Return False
        End Function

        Friend Function Service_Start() As Boolean
            Try
                Dim services As ServiceController() = ServiceController.GetServices()
                Dim len As Integer = services.Count - 1
                For i As Integer = 0 To len
                    Dim serviceName As String = services(i).ServiceName
                    If serviceName.IndexOf("AlSoozRemotePCService") > -1 Then
                        services(i).Start()

                        Return True
                    End If
                Next

            Catch ex As Exception
            End Try
            Return False
        End Function
        Friend Function getServiceVersion_LocalFile() As String
            Dim serviceInfo As FileVersionInfo = FileVersionInfo.GetVersionInfo(Gbl_Serivce_Path)
            Return serviceInfo.FileVersion
        End Function

        Friend Function getServiceVersion_Embedded() As String

            ' Dim serviceExe As Assembly = Assembly.Load(My.Resources.AlSoozRemotePCService)
            'Dim att As AssemblyFileVersionAttribute = serviceExe.GetCustomAttribute(GetType(AssemblyFileVersionAttribute))
            ' Dim serviceVersion As String = att.Version
            'Return att.Version

            Dim ServiceVersion As String = ""
            Dim serviceExe As Assembly = Assembly.ReflectionOnlyLoad(My.Resources.AlSoozRemotePCService)
            Dim att As CustomAttributeData
            For Each att In serviceExe.GetCustomAttributesData()
                If att.AttributeType = GetType(AssemblyFileVersionAttribute) Then
                    ServiceVersion = att.ConstructorArguments(0).ToString.Replace("""", "")
                    Exit For
                End If
            Next

            ' Dim serviceVersion As String = att.Version
            Return ServiceVersion

        End Function
    End Class
End Module
