﻿Imports System.Runtime.InteropServices
Imports System.Text

Module Mod_Clipboard

    Friend Clipboard_IsListen_On As Boolean = False
    Friend Clipboard_IsListen_ResumeTime As Date = Now.AddSeconds(-1)

    Private Clipboard_Last_DataType As Clipboard_dataType = Clipboard_dataType.None
    Private Clipboard_Last_DataTime As Date = Now
    Private Clipboard_Last_DataTime_Used As Date = Clipboard_Last_DataTime

    Private Clipboard_Last_Text As String = ""
    Private Clipboard_Last_Files As New List(Of String)

    Private Clipboard_Thread As Threading.Thread
    Private Clipboard_Thread_Lock As New Object
    Private Clipboard_Thread_IsContinue As Boolean = False

    Friend Const WM_CLIPBOARDUPDATE As Integer = &H31D

    <DllImport("user32.dll", SetLastError:=True)>
    Private Function AddClipboardFormatListener(ByVal hwnd As IntPtr) As Integer
    End Function

    <DllImport("user32.dll", SetLastError:=True)>
    Private Function RemoveClipboardFormatListener(ByVal hwnd As IntPtr) As Integer
    End Function

    Private Sub ClipBoard_CopyTextBetweenPcs(ByVal txtData As String)
        If myApp.Controller_AllowClipboardSend = "yes" Then
            Dim strb As New StringBuilder
            strb.Append("cb_")
            strb.Append(txtData)
            myApp.MyConn.SendRequestAsText(strb.ToString)
        End If
    End Sub

    Friend Sub Clipboard_SetRemoteText(ByVal txtData As String)
        Try
            If Not IsNothing(frmTrayObj) Then
                frmTrayObj.BeginInvoke(Sub()
                                           Clipboard_IsListen_ResumeTime = Now.AddSeconds(2)
                                           Try
                                               Dim cb_txt As String = txtData.Substring(3)
                                               Clipboard.SetText(cb_txt)
                                               cb_txt = Nothing
                                           Catch ex As Exception
                                           End Try

                                       End Sub)
            End If
        Catch ex As Exception
        End Try
    End Sub

    Friend Sub Clipboard_Listen_Start(ByVal winHandle As IntPtr)
        Try
            Dim isOk As Integer = AddClipboardFormatListener(winHandle)
            Clipboard_IsListen_On = True
            Clipboard_Thread_IsContinue = True
            Clipboard_Thread = New Threading.Thread(Sub()
                                                        Clipboard_Loop()
                                                    End Sub)
            Clipboard_Thread.Start()
        Catch ex As Exception
        End Try

    End Sub

    Friend Sub Clipboard_Listen_End(ByVal winHandle As IntPtr)
        Try
            If Clipboard_IsListen_On OrElse Clipboard_Thread_IsContinue Then
                Clipboard_Thread_IsContinue = False
                RemoveClipboardFormatListener(winHandle)
                Clipboard_IsListen_On = False
                Clipboard_Event_NewContent()
            End If
        Catch ex As Exception
        End Try

    End Sub

    Private Sub Clipboard_Event_NewContent()
        Try
            Threading.Monitor.Enter(Clipboard_Thread_Lock)
            Threading.Monitor.PulseAll(Clipboard_Thread_Lock)
        Catch ex As Exception
        End Try
        Try
            Threading.Monitor.Exit(Clipboard_Thread_Lock)
        Catch ex As Exception
        End Try
    End Sub
    Private Sub Clipboard_Loop()
        Try
            Do While Clipboard_Thread_IsContinue
                Try
                    Threading.Monitor.Enter(Clipboard_Thread_Lock)
                    Threading.Monitor.Wait(Clipboard_Thread_Lock, 5000)
                    If myApp.MyConn.IsRemotePCConnected Then
                        If Clipboard_Last_DataTime <> Clipboard_Last_DataTime_Used Then
                            Clipboard_Last_DataTime = Clipboard_Last_DataTime_Used
                            If Clipboard_Last_DataType = Clipboard_dataType.Text Then
                                ClipBoard_CopyTextBetweenPcs(Clipboard_Last_Text)
                            End If

                        End If
                    End If
                Catch ex As Exception
                End Try
                Try
                    If Threading.Monitor.IsEntered(Clipboard_Thread_Lock) Then Threading.Monitor.Exit(Clipboard_Thread_Lock)
                Catch ex As Exception
                End Try
            Loop
        Catch ex As Exception
        End Try
        Clipboard_Thread_IsContinue = False
    End Sub

    Friend Sub Clipboard_SaveOSDataToAppData()
        If Clipboard.ContainsText() Then
            If myApp.MyConn.isServiceOpen_WS_Mouse Then
                Clipboard_Last_DataType = Clipboard_dataType.Text
                Clipboard_Last_Text = Clipboard.GetText
                Clipboard_Last_DataTime = Now
                Clipboard_Event_NewContent()
            End If
            ' ElseIf Clipboard.ContainsFileDropList Then
            ' Clipboard_Last_Files.Clear()
            '  Clipboard_Last_Files.AddRange(Clipboard.GetFileDropList())
        End If
    End Sub
    Private Enum Clipboard_dataType
        None
        Text
        Files
    End Enum




End Module
