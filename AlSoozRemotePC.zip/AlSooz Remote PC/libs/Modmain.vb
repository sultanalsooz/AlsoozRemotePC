﻿Imports System.Drawing.Drawing2D
Imports System.Text

Module Modmain

    Friend Gbl_FolderPath_God As String = "C:\Program Files\AlSooz Remote PC\"

    Friend Gbl_EXEPath As String = Gbl_FolderPath_God & "AlSoozRemotePC.exe"
    Friend Gbl_Serivce_Path As String = Gbl_FolderPath_God & "AlSoozRemotePCService.exe"
    Friend Gbl_DiskValuesPath As String = Gbl_FolderPath_God & "diskvalues.txt"


    'Friend Gbl_Config_Path As String = ' redirected to user path Gbl_FolderPath_God & "Config.txt"


    Friend Gbl_FolderPath_User As String = "C:\ProgramData\AlSoozRemotePC\" 'My.Computer.FileSystem.SpecialDirectories.MyDocuments & "\AlSooz Remote PC\"
    Friend Gbl_Config_Path_User As String = Gbl_FolderPath_User & "Config.txt"

    Friend Gbl_Uninstall_Path_User As String = Gbl_FolderPath_User & "AlSoozRemotePCUninstall.exe"


    Friend Gbl_Config_Path As String = Gbl_Config_Path_User

    Friend Gbl_InstallSerivce_Path_User As String = Gbl_FolderPath_User & "AlSoozRemotePCService.exe"

    Friend Gbl_BrokerApp_Path_User As String = Gbl_FolderPath_User & "AlSoozRemotePCBroker.exe"
    Friend Gbl_MainAppCopy_Path_User As String = Gbl_FolderPath_User & "AlSoozRemotePC.exe"
    Friend Gbl_UpdateAppCopy_Path_User As String = Gbl_FolderPath_User & "AlSoozRemotePC_update.exe"

    Friend LogFile_DirPath As String = Gbl_FolderPath_User & "logs"

    Friend isGodPower As Boolean = False
    Friend gbl_chunkSize As Integer = 62464 '= 61k,  63488 = 62k , 66560 = 65k ' 81920 ' 10240

    Friend WS_bufferSize_CMD As Integer = 2048

    Friend WS_bufferSize_MouseMove As Integer = 1024
    Friend WS_bufferSize_Image As Integer = 62465
    Friend WS_bufferSize_File As Integer = 62465

    Friend Gbl_DesktopName As String = ""


    Friend gbl_ImgBitWidthLen As Integer = 4 ' 2 ' 2= 16bits , 4 = 32bits
    Friend JPGBits As Imaging.PixelFormat = Imaging.PixelFormat.Format32bppArgb  ' Imaging.PixelFormat.Format16bppRgb555

    Friend gbl_TitleBoxSize As Integer = 64 '32

    Friend fileShare_FolderName As String = "aFileShare"

    Friend JPGCompressLevel As Integer = 0



    Friend tryLoadLockObj As New Object
    ' Friend PNGResizeQuality As InterpolationMode = InterpolationMode.High       ' InterpolationMode.HighQualityBicubic

    'New RangeClass(1280, 1280, "1280 X 1280"), ' Maximum 
    'New RangeClass(1408, 1408, "1408 X 1408"), '  New RangeClass(1440, 900, "1440 X 900"),
    'New RangeClass(1536, 1536, "1536 X 1536"),
    'New RangeClass(1664, 1664, "1664 x 1664")}


    'Friend Range_SocketRecSize As RangeClass() = {New RangeClass(1024, 0, "1 kb"),
    '                                        New RangeClass(2048, 0, "2 kb"),
    '                                                       3072

    '                                        New RangeClass(4096, 0, "4 kb"),
    '                                        New RangeClass(6144, 0, "6 kb"),
    '                                        New RangeClass(8192, 0, "8 kb"),
    '                                        New RangeClass(10240, 0, "10 kb"),
    '                                        New RangeClass(20480, 0, "20 kb"),
    '                                        New RangeClass(40960, 0, "40 kb"),
    '                                        New RangeClass(61440, 0, "60 kb"),
    '                                        New RangeClass(81920, 0, "80 kb"),
    '                                        New RangeClass(102400, 0, "100 kb"),
    '                                        New RangeClass(204800, 0, "200 kb")}

    'Friend Range_ImgBitSize As RangeClass() = {
    '                                        New RangeClass(Imaging.PixelFormat.Format16bppRgb555, 0, "16 555"),
    '                                        New RangeClass(Imaging.PixelFormat.Format24bppRgb, 0, "24 bit"),
    '                                        New RangeClass(Imaging.PixelFormat.Format32bppArgb, 0, "32 bit")}


    Friend Sub loadRang(ByRef listb As ListBox, ByRef listRange As RangeClass(), ByVal selectedValue As Object)
        listb.Items.Clear()
        Dim len As Integer = listRange.Count - 1
        For i As Integer = 0 To len
            listb.Items.Add(listRange(i).strValue)

            If TypeOf selectedValue Is Size Then

                Dim s As Size = selectedValue
                If listRange(i).intValue1 = s.Width AndAlso listRange(i).intValue2 = s.Height Then
                    listb.SelectedIndex = i
                End If

            Else
                If listRange(i).intValue1 = selectedValue Then
                    listb.SelectedIndex = i
                End If

            End If
        Next

    End Sub

    Friend frmAccountDetailsObj As frmAccountDetails = Nothing
    Friend frmFilesObj As frmfiles = Nothing
    Friend frmUserUIObj As frmUserUI = Nothing
    Friend frmStartObj As frmStart = Nothing
    Friend frmTrayObj As frmTray = Nothing
    Friend frmScreenControlObj As frmScreenControl = Nothing
    Friend frmMessageObj As frmMsgbox = Nothing
    Friend frmPasswordObj As frmPassword = Nothing

    ' Friend frmdebugObj As frmdebug = Nothing
    'Friend frmSenderObj As frmsender = Nothing

    Friend Class RangeClass
        Friend intValue1 As Integer
        Friend intValue2 As Integer
        Friend strValue As String
        Sub New(ByRef intRange1 As Integer, ByRef intRange2 As Integer, ByRef strRange As String)
            intValue1 = intRange1
            intValue2 = intRange2
            strValue = strRange
        End Sub
    End Class


    Friend Function getMyIP() As String
        Dim IPs As Net.IPAddress() = Net.Dns.GetHostAddresses(Net.Dns.GetHostName)
        For i As Integer = 0 To IPs.Count - 1
            If IPs(i).AddressFamily = Net.Sockets.AddressFamily.InterNetwork Then
                Return IPs(i).ToString
                Exit For
            End If
        Next
        Return "NotFound"
    End Function




    'Friend Sub TrayFormCheck_write(ByVal iSStarted As Boolean)
    '    Try
    '        Dim started As String = "yes"
    '        If iSStarted = False Then started = "no"
    '        My.Computer.FileSystem.WriteAllText(Gbl_TrayCheckPath, started, False)
    '    Catch ex As Exception
    '        writeLogLine("writeTrayFormCheck: " & ex.Message)
    '    End Try

    'End Sub

    'Friend Function TrayFormCheck_read() As String
    '    Dim str As String = ""
    '    Try
    '        str = My.Computer.FileSystem.ReadAllText(Gbl_TrayCheckPath)
    '    Catch ex As Exception
    '        str = "err"
    '        writeLogLine("ReadTrayFormCheck: " & ex.Message)
    '    End Try

    '    Return str
    'End Function

    Friend gbl_Tree As New UserSettings_ClientsTreeClass()

    Friend Class UserSettings_ClientsTreeClass

        Friend myPCs As List(Of UserSettings_ClientsPCClass)

        Friend myFolders As List(Of UserSettings_ClientsFolderClass)

        Private myFoldersLevel_Limit As Integer = 3

        Private treeObj As TreeView = Nothing

        Private AutoDiscoveryLockObj As New Object
        Private onetimecheck As Boolean = False

        Friend Sub AutoDiscovery_AddPC(remotePCInstallID As String, remotePCName As String, ByVal remoteUserName As String)
            Try
                If Threading.Monitor.TryEnter(AutoDiscoveryLockObj, 10000) Then

                    If onetimecheck = False Then
                        onetimecheck = True
                        If isDuplicateFolderName("Auto Discovery", 0) Then
                            For i As Int16 = 0 To 10
                                Dim folderIndx As Integer = getFolderIndexFromFolderName("Auto Discovery")
                                If folderIndx > -1 Then
                                    Dim folderid1 As ULong = myFolders(folderIndx).FolderID
                                    Del_Folder(folderid1, True)
                                Else
                                    Exit For
                                End If
                            Next

                        End If
                    End If

                    Dim pLen As Integer = myPCs.Count - 1
                    Dim isfound As Boolean = False
                    For i As Integer = 0 To pLen
                        If myPCs(i).InstallID = remotePCInstallID Then
                            isfound = True
                            Exit For
                        End If
                    Next

                    If isfound = False Then
                        Dim folderIndx As Integer = getFolderIndexFromFolderName("Auto Discovery")
                        If folderIndx = -1 Then

                            Dim FolderID As ULong = Add_Folder(0, "Auto Discovery", 0, False)
                            Add_Folder(0, "Personal", 0, False)
                            Add_Folder(0, "Work", 0, False)

                            folderIndx = getFolderIndexFromFolderID(FolderID)
                        End If

                        If folderIndx > -1 Then
                            Dim folderid1 As ULong = myFolders(folderIndx).FolderID
                            Add_PC(remotePCName, "pass", "id", remotePCInstallID, folderid1, remotePCName, remoteUserName)

                            If myApp.Controller_AllowAutoDiscoveryNotification = "yes" Then
                                showMessageNewAutoDiscoveryPCAdded(remotePCName & vbCrLf & vbCrLf & "  was discovered with user Id: " & remoteUserName)
                            End If

                        End If

                    End If
                End If

            Catch ex As Exception
            End Try

            Try
                Threading.Monitor.Exit(AutoDiscoveryLockObj)
            Catch ex As Exception

            End Try
        End Sub

        Friend Sub showMessageNewAutoDiscoveryPCAdded(message As String)
            Try
                If myApp.isScreenLocked = False AndAlso Not IsNothing(frmTrayObj) Then


                    frmTrayObj.BeginInvoke(Sub()
                                               If Not IsNothing(frmMessageObj) Then
                                                   Try
                                                       frmMessageObj.Close()
                                                   Catch ex As Exception
                                                   End Try
                                               End If
                                               Try
                                                   frmMessageObj = New frmMsgbox
                                                   frmMessageObj.isSimpleMessage = True
                                                   frmMessageObj.simpleMessage = message
                                                   frmMessageObj.countDown_Current = 10
                                                   frmMessageObj.Show()
                                               Catch ex As Exception
                                               End Try


                                           End Sub)
                End If
            Catch ex As Exception
            End Try
        End Sub
        Friend Function getSerializedObj_folders() As StringBuilder
            Dim strb As New StringBuilder
            Dim fLen As Integer = myFolders.Count - 1

            For i As Integer = 0 To fLen
                strb.Append(myFolders(i).getSerializedObj())
                strb.Append("|")
            Next

            Return strb

        End Function

        Friend Function getSerializedObj_PCs() As StringBuilder
            Dim strb As New StringBuilder

            Dim pLen As Integer = myPCs.Count - 1

            For i As Integer = 0 To pLen
                Try
                    strb.Append(myPCs(i).getSerializedObj())
                    strb.Append("|")
                Catch ex As Exception

                End Try

            Next

            Return strb
        End Function

        Friend Function getTreeStats() As Integer()
            Dim stats As Integer() = {myFolders.Count, myPCs.Count}

            Return stats
        End Function
        Friend Sub setSerializedObjs_Folders(ByRef strb_Folders As String)

            Dim strs_Folder As String() = strb_Folders.Split(New String() {"|"}, StringSplitOptions.RemoveEmptyEntries)

            Dim flen As Integer = strs_Folder.Count - 1
            For i As Integer = 0 To flen
                myFolders.Add(New UserSettings_ClientsFolderClass(strs_Folder(i).Trim))
            Next

            Dim isResort As Boolean = False
tryAgain:
            isResort = False
            For i As Integer = 1 To flen
                If myFolders(i - 1).ParentSortIndex > myFolders(i).ParentSortIndex Then
                    Dim tmp As UserSettings_ClientsFolderClass = myFolders(i)
                    myFolders(i) = myFolders(i - 1)
                    myFolders(i - 1) = tmp
                    isResort = True
                End If
            Next
            If isResort Then GoTo tryAgain
        End Sub

        Friend Sub setSerializedObjs_PCs(ByRef strb_PCs As String)

            Dim strs_Pcs As String() = strb_PCs.Split(New String() {"|"}, StringSplitOptions.RemoveEmptyEntries)
            Dim plen As Integer = strs_Pcs.Count - 1

            For i As Integer = 0 To plen
                myPCs.Add(New UserSettings_ClientsPCClass(strs_Pcs(i).Trim))
            Next

            Dim isResort As Boolean = False
tryAgain:
            isResort = False
            For i As Integer = 1 To plen
                If myPCs(i - 1).ParentSortIndex > myPCs(i).ParentSortIndex Then
                    Dim tmp As UserSettings_ClientsPCClass = myPCs(i)
                    myPCs(i) = myPCs(i - 1)
                    myPCs(i - 1) = tmp
                    isResort = True
                End If
            Next
            If isResort Then GoTo tryAgain

            Dim here As String = ""
        End Sub



        Friend Sub setTreeObj(ByRef tree As TreeView)
            treeObj = tree
            drawTree()
        End Sub


        Friend Sub unsetTreeObj()
            treeObj = Nothing
        End Sub

        Sub New()
            myPCs = New List(Of UserSettings_ClientsPCClass)
            myFolders = New List(Of UserSettings_ClientsFolderClass)
        End Sub

        'Sub New(ByRef strb_Folders As String, ByRef strb_PCs As String)
        '    setSerializedObjs(strb_Folders, strb_PCs)
        'End Sub

        Private Sub drawTree()

            If Not IsNothing(treeObj) Then
                treeObj.Nodes.Clear()

                Dim folderlen As Integer = myFolders.Count - 1
                Dim pcslen As Integer = myPCs.Count - 1

                For i As Integer = 0 To folderlen
                    If myFolders(i).FolderLevel = 0 Then
                        Dim rootNode As TreeNode = addFolderNode(myFolders(i), treeObj.Nodes)
                        drawFolderSubObjs(folderlen, pcslen, myFolders(i), rootNode)
                    End If
                Next
                treeObj.ExpandAll()
            End If


        End Sub

        Private Sub drawFolderSubObjs(ByRef folderlen As Integer, ByRef pcslen As Integer, ByRef folderObj As UserSettings_ClientsFolderClass, ByRef parentNode As TreeNode)

            drawSubFolders(folderlen, pcslen, folderObj, parentNode)
            drawSubPcs(pcslen, folderObj, parentNode)
            ReProvideSubObjsSortIndex(parentNode.Nodes)
        End Sub

        Friend Sub drawSubFolders(ByRef folderlen As Integer, ByRef pcslen As Integer, ByRef folderObj As UserSettings_ClientsFolderClass, ByRef parentNode As TreeNode)
            For i As Integer = 0 To folderlen
                If myFolders(i).FolderParentID = folderObj.FolderID Then
                    Dim childNode As TreeNode = addFolderNode(myFolders(i), parentNode.Nodes)
                    drawFolderSubObjs(folderlen, pcslen, myFolders(i), childNode)
                End If
            Next
        End Sub

        Friend Sub drawSubPcs(ByRef pcslen As Integer, ByRef folderObj As UserSettings_ClientsFolderClass, ByRef parentNode As TreeNode)

            For i As Integer = 0 To pcslen
                If myPCs(i).FolderParentID = folderObj.FolderID Then
                    addPCNode(myPCs(i), parentNode.Nodes)
                End If
            Next
        End Sub

        Private Function addFolderNode(ByRef folderobj As UserSettings_ClientsFolderClass, ByRef parentFolderCollect As TreeNodeCollection) As TreeNode
            Dim newNode As TreeNode = parentFolderCollect.Add(folderobj.FolderName)
            newNode.Tag = folderobj.FolderID
            newNode.ImageIndex = 0
            newNode.SelectedImageIndex = 0
            folderobj.TNode = newNode

            Return newNode
        End Function

        Private Function addPCNode(ByRef PcObj As UserSettings_ClientsPCClass, ByRef parentFolderCollect As TreeNodeCollection) As TreeNode
            Dim newNode As TreeNode = parentFolderCollect.Add(PcObj.Name)
            newNode.Tag = PcObj.PcID
            newNode.ImageIndex = 1
            newNode.SelectedImageIndex = 1
            PcObj.TNode = newNode
            Return newNode
        End Function

        Friend Sub ReProvideSubObjsSortIndex(ByRef AllNode As TreeNodeCollection)

            Dim pcIndex As Integer = 0
            Dim folderIndex As Integer = 0
            Dim len As Integer = AllNode.Count - 1
            For i As Integer = 0 To len
                Dim currentNode As TreeNode = AllNode(i)
                Dim nodetype As String = gbl_Tree.getNodeTypeFromNodeTag(currentNode.Tag)
                If nodetype = "pc" Then
                    Dim pcObj As UserSettings_ClientsPCClass = gbl_Tree.myPCs(gbl_Tree.getPCIndexFromPcID(currentNode.Tag))
                    pcObj.ParentSortIndex = pcIndex
                    pcIndex += 1
                Else
                    Dim folderObj As UserSettings_ClientsFolderClass = gbl_Tree.myFolders(gbl_Tree.getFolderIndexFromFolderID(currentNode.Tag))
                    folderObj.ParentSortIndex = folderIndex
                    folderIndex += 1
                End If
            Next
        End Sub

        Friend Function getTNodeFromObjID(ByVal FolderId As UInt64, ByRef tNodeCollection As TreeNodeCollection) As TreeNode
            Dim len As Integer = tNodeCollection.Count - 1
            For i As Integer = 0 To len
                If tNodeCollection(i).Tag = FolderId Then
                    Return tNodeCollection(i)
                Else
                    Dim tnode As TreeNode = getTNodeFromObjID(FolderId, tNodeCollection(i).Nodes)
                    If Not IsNothing(tnode) Then Return tnode
                End If
            Next
            Return Nothing
        End Function

        Friend Function getNodeTypeFromNodeTag(ByVal ObjID As UInt64) As String
            Dim flen As Integer = myFolders.Count - 1
            For i As Integer = 0 To flen
                If myFolders(i).FolderID = ObjID Then Return "folder"
            Next

            Dim plen As Integer = myPCs.Count - 1
            For i As Integer = 0 To plen
                If myPCs(i).PcID = ObjID Then Return "pc"
            Next

            Return "notfound"
        End Function
        Friend Function getFolderIndexFromFolderID(ByVal FolderId As UInt64) As Integer
            Dim len As Integer = myFolders.Count - 1
            For i As Integer = 0 To len
                If myFolders(i).FolderID = FolderId Then Return i
            Next
            Return -1
        End Function

        Private Function isDuplicateFolderName(ByVal Foldername As String, ByVal folderLevel As Integer) As Boolean
            Try
                Dim len As Integer = myFolders.Count - 1
                Dim scount As Integer = 0
                For i As Integer = 0 To len
                    If myFolders(i).FolderName = Foldername AndAlso myFolders(i).FolderLevel = folderLevel Then
                        scount += 1
                    End If
                Next
                If scount > 1 Then
                    Return True
                Else
                    Return False
                End If
            Catch ex As Exception
                Return False
            End Try

        End Function

        Friend Function getFolderIndexFromFolderName(ByVal FolderName As String) As Integer
            Dim len As Integer = myFolders.Count - 1
            For i As Integer = 0 To len
                If myFolders(i).FolderName = FolderName Then Return i
            Next
            Return -1
        End Function

        Friend Function getPCIndexFromPcID(ByVal PcID As UInt64) As Integer
            Dim len As Integer = myPCs.Count - 1
            For i As Integer = 0 To len
                If myPCs(i).PcID = PcID Then Return i
            Next
            Return -1
        End Function

        Friend Function getPCIndexFromPcInstallationID(ByVal PcInstallationID As String) As Integer
            Dim len As Integer = myPCs.Count - 1
            For i As Integer = 0 To len
                If myPCs(i).InstallID = PcInstallationID Then Return i
            Next
            Return -1
        End Function

        Friend Function Add_PC(ByVal PCName As String, ByVal PCPassword As String, ByVal PcConnectionType As String, ByVal PcIP As String, ByVal ParentFolderID As UInt64, ByVal NetBIOSName_new As String, ByVal UserName As String) As UInt64

            Dim newPC As New UserSettings_ClientsPCClass(PCName, PCPassword, PcConnectionType, PcIP, ParentFolderID, NetBIOSName_new, UserName)
            myPCs.Add(newPC)
            Try
                If Not IsNothing(treeObj) Then
                    Dim pnode As TreeNode = getTNodeFromObjID(ParentFolderID, treeObj.Nodes)
                    If Not IsNothing(pnode) Then
                        treeObj.BeginInvoke(Sub()
                                                Try
                                                    addPCNode(newPC, pnode.Nodes)
                                                    ReProvideSubObjsSortIndex(pnode.Nodes)
                                                Catch ex As Exception
                                                End Try
                                            End Sub)
                    End If
                End If

            Catch ex As Exception
            End Try

            myApp.saveSettings()

            Return newPC.PcID
        End Function

        Friend Sub Del_PC_usingInstallID(ByVal PcInstallID As String)

            Dim pcIndex As Integer = gbl_Tree.getPCIndexFromPcInstallationID(PcInstallID)
            If pcIndex > -1 Then
                Dim pcObj As UserSettings_ClientsPCClass = myPCs(pcIndex)
                myPCs.RemoveAt(pcIndex)
                Try
                    If Not IsNothing(treeObj) AndAlso Not IsNothing(frmUserUIObj) Then
                        If Not IsNothing(pcObj) Then
                            If Not IsNothing(pcObj.TNode) Then
                                frmUserUIObj.BeginInvoke(Sub()
                                                             pcObj.TNode.Remove()
                                                             frmUserUIObj.updatefullTreeStats()
                                                         End Sub)
                            End If
                        End If
                    End If
                Catch ex As Exception
                End Try
                myApp.saveSettings()
            End If

        End Sub

        Friend Sub Del_PC(ByVal PcID As UInt64)

            If Not IsNothing(treeObj) Then
                Dim tnode As TreeNode = getTNodeFromObjID(PcID, treeObj.Nodes)

                If Not IsNothing(tnode) Then
                    tnode.Remove()
                End If
            End If

            Dim PCindx As Integer = getPCIndexFromPcID(PcID)
            If PCindx > -1 Then
                myPCs.RemoveAt(PCindx)
            End If

            myApp.saveSettings()
        End Sub

        Friend Sub Move_PC()

            myApp.saveSettings()
        End Sub

        Friend Function Add_Folder(ByVal FolderLevel As Integer, ByVal FolderName As String, ByVal ParentFolderID As UInt64, ByVal withSave As Boolean) As UInt64

            Dim newPCFolder As New UserSettings_ClientsFolderClass(FolderLevel, FolderName, ParentFolderID)
            myFolders.Add(newPCFolder)

            If Not IsNothing(treeObj) Then
                If ParentFolderID > 0 Then

                    Dim pnode As TreeNode = getTNodeFromObjID(ParentFolderID, treeObj.Nodes)
                    If Not IsNothing(pnode) Then
                        treeObj.BeginInvoke(Sub()
                                                addFolderNode(newPCFolder, pnode.Nodes)
                                                ReProvideSubObjsSortIndex(pnode.Nodes)
                                                If withSave Then myApp.saveSettings()
                                            End Sub)
                    End If

                Else
                    'treeObj.BeginInvoke(Sub()
                    addFolderNode(newPCFolder, treeObj.Nodes)
                    If newPCFolder.FolderLevel = 0 AndAlso newPCFolder.FolderName = "Work" Then
                        Add_PC("Sample PC", "", "id", "", newPCFolder.FolderID, "", "SampleUserName")
                    End If
                    ReProvideSubObjsSortIndex(treeObj.Nodes)
                    '      End Sub)
                    If withSave Then myApp.saveSettings()
                End If

            Else
                If withSave Then myApp.saveSettings()
            End If




            Return newPCFolder.FolderID

        End Function

        Friend Sub Del_Folder(ByVal FolderID As UInt64, ByVal isSkipSave As Boolean)

            If Not IsNothing(treeObj) Then
                Dim tnode As TreeNode = getTNodeFromObjID(FolderID, treeObj.Nodes)

                If Not IsNothing(tnode) Then
                    tnode.Remove()
                End If
            End If

            Dim pLen As Integer = myPCs.Count - 1

            For i As Integer = pLen To 0 Step -1
                If myPCs(i).FolderParentID = FolderID Then
                    myPCs.RemoveAt(i)
                End If
            Next

RestartDeleteFolderLoop:
            Dim len As Integer = myFolders.Count - 1
            For i As Integer = 0 To len
                If myFolders(i).FolderParentID = FolderID Then
                    Del_Folder(myFolders(i).FolderID, True)
                    GoTo RestartDeleteFolderLoop
                End If
            Next

            Dim folderindx As Integer = getFolderIndexFromFolderID(FolderID)

            If folderindx > -1 Then
                myFolders.RemoveAt(folderindx)
            End If

            If isSkipSave = False Then myApp.saveSettings()
        End Sub

        Friend Sub Move_Folder(ByVal FolderID As UInt64, ByVal FolderID_NewParent As UInt64)

            myApp.saveSettings()
        End Sub


        Friend Sub RequestPCsOnlineStatus()
            Dim strb As New StringBuilder
            Dim len As Integer = myPCs.Count - 1
            For i As Integer = 0 To len
                If myPCs(i).ConType = "id" AndAlso myPCs(i).InstallID.Length > 5 Then
                    strb.Append(myPCs(i).InstallID).Append(";")
                End If
            Next
            myApp.MyConn.SendRequestAsText("SvrCMD:onlinestatus|" & strb.ToString)
        End Sub

        Friend Sub UpdatePcsOnlineStatus(ByRef PCsstatusList As String)

            Dim PcsList As String() = PCsstatusList.Split(New String() {";"}, StringSplitOptions.RemoveEmptyEntries)
            If Not IsNothing(frmUserUIObj) Then
                frmUserUIObj.BeginInvoke(Sub()
                                             Try
                                                 PcsOnlineStatusLoop(PcsList, True)
                                                 ' frmUserUIObj.btn_RefreshOnlineStatus.Enabled = True
                                             Catch ex As Exception
                                             End Try
                                         End Sub)
            Else
                Task.Run(Sub()
                             PcsOnlineStatusLoop(PcsList, False)
                         End Sub)
            End If

        End Sub
        Private Sub PcsOnlineStatusLoop(ByRef PcsList As String(), withUI As Boolean)
            Dim len As Integer = PcsList.Count - 1
            For i As Integer = 0 To len
                Dim pcLine As String() = PcsList(i).Split("|")
                Dim pcObj As UserSettings_ClientsPCClass = myPCs(getPCIndexFromPcInstallationID(pcLine(0).Trim))

                If pcLine(1).Trim = "co" Then
                    pcObj.onlineStatus = enum_PCOnlineStatus.Connected
                    If pcObj.UserName = "" Then

                    End If
                ElseIf pcLine(1).Trim = "on" Then
                    pcObj.onlineStatus = enum_PCOnlineStatus.Online
                Else
                    pcObj.onlineStatus = enum_PCOnlineStatus.Offline
                End If

                Try
                    If withUI Then
                        pcObj.TNode.ImageIndex = pcObj.onlineStatus
                        pcObj.TNode.SelectedImageIndex = pcObj.onlineStatus
                    End If
                Catch ex As Exception
                End Try

            Next
        End Sub

    End Class

    Friend Class UserSettings_ClientsFolderClass

        Friend FolderParentID As UInt64 = 0
        Friend FolderName As String = ""
        Friend FolderID As UInt64 = 0
        Friend FolderLevel As Integer = 0
        Friend ParentSortIndex As Integer = 0
        Friend TNode As TreeNode = Nothing
        Friend Function getSerializedObj() As StringBuilder
            Dim strb As New StringBuilder

            strb.Append(FolderID).Append(";") ' 0
            strb.Append(FolderParentID).Append(";") ' 1
            strb.Append(FolderName).Append(";") ' 2
            strb.Append(FolderLevel).Append(";") ' 3
            strb.Append(ParentSortIndex).Append(";") ' 4
            Return strb

        End Function

        Friend Sub setSerializedObj(ByRef strb As String)

            Dim strs As String() = strb.Split(New String() {";"}, StringSplitOptions.None)
            FolderID = CLng(strs(0).Trim)
            FolderParentID = CLng(strs(1).Trim)
            FolderName = strs(2).Trim
            FolderLevel = CInt(strs(3).Trim)
            Try
                ParentSortIndex = CInt(strs(4).Trim)
            Catch ex As Exception
            End Try
        End Sub


        Sub New(ByVal FolderLevel_new As Integer, ByVal FolderName_new As String, ByVal FolderParentID_new As UInt64)
            FolderLevel = FolderLevel_new
            FolderName = FolderName_new.Replace(";", "").Replace("|", "")
            FolderParentID = FolderParentID_new
            FolderID = myApp.get_NextUniqueID
            myApp.saveSettings()
        End Sub

        Sub New(ByRef strb As String)
            setSerializedObj(strb)
        End Sub

        Friend Function getStats() As Integer()
            Dim stats As Integer() = {0, 0}
            Dim flen As Integer = gbl_Tree.myFolders.Count - 1
            For i As Integer = 0 To flen
                If gbl_Tree.myFolders(i).FolderParentID = FolderID Then
                    stats(0) += 1
                End If
            Next
            Dim plen As Integer = gbl_Tree.myPCs.Count - 1
            For i As Integer = 0 To plen
                If gbl_Tree.myPCs(i).FolderParentID = FolderID Then
                    stats(1) += 1
                End If
            Next

            Return stats
        End Function
    End Class

    Friend Enum enum_PCOnlineStatus
        NA
        Offline
        Online
        Connected
    End Enum
    Friend Class UserSettings_ClientsPCClass

        Friend FolderParentID As UInt64 = 0
        Friend Name As String = ""
        Friend InstallID As String = ""
        Friend Password As String = ""
        Friend PcID As UInt64 = 0
        Friend ConType As String = "id"  ' "id"
        Friend NetBIOSName As String = ""
        Friend ParentSortIndex As Integer = 0

        Friend UserName As String = ""
        Friend DateAdded As String = ""

        Friend onlineStatus As enum_PCOnlineStatus = enum_PCOnlineStatus.Offline

        Friend TNode As TreeNode = Nothing

        Friend Sub updateNetBIOSName(PC_NetBIOSName As String)
            NetBIOSName = PC_NetBIOSName
            myApp.saveSettings()
        End Sub

        Friend Sub updateUserName(PC_UserName As String)
            UserName = PC_UserName
            myApp.saveSettings()
        End Sub

        Friend Function getSerializedObj() As StringBuilder
            Dim strb As New StringBuilder

            strb.Append(ConType).Append(";") ' 0
            strb.Append(PcID).Append(";") '1
            strb.Append(FolderParentID).Append(";") '2
            strb.Append(Name).Append(";") '3
            strb.Append(Password).Append(";") '4
            strb.Append(InstallID).Append(";") '5
            strb.Append(NetBIOSName).Append(";") '6
            strb.Append(ParentSortIndex).Append(";") '7
            strb.Append(UserName).Append(";") '8
            strb.Append(DateAdded).Append(";") '9
            Return strb

        End Function

        Friend Sub setSerializedObj(ByRef strb As String)

            Dim strs As String() = strb.Split(New String() {";"}, StringSplitOptions.None)
            ConType = strs(0).Trim
            PcID = CLng(strs(1).Trim)
            FolderParentID = CLng(strs(2).Trim)
            Name = strs(3).Trim
            '
            Password = strs(4).Trim

            Try
                If Password.IndexOf("==") > -1 Then
                    Password = decodeTextFromBase64(Password)
                End If
            Catch ex As Exception
            End Try

            InstallID = strs(5).Trim()
            Try
                NetBIOSName = strs(6).Trim()
            Catch ex As Exception
            End Try

            Try
                ParentSortIndex = strs(7).Trim()
            Catch ex As Exception
            End Try

            Try
                UserName = strs(8).Trim()
            Catch ex As Exception

            End Try

            Try
                DateAdded = strs(9).Trim()
            Catch ex As Exception
                DateAdded = Format(Now, "yyyy-MM-dd HH:mm")
            End Try

        End Sub

        Sub New(ByVal PCName_new As String, ByVal PCPassword As String, ByVal Connectiontype As String, ByVal IPAddress_new As String, ByVal FolderParentID_new As UInt64, ByVal NetBIOSName_new As String,
                 ByVal UserName_new As String)
            PcID = myApp.get_NextUniqueID()
            ConType = Connectiontype
            Name = PCName_new.Replace(";", "").Replace("|", "")
            Password = PCPassword.Replace(";", "").Replace("|", "")
            InstallID = IPAddress_new.Replace(";", "").Replace("|", "") '"127.0.0.1"
            NetBIOSName = NetBIOSName_new
            FolderParentID = FolderParentID_new

            UserName = UserName_new.Replace(";", "").Replace("|", "")

            DateAdded = Format(Now, "yyyy-MM-dd HH:mm")

            myApp.saveSettings()

        End Sub

        Sub New(ByRef strb As String)
            setSerializedObj(strb)
        End Sub

    End Class



End Module
