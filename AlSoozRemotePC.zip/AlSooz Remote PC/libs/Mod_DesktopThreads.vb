﻿Imports System.Runtime.InteropServices
Imports System.Security.Principal
Imports System.Text

Module Mod_DesktopThreads

    <DllImport("user32.dll", SetLastError:=True)>
    Private Sub SendSAS(ByVal fAsUser As Boolean)
    End Sub

    <DllImport("user32.dll", SetLastError:=True)>
    Private Function OpenInputDesktop(ByVal flags As Integer, <MarshalAs(UnmanagedType.Bool)> ByVal inherit As Boolean, ByVal desiredAccess As Integer) As IntPtr
    End Function


    <DllImport("user32.dll", SetLastError:=True)>
    Private Function GetThreadDesktop(<MarshalAs(UnmanagedType.I4)> ByVal dwThreadId As Integer) As IntPtr
    End Function

    <DllImport("user32.dll", SetLastError:=True)>
    Public Function OpenDesktop(ByVal lpszDesktop As String, ByVal dwFlags As Integer, ByVal fInderit As Boolean, ByVal dwDesiredAccess As Integer) As IntPtr
    End Function

    <DllImport("kernel32.dll", SetLastError:=True)>
    Private Function GetCurrentThreadId() As UInteger
    End Function

    <DllImport("user32.dll", SetLastError:=True)>
    Private Function CloseDesktop(ByVal desktop As IntPtr) As <MarshalAs(UnmanagedType.Bool)> Boolean
    End Function

    <DllImport("user32.dll", CharSet:=CharSet.Auto, SetLastError:=True)>
    Private Function GetUserObjectInformation(ByVal hObj As IntPtr, ByVal nIndex As Integer, ByVal pvInfo As StringBuilder, ByVal nLength As UInteger, ByRef lpnLengthNeeded As UInteger) As Boolean
    End Function



    <DllImport("user32.dll", SetLastError:=True)>
    Private Function SetThreadDesktop(ByVal desktop As IntPtr) As <MarshalAs(UnmanagedType.Bool)> Boolean
    End Function

    <DllImport("user32.dll", CharSet:=CharSet.Unicode)>
    Private Function SetForegroundWindow(ByVal hWnd As IntPtr) As <MarshalAs(UnmanagedType.Bool)> Boolean
    End Function

    <StructLayout(LayoutKind.Sequential, CharSet:=CharSet.Unicode)>
    Public Structure STARTUPINFOEX
        Public StartupInfo As STARTUPINFO
        Public lpAttributeList As IntPtr
    End Structure

    <StructLayout(LayoutKind.Sequential)>
    Public Structure STARTUPINFO
        Public cb As Integer
        Public lpReserved As String
        Public lpDesktop As String
        Public lpTitle As String
        Public dwX As Integer
        Public dwY As Integer
        Public dwXSize As Integer
        Public dwYSize As Integer
        Public dwXCountChars As Integer
        Public dwYCountChars As Integer
        Public dwFillAttribute As Integer
        Public dwFlags As Integer
        Public wShowWindow As Short
        Public cbReserved2 As Short
        Public lpReserved2 As Integer
        Public hStdInput As Integer
        Public hStdOutput As Integer
        Public hStdError As Integer
    End Structure
    Structure PROCESS_INFORMATION
        Public hProcess As IntPtr
        Public hThread As IntPtr
        Public dwProcessId As Integer
        Public dwThreadId As Integer
    End Structure

    Private Const CREATE_NEW_CONSOLE As Integer = &H10
    Private Const HIGH_PRIORITY_CLASS As Integer = &H80

    <DllImport("kernel32.dll")>
    Private Function CreateProcess(
    lpApplicationName As String,
    lpCommandLine As String,
    ByRef lpProcessAttributes As SECURITY_ATTRIBUTES,
    ByRef lpThreadAttributes As SECURITY_ATTRIBUTES,
    bInheritHandles As Boolean,
    dwCreationFlags As UInt32,
    lpEnvironment As IntPtr,
    lpCurrentDirectory As String,
    <[In]> ByRef lpStartupInfo As STARTUPINFO,
    <[Out]> ByRef lpProcessInformation As PROCESS_INFORMATION) As Boolean
    End Function


    Friend Function StartAppFromName(AppName As String) As Boolean

        Try

            Dim dwCreationFlags As UInteger = HIGH_PRIORITY_CLASS Or CREATE_NEW_CONSOLE

            Dim startProc As New PROCESS_INFORMATION()
            Dim StartInfo As New STARTUPINFO()

            StartInfo.lpDesktop = "default"
            CreateProcess(Nothing, AppName, Nothing, Nothing, False, dwCreationFlags, Nothing, Nothing, StartInfo, startProc)

            CloseHandle(startProc.hProcess)
            CloseHandle(startProc.hThread)
        Catch ex As Exception
            Return False
        End Try
        Return True
    End Function

    Friend Sub ShowFormOnTop(ByRef frm As Form)
        SetForegroundWindow(frm.Handle)
    End Sub



    Private Const UOI_NAME As Integer = 2

    Private Enum ACCESS_MASK
        MAXIMUM_ALLOWED = &H2000000
        GENERIC_ALL = &H10000000
    End Enum

    Friend DesktopThread_SwitchSignal_Mouse As Boolean = True
    Friend DesktopThread_SwitchSignal_Keyboard As Boolean = True
    Friend Sub setThreadTo_InputDesktop()

        Try

            Dim hDEsktop As IntPtr = OpenInputDesktop(0, False, ACCESS_MASK.MAXIMUM_ALLOWED)

            SetThreadDesktop(hDEsktop)

            CloseDesktop(hDEsktop)

        Catch ex As Exception
        End Try

        Gbl_DesktopName = GetCurrentThreadDesktopName()

        ' sendUDPToService("ThreadDekstopSwitch Started:" & GetCurrentDesktopName())

    End Sub

    Public Function GetInputThreadDesktopName() As String

        Dim deskName As String = "init"
        Try

            Dim inputDesktop As IntPtr = OpenInputDesktop(0, False, ACCESS_MASK.MAXIMUM_ALLOWED)

            Dim lenNeeded As UInteger
            Try

                GetUserObjectInformation(inputDesktop, UOI_NAME, Nothing, 0, lenNeeded)

                Dim buffer As New StringBuilder

                GetUserObjectInformation(inputDesktop, UOI_NAME, buffer, lenNeeded, lenNeeded)

                deskName = buffer.ToString

            Catch ex As Exception
                deskName = ex.Message
            End Try

            CloseDesktop(inputDesktop)
        Catch ex As Exception
            '  deskName = ex.Message
        End Try
        Return deskName.ToLower()
    End Function

    Public Function GetCurrentThreadDesktopName() As String

        Dim deskName As String = "init"
        Try

            ' Dim inputDesktop As IntPtr = OpenInputDesktop(0, False, ACCESS_MASK.MAXIMUM_ALLOWED)

            Dim inputDesktop As IntPtr = GetThreadDesktop(GetCurrentThreadId())

            Dim lenNeeded As UInteger
            Try

                GetUserObjectInformation(inputDesktop, UOI_NAME, Nothing, 0, lenNeeded)

                Dim buffer As New StringBuilder

                GetUserObjectInformation(inputDesktop, UOI_NAME, buffer, lenNeeded, lenNeeded)

                deskName = buffer.ToString

            Catch ex As Exception
                deskName = ex.Message
            End Try

            CloseDesktop(inputDesktop)
        Catch ex As Exception
            '  deskName = ex.Message
        End Try

        Return deskName.ToLower()
    End Function


    Friend Sub openFormInAnotherDesktop(ByVal DesktopName As String, ByVal FormName As String)
        Try

            Dim p As New Threading.Thread(Sub()
                                              Try

                                                  If FormName = "tray" Then
                                                      setThreadTo_NamedDesktop(DesktopName) '"winlogon","default"
                                                      myApp.writeDiskVariablesState(myAppClass.Gbl_DiskVariables.IsTrayFormObjNull, "yes")
                                                      Application.Run(New frmTray)
                                                  ElseIf FormName = "controller" Then
                                                      setThreadTo_NamedDesktop(DesktopName)
                                                      frmScreenControlObj = New frmScreenControl
                                                      Application.Run(frmScreenControlObj)
                                                  End If
                                              Catch ex As Exception
                                                  ' writeLogLine("Application.Run: error1 start try")
                                              End Try
                                          End Sub)

            p.SetApartmentState(Threading.ApartmentState.STA)
            p.Start()
        Catch ex As Exception
            '  writeLogLine("openFormInAnotherDesktop: error2 start try")
        End Try

    End Sub

    'Friend Sub Send_CNTL_ALT_DEL(ByVal isCaller As Boolean)
    '    SendSAS(isCaller)
    'End Sub

    Friend Sub setThreadTo_NamedDesktop(ByVal DesktopName As String)

        Try

            Dim hDesktop As IntPtr = OpenDesktop(DesktopName, 0, False, ACCESS_MASK.MAXIMUM_ALLOWED)

            'If hDesktop = IntPtr.Zero Then
            '    '  writeLogLine("No Desktop Found")
            'End If

            SetThreadDesktop(hDesktop)

            CloseDesktop(hDesktop)

        Catch ex As Exception
            '  writeLogLine("setThreadTo_NamedDesktop Err: " & ex.Message)
        End Try

        ' sendUDPToService("ThreadDekstopSwitch Started:" & GetCurrentDesktopName())

    End Sub


    <StructLayout(LayoutKind.Sequential)>
    Public Structure SECURITY_ATTRIBUTES
        Public Length As Integer
        Public lpSecurityDescriptor As IntPtr
        Public bInheritHandle As Boolean
    End Structure

    <DllImport("advapi32.dll", CharSet:=CharSet.Auto, SetLastError:=True)>
    Private Function DuplicateTokenEx(ByVal hExistingToken As IntPtr, ByVal dwDesiredAccess As UInteger, ByRef lpTokenAttributes As SECURITY_ATTRIBUTES, ByVal ImpersonationLevel As SECURITY_IMPERSONATION_LEVEL, ByVal TokenType As TOKEN_TYPE, <Out> ByRef phNewToken As IntPtr) As Boolean
    End Function

    <DllImport("kernel32.dll", SetLastError:=True)>
    Private Function CloseHandle(ByVal hSnapshot As IntPtr) As Boolean
    End Function

    <DllImport("wtsapi32.dll", SetLastError:=True)>
    Private Function WTSQueryUserToken(ByVal SessionId As UInt32, ByRef Token As IntPtr) As Boolean
    End Function

    <DllImport("kernel32.dll")>
    Public Function WTSGetActiveConsoleSessionId() As UInteger
    End Function

    Private Enum SECURITY_IMPERSONATION_LEVEL
        SecurityAnonymous = 0
        SecurityIdentification = 1
        SecurityImpersonation = 2
        SecurityDelegation = 3
    End Enum

    Private Enum TOKEN_TYPE
        TokenPrimary = 1
        TokenImpersonation = 2
    End Enum

    Friend gbl_ImpersonateContext As WindowsImpersonationContext = Nothing

    Friend Function setThread_RunUnderLoggedInUserAccount() As WindowsImpersonationContext
        Dim hUserTokenDup As IntPtr = IntPtr.Zero
        Dim hPToken As IntPtr = IntPtr.Zero

        Try
            Dim sa As SECURITY_ATTRIBUTES = New SECURITY_ATTRIBUTES()
            sa.Length = Marshal.SizeOf(sa)

            Dim activeSessionId As UInteger = WTSGetActiveConsoleSessionId()

            If Not WTSQueryUserToken(activeSessionId, hPToken) Then
                'MsgBox("WTSQueryUserToken: false")
                CloseHandle(hPToken)
                Return Nothing
            End If

            If Not DuplicateTokenEx(hPToken, ACCESS_MASK.MAXIMUM_ALLOWED, sa, CInt(SECURITY_IMPERSONATION_LEVEL.SecurityImpersonation), CInt(TOKEN_TYPE.TokenPrimary), hUserTokenDup) Then
                '  writeLogLine("DuplicateTokenEx")
                'MsgBox("DuplicateTokenEx: false")
                CloseHandle(hPToken)
                Return Nothing

            Else

                Return WindowsIdentity.Impersonate(hUserTokenDup)

            End If

        Catch ex As Exception
        End Try

        Return Nothing
    End Function

    Friend Sub UnsetThread_RunUnderLoggedInUserAccount(ByRef WinImpersonContext As WindowsImpersonationContext)
        Try
            WinImpersonContext.Undo()
        Catch ex As Exception

        End Try
    End Sub


    <DllImport("user32.dll", SetLastError:=True, CharSet:=CharSet.Auto)>
    Private Function FindWindowEx(ByVal parentHandle As IntPtr,
                      ByVal childAfter As IntPtr,
                      ByVal lclassName As String,
                      ByVal windowTitle As String) As IntPtr
    End Function

    Friend Function isDesktopReady() As Boolean
        Dim desktopHandle As IntPtr = IntPtr.Zero
        Try
            desktopHandle = FindWindowEx(0, 0, "Shell_TrayWnd", vbNullString)
            If desktopHandle <> IntPtr.Zero Then Return True

        Catch ex As Exception
            ' writeLogLine("isDesktopReady Err: " & ex.Message)
        End Try
        Return False
    End Function



    Friend Class clsAuthenticator

        ' group type enum
        Friend Enum SECURITY_IMPERSONATION_LEVEL As Int32
            SecurityAnonymous = 0
            SecurityIdentification = 1
            SecurityImpersonation = 2
            SecurityDelegation = 3
        End Enum

        Friend Enum LogonType As Integer
            'This logon type is intended for users who will be interactively using the computer, such as a user being logged on
            'by a terminal server, remote shell, or similar process.
            'This logon type has the additional expense of caching logon information for disconnected operations;
            'therefore, it is inappropriate for some client/server applications,
            'such as a mail server.
            LOGON32_LOGON_INTERACTIVE = 2

            'This logon type is intended for high performance servers to authenticate plaintext passwords.
            'The LogonUser function does not cache credentials for this logon type.
            LOGON32_LOGON_NETWORK = 3

            'This logon type is intended for batch servers, where processes may be executing on behalf of a user without
            'their direct intervention. This type is also for higher performance servers that process many plaintext
            'authentication attempts at a time, such as mail or Web servers.
            'The LogonUser function does not cache credentials for this logon type.
            LOGON32_LOGON_BATCH = 4

            'Indicates a service-type logon. The account provided must have the service privilege enabled.
            LOGON32_LOGON_SERVICE = 5

            'This logon type is for GINA DLLs that log on users who will be interactively using the computer.
            'This logon type can generate a unique audit record that shows when the workstation was unlocked.
            LOGON32_LOGON_UNLOCK = 7

            'This logon type preserves the name and password in the authentication package, which allows the server to make
            'connections to other network servers while impersonating the client. A server can accept plaintext credentials
            'from a client, call LogonUser, verify that the user can access the system across the network, and still
            'communicate with other servers.
            'NOTE: Windows NT:  This value is not supported.
            LOGON32_LOGON_NETWORK_CLEARTEXT = 8

            'This logon type allows the caller to clone its current token and specify new credentials for outbound connections.
            'The new logon session has the same local identifier but uses different credentials for other network connections.
            'NOTE: This logon type is supported only by the LOGON32_PROVIDER_WINNT50 logon provider.
            'NOTE: Windows NT:  This value is not supported.
            LOGON32_LOGON_NEW_CREDENTIALS = 9
        End Enum

        Friend Enum LogonProvider As Integer
            'Use the standard logon provider for the system.
            'The default security provider is negotiate, unless you pass NULL for the domain name and the user name
            'is not in UPN format. In this case, the default provider is NTLM.
            'NOTE: Windows 2000/NT:   The default security provider is NTLM.
            LOGON32_PROVIDER_DEFAULT = 0
            LOGON32_PROVIDER_WINNT35 = 1
            LOGON32_PROVIDER_WINNT40 = 2
            LOGON32_PROVIDER_WINNT50 = 3
        End Enum

        ' obtains user token
        Private Declare Auto Function LogonUser Lib "advapi32.dll" (ByVal lpszUsername As String, ByVal lpszDomain As String, ByVal lpszPassword As String, ByVal dwLogonType As LogonType, ByVal dwLogonProvider As LogonProvider, ByRef phToken As IntPtr) As Integer

        Private Declare Auto Function DuplicateToken Lib "advapi32.dll" (ExistingTokenHandle As IntPtr, SECURITY_IMPERSONATION_LEVEL As Int16, ByRef DuplicateTokenHandle As IntPtr) As Boolean


        Private newUser As WindowsImpersonationContext


        Friend Sub Impersonator(ByVal sDomain As String, ByVal sUsername As String, ByVal sPassword As String)
            ' initialize tokens

            Dim pExistingTokenHandle As New IntPtr(0)
            Dim pDuplicateTokenHandle As New IntPtr(0)

            If sDomain = "" Then
                sDomain = System.Environment.MachineName
            End If

            Try

                Dim bImpersonated As Boolean = LogonUser(sUsername, sDomain, sPassword, LogonType.LOGON32_LOGON_INTERACTIVE, LogonProvider.LOGON32_PROVIDER_DEFAULT, pExistingTokenHandle)

                If bImpersonated = False Then
                    Dim nErrorCode As Int32 = Marshal.GetLastWin32Error()
                    Throw New ApplicationException("LogonUser() failed with error code: " & nErrorCode.ToString)
                End If

                Dim bRetVal As Boolean = DuplicateToken(pExistingTokenHandle, SECURITY_IMPERSONATION_LEVEL.SecurityImpersonation, pDuplicateTokenHandle)
                If bRetVal = False Then
                    Dim nErrorCode As Int32 = Marshal.GetLastWin32Error
                    CloseHandle(pExistingTokenHandle)
                    Throw New ApplicationException("DuplicateToken() failed with error code: " & nErrorCode)
                Else
                    Dim newId As New WindowsIdentity(pDuplicateTokenHandle)
                    Dim impersonatedUser As WindowsImpersonationContext = newId.Impersonate
                    newUser = impersonatedUser
                End If

            Catch ex As Exception
                MsgBox(ex.Message)
            Finally
                If pExistingTokenHandle <> IntPtr.Zero Then
                    CloseHandle(pExistingTokenHandle)
                End If
                If pDuplicateTokenHandle <> IntPtr.Zero Then
                    CloseHandle(pDuplicateTokenHandle)
                End If
            End Try

        End Sub

        Friend Sub Undo()
            Try
                newUser.Undo()
            Catch ex As Exception
            End Try

        End Sub

        ' ---------- how to use -----------
        ' Dim Impersonator As New clsAuthenticator
        '  Impersonator.Impersonator(remotedomain, remoteuser, remotepass)

        'Dim user As SecurityIdentifier = WindowsIdentity.GetCurrent.User
        'Dim userName As String = user.Translate(GetType(NTAccount)).Value

        ' Impersonator.Undo()


    End Class
End Module
