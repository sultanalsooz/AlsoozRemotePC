﻿Imports System.IO
Imports System.Drawing.Imaging
Imports System.Drawing.Drawing2D
Imports System.Runtime.InteropServices


Module Mod_screenshot

    <DllImport("msvcrt.dll", CallingConvention:=CallingConvention.Cdecl)>
    Private Function memcmp(ByVal b1 As Byte(), ByVal b2 As Byte(), ByVal count As UIntPtr) As Integer
    End Function

    Friend Function ByteArrayCompare(ByRef b1 As Byte(), ByRef b2 As Byte()) As Boolean
        Return b1.Length = b2.Length AndAlso memcmp(b1, b2, b1.Length) = 0
    End Function

    <StructLayout(LayoutKind.Sequential)>
    Structure CURSORINFO
        Public cbSize As Int32
        Public flags As Int32
        Public hCursor As IntPtr
        Public ptScreenPos As POINTAPI
    End Structure

    <StructLayout(LayoutKind.Sequential)>
    Structure POINTAPI
        Public x As Integer
        Public y As Integer
    End Structure

    <DllImport("user32.dll")>
    Private Function GetCursorInfo(<Out> ByRef pci As CURSORINFO) As Boolean
    End Function

    <DllImport("user32.dll")>
    Private Function DrawIcon(ByVal hDC As IntPtr, ByVal X As Integer, ByVal Y As Integer, ByVal hIcon As IntPtr) As Boolean
    End Function

    Const CURSOR_SHOWING As Int32 = &H1


    <StructLayout(LayoutKind.Sequential)>
    Public Structure RECT
        Public left As Integer
        Public top As Integer
        Public right As Integer
        Public bottom As Integer
    End Structure 'RECT




    <DllImport("user32.dll")>
    Public Function GetWindowRect(ByVal hWnd As IntPtr, ByRef rect As RECT) As IntPtr
    End Function

    ' P/Invoke declarations
    <DllImport("gdi32.dll")>
    Friend Function BitBlt(hdcDest As IntPtr, xDest As Integer, yDest As Integer, wDest As Integer, hDest As Integer, hdcSource As IntPtr, xSrc As Integer, ySrc As Integer, rop As CopyPixelOperation) As Boolean
    End Function
    <DllImport("user32.dll")>
    Friend Function ReleaseDC(hWnd As IntPtr, hDc As IntPtr) As Boolean
    End Function
    <DllImport("gdi32.dll")>
    Friend Function DeleteDC(hDc As IntPtr) As IntPtr
    End Function
    <DllImport("gdi32.dll")>
    Friend Function DeleteObject(hDc As IntPtr) As IntPtr
    End Function
    <DllImport("gdi32.dll")>
    Friend Function CreateCompatibleBitmap(hdc As IntPtr, nWidth As Integer, nHeight As Integer) As IntPtr
    End Function
    <DllImport("gdi32.dll")>
    Friend Function CreateCompatibleDC(hdc As IntPtr) As IntPtr
    End Function
    <DllImport("gdi32.dll")>
    Friend Function SelectObject(hdc As IntPtr, bmp As IntPtr) As IntPtr
    End Function
    <DllImport("user32.dll")>
    Private Function GetDesktopWindow() As IntPtr
    End Function
    <DllImport("user32.dll")>
    Private Function GetWindowDC(ptr As IntPtr) As IntPtr
    End Function


    <DllImport("gdi32.dll")>
    Public Function StretchBlt(ByVal hdcDest As IntPtr,
                                           ByVal nXOriginDest As Integer,
                                           ByVal nYOriginDest As Integer,
                                           ByVal nWidthDest As Integer,
                                           ByVal nHeightDest As Integer,
                                           ByVal hdcSrc As IntPtr,
                                           ByVal nXOriginSrc As Integer,
                                           ByVal nYOriginSrc As Integer,
                                           ByVal nWidthSrc As Integer,
                                           ByVal nHeightSrc As Integer,
                                           ByVal dwRop As CopyPixelOperation) As Boolean
    End Function

    Public Enum StretchBltMode As Integer
        STRETCH_ANDSCANS = 1
        STRETCH_ORSCANS = 2
        STRETCH_DELETESCANS = 3
        STRETCH_HALFTONE = 4
    End Enum

    <DllImport("gdi32.dll")>
    Public Function SetStretchBltMode(hdc As IntPtr, iStretchMode As StretchBltMode) As Boolean
    End Function

    Friend MyScreenHeight As Integer
    Friend MyScreenWidth As Integer
    Friend MyScreenScaledFactorY As Single
    Friend MyScreenScaledFactorX As Single
    Friend Sub InitializeScalingFactor()
        Dim g As Graphics = Graphics.FromHwnd(IntPtr.Zero)
        Dim desktop As IntPtr = g.GetHdc()
        Dim LogicalScreenHeight As Integer = GetDeviceCaps(desktop, CInt(DeviceCap.VERTRES))
        Dim LogicalScreenWidth As Integer = GetDeviceCaps(desktop, CInt(DeviceCap.HORZRES))
        Dim PhysicalScreenHeight As Integer = GetDeviceCaps(desktop, CInt(DeviceCap.DESKTOPVERTRES))
        Dim PhysicalScreenWidth As Integer = GetDeviceCaps(desktop, CInt(DeviceCap.DESKTOPHORZRES))
        MyScreenHeight = PhysicalScreenHeight
        MyScreenWidth = PhysicalScreenWidth

        MyScreenScaledFactorY = CSng(PhysicalScreenHeight) / CSng(LogicalScreenHeight)
        MyScreenScaledFactorX = CSng(PhysicalScreenWidth) / CSng(LogicalScreenWidth)

        ' 1.25 = 125%
    End Sub

    Friend imageSizeToRecord As Size

    Private pci As CURSORINFO

    Friend gbl_drawMouseCursor As Boolean = False
    Private ImageLockObj As New Object

    Private SS_hDesk As IntPtr = Nothing
    Private SS_hSrce As IntPtr = Nothing
    Private SS_hDest As IntPtr = Nothing
    Private SS_hBmp As IntPtr = Nothing
    Private SS_hOldBmp As IntPtr = Nothing

    Private isSSLoaded As Boolean = False
    Private scaledMyScreenWidth As Integer
    Private scaledMyScreenHeight As Integer

    Friend Sub initScreenShotNative()
        If isSSLoaded Then Return
        isSSLoaded = True
        InitializeScalingFactor()
        Try
            ' scaledMyScreenWidth = MyScreenWidth / 2
            ' scaledMyScreenHeight = MyScreenHeight / 2

            SS_hDesk = GetDesktopWindow()
            SS_hSrce = GetWindowDC(SS_hDesk)
            SS_hDest = CreateCompatibleDC(SS_hSrce)
            SS_hBmp = CreateCompatibleBitmap(SS_hSrce, MyScreenWidth, MyScreenHeight)

            ' SS_hBmp = CreateCompatibleBitmap(SS_hSrce, scaledMyScreenWidth, scaledMyScreenHeight)

            SS_hOldBmp = SelectObject(SS_hDest, SS_hBmp)

            '' SetStretchBltMode(SS_hDest, 4)

        Catch ex As Exception
        End Try
        pci = New CURSORINFO()
        pci.cbSize = 0

    End Sub

    Friend Sub endScreenShotNative()
        Try
            SelectObject(SS_hDest, SS_hOldBmp)
            DeleteObject(SS_hBmp)
            DeleteDC(SS_hDest)
            ReleaseDC(SS_hDesk, SS_hSrce)
            SS_hDesk = Nothing
        Catch ex As Exception
        End Try

        isSSLoaded = False
        pci = Nothing
    End Sub

    'Private ss_bmp As Bitmap = Nothing

    Private Const copyOperationCode As Integer = CopyPixelOperation.SourceCopy Or CopyPixelOperation.CaptureBlt

    '<HandleProcessCorruptedStateExceptions>
    '<System.Security.SecurityCritical>
    Friend Function getScreenShotNative() As Bitmap

        Try
            ' Threading.Monitor.Enter(ImageLockObj)

            If BitBlt(SS_hDest, 0, 0, MyScreenWidth, MyScreenHeight, SS_hSrce, 0, 0, copyOperationCode) Then

                Try
                    If gbl_drawMouseCursor Then

                        If pci.cbSize = 0 Then pci.cbSize = Marshal.SizeOf(GetType(CURSORINFO))
                        If GetCursorInfo(pci) Then
                            If pci.flags = CURSOR_SHOWING Then
                                Dim x As Integer = CInt(pci.ptScreenPos.x * MyScreenScaledFactorX)
                                Dim y As Integer = CInt(pci.ptScreenPos.y * MyScreenScaledFactorY)

                                DrawIcon(SS_hDest, x, y, pci.hCursor)
                            End If
                        End If

                    End If

                Catch ex As Exception
                End Try

                ' Debug.Print("After bitblt: " & MyRecorder.gblTimer.ElapsedMilliseconds)

                'Return Bitmap.FromHbitmap(SS_hBmp, IntPtr.Zero)

                If myApp.myScreen.isRecordingOn Then

                    '  Return Bitmap.FromHbitmap(SS_hBmp, IntPtr.Zero)


                    If JPGCompressLevel = 2 Then
                        Dim bm As Bitmap = Bitmap.FromHbitmap(SS_hBmp, IntPtr.Zero)
                        If bm.Width > myApp.myScreen.DesktopImgWidth(2) Then
                            If myApp.myScreen.isDestroyBm Then myApp.myScreen.isDestroyBm = False
                            '  Debug.Print("large bm width: " & bm.Width)
                            Return ResizeImage(bm, imageSizeToRecord)
                        Else
                            '  Debug.Print("small bm width: " & bm.Width)
                            If myApp.myScreen.isDestroyBm = False Then myApp.myScreen.isDestroyBm = True
                            Return bm
                        End If
                    Else
                        Using bm As Bitmap = Bitmap.FromHbitmap(SS_hBmp, IntPtr.Zero)
                            If myApp.myScreen.isDestroyBm Then myApp.myScreen.isDestroyBm = False
                            Return ResizeImage(bm, imageSizeToRecord)
                        End Using
                    End If

                End If
            Else
                endScreenShotNative()
                Threading.Thread.Sleep(100)
                setThreadTo_InputDesktop()
                DesktopThread_SwitchSignal_Mouse = True
                DesktopThread_SwitchSignal_Keyboard = True
                isSSLoaded = False
                initScreenShotNative()
            End If


            ' bmp = clsGDI_Graphics.ResizeImageGDI(bmp, imageSizeToRecord.Width, imageSizeToRecord.Height)
            'Catch exstate As AccessViolationException
            '    sendUDPToService("AccessViolationException: " & exstate.Message)
        Catch ex As Exception
            endScreenShotNative()
            initScreenShotNative()
        End Try


        Return Nothing

    End Function

    <StructLayout(LayoutKind.Sequential)>
    Private Structure Native_BITMAP
        Public bmType As Integer
        Public bmWidth As Integer
        Public bmHeight As Integer
        Public bmWidthBytes As Integer
        Public bmPlanes As UShort
        Public bmBitsPixel As UShort
        Public bmBits As IntPtr
    End Structure

    <DllImport("gdi32", CharSet:=CharSet.Auto, EntryPoint:="GetObject")>
    Private Function GetObjectBitmap(ByVal hObject As IntPtr, ByVal nCount As Integer, ByRef lpObject As Native_BITMAP) As Integer

    End Function

    <DllImport("gdiplus.dll", CharSet:=CharSet.Unicode, ExactSpelling:=True)>
    Private Function GdipCreateBitmapFromHBITMAP(ByVal hbitmap As HandleRef, ByVal hpalette As HandleRef, <Out> ByRef bitmap As IntPtr) As Integer

    End Function

    Private Function CopyHBitmapToBitmap(ByVal nativeHBitmap As IntPtr) As Bitmap
        Dim bitmapStruct As Native_BITMAP = New Native_BITMAP()
        GetObjectBitmap(nativeHBitmap, Marshal.SizeOf(bitmapStruct), bitmapStruct)
        Dim managedBitmapPointer As Bitmap = New Bitmap(bitmapStruct.bmWidth, bitmapStruct.bmHeight, bitmapStruct.bmWidth * 4, PixelFormat.Format32bppArgb, bitmapStruct.bmBits)
        Dim managedBitmapReal As Bitmap = New Bitmap(bitmapStruct.bmWidth, bitmapStruct.bmHeight, PixelFormat.Format32bppArgb)
        Dim graphics As Graphics = Graphics.FromImage(managedBitmapReal)
        graphics.DrawImage(managedBitmapPointer, 0, 0)
        DeleteObject(nativeHBitmap)
        Return managedBitmapReal
    End Function


    Friend gblEncoderParametersJpeg As New EncoderParameters(1)
    Friend gblEncoderParameterJpeg As EncoderParameter
    Friend gblEncoderInfoJpeg As ImageCodecInfo = Nothing


    Friend Function compressPhotoToJPG(ByRef input_bm As Image, ByRef compressRatio As Integer) As MemoryStream

        Dim outputMS As MemoryStream = New MemoryStream()

        Try
            If compressRatio = 0 Then
                input_bm.Save(outputMS, gblEncoderInfoJpeg, gblEncoderParametersJpeg)

            Else

                input_bm.Save(outputMS, ImageFormat.Png)

            End If
            Return outputMS
        Catch ex As Exception
        End Try

        Return outputMS
    End Function

    'Friend Function compressPhotoToWebp(ByRef input_bm As Image, ByRef compressRatio As Integer) As Byte()

    '    Dim outputMS As Byte() = Nothing

    '    Try
    '        Using WebPObj As New WebP()
    '            If compressRatio = 0 Then
    '                outputMS = WebPObj.EncodeLossy(input_bm, 80, 0, False)
    '            ElseIf compressRatio = 1 Then
    '                outputMS = WebPObj.EncodeLossless(input_bm)
    '            ElseIf compressRatio = 2 Then
    '                outputMS = WebPObj.EncodeLossless(input_bm)

    '            End If
    '        End Using
    '        Return outputMS
    '    Catch ex As Exception
    '    End Try

    '    Return outputMS
    'End Function

    Private gbl_newImage As Bitmap = Nothing
    Private gbl_graphicsHandle As Graphics = Nothing
    Private gbl_LastImgWidth As Integer = 0

    Private gbl_newWidth As Integer = 0
    Private gbl_newHeight As Integer = 0

    Friend Function ResizeImage(ByRef oldImage As Bitmap, ByRef size As Size) As Image

        Try

            If gbl_LastImgWidth <> size.Width Then
                Try
                    If Not IsNothing(gbl_newImage) Then gbl_newImage.Dispose()
                Catch ex As Exception
                End Try

                gbl_LastImgWidth = size.Width

                Dim originalWidth As Integer = oldImage.Width
                Dim originalHeight As Integer = oldImage.Height
                Dim percentWidth As Single = CSng(size.Width) / CSng(originalWidth)
                Dim percentHeight As Single = CSng(size.Height) / CSng(originalHeight)
                Dim percent As Single = If(percentHeight < percentWidth, percentHeight, percentWidth)
                gbl_newWidth = CInt(originalWidth * percent)
                gbl_newHeight = CInt(originalHeight * percent)


                gbl_newImage = New Bitmap(gbl_newWidth, gbl_newHeight, JPGBits)
                gbl_graphicsHandle = Graphics.FromImage(gbl_newImage)

                gbl_graphicsHandle.CompositingQuality = CompositingQuality.HighSpeed
                gbl_graphicsHandle.SmoothingMode = SmoothingMode.HighSpeed
                gbl_graphicsHandle.PixelOffsetMode = PixelOffsetMode.HighSpeed

            End If

            gbl_graphicsHandle.DrawImage(oldImage, 0, 0, gbl_newWidth, gbl_newHeight)

            'Debug.Print("After Graphics: " & MyRecorder.gblTimer.ElapsedMilliseconds)

            If JPGCompressLevel = 2 Then
                oldImage.Dispose()
            End If
        Catch ex As Exception
            Try
                If Not IsNothing(gbl_newImage) Then gbl_newImage.Dispose()
                gbl_newImage = Nothing
            Catch ex2 As Exception
            End Try
        End Try

        ' oldImage.Dispose()

        Return gbl_newImage
    End Function

    Friend Function GetImgEncoder(ByVal format As ImageFormat) As ImageCodecInfo

        Dim codecs As ImageCodecInfo() = ImageCodecInfo.GetImageDecoders()

        Dim codec As ImageCodecInfo
        For Each codec In codecs
            If codec.FormatID = format.Guid Then
                Return codec
            End If
        Next codec
        Return Nothing

    End Function

    'Friend Function ImageTo8bpp(ByRef bm As Bitmap) As Bitmap


    '    Using stream = New MemoryStream()
    '        Dim parameters = New EncoderParameters(1)
    '        parameters.Param(0) = New EncoderParameter(Encoder.ColorDepth, 1L)
    '        Dim info = GetImgEncoder(ImageFormat.Tiff)
    '        bm.Save(stream, info, parameters)
    '        Return Bitmap.FromStream(stream)
    '    End Using
    'End Function


End Module
