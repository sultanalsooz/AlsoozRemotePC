﻿Imports System.Reflection
Imports Microsoft.VisualBasic.ApplicationServices
Imports Microsoft.VisualBasic.Devices

Namespace My
    ' The following events are available for MyApplication:
    ' Startup: Raised when the application starts, before the startup form is created.
    ' Shutdown: Raised after all application forms are closed.  This event is not raised if the application terminates abnormally.
    ' UnhandledException: Raised if the application encounters an unhandled exception.
    ' StartupNextInstance: Raised when launching a single-instance application and the application is already active. 
    ' NetworkAvailabilityChanged: Raised when the network connection is connected or disconnected.
    Partial Friend Class MyApplication

        Private Sub MyApplication_Startup(sender As Object, e As StartupEventArgs) Handles Me.Startup
            loadDlls()
        End Sub

        Private Sub loadDlls()
            AddHandler AppDomain.CurrentDomain.AssemblyResolve, AddressOf MyResolveEventHandler

        End Sub

        'Friend mytmpassembly As String = ""
        Private counterdll As Integer = 0
        Private Function MyResolveEventHandler(sender As Object, args As ResolveEventArgs) As [Assembly]
            Dim MyAssembly As [Assembly] = Nothing
            Try

                'If args.Name.ToLower().IndexOf("csharpcode") > -1 Then
                '    MyAssembly = [Assembly].Load(My.Resources.cSharpCode)

                '    'ElseIf args.Name.ToLower().IndexOf("opus") > -1 Then
                '    '    MyAssembly = [Assembly].Load(My.Resources.opus)

                'ElseIf args.Name.ToLower().IndexOf("naudio") > -1 Then
                '    MyAssembly = [Assembly].Load(My.Resources.NAudio)

                'Else
                '    'frmTrayObj.BeginInvoke(Sub()
                '    '                           MsgBox("args.Name: " & args.Name)
                '    '                       End Sub)
                'End If


            Catch ex As Exception

            End Try

            Return MyAssembly
        End Function

        'Private Sub MyApplication_NetworkAvailabilityChanged(sender As Object, e As NetworkAvailableEventArgs) Handles Me.NetworkAvailabilityChanged
        '    If Not IsNothing(frmMainObj) AndAlso frmMainObj.isFormLoaded Then
        '        If e.IsNetworkAvailable Then frmMainObj.NetworkChanged()
        '    End If
        'End Sub
    End Class
End Namespace
