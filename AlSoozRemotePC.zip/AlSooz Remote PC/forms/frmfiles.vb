﻿Imports System.ComponentModel
Imports System.Text

Public Class frmfiles

    Private Sub frmfiles_Closing(sender As Object, e As CancelEventArgs) Handles Me.Closing
        frmFilesObj = Nothing
        myApp.isService_FileOn = False
    End Sub

    Private Sub frmfiles_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        myApp.isService_FileOn = True
        pnl_files_txt_log.Visible = False

        frmFilesObj = Me
    End Sub


    Private Sub pnl_files_btn_log_Click(sender As Object, e As EventArgs) Handles pnl_files_btn_log.Click

        If pnl_files_btn_log.Text = "Show Log" Then
            showLogTxt(True)
        ElseIf pnl_files_btn_log.Text = "Hide Log" Then
            showLogTxt(False)
        End If
    End Sub

    Private Sub showLogTxt(isShow As Boolean)
        If isShow Then
            pnl_files_btn_log.Text = "Hide Log"
            btnSendFile.Text = "Clear Log"
            pnl_files_txt_log.Text = getLogtxtFormated()
            pnl_files_txt_log.Visible = True

        Else
            pnl_files_txt_log.Visible = False
            pnl_files_btn_log.Text = "Show Log"
            btnSendFile.Text = "Browse"
        End If
    End Sub

    Private Function getLogtxtFormated() As String

        Dim strb As New StringBuilder
        Dim len As Integer = myApp.myFileShare.LastLog.Count - 1
        If len > 0 Then
            For i As Integer = 0 To len
                Dim sline As String() = myApp.myFileShare.LastLog(i)
                strb.Append(sline(2).Split(" ")(1).Trim)
                If sline(0) = "fileRec" Then
                    strb.Append(" Received:  ")
                    strb.Append(sline(1))
                ElseIf sline(0) = "fileSend" Then
                    strb.Append(" Sent:  ")
                    strb.Append(sline(1))
                ElseIf sline(0) = "fileRecCompleted" Then
                    strb.Append(" Received Completed")
                ElseIf sline(0) = "fileSendCompleted" Then
                    strb.Append(" Sent Completed")
                ElseIf sline(0) = "fileSendError" Then
                    strb.Append(" Sent Error")
                End If

                strb.Append(vbCrLf)
            Next

        Else
            strb.Append("No Logs")
        End If

        Return strb.ToString()
    End Function

    Private Sub btnSendFile_Click(sender As Object, e As EventArgs) Handles btnSendFile.Click
        If btnSendFile.Text = "Browse" Then
            Dim sfiles As DialogResult = popup_files.ShowDialog()
            If sfiles = DialogResult.OK Then
                If popup_files.FileNames.Count > 0 Then
                    myApp.myFileShare.FileShare_SendFiles(popup_files.FileNames.ToArray)
                End If
            End If

        ElseIf btnSendFile.Text = "Clear Log" Then

            myApp.myFileShare.LastLog.Clear()
            pnl_files_txt_log.Text = ""
            showLogTxt(False)

        End If
    End Sub


End Class