﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class frmUserUI
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmUserUI))
        Me.btn_fileLocation = New System.Windows.Forms.Button()
        Me.popup_folder = New System.Windows.Forms.FolderBrowserDialog()
        Me.treeObj = New System.Windows.Forms.TreeView()
        Me.TreeViewImgs = New System.Windows.Forms.ImageList(Me.components)
        Me.btn_option1 = New System.Windows.Forms.Button()
        Me.btn_option2 = New System.Windows.Forms.Button()
        Me.btn_option4 = New System.Windows.Forms.Button()
        Me.btn_option3 = New System.Windows.Forms.Button()
        Me.pnl_NewPC = New System.Windows.Forms.Panel()
        Me.pnl_NewPC_txt_Dateadded = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.pnl_NewPC_txt_Username = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Panel6 = New System.Windows.Forms.Panel()
        Me.pnl_NewPC_rdo2 = New System.Windows.Forms.RadioButton()
        Me.pnl_NewPC_rdo1 = New System.Windows.Forms.RadioButton()
        Me.Label26 = New System.Windows.Forms.Label()
        Me.pnl_NewPC_txt_NetBIOSName = New System.Windows.Forms.Label()
        Me.Label24 = New System.Windows.Forms.Label()
        Me.pnl_NewPC_Txt_FolderParent = New System.Windows.Forms.TextBox()
        Me.Label23 = New System.Windows.Forms.Label()
        Me.pnl_NewPC_btn_PWDShow = New System.Windows.Forms.Button()
        Me.pnl_NewPC_txt_PCPassword = New System.Windows.Forms.TextBox()
        Me.pnl_NewPC_lbl2 = New System.Windows.Forms.Label()
        Me.pnl_NewPC_btn_add = New System.Windows.Forms.Button()
        Me.pnl_NewPC_txt_PCIP = New System.Windows.Forms.TextBox()
        Me.pnl_NewPC_lbl1 = New System.Windows.Forms.Label()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.pnl_NewPC_txt_PCName = New System.Windows.Forms.TextBox()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.pnl_NewFolder = New System.Windows.Forms.Panel()
        Me.btnFolder_MoveDown = New System.Windows.Forms.Button()
        Me.btnFolder_MoveUp = New System.Windows.Forms.Button()
        Me.pnl_NewFolder_chk_isRoot = New System.Windows.Forms.CheckBox()
        Me.pnl_NewFolder_lbl_folders = New System.Windows.Forms.Label()
        Me.pnl_NewFolder_lbl_PCs = New System.Windows.Forms.Label()
        Me.Label22 = New System.Windows.Forms.Label()
        Me.pnl_NewFolder_Txt_FolderParent = New System.Windows.Forms.TextBox()
        Me.Label18 = New System.Windows.Forms.Label()
        Me.pnl_NewFolder_btn_Add = New System.Windows.Forms.Button()
        Me.Label19 = New System.Windows.Forms.Label()
        Me.pnl_NewFolder_Txt_FolderName = New System.Windows.Forms.TextBox()
        Me.Label20 = New System.Windows.Forms.Label()
        Me.lbl_TreeStats_PCs = New System.Windows.Forms.Label()
        Me.lbl_TreeStats_Folders = New System.Windows.Forms.Label()
        Me.pnl_TopManu = New System.Windows.Forms.Panel()
        Me.pnl_Icon4 = New System.Windows.Forms.Panel()
        Me.btn_Install = New System.Windows.Forms.Label()
        Me.pnl_Icon4_img = New System.Windows.Forms.PictureBox()
        Me.pnl_Icon1 = New System.Windows.Forms.Panel()
        Me.myPcStatus_lbl_Unattended_2 = New System.Windows.Forms.Label()
        Me.myPcStatus_lbl_Unattended_1 = New System.Windows.Forms.Label()
        Me.myPcStatus_lbl_Service_1 = New System.Windows.Forms.Label()
        Me.myPcStatus_lbl_Service_2 = New System.Windows.Forms.Label()
        Me.pnl_Icon7 = New System.Windows.Forms.Panel()
        Me.pnl_Icon7_lbl = New System.Windows.Forms.Label()
        Me.pnl_Icon7_img = New System.Windows.Forms.PictureBox()
        Me.myPcStatus_lbl_RemoteID_2 = New System.Windows.Forms.Label()
        Me.myPcStatus_lbl_MyID_2 = New System.Windows.Forms.Label()
        Me.myPcStatus_lbl_RemotePC_2 = New System.Windows.Forms.Label()
        Me.btn_Disconnect_RemotePC = New System.Windows.Forms.Button()
        Me.myPcStatus_lbl_MyPC_2 = New System.Windows.Forms.Label()
        Me.btn_Disconnect_MyPC = New System.Windows.Forms.Button()
        Me.pnl_status = New System.Windows.Forms.Panel()
        Me.txtdebug = New System.Windows.Forms.TextBox()
        Me.btnTaskmgr = New System.Windows.Forms.Button()
        Me.btn_ScreenControl_RemotePC = New System.Windows.Forms.Button()
        Me.btn_Files_RemotePC = New System.Windows.Forms.Button()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.myPcStatus_lbl_RemoteNetBIOS = New System.Windows.Forms.Label()
        Me.myPcStatus_lbl_MyNetBIOS = New System.Windows.Forms.Label()
        Me.pnl_status_lbl = New System.Windows.Forms.Label()
        Me.pnl_status_PC1 = New System.Windows.Forms.PictureBox()
        Me.pnl_status_icon = New System.Windows.Forms.PictureBox()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.pnl_status_wire_remotePC = New System.Windows.Forms.PictureBox()
        Me.pnl_status_wire_MyPC = New System.Windows.Forms.PictureBox()
        Me.pnl_Config_1 = New System.Windows.Forms.Panel()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.pnl_Config_1_chk_discoveryNotification = New System.Windows.Forms.CheckBox()
        Me.pnl_Config_1_txt_AutoDiscoverKeyword = New System.Windows.Forms.TextBox()
        Me.Label36 = New System.Windows.Forms.Label()
        Me.Panel4 = New System.Windows.Forms.Panel()
        Me.pnl_Config_1_UserApproval_chk = New System.Windows.Forms.CheckBox()
        Me.pnl_Config_1_UserApproval_rdo1 = New System.Windows.Forms.RadioButton()
        Me.pnl_Config_1_UserApproval_rdo2 = New System.Windows.Forms.RadioButton()
        Me.pnl_files_path_receive = New System.Windows.Forms.TextBox()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.pnl_Config_2_Rdo1 = New System.Windows.Forms.RadioButton()
        Me.pnl_Config_2_Rdo2 = New System.Windows.Forms.RadioButton()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.pnl_Config_3_wsURL = New System.Windows.Forms.TextBox()
        Me.pnl_Config_3_wsProtocol = New System.Windows.Forms.ComboBox()
        Me.pnl_Config_3_wsProtocol_lbl = New System.Windows.Forms.Label()
        Me.pnl_Config_1_txt_ID = New System.Windows.Forms.TextBox()
        Me.Label31 = New System.Windows.Forms.Label()
        Me.pnl_Config_1_pnl1 = New System.Windows.Forms.Panel()
        Me.pnl_Config_1_pnl1_rdo2 = New System.Windows.Forms.RadioButton()
        Me.pnl_Config_1_pnl1_rdo1 = New System.Windows.Forms.RadioButton()
        Me.pnl_Config_3_wsURL_lbl = New System.Windows.Forms.Label()
        Me.Button7 = New System.Windows.Forms.Button()
        Me.lbl1 = New System.Windows.Forms.Label()
        Me.pnl_Config_3 = New System.Windows.Forms.Panel()
        Me.pnl_Config_3_chkAllowClipboardReceive = New System.Windows.Forms.CheckBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.pnl_Config_3_chkAllowClipboardSend = New System.Windows.Forms.CheckBox()
        Me.pnl_Config_3_chkAllowFilesReceive = New System.Windows.Forms.CheckBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.pnl_Config_3_chkAllowFilesSend = New System.Windows.Forms.CheckBox()
        Me.CheckBox2 = New System.Windows.Forms.CheckBox()
        Me.pnl_Config_3_Start_CloseConnection_chk2 = New System.Windows.Forms.CheckBox()
        Me.pnl_Config_3_Start_ViewControl_dd_Quality = New System.Windows.Forms.ComboBox()
        Me.pnl_Config_3_Start_ViewControl_chk2 = New System.Windows.Forms.CheckBox()
        Me.pnl_Config_3_Start_ViewControl_chk3 = New System.Windows.Forms.CheckBox()
        Me.pnl_Config_3_Start_ViewControl_chk1 = New System.Windows.Forms.CheckBox()
        Me.Label38 = New System.Windows.Forms.Label()
        Me.pnl_Config_3_Start_Actions_chk1 = New System.Windows.Forms.CheckBox()
        Me.pnl_Config_3_Start_Actions_chk2 = New System.Windows.Forms.CheckBox()
        Me.Label33 = New System.Windows.Forms.Label()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.Label34 = New System.Windows.Forms.Label()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.Label37 = New System.Windows.Forms.Label()
        Me.lbl_AppVersion = New System.Windows.Forms.Label()
        Me.lbl_AppStatus = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.tmrUserApproval = New System.Windows.Forms.Timer(Me.components)
        Me.pnl_Config_1_btn_password_MyPC = New System.Windows.Forms.Button()
        Me.pnl_Config_1_txt_password_myPC = New System.Windows.Forms.TextBox()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Label30 = New System.Windows.Forms.Label()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.pnl_Config_1_chk_password_MyPC = New System.Windows.Forms.CheckBox()
        Me.pnl_Config_1_btn_password_UIAccess = New System.Windows.Forms.Button()
        Me.pnl_Config_1_txt_password_UIAccess = New System.Windows.Forms.TextBox()
        Me.Label25 = New System.Windows.Forms.Label()
        Me.pnl_Config_1_chk_password_UIAccess = New System.Windows.Forms.CheckBox()
        Me.pnl_Config_1_btn_password_Config = New System.Windows.Forms.Button()
        Me.pnl_Config_1_txt_password_config = New System.Windows.Forms.TextBox()
        Me.Label28 = New System.Windows.Forms.Label()
        Me.pnl_Config_1_chk_password_config = New System.Windows.Forms.CheckBox()
        Me.pnl_Config_2 = New System.Windows.Forms.Panel()
        Me.pnl_Config_1_chk_password_Exit = New System.Windows.Forms.CheckBox()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.pnl_Config_1_txt_password_Exit = New System.Windows.Forms.TextBox()
        Me.pnl_Config_1_btn_password_Exit = New System.Windows.Forms.Button()
        Me.tmrAllOnlineStatus = New System.Windows.Forms.Timer(Me.components)
        Me.txt_Search = New System.Windows.Forms.TextBox()
        Me.pnlFolderPCs = New System.Windows.Forms.Panel()
        Me.pnl_NewPC.SuspendLayout()
        Me.Panel6.SuspendLayout()
        Me.pnl_NewFolder.SuspendLayout()
        Me.pnl_TopManu.SuspendLayout()
        Me.pnl_Icon4.SuspendLayout()
        CType(Me.pnl_Icon4_img, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.pnl_Icon1.SuspendLayout()
        Me.pnl_Icon7.SuspendLayout()
        CType(Me.pnl_Icon7_img, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.pnl_status.SuspendLayout()
        CType(Me.pnl_status_PC1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pnl_status_icon, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pnl_status_wire_remotePC, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pnl_status_wire_MyPC, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.pnl_Config_1.SuspendLayout()
        Me.Panel4.SuspendLayout()
        Me.Panel1.SuspendLayout()
        Me.pnl_Config_1_pnl1.SuspendLayout()
        Me.pnl_Config_3.SuspendLayout()
        Me.Panel2.SuspendLayout()
        Me.pnl_Config_2.SuspendLayout()
        Me.pnlFolderPCs.SuspendLayout()
        Me.SuspendLayout()
        '
        'btn_fileLocation
        '
        Me.btn_fileLocation.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.btn_fileLocation.Font = New System.Drawing.Font("Calibri", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_fileLocation.Location = New System.Drawing.Point(423, 141)
        Me.btn_fileLocation.Name = "btn_fileLocation"
        Me.btn_fileLocation.Size = New System.Drawing.Size(118, 32)
        Me.btn_fileLocation.TabIndex = 16
        Me.btn_fileLocation.Text = "Change"
        Me.btn_fileLocation.UseVisualStyleBackColor = False
        '
        'treeObj
        '
        Me.treeObj.AllowDrop = True
        Me.treeObj.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.treeObj.HideSelection = False
        Me.treeObj.HotTracking = True
        Me.treeObj.ImageIndex = 0
        Me.treeObj.ImageList = Me.TreeViewImgs
        Me.treeObj.Location = New System.Drawing.Point(-1, 38)
        Me.treeObj.Name = "treeObj"
        Me.treeObj.SelectedImageIndex = 0
        Me.treeObj.Size = New System.Drawing.Size(275, 454)
        Me.treeObj.TabIndex = 21
        '
        'TreeViewImgs
        '
        Me.TreeViewImgs.ImageStream = CType(resources.GetObject("TreeViewImgs.ImageStream"), System.Windows.Forms.ImageListStreamer)
        Me.TreeViewImgs.TransparentColor = System.Drawing.Color.Transparent
        Me.TreeViewImgs.Images.SetKeyName(0, "foldericon.png")
        Me.TreeViewImgs.Images.SetKeyName(1, "PC_Offline.png")
        Me.TreeViewImgs.Images.SetKeyName(2, "PC_Online.png")
        Me.TreeViewImgs.Images.SetKeyName(3, "PC_Connected.png")
        '
        'btn_option1
        '
        Me.btn_option1.AutoEllipsis = True
        Me.btn_option1.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.btn_option1.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btn_option1.Font = New System.Drawing.Font("Calibri", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_option1.Location = New System.Drawing.Point(289, 8)
        Me.btn_option1.Name = "btn_option1"
        Me.btn_option1.Size = New System.Drawing.Size(136, 32)
        Me.btn_option1.TabIndex = 24
        Me.btn_option1.Text = "Option1"
        Me.btn_option1.UseVisualStyleBackColor = False
        '
        'btn_option2
        '
        Me.btn_option2.AutoEllipsis = True
        Me.btn_option2.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.btn_option2.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btn_option2.Location = New System.Drawing.Point(430, 8)
        Me.btn_option2.Name = "btn_option2"
        Me.btn_option2.Size = New System.Drawing.Size(136, 32)
        Me.btn_option2.TabIndex = 25
        Me.btn_option2.Text = "Option2"
        Me.btn_option2.UseVisualStyleBackColor = False
        '
        'btn_option4
        '
        Me.btn_option4.AutoEllipsis = True
        Me.btn_option4.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.btn_option4.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btn_option4.Location = New System.Drawing.Point(711, 8)
        Me.btn_option4.Name = "btn_option4"
        Me.btn_option4.Size = New System.Drawing.Size(136, 32)
        Me.btn_option4.TabIndex = 27
        Me.btn_option4.Text = "Send SAS"
        Me.btn_option4.UseVisualStyleBackColor = False
        '
        'btn_option3
        '
        Me.btn_option3.AutoEllipsis = True
        Me.btn_option3.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.btn_option3.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btn_option3.Location = New System.Drawing.Point(570, 8)
        Me.btn_option3.Name = "btn_option3"
        Me.btn_option3.Size = New System.Drawing.Size(136, 32)
        Me.btn_option3.TabIndex = 28
        Me.btn_option3.Text = "Option3"
        Me.btn_option3.UseVisualStyleBackColor = False
        '
        'pnl_NewPC
        '
        Me.pnl_NewPC.BackColor = System.Drawing.Color.White
        Me.pnl_NewPC.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.pnl_NewPC.Controls.Add(Me.pnl_NewPC_txt_Dateadded)
        Me.pnl_NewPC.Controls.Add(Me.Label6)
        Me.pnl_NewPC.Controls.Add(Me.pnl_NewPC_txt_Username)
        Me.pnl_NewPC.Controls.Add(Me.Label2)
        Me.pnl_NewPC.Controls.Add(Me.Panel6)
        Me.pnl_NewPC.Controls.Add(Me.Label26)
        Me.pnl_NewPC.Controls.Add(Me.pnl_NewPC_txt_NetBIOSName)
        Me.pnl_NewPC.Controls.Add(Me.Label24)
        Me.pnl_NewPC.Controls.Add(Me.pnl_NewPC_Txt_FolderParent)
        Me.pnl_NewPC.Controls.Add(Me.Label23)
        Me.pnl_NewPC.Controls.Add(Me.pnl_NewPC_btn_PWDShow)
        Me.pnl_NewPC.Controls.Add(Me.pnl_NewPC_txt_PCPassword)
        Me.pnl_NewPC.Controls.Add(Me.pnl_NewPC_lbl2)
        Me.pnl_NewPC.Controls.Add(Me.pnl_NewPC_btn_add)
        Me.pnl_NewPC.Controls.Add(Me.pnl_NewPC_txt_PCIP)
        Me.pnl_NewPC.Controls.Add(Me.pnl_NewPC_lbl1)
        Me.pnl_NewPC.Controls.Add(Me.Label15)
        Me.pnl_NewPC.Controls.Add(Me.pnl_NewPC_txt_PCName)
        Me.pnl_NewPC.Controls.Add(Me.Label17)
        Me.pnl_NewPC.Location = New System.Drawing.Point(289, 46)
        Me.pnl_NewPC.Name = "pnl_NewPC"
        Me.pnl_NewPC.Size = New System.Drawing.Size(558, 353)
        Me.pnl_NewPC.TabIndex = 30
        '
        'pnl_NewPC_txt_Dateadded
        '
        Me.pnl_NewPC_txt_Dateadded.Location = New System.Drawing.Point(140, 277)
        Me.pnl_NewPC_txt_Dateadded.Name = "pnl_NewPC_txt_Dateadded"
        Me.pnl_NewPC_txt_Dateadded.Size = New System.Drawing.Size(249, 24)
        Me.pnl_NewPC_txt_Dateadded.TabIndex = 40
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(17, 277)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(90, 18)
        Me.Label6.TabIndex = 39
        Me.Label6.Text = "Time  Added:"
        '
        'pnl_NewPC_txt_Username
        '
        Me.pnl_NewPC_txt_Username.Location = New System.Drawing.Point(140, 210)
        Me.pnl_NewPC_txt_Username.Name = "pnl_NewPC_txt_Username"
        Me.pnl_NewPC_txt_Username.Size = New System.Drawing.Size(249, 24)
        Me.pnl_NewPC_txt_Username.TabIndex = 38
        Me.pnl_NewPC_txt_Username.Text = "Connect once to get name"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(17, 210)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(75, 18)
        Me.Label2.TabIndex = 37
        Me.Label2.Text = "Username:"
        '
        'Panel6
        '
        Me.Panel6.Controls.Add(Me.pnl_NewPC_rdo2)
        Me.Panel6.Controls.Add(Me.pnl_NewPC_rdo1)
        Me.Panel6.Location = New System.Drawing.Point(434, 230)
        Me.Panel6.Name = "Panel6"
        Me.Panel6.Size = New System.Drawing.Size(246, 26)
        Me.Panel6.TabIndex = 36
        '
        'pnl_NewPC_rdo2
        '
        Me.pnl_NewPC_rdo2.AutoSize = True
        Me.pnl_NewPC_rdo2.Checked = True
        Me.pnl_NewPC_rdo2.Location = New System.Drawing.Point(3, 2)
        Me.pnl_NewPC_rdo2.Name = "pnl_NewPC_rdo2"
        Me.pnl_NewPC_rdo2.Size = New System.Drawing.Size(111, 22)
        Me.pnl_NewPC_rdo2.TabIndex = 1
        Me.pnl_NewPC_rdo2.TabStop = True
        Me.pnl_NewPC_rdo2.Text = "Online Server"
        Me.pnl_NewPC_rdo2.UseVisualStyleBackColor = True
        Me.pnl_NewPC_rdo2.Visible = False
        '
        'pnl_NewPC_rdo1
        '
        Me.pnl_NewPC_rdo1.AutoSize = True
        Me.pnl_NewPC_rdo1.Location = New System.Drawing.Point(149, 2)
        Me.pnl_NewPC_rdo1.Name = "pnl_NewPC_rdo1"
        Me.pnl_NewPC_rdo1.Size = New System.Drawing.Size(91, 22)
        Me.pnl_NewPC_rdo1.TabIndex = 0
        Me.pnl_NewPC_rdo1.Text = "IP Address"
        Me.pnl_NewPC_rdo1.UseVisualStyleBackColor = True
        '
        'Label26
        '
        Me.Label26.AutoSize = True
        Me.Label26.Location = New System.Drawing.Point(437, 254)
        Me.Label26.Name = "Label26"
        Me.Label26.Size = New System.Drawing.Size(114, 18)
        Me.Label26.TabIndex = 32
        Me.Label26.Text = "Connection Type:"
        Me.Label26.Visible = False
        '
        'pnl_NewPC_txt_NetBIOSName
        '
        Me.pnl_NewPC_txt_NetBIOSName.Location = New System.Drawing.Point(140, 243)
        Me.pnl_NewPC_txt_NetBIOSName.Name = "pnl_NewPC_txt_NetBIOSName"
        Me.pnl_NewPC_txt_NetBIOSName.Size = New System.Drawing.Size(249, 24)
        Me.pnl_NewPC_txt_NetBIOSName.TabIndex = 28
        Me.pnl_NewPC_txt_NetBIOSName.Text = "Connect once to get name"
        '
        'Label24
        '
        Me.Label24.AutoSize = True
        Me.Label24.Location = New System.Drawing.Point(17, 243)
        Me.Label24.Name = "Label24"
        Me.Label24.Size = New System.Drawing.Size(104, 18)
        Me.Label24.TabIndex = 31
        Me.Label24.Text = "NetBIOS Name:"
        '
        'pnl_NewPC_Txt_FolderParent
        '
        Me.pnl_NewPC_Txt_FolderParent.Location = New System.Drawing.Point(142, 44)
        Me.pnl_NewPC_Txt_FolderParent.Name = "pnl_NewPC_Txt_FolderParent"
        Me.pnl_NewPC_Txt_FolderParent.ReadOnly = True
        Me.pnl_NewPC_Txt_FolderParent.Size = New System.Drawing.Size(246, 26)
        Me.pnl_NewPC_Txt_FolderParent.TabIndex = 28
        '
        'Label23
        '
        Me.Label23.AutoSize = True
        Me.Label23.Location = New System.Drawing.Point(17, 47)
        Me.Label23.Name = "Label23"
        Me.Label23.Size = New System.Drawing.Size(96, 18)
        Me.Label23.TabIndex = 29
        Me.Label23.Text = "Parent Folder:"
        '
        'pnl_NewPC_btn_PWDShow
        '
        Me.pnl_NewPC_btn_PWDShow.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.pnl_NewPC_btn_PWDShow.Location = New System.Drawing.Point(421, 121)
        Me.pnl_NewPC_btn_PWDShow.Name = "pnl_NewPC_btn_PWDShow"
        Me.pnl_NewPC_btn_PWDShow.Size = New System.Drawing.Size(118, 32)
        Me.pnl_NewPC_btn_PWDShow.TabIndex = 27
        Me.pnl_NewPC_btn_PWDShow.Text = "Show"
        Me.pnl_NewPC_btn_PWDShow.UseVisualStyleBackColor = False
        '
        'pnl_NewPC_txt_PCPassword
        '
        Me.pnl_NewPC_txt_PCPassword.Location = New System.Drawing.Point(142, 123)
        Me.pnl_NewPC_txt_PCPassword.Name = "pnl_NewPC_txt_PCPassword"
        Me.pnl_NewPC_txt_PCPassword.Size = New System.Drawing.Size(246, 26)
        Me.pnl_NewPC_txt_PCPassword.TabIndex = 24
        Me.pnl_NewPC_txt_PCPassword.UseSystemPasswordChar = True
        '
        'pnl_NewPC_lbl2
        '
        Me.pnl_NewPC_lbl2.AutoSize = True
        Me.pnl_NewPC_lbl2.Location = New System.Drawing.Point(16, 126)
        Me.pnl_NewPC_lbl2.Name = "pnl_NewPC_lbl2"
        Me.pnl_NewPC_lbl2.Size = New System.Drawing.Size(71, 18)
        Me.pnl_NewPC_lbl2.TabIndex = 23
        Me.pnl_NewPC_lbl2.Text = "Password:"
        '
        'pnl_NewPC_btn_add
        '
        Me.pnl_NewPC_btn_add.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.pnl_NewPC_btn_add.Location = New System.Drawing.Point(423, 306)
        Me.pnl_NewPC_btn_add.Name = "pnl_NewPC_btn_add"
        Me.pnl_NewPC_btn_add.Size = New System.Drawing.Size(118, 32)
        Me.pnl_NewPC_btn_add.TabIndex = 22
        Me.pnl_NewPC_btn_add.Text = "Add"
        Me.pnl_NewPC_btn_add.UseVisualStyleBackColor = False
        '
        'pnl_NewPC_txt_PCIP
        '
        Me.pnl_NewPC_txt_PCIP.Location = New System.Drawing.Point(142, 165)
        Me.pnl_NewPC_txt_PCIP.Name = "pnl_NewPC_txt_PCIP"
        Me.pnl_NewPC_txt_PCIP.Size = New System.Drawing.Size(246, 26)
        Me.pnl_NewPC_txt_PCIP.TabIndex = 21
        '
        'pnl_NewPC_lbl1
        '
        Me.pnl_NewPC_lbl1.AutoSize = True
        Me.pnl_NewPC_lbl1.Location = New System.Drawing.Point(17, 168)
        Me.pnl_NewPC_lbl1.Name = "pnl_NewPC_lbl1"
        Me.pnl_NewPC_lbl1.Size = New System.Drawing.Size(81, 18)
        Me.pnl_NewPC_lbl1.TabIndex = 20
        Me.pnl_NewPC_lbl1.Text = "Network IP:"
        '
        'Label15
        '
        Me.Label15.BackColor = System.Drawing.Color.LightSteelBlue
        Me.Label15.ForeColor = System.Drawing.Color.Black
        Me.Label15.Location = New System.Drawing.Point(0, -1)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(558, 32)
        Me.Label15.TabIndex = 19
        Me.Label15.Text = "Remote PC Details"
        Me.Label15.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'pnl_NewPC_txt_PCName
        '
        Me.pnl_NewPC_txt_PCName.Location = New System.Drawing.Point(142, 80)
        Me.pnl_NewPC_txt_PCName.Name = "pnl_NewPC_txt_PCName"
        Me.pnl_NewPC_txt_PCName.Size = New System.Drawing.Size(246, 26)
        Me.pnl_NewPC_txt_PCName.TabIndex = 2
        '
        'Label17
        '
        Me.Label17.AutoSize = True
        Me.Label17.Location = New System.Drawing.Point(17, 83)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(68, 18)
        Me.Label17.TabIndex = 14
        Me.Label17.Text = "PC Name:"
        '
        'pnl_NewFolder
        '
        Me.pnl_NewFolder.BackColor = System.Drawing.Color.White
        Me.pnl_NewFolder.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.pnl_NewFolder.Controls.Add(Me.btnFolder_MoveDown)
        Me.pnl_NewFolder.Controls.Add(Me.btnFolder_MoveUp)
        Me.pnl_NewFolder.Controls.Add(Me.pnl_NewFolder_chk_isRoot)
        Me.pnl_NewFolder.Controls.Add(Me.pnl_NewFolder_lbl_folders)
        Me.pnl_NewFolder.Controls.Add(Me.pnl_NewFolder_lbl_PCs)
        Me.pnl_NewFolder.Controls.Add(Me.Label22)
        Me.pnl_NewFolder.Controls.Add(Me.pnl_NewFolder_Txt_FolderParent)
        Me.pnl_NewFolder.Controls.Add(Me.Label18)
        Me.pnl_NewFolder.Controls.Add(Me.pnl_NewFolder_btn_Add)
        Me.pnl_NewFolder.Controls.Add(Me.Label19)
        Me.pnl_NewFolder.Controls.Add(Me.pnl_NewFolder_Txt_FolderName)
        Me.pnl_NewFolder.Controls.Add(Me.Label20)
        Me.pnl_NewFolder.Location = New System.Drawing.Point(289, 46)
        Me.pnl_NewFolder.Name = "pnl_NewFolder"
        Me.pnl_NewFolder.Size = New System.Drawing.Size(558, 353)
        Me.pnl_NewFolder.TabIndex = 32
        '
        'btnFolder_MoveDown
        '
        Me.btnFolder_MoveDown.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.btnFolder_MoveDown.Location = New System.Drawing.Point(20, 234)
        Me.btnFolder_MoveDown.Name = "btnFolder_MoveDown"
        Me.btnFolder_MoveDown.Size = New System.Drawing.Size(60, 50)
        Me.btnFolder_MoveDown.TabIndex = 39
        Me.btnFolder_MoveDown.Text = "Move" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "Down"
        Me.btnFolder_MoveDown.UseVisualStyleBackColor = False
        '
        'btnFolder_MoveUp
        '
        Me.btnFolder_MoveUp.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.btnFolder_MoveUp.Location = New System.Drawing.Point(20, 176)
        Me.btnFolder_MoveUp.Name = "btnFolder_MoveUp"
        Me.btnFolder_MoveUp.Size = New System.Drawing.Size(60, 50)
        Me.btnFolder_MoveUp.TabIndex = 38
        Me.btnFolder_MoveUp.Text = "Move" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "Up"
        Me.btnFolder_MoveUp.UseVisualStyleBackColor = False
        '
        'pnl_NewFolder_chk_isRoot
        '
        Me.pnl_NewFolder_chk_isRoot.AutoSize = True
        Me.pnl_NewFolder_chk_isRoot.Location = New System.Drawing.Point(421, 45)
        Me.pnl_NewFolder_chk_isRoot.Name = "pnl_NewFolder_chk_isRoot"
        Me.pnl_NewFolder_chk_isRoot.Size = New System.Drawing.Size(99, 22)
        Me.pnl_NewFolder_chk_isRoot.TabIndex = 37
        Me.pnl_NewFolder_chk_isRoot.Text = "Root Folder"
        Me.pnl_NewFolder_chk_isRoot.UseVisualStyleBackColor = True
        '
        'pnl_NewFolder_lbl_folders
        '
        Me.pnl_NewFolder_lbl_folders.Location = New System.Drawing.Point(145, 129)
        Me.pnl_NewFolder_lbl_folders.Name = "pnl_NewFolder_lbl_folders"
        Me.pnl_NewFolder_lbl_folders.Size = New System.Drawing.Size(126, 24)
        Me.pnl_NewFolder_lbl_folders.TabIndex = 27
        Me.pnl_NewFolder_lbl_folders.Text = "Folders:"
        '
        'pnl_NewFolder_lbl_PCs
        '
        Me.pnl_NewFolder_lbl_PCs.Location = New System.Drawing.Point(278, 129)
        Me.pnl_NewFolder_lbl_PCs.Name = "pnl_NewFolder_lbl_PCs"
        Me.pnl_NewFolder_lbl_PCs.Size = New System.Drawing.Size(97, 24)
        Me.pnl_NewFolder_lbl_PCs.TabIndex = 26
        Me.pnl_NewFolder_lbl_PCs.Text = "PCs: "
        '
        'Label22
        '
        Me.Label22.AutoSize = True
        Me.Label22.Location = New System.Drawing.Point(17, 129)
        Me.Label22.Name = "Label22"
        Me.Label22.Size = New System.Drawing.Size(65, 18)
        Me.Label22.TabIndex = 25
        Me.Label22.Text = "Statistics:"
        '
        'pnl_NewFolder_Txt_FolderParent
        '
        Me.pnl_NewFolder_Txt_FolderParent.Location = New System.Drawing.Point(145, 44)
        Me.pnl_NewFolder_Txt_FolderParent.Name = "pnl_NewFolder_Txt_FolderParent"
        Me.pnl_NewFolder_Txt_FolderParent.ReadOnly = True
        Me.pnl_NewFolder_Txt_FolderParent.Size = New System.Drawing.Size(246, 26)
        Me.pnl_NewFolder_Txt_FolderParent.TabIndex = 23
        '
        'Label18
        '
        Me.Label18.AutoSize = True
        Me.Label18.Location = New System.Drawing.Point(17, 47)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(96, 18)
        Me.Label18.TabIndex = 24
        Me.Label18.Text = "Parent Folder:"
        '
        'pnl_NewFolder_btn_Add
        '
        Me.pnl_NewFolder_btn_Add.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.pnl_NewFolder_btn_Add.Location = New System.Drawing.Point(421, 123)
        Me.pnl_NewFolder_btn_Add.Name = "pnl_NewFolder_btn_Add"
        Me.pnl_NewFolder_btn_Add.Size = New System.Drawing.Size(118, 32)
        Me.pnl_NewFolder_btn_Add.TabIndex = 22
        Me.pnl_NewFolder_btn_Add.Text = "Add"
        Me.pnl_NewFolder_btn_Add.UseVisualStyleBackColor = False
        '
        'Label19
        '
        Me.Label19.BackColor = System.Drawing.Color.LightSteelBlue
        Me.Label19.ForeColor = System.Drawing.Color.Black
        Me.Label19.Location = New System.Drawing.Point(0, -1)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(558, 32)
        Me.Label19.TabIndex = 19
        Me.Label19.Text = "Folder Details"
        Me.Label19.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'pnl_NewFolder_Txt_FolderName
        '
        Me.pnl_NewFolder_Txt_FolderName.Location = New System.Drawing.Point(145, 82)
        Me.pnl_NewFolder_Txt_FolderName.Name = "pnl_NewFolder_Txt_FolderName"
        Me.pnl_NewFolder_Txt_FolderName.Size = New System.Drawing.Size(246, 26)
        Me.pnl_NewFolder_Txt_FolderName.TabIndex = 2
        '
        'Label20
        '
        Me.Label20.AutoSize = True
        Me.Label20.Location = New System.Drawing.Point(17, 85)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(92, 18)
        Me.Label20.TabIndex = 14
        Me.Label20.Text = "Folder Name:"
        '
        'lbl_TreeStats_PCs
        '
        Me.lbl_TreeStats_PCs.BackColor = System.Drawing.Color.FromArgb(CType(CType(76, Byte), Integer), CType(CType(76, Byte), Integer), CType(CType(76, Byte), Integer))
        Me.lbl_TreeStats_PCs.Font = New System.Drawing.Font("Calibri", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_TreeStats_PCs.ForeColor = System.Drawing.Color.White
        Me.lbl_TreeStats_PCs.Location = New System.Drawing.Point(134, -1)
        Me.lbl_TreeStats_PCs.Name = "lbl_TreeStats_PCs"
        Me.lbl_TreeStats_PCs.Size = New System.Drawing.Size(140, 32)
        Me.lbl_TreeStats_PCs.TabIndex = 34
        Me.lbl_TreeStats_PCs.Text = "PCs:"
        Me.lbl_TreeStats_PCs.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lbl_TreeStats_Folders
        '
        Me.lbl_TreeStats_Folders.BackColor = System.Drawing.Color.FromArgb(CType(CType(76, Byte), Integer), CType(CType(76, Byte), Integer), CType(CType(76, Byte), Integer))
        Me.lbl_TreeStats_Folders.Font = New System.Drawing.Font("Calibri", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_TreeStats_Folders.ForeColor = System.Drawing.Color.White
        Me.lbl_TreeStats_Folders.Location = New System.Drawing.Point(-1, -1)
        Me.lbl_TreeStats_Folders.Name = "lbl_TreeStats_Folders"
        Me.lbl_TreeStats_Folders.Size = New System.Drawing.Size(139, 32)
        Me.lbl_TreeStats_Folders.TabIndex = 35
        Me.lbl_TreeStats_Folders.Text = "Folders:"
        Me.lbl_TreeStats_Folders.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'pnl_TopManu
        '
        Me.pnl_TopManu.BackColor = System.Drawing.Color.White
        Me.pnl_TopManu.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.pnl_TopManu.Controls.Add(Me.pnl_Icon4)
        Me.pnl_TopManu.Controls.Add(Me.pnl_Icon1)
        Me.pnl_TopManu.Location = New System.Drawing.Point(289, 410)
        Me.pnl_TopManu.Name = "pnl_TopManu"
        Me.pnl_TopManu.Size = New System.Drawing.Size(383, 91)
        Me.pnl_TopManu.TabIndex = 36
        '
        'pnl_Icon4
        '
        Me.pnl_Icon4.Controls.Add(Me.btn_Install)
        Me.pnl_Icon4.Controls.Add(Me.pnl_Icon4_img)
        Me.pnl_Icon4.Location = New System.Drawing.Point(253, -1)
        Me.pnl_Icon4.Name = "pnl_Icon4"
        Me.pnl_Icon4.Size = New System.Drawing.Size(130, 91)
        Me.pnl_Icon4.TabIndex = 31
        '
        'btn_Install
        '
        Me.btn_Install.Location = New System.Drawing.Point(-3, 65)
        Me.btn_Install.Name = "btn_Install"
        Me.btn_Install.Size = New System.Drawing.Size(131, 18)
        Me.btn_Install.TabIndex = 20
        Me.btn_Install.Text = "Install Service"
        Me.btn_Install.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btn_Install.UseMnemonic = False
        '
        'pnl_Icon4_img
        '
        Me.pnl_Icon4_img.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.pnl_Icon4_img.Image = Global.AlSooz_RemotePC_VB.My.Resources.Resources.install
        Me.pnl_Icon4_img.Location = New System.Drawing.Point(15, 3)
        Me.pnl_Icon4_img.Name = "pnl_Icon4_img"
        Me.pnl_Icon4_img.Size = New System.Drawing.Size(93, 60)
        Me.pnl_Icon4_img.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage
        Me.pnl_Icon4_img.TabIndex = 0
        Me.pnl_Icon4_img.TabStop = False
        '
        'pnl_Icon1
        '
        Me.pnl_Icon1.Controls.Add(Me.myPcStatus_lbl_Unattended_2)
        Me.pnl_Icon1.Controls.Add(Me.myPcStatus_lbl_Unattended_1)
        Me.pnl_Icon1.Controls.Add(Me.myPcStatus_lbl_Service_1)
        Me.pnl_Icon1.Controls.Add(Me.myPcStatus_lbl_Service_2)
        Me.pnl_Icon1.Location = New System.Drawing.Point(-1, -1)
        Me.pnl_Icon1.Name = "pnl_Icon1"
        Me.pnl_Icon1.Size = New System.Drawing.Size(262, 91)
        Me.pnl_Icon1.TabIndex = 29
        '
        'myPcStatus_lbl_Unattended_2
        '
        Me.myPcStatus_lbl_Unattended_2.Font = New System.Drawing.Font("Calibri", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.myPcStatus_lbl_Unattended_2.Location = New System.Drawing.Point(122, 50)
        Me.myPcStatus_lbl_Unattended_2.Name = "myPcStatus_lbl_Unattended_2"
        Me.myPcStatus_lbl_Unattended_2.Size = New System.Drawing.Size(150, 18)
        Me.myPcStatus_lbl_Unattended_2.TabIndex = 38
        Me.myPcStatus_lbl_Unattended_2.Text = "Deactivated"
        Me.myPcStatus_lbl_Unattended_2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'myPcStatus_lbl_Unattended_1
        '
        Me.myPcStatus_lbl_Unattended_1.Location = New System.Drawing.Point(5, 50)
        Me.myPcStatus_lbl_Unattended_1.Name = "myPcStatus_lbl_Unattended_1"
        Me.myPcStatus_lbl_Unattended_1.Size = New System.Drawing.Size(114, 18)
        Me.myPcStatus_lbl_Unattended_1.TabIndex = 37
        Me.myPcStatus_lbl_Unattended_1.Text = "Connection:"
        Me.myPcStatus_lbl_Unattended_1.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'myPcStatus_lbl_Service_1
        '
        Me.myPcStatus_lbl_Service_1.Location = New System.Drawing.Point(5, 18)
        Me.myPcStatus_lbl_Service_1.Name = "myPcStatus_lbl_Service_1"
        Me.myPcStatus_lbl_Service_1.Size = New System.Drawing.Size(114, 18)
        Me.myPcStatus_lbl_Service_1.TabIndex = 29
        Me.myPcStatus_lbl_Service_1.Text = "Admin Service:"
        Me.myPcStatus_lbl_Service_1.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'myPcStatus_lbl_Service_2
        '
        Me.myPcStatus_lbl_Service_2.Font = New System.Drawing.Font("Calibri", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.myPcStatus_lbl_Service_2.Location = New System.Drawing.Point(122, 18)
        Me.myPcStatus_lbl_Service_2.Name = "myPcStatus_lbl_Service_2"
        Me.myPcStatus_lbl_Service_2.Size = New System.Drawing.Size(150, 18)
        Me.myPcStatus_lbl_Service_2.TabIndex = 30
        Me.myPcStatus_lbl_Service_2.Text = "Not Installed"
        Me.myPcStatus_lbl_Service_2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'pnl_Icon7
        '
        Me.pnl_Icon7.BackColor = System.Drawing.Color.White
        Me.pnl_Icon7.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.pnl_Icon7.Controls.Add(Me.pnl_Icon7_lbl)
        Me.pnl_Icon7.Controls.Add(Me.pnl_Icon7_img)
        Me.pnl_Icon7.Location = New System.Drawing.Point(678, 410)
        Me.pnl_Icon7.Name = "pnl_Icon7"
        Me.pnl_Icon7.Size = New System.Drawing.Size(170, 91)
        Me.pnl_Icon7.TabIndex = 31
        '
        'pnl_Icon7_lbl
        '
        Me.pnl_Icon7_lbl.Location = New System.Drawing.Point(17, 65)
        Me.pnl_Icon7_lbl.Name = "pnl_Icon7_lbl"
        Me.pnl_Icon7_lbl.Size = New System.Drawing.Size(133, 18)
        Me.pnl_Icon7_lbl.TabIndex = 20
        Me.pnl_Icon7_lbl.Text = "Configuration"
        Me.pnl_Icon7_lbl.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'pnl_Icon7_img
        '
        Me.pnl_Icon7_img.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.pnl_Icon7_img.Image = CType(resources.GetObject("pnl_Icon7_img.Image"), System.Drawing.Image)
        Me.pnl_Icon7_img.Location = New System.Drawing.Point(37, 3)
        Me.pnl_Icon7_img.Name = "pnl_Icon7_img"
        Me.pnl_Icon7_img.Size = New System.Drawing.Size(93, 60)
        Me.pnl_Icon7_img.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage
        Me.pnl_Icon7_img.TabIndex = 0
        Me.pnl_Icon7_img.TabStop = False
        '
        'myPcStatus_lbl_RemoteID_2
        '
        Me.myPcStatus_lbl_RemoteID_2.Cursor = System.Windows.Forms.Cursors.Hand
        Me.myPcStatus_lbl_RemoteID_2.Font = New System.Drawing.Font("Calibri", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.myPcStatus_lbl_RemoteID_2.Location = New System.Drawing.Point(372, 202)
        Me.myPcStatus_lbl_RemoteID_2.Name = "myPcStatus_lbl_RemoteID_2"
        Me.myPcStatus_lbl_RemoteID_2.Size = New System.Drawing.Size(179, 18)
        Me.myPcStatus_lbl_RemoteID_2.TabIndex = 42
        Me.myPcStatus_lbl_RemoteID_2.Text = "19022023110103"
        Me.myPcStatus_lbl_RemoteID_2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'myPcStatus_lbl_MyID_2
        '
        Me.myPcStatus_lbl_MyID_2.Cursor = System.Windows.Forms.Cursors.Hand
        Me.myPcStatus_lbl_MyID_2.Font = New System.Drawing.Font("Calibri", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.myPcStatus_lbl_MyID_2.Location = New System.Drawing.Point(3, 201)
        Me.myPcStatus_lbl_MyID_2.Name = "myPcStatus_lbl_MyID_2"
        Me.myPcStatus_lbl_MyID_2.Size = New System.Drawing.Size(179, 18)
        Me.myPcStatus_lbl_MyID_2.TabIndex = 40
        Me.myPcStatus_lbl_MyID_2.Text = "Online ID"
        Me.myPcStatus_lbl_MyID_2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'myPcStatus_lbl_RemotePC_2
        '
        Me.myPcStatus_lbl_RemotePC_2.Font = New System.Drawing.Font("Calibri", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.myPcStatus_lbl_RemotePC_2.Location = New System.Drawing.Point(372, 161)
        Me.myPcStatus_lbl_RemotePC_2.Name = "myPcStatus_lbl_RemotePC_2"
        Me.myPcStatus_lbl_RemotePC_2.Size = New System.Drawing.Size(179, 42)
        Me.myPcStatus_lbl_RemotePC_2.TabIndex = 36
        Me.myPcStatus_lbl_RemotePC_2.Text = "Connected"
        Me.myPcStatus_lbl_RemotePC_2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'btn_Disconnect_RemotePC
        '
        Me.btn_Disconnect_RemotePC.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.btn_Disconnect_RemotePC.ForeColor = System.Drawing.Color.Crimson
        Me.btn_Disconnect_RemotePC.Location = New System.Drawing.Point(392, 253)
        Me.btn_Disconnect_RemotePC.Name = "btn_Disconnect_RemotePC"
        Me.btn_Disconnect_RemotePC.Size = New System.Drawing.Size(138, 36)
        Me.btn_Disconnect_RemotePC.TabIndex = 34
        Me.btn_Disconnect_RemotePC.Text = "Disconnect"
        Me.btn_Disconnect_RemotePC.UseVisualStyleBackColor = False
        '
        'myPcStatus_lbl_MyPC_2
        '
        Me.myPcStatus_lbl_MyPC_2.Font = New System.Drawing.Font("Calibri", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.myPcStatus_lbl_MyPC_2.Location = New System.Drawing.Point(3, 161)
        Me.myPcStatus_lbl_MyPC_2.Name = "myPcStatus_lbl_MyPC_2"
        Me.myPcStatus_lbl_MyPC_2.Size = New System.Drawing.Size(179, 42)
        Me.myPcStatus_lbl_MyPC_2.TabIndex = 33
        Me.myPcStatus_lbl_MyPC_2.Text = "Connected"
        Me.myPcStatus_lbl_MyPC_2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'btn_Disconnect_MyPC
        '
        Me.btn_Disconnect_MyPC.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.btn_Disconnect_MyPC.Location = New System.Drawing.Point(25, 252)
        Me.btn_Disconnect_MyPC.Name = "btn_Disconnect_MyPC"
        Me.btn_Disconnect_MyPC.Size = New System.Drawing.Size(138, 36)
        Me.btn_Disconnect_MyPC.TabIndex = 31
        Me.btn_Disconnect_MyPC.Text = "Disconnect"
        Me.btn_Disconnect_MyPC.UseVisualStyleBackColor = False
        '
        'pnl_status
        '
        Me.pnl_status.BackColor = System.Drawing.Color.White
        Me.pnl_status.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.pnl_status.Controls.Add(Me.txtdebug)
        Me.pnl_status.Controls.Add(Me.btnTaskmgr)
        Me.pnl_status.Controls.Add(Me.btn_ScreenControl_RemotePC)
        Me.pnl_status.Controls.Add(Me.btn_Files_RemotePC)
        Me.pnl_status.Controls.Add(Me.Label1)
        Me.pnl_status.Controls.Add(Me.myPcStatus_lbl_RemoteNetBIOS)
        Me.pnl_status.Controls.Add(Me.myPcStatus_lbl_MyNetBIOS)
        Me.pnl_status.Controls.Add(Me.myPcStatus_lbl_RemoteID_2)
        Me.pnl_status.Controls.Add(Me.myPcStatus_lbl_MyID_2)
        Me.pnl_status.Controls.Add(Me.btn_Disconnect_RemotePC)
        Me.pnl_status.Controls.Add(Me.pnl_status_lbl)
        Me.pnl_status.Controls.Add(Me.btn_Disconnect_MyPC)
        Me.pnl_status.Controls.Add(Me.pnl_status_PC1)
        Me.pnl_status.Controls.Add(Me.pnl_status_icon)
        Me.pnl_status.Controls.Add(Me.myPcStatus_lbl_RemotePC_2)
        Me.pnl_status.Controls.Add(Me.PictureBox1)
        Me.pnl_status.Controls.Add(Me.pnl_status_wire_remotePC)
        Me.pnl_status.Controls.Add(Me.pnl_status_wire_MyPC)
        Me.pnl_status.Controls.Add(Me.myPcStatus_lbl_MyPC_2)
        Me.pnl_status.Location = New System.Drawing.Point(289, 8)
        Me.pnl_status.Name = "pnl_status"
        Me.pnl_status.Size = New System.Drawing.Size(558, 391)
        Me.pnl_status.TabIndex = 38
        '
        'txtdebug
        '
        Me.txtdebug.BackColor = System.Drawing.Color.White
        Me.txtdebug.Location = New System.Drawing.Point(184, 192)
        Me.txtdebug.Multiline = True
        Me.txtdebug.Name = "txtdebug"
        Me.txtdebug.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.txtdebug.Size = New System.Drawing.Size(186, 186)
        Me.txtdebug.TabIndex = 50
        '
        'btnTaskmgr
        '
        Me.btnTaskmgr.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.btnTaskmgr.ForeColor = System.Drawing.SystemColors.ControlText
        Me.btnTaskmgr.Location = New System.Drawing.Point(25, 298)
        Me.btnTaskmgr.Name = "btnTaskmgr"
        Me.btnTaskmgr.Size = New System.Drawing.Size(138, 36)
        Me.btnTaskmgr.TabIndex = 49
        Me.btnTaskmgr.Text = "Task Manager"
        Me.btnTaskmgr.UseVisualStyleBackColor = False
        '
        'btn_ScreenControl_RemotePC
        '
        Me.btn_ScreenControl_RemotePC.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.btn_ScreenControl_RemotePC.ForeColor = System.Drawing.SystemColors.ControlText
        Me.btn_ScreenControl_RemotePC.Location = New System.Drawing.Point(392, 343)
        Me.btn_ScreenControl_RemotePC.Name = "btn_ScreenControl_RemotePC"
        Me.btn_ScreenControl_RemotePC.Size = New System.Drawing.Size(138, 36)
        Me.btn_ScreenControl_RemotePC.TabIndex = 47
        Me.btn_ScreenControl_RemotePC.Text = "Control PC"
        Me.btn_ScreenControl_RemotePC.UseVisualStyleBackColor = False
        '
        'btn_Files_RemotePC
        '
        Me.btn_Files_RemotePC.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.btn_Files_RemotePC.ForeColor = System.Drawing.SystemColors.ControlText
        Me.btn_Files_RemotePC.Location = New System.Drawing.Point(392, 298)
        Me.btn_Files_RemotePC.Name = "btn_Files_RemotePC"
        Me.btn_Files_RemotePC.Size = New System.Drawing.Size(138, 36)
        Me.btn_Files_RemotePC.TabIndex = 48
        Me.btn_Files_RemotePC.Text = "File Transfer"
        Me.btn_Files_RemotePC.UseVisualStyleBackColor = False
        '
        'Label1
        '
        Me.Label1.BackColor = System.Drawing.Color.FromArgb(CType(CType(76, Byte), Integer), CType(CType(76, Byte), Integer), CType(CType(76, Byte), Integer))
        Me.Label1.ForeColor = System.Drawing.Color.White
        Me.Label1.Location = New System.Drawing.Point(0, 0)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(560, 32)
        Me.Label1.TabIndex = 45
        Me.Label1.Text = "Connection Status"
        Me.Label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'myPcStatus_lbl_RemoteNetBIOS
        '
        Me.myPcStatus_lbl_RemoteNetBIOS.Cursor = System.Windows.Forms.Cursors.Hand
        Me.myPcStatus_lbl_RemoteNetBIOS.Font = New System.Drawing.Font("Calibri", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.myPcStatus_lbl_RemoteNetBIOS.ForeColor = System.Drawing.Color.Gray
        Me.myPcStatus_lbl_RemoteNetBIOS.Location = New System.Drawing.Point(372, 228)
        Me.myPcStatus_lbl_RemoteNetBIOS.Name = "myPcStatus_lbl_RemoteNetBIOS"
        Me.myPcStatus_lbl_RemoteNetBIOS.Size = New System.Drawing.Size(179, 18)
        Me.myPcStatus_lbl_RemoteNetBIOS.TabIndex = 46
        Me.myPcStatus_lbl_RemoteNetBIOS.Text = "Online ID"
        Me.myPcStatus_lbl_RemoteNetBIOS.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'myPcStatus_lbl_MyNetBIOS
        '
        Me.myPcStatus_lbl_MyNetBIOS.Cursor = System.Windows.Forms.Cursors.Hand
        Me.myPcStatus_lbl_MyNetBIOS.Font = New System.Drawing.Font("Calibri", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.myPcStatus_lbl_MyNetBIOS.ForeColor = System.Drawing.Color.Gray
        Me.myPcStatus_lbl_MyNetBIOS.Location = New System.Drawing.Point(3, 227)
        Me.myPcStatus_lbl_MyNetBIOS.Name = "myPcStatus_lbl_MyNetBIOS"
        Me.myPcStatus_lbl_MyNetBIOS.Size = New System.Drawing.Size(179, 18)
        Me.myPcStatus_lbl_MyNetBIOS.TabIndex = 45
        Me.myPcStatus_lbl_MyNetBIOS.Text = "PC Name"
        Me.myPcStatus_lbl_MyNetBIOS.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'pnl_status_lbl
        '
        Me.pnl_status_lbl.Font = New System.Drawing.Font("Verdana", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.pnl_status_lbl.Location = New System.Drawing.Point(187, 136)
        Me.pnl_status_lbl.Name = "pnl_status_lbl"
        Me.pnl_status_lbl.Size = New System.Drawing.Size(179, 44)
        Me.pnl_status_lbl.TabIndex = 21
        Me.pnl_status_lbl.Text = "Connected"
        Me.pnl_status_lbl.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'pnl_status_PC1
        '
        Me.pnl_status_PC1.Image = Global.AlSooz_RemotePC_VB.My.Resources.Resources.windowspc_local_new
        Me.pnl_status_PC1.Location = New System.Drawing.Point(25, 45)
        Me.pnl_status_PC1.Name = "pnl_status_PC1"
        Me.pnl_status_PC1.Size = New System.Drawing.Size(138, 120)
        Me.pnl_status_PC1.TabIndex = 0
        Me.pnl_status_PC1.TabStop = False
        '
        'pnl_status_icon
        '
        Me.pnl_status_icon.Image = CType(resources.GetObject("pnl_status_icon.Image"), System.Drawing.Image)
        Me.pnl_status_icon.Location = New System.Drawing.Point(244, 63)
        Me.pnl_status_icon.Name = "pnl_status_icon"
        Me.pnl_status_icon.Size = New System.Drawing.Size(67, 70)
        Me.pnl_status_icon.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize
        Me.pnl_status_icon.TabIndex = 2
        Me.pnl_status_icon.TabStop = False
        '
        'PictureBox1
        '
        Me.PictureBox1.Image = Global.AlSooz_RemotePC_VB.My.Resources.Resources.windowspc_remote_new
        Me.PictureBox1.Location = New System.Drawing.Point(390, 45)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(140, 120)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize
        Me.PictureBox1.TabIndex = 1
        Me.PictureBox1.TabStop = False
        '
        'pnl_status_wire_remotePC
        '
        Me.pnl_status_wire_remotePC.Image = CType(resources.GetObject("pnl_status_wire_remotePC.Image"), System.Drawing.Image)
        Me.pnl_status_wire_remotePC.InitialImage = CType(resources.GetObject("pnl_status_wire_remotePC.InitialImage"), System.Drawing.Image)
        Me.pnl_status_wire_remotePC.Location = New System.Drawing.Point(295, 74)
        Me.pnl_status_wire_remotePC.Name = "pnl_status_wire_remotePC"
        Me.pnl_status_wire_remotePC.Size = New System.Drawing.Size(118, 50)
        Me.pnl_status_wire_remotePC.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize
        Me.pnl_status_wire_remotePC.TabIndex = 4
        Me.pnl_status_wire_remotePC.TabStop = False
        '
        'pnl_status_wire_MyPC
        '
        Me.pnl_status_wire_MyPC.Image = CType(resources.GetObject("pnl_status_wire_MyPC.Image"), System.Drawing.Image)
        Me.pnl_status_wire_MyPC.InitialImage = CType(resources.GetObject("pnl_status_wire_MyPC.InitialImage"), System.Drawing.Image)
        Me.pnl_status_wire_MyPC.Location = New System.Drawing.Point(129, 74)
        Me.pnl_status_wire_MyPC.Name = "pnl_status_wire_MyPC"
        Me.pnl_status_wire_MyPC.Size = New System.Drawing.Size(118, 50)
        Me.pnl_status_wire_MyPC.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize
        Me.pnl_status_wire_MyPC.TabIndex = 3
        Me.pnl_status_wire_MyPC.TabStop = False
        '
        'pnl_Config_1
        '
        Me.pnl_Config_1.BackColor = System.Drawing.Color.White
        Me.pnl_Config_1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.pnl_Config_1.Controls.Add(Me.Label8)
        Me.pnl_Config_1.Controls.Add(Me.pnl_Config_1_chk_discoveryNotification)
        Me.pnl_Config_1.Controls.Add(Me.pnl_Config_1_txt_AutoDiscoverKeyword)
        Me.pnl_Config_1.Controls.Add(Me.Label36)
        Me.pnl_Config_1.Controls.Add(Me.Panel4)
        Me.pnl_Config_1.Controls.Add(Me.pnl_files_path_receive)
        Me.pnl_Config_1.Controls.Add(Me.Label12)
        Me.pnl_Config_1.Controls.Add(Me.Panel1)
        Me.pnl_Config_1.Controls.Add(Me.Label11)
        Me.pnl_Config_1.Controls.Add(Me.btn_fileLocation)
        Me.pnl_Config_1.Controls.Add(Me.pnl_Config_3_wsURL)
        Me.pnl_Config_1.Controls.Add(Me.pnl_Config_3_wsProtocol)
        Me.pnl_Config_1.Controls.Add(Me.pnl_Config_3_wsProtocol_lbl)
        Me.pnl_Config_1.Controls.Add(Me.pnl_Config_1_txt_ID)
        Me.pnl_Config_1.Controls.Add(Me.Label31)
        Me.pnl_Config_1.Controls.Add(Me.pnl_Config_1_pnl1)
        Me.pnl_Config_1.Controls.Add(Me.pnl_Config_3_wsURL_lbl)
        Me.pnl_Config_1.Controls.Add(Me.Button7)
        Me.pnl_Config_1.Controls.Add(Me.lbl1)
        Me.pnl_Config_1.Location = New System.Drawing.Point(289, 46)
        Me.pnl_Config_1.Name = "pnl_Config_1"
        Me.pnl_Config_1.Size = New System.Drawing.Size(558, 353)
        Me.pnl_Config_1.TabIndex = 39
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(17, 309)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(87, 36)
        Me.Label8.TabIndex = 64
        Me.Label8.Text = "Notification" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "on Discovery"
        Me.Label8.UseMnemonic = False
        '
        'pnl_Config_1_chk_discoveryNotification
        '
        Me.pnl_Config_1_chk_discoveryNotification.AutoSize = True
        Me.pnl_Config_1_chk_discoveryNotification.Location = New System.Drawing.Point(143, 318)
        Me.pnl_Config_1_chk_discoveryNotification.Name = "pnl_Config_1_chk_discoveryNotification"
        Me.pnl_Config_1_chk_discoveryNotification.Size = New System.Drawing.Size(61, 22)
        Me.pnl_Config_1_chk_discoveryNotification.TabIndex = 63
        Me.pnl_Config_1_chk_discoveryNotification.Text = "Show"
        Me.pnl_Config_1_chk_discoveryNotification.UseMnemonic = False
        Me.pnl_Config_1_chk_discoveryNotification.UseVisualStyleBackColor = True
        '
        'pnl_Config_1_txt_AutoDiscoverKeyword
        '
        Me.pnl_Config_1_txt_AutoDiscoverKeyword.BackColor = System.Drawing.Color.White
        Me.pnl_Config_1_txt_AutoDiscoverKeyword.Location = New System.Drawing.Point(145, 270)
        Me.pnl_Config_1_txt_AutoDiscoverKeyword.Name = "pnl_Config_1_txt_AutoDiscoverKeyword"
        Me.pnl_Config_1_txt_AutoDiscoverKeyword.Size = New System.Drawing.Size(253, 26)
        Me.pnl_Config_1_txt_AutoDiscoverKeyword.TabIndex = 46
        '
        'Label36
        '
        Me.Label36.AutoSize = True
        Me.Label36.ForeColor = System.Drawing.Color.FromArgb(CType(CType(244, Byte), Integer), CType(CType(114, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.Label36.Location = New System.Drawing.Point(16, 263)
        Me.Label36.Name = "Label36"
        Me.Label36.Size = New System.Drawing.Size(101, 36)
        Me.Label36.TabIndex = 45
        Me.Label36.Text = "Auto Discovery" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "Keyword:"
        '
        'Panel4
        '
        Me.Panel4.Controls.Add(Me.pnl_Config_1_UserApproval_chk)
        Me.Panel4.Controls.Add(Me.pnl_Config_1_UserApproval_rdo1)
        Me.Panel4.Controls.Add(Me.pnl_Config_1_UserApproval_rdo2)
        Me.Panel4.Location = New System.Drawing.Point(145, 34)
        Me.Panel4.Name = "Panel4"
        Me.Panel4.Size = New System.Drawing.Size(409, 48)
        Me.Panel4.TabIndex = 44
        '
        'pnl_Config_1_UserApproval_chk
        '
        Me.pnl_Config_1_UserApproval_chk.AutoSize = True
        Me.pnl_Config_1_UserApproval_chk.Location = New System.Drawing.Point(273, 5)
        Me.pnl_Config_1_UserApproval_chk.Name = "pnl_Config_1_UserApproval_chk"
        Me.pnl_Config_1_UserApproval_chk.Size = New System.Drawing.Size(116, 40)
        Me.pnl_Config_1_UserApproval_chk.TabIndex = 2
        Me.pnl_Config_1_UserApproval_chk.Text = "Auto Approve " & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "When Locked"
        Me.pnl_Config_1_UserApproval_chk.UseVisualStyleBackColor = True
        '
        'pnl_Config_1_UserApproval_rdo1
        '
        Me.pnl_Config_1_UserApproval_rdo1.AutoSize = True
        Me.pnl_Config_1_UserApproval_rdo1.Checked = True
        Me.pnl_Config_1_UserApproval_rdo1.Location = New System.Drawing.Point(3, 14)
        Me.pnl_Config_1_UserApproval_rdo1.Name = "pnl_Config_1_UserApproval_rdo1"
        Me.pnl_Config_1_UserApproval_rdo1.Size = New System.Drawing.Size(103, 22)
        Me.pnl_Config_1_UserApproval_rdo1.TabIndex = 1
        Me.pnl_Config_1_UserApproval_rdo1.TabStop = True
        Me.pnl_Config_1_UserApproval_rdo1.Text = "No Approval"
        Me.pnl_Config_1_UserApproval_rdo1.UseVisualStyleBackColor = True
        '
        'pnl_Config_1_UserApproval_rdo2
        '
        Me.pnl_Config_1_UserApproval_rdo2.AutoSize = True
        Me.pnl_Config_1_UserApproval_rdo2.Location = New System.Drawing.Point(138, 14)
        Me.pnl_Config_1_UserApproval_rdo2.Name = "pnl_Config_1_UserApproval_rdo2"
        Me.pnl_Config_1_UserApproval_rdo2.Size = New System.Drawing.Size(115, 22)
        Me.pnl_Config_1_UserApproval_rdo2.TabIndex = 0
        Me.pnl_Config_1_UserApproval_rdo2.Text = "With Approval"
        Me.pnl_Config_1_UserApproval_rdo2.UseVisualStyleBackColor = True
        '
        'pnl_files_path_receive
        '
        Me.pnl_files_path_receive.Location = New System.Drawing.Point(145, 131)
        Me.pnl_files_path_receive.Multiline = True
        Me.pnl_files_path_receive.Name = "pnl_files_path_receive"
        Me.pnl_files_path_receive.ReadOnly = True
        Me.pnl_files_path_receive.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.pnl_files_path_receive.Size = New System.Drawing.Size(253, 49)
        Me.pnl_files_path_receive.TabIndex = 31
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Location = New System.Drawing.Point(17, 50)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(106, 18)
        Me.Label12.TabIndex = 43
        Me.Label12.Text = "Local PC Access:"
        '
        'Panel1
        '
        Me.Panel1.Controls.Add(Me.pnl_Config_2_Rdo1)
        Me.Panel1.Controls.Add(Me.pnl_Config_2_Rdo2)
        Me.Panel1.Location = New System.Drawing.Point(420, 192)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(262, 26)
        Me.Panel1.TabIndex = 42
        Me.Panel1.Visible = False
        '
        'pnl_Config_2_Rdo1
        '
        Me.pnl_Config_2_Rdo1.AutoSize = True
        Me.pnl_Config_2_Rdo1.Checked = True
        Me.pnl_Config_2_Rdo1.Location = New System.Drawing.Point(3, 2)
        Me.pnl_Config_2_Rdo1.Name = "pnl_Config_2_Rdo1"
        Me.pnl_Config_2_Rdo1.Size = New System.Drawing.Size(124, 22)
        Me.pnl_Config_2_Rdo1.TabIndex = 1
        Me.pnl_Config_2_Rdo1.TabStop = True
        Me.pnl_Config_2_Rdo1.Text = "Auto Reconnect"
        Me.pnl_Config_2_Rdo1.UseVisualStyleBackColor = True
        '
        'pnl_Config_2_Rdo2
        '
        Me.pnl_Config_2_Rdo2.AutoSize = True
        Me.pnl_Config_2_Rdo2.Location = New System.Drawing.Point(138, 2)
        Me.pnl_Config_2_Rdo2.Name = "pnl_Config_2_Rdo2"
        Me.pnl_Config_2_Rdo2.Size = New System.Drawing.Size(126, 22)
        Me.pnl_Config_2_Rdo2.TabIndex = 0
        Me.pnl_Config_2_Rdo2.Text = "Manual Connect"
        Me.pnl_Config_2_Rdo2.UseVisualStyleBackColor = True
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Location = New System.Drawing.Point(17, 134)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(93, 36)
        Me.Label11.TabIndex = 32
        Me.Label11.Text = "My Receiving " & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "File Path:"
        '
        'pnl_Config_3_wsURL
        '
        Me.pnl_Config_3_wsURL.BackColor = System.Drawing.Color.White
        Me.pnl_Config_3_wsURL.Location = New System.Drawing.Point(145, 225)
        Me.pnl_Config_3_wsURL.Name = "pnl_Config_3_wsURL"
        Me.pnl_Config_3_wsURL.Size = New System.Drawing.Size(253, 26)
        Me.pnl_Config_3_wsURL.TabIndex = 31
        Me.pnl_Config_3_wsURL.Text = "www.alsoozphone.com"
        '
        'pnl_Config_3_wsProtocol
        '
        Me.pnl_Config_3_wsProtocol.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.pnl_Config_3_wsProtocol.FormattingEnabled = True
        Me.pnl_Config_3_wsProtocol.Items.AddRange(New Object() {"wss://", "ws://"})
        Me.pnl_Config_3_wsProtocol.Location = New System.Drawing.Point(145, 193)
        Me.pnl_Config_3_wsProtocol.Name = "pnl_Config_3_wsProtocol"
        Me.pnl_Config_3_wsProtocol.Size = New System.Drawing.Size(79, 26)
        Me.pnl_Config_3_wsProtocol.TabIndex = 30
        '
        'pnl_Config_3_wsProtocol_lbl
        '
        Me.pnl_Config_3_wsProtocol_lbl.AutoSize = True
        Me.pnl_Config_3_wsProtocol_lbl.Location = New System.Drawing.Point(17, 196)
        Me.pnl_Config_3_wsProtocol_lbl.Name = "pnl_Config_3_wsProtocol_lbl"
        Me.pnl_Config_3_wsProtocol_lbl.Size = New System.Drawing.Size(90, 18)
        Me.pnl_Config_3_wsProtocol_lbl.TabIndex = 29
        Me.pnl_Config_3_wsProtocol_lbl.Text = "URL Protocol:"
        '
        'pnl_Config_1_txt_ID
        '
        Me.pnl_Config_1_txt_ID.Location = New System.Drawing.Point(145, 91)
        Me.pnl_Config_1_txt_ID.Name = "pnl_Config_1_txt_ID"
        Me.pnl_Config_1_txt_ID.ReadOnly = True
        Me.pnl_Config_1_txt_ID.Size = New System.Drawing.Size(253, 26)
        Me.pnl_Config_1_txt_ID.TabIndex = 31
        '
        'Label31
        '
        Me.Label31.AutoSize = True
        Me.Label31.Location = New System.Drawing.Point(17, 94)
        Me.Label31.Name = "Label31"
        Me.Label31.Size = New System.Drawing.Size(97, 18)
        Me.Label31.TabIndex = 32
        Me.Label31.Text = "Installation ID:"
        '
        'pnl_Config_1_pnl1
        '
        Me.pnl_Config_1_pnl1.Controls.Add(Me.pnl_Config_1_pnl1_rdo2)
        Me.pnl_Config_1_pnl1.Controls.Add(Me.pnl_Config_1_pnl1_rdo1)
        Me.pnl_Config_1_pnl1.Location = New System.Drawing.Point(418, 220)
        Me.pnl_Config_1_pnl1.Name = "pnl_Config_1_pnl1"
        Me.pnl_Config_1_pnl1.Size = New System.Drawing.Size(262, 26)
        Me.pnl_Config_1_pnl1.TabIndex = 30
        Me.pnl_Config_1_pnl1.Visible = False
        '
        'pnl_Config_1_pnl1_rdo2
        '
        Me.pnl_Config_1_pnl1_rdo2.AutoSize = True
        Me.pnl_Config_1_pnl1_rdo2.Location = New System.Drawing.Point(3, 2)
        Me.pnl_Config_1_pnl1_rdo2.Name = "pnl_Config_1_pnl1_rdo2"
        Me.pnl_Config_1_pnl1_rdo2.Size = New System.Drawing.Size(111, 22)
        Me.pnl_Config_1_pnl1_rdo2.TabIndex = 1
        Me.pnl_Config_1_pnl1_rdo2.TabStop = True
        Me.pnl_Config_1_pnl1_rdo2.Text = "Online Server"
        Me.pnl_Config_1_pnl1_rdo2.UseVisualStyleBackColor = True
        '
        'pnl_Config_1_pnl1_rdo1
        '
        Me.pnl_Config_1_pnl1_rdo1.AutoSize = True
        Me.pnl_Config_1_pnl1_rdo1.Location = New System.Drawing.Point(138, 2)
        Me.pnl_Config_1_pnl1_rdo1.Name = "pnl_Config_1_pnl1_rdo1"
        Me.pnl_Config_1_pnl1_rdo1.Size = New System.Drawing.Size(131, 22)
        Me.pnl_Config_1_pnl1_rdo1.TabIndex = 0
        Me.pnl_Config_1_pnl1_rdo1.Text = "Direct IP Address"
        Me.pnl_Config_1_pnl1_rdo1.UseVisualStyleBackColor = True
        '
        'pnl_Config_3_wsURL_lbl
        '
        Me.pnl_Config_3_wsURL_lbl.AutoSize = True
        Me.pnl_Config_3_wsURL_lbl.Location = New System.Drawing.Point(17, 228)
        Me.pnl_Config_3_wsURL_lbl.Name = "pnl_Config_3_wsURL_lbl"
        Me.pnl_Config_3_wsURL_lbl.Size = New System.Drawing.Size(78, 18)
        Me.pnl_Config_3_wsURL_lbl.TabIndex = 14
        Me.pnl_Config_3_wsURL_lbl.Text = "URL Server:"
        '
        'Button7
        '
        Me.Button7.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.Button7.Location = New System.Drawing.Point(423, 306)
        Me.Button7.Name = "Button7"
        Me.Button7.Size = New System.Drawing.Size(118, 32)
        Me.Button7.TabIndex = 22
        Me.Button7.Text = "Save Changes"
        Me.Button7.UseVisualStyleBackColor = False
        '
        'lbl1
        '
        Me.lbl1.BackColor = System.Drawing.Color.LightSteelBlue
        Me.lbl1.ForeColor = System.Drawing.Color.Black
        Me.lbl1.Location = New System.Drawing.Point(0, -1)
        Me.lbl1.Name = "lbl1"
        Me.lbl1.Size = New System.Drawing.Size(558, 32)
        Me.lbl1.TabIndex = 19
        Me.lbl1.Text = "Main Configuration"
        Me.lbl1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'pnl_Config_3
        '
        Me.pnl_Config_3.BackColor = System.Drawing.Color.White
        Me.pnl_Config_3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.pnl_Config_3.Controls.Add(Me.pnl_Config_3_chkAllowClipboardReceive)
        Me.pnl_Config_3.Controls.Add(Me.Label5)
        Me.pnl_Config_3.Controls.Add(Me.pnl_Config_3_chkAllowClipboardSend)
        Me.pnl_Config_3.Controls.Add(Me.pnl_Config_3_chkAllowFilesReceive)
        Me.pnl_Config_3.Controls.Add(Me.Label3)
        Me.pnl_Config_3.Controls.Add(Me.pnl_Config_3_chkAllowFilesSend)
        Me.pnl_Config_3.Controls.Add(Me.CheckBox2)
        Me.pnl_Config_3.Controls.Add(Me.pnl_Config_3_Start_CloseConnection_chk2)
        Me.pnl_Config_3.Controls.Add(Me.pnl_Config_3_Start_ViewControl_dd_Quality)
        Me.pnl_Config_3.Controls.Add(Me.pnl_Config_3_Start_ViewControl_chk2)
        Me.pnl_Config_3.Controls.Add(Me.pnl_Config_3_Start_ViewControl_chk3)
        Me.pnl_Config_3.Controls.Add(Me.pnl_Config_3_Start_ViewControl_chk1)
        Me.pnl_Config_3.Controls.Add(Me.Label38)
        Me.pnl_Config_3.Controls.Add(Me.pnl_Config_3_Start_Actions_chk1)
        Me.pnl_Config_3.Controls.Add(Me.pnl_Config_3_Start_Actions_chk2)
        Me.pnl_Config_3.Controls.Add(Me.Label33)
        Me.pnl_Config_3.Controls.Add(Me.Button2)
        Me.pnl_Config_3.Controls.Add(Me.Label34)
        Me.pnl_Config_3.Location = New System.Drawing.Point(289, 46)
        Me.pnl_Config_3.Name = "pnl_Config_3"
        Me.pnl_Config_3.Size = New System.Drawing.Size(558, 353)
        Me.pnl_Config_3.TabIndex = 41
        '
        'pnl_Config_3_chkAllowClipboardReceive
        '
        Me.pnl_Config_3_chkAllowClipboardReceive.AutoSize = True
        Me.pnl_Config_3_chkAllowClipboardReceive.Location = New System.Drawing.Point(189, 322)
        Me.pnl_Config_3_chkAllowClipboardReceive.Name = "pnl_Config_3_chkAllowClipboardReceive"
        Me.pnl_Config_3_chkAllowClipboardReceive.Size = New System.Drawing.Size(167, 22)
        Me.pnl_Config_3_chkAllowClipboardReceive.TabIndex = 63
        Me.pnl_Config_3_chkAllowClipboardReceive.Text = "Allow Receive Receive"
        Me.pnl_Config_3_chkAllowClipboardReceive.UseMnemonic = False
        Me.pnl_Config_3_chkAllowClipboardReceive.UseVisualStyleBackColor = True
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(16, 301)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(161, 18)
        Me.Label5.TabIndex = 62
        Me.Label5.Text = "Clipboard Share Feature:"
        Me.Label5.UseMnemonic = False
        '
        'pnl_Config_3_chkAllowClipboardSend
        '
        Me.pnl_Config_3_chkAllowClipboardSend.AutoSize = True
        Me.pnl_Config_3_chkAllowClipboardSend.Location = New System.Drawing.Point(189, 300)
        Me.pnl_Config_3_chkAllowClipboardSend.Name = "pnl_Config_3_chkAllowClipboardSend"
        Me.pnl_Config_3_chkAllowClipboardSend.Size = New System.Drawing.Size(160, 22)
        Me.pnl_Config_3_chkAllowClipboardSend.TabIndex = 61
        Me.pnl_Config_3_chkAllowClipboardSend.Text = "Allow Send Clipboard"
        Me.pnl_Config_3_chkAllowClipboardSend.UseMnemonic = False
        Me.pnl_Config_3_chkAllowClipboardSend.UseVisualStyleBackColor = True
        '
        'pnl_Config_3_chkAllowFilesReceive
        '
        Me.pnl_Config_3_chkAllowFilesReceive.AutoSize = True
        Me.pnl_Config_3_chkAllowFilesReceive.Location = New System.Drawing.Point(189, 257)
        Me.pnl_Config_3_chkAllowFilesReceive.Name = "pnl_Config_3_chkAllowFilesReceive"
        Me.pnl_Config_3_chkAllowFilesReceive.Size = New System.Drawing.Size(147, 22)
        Me.pnl_Config_3_chkAllowFilesReceive.TabIndex = 60
        Me.pnl_Config_3_chkAllowFilesReceive.Text = "Allow Receive Files"
        Me.pnl_Config_3_chkAllowFilesReceive.UseMnemonic = False
        Me.pnl_Config_3_chkAllowFilesReceive.UseVisualStyleBackColor = True
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(16, 236)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(139, 18)
        Me.Label3.TabIndex = 59
        Me.Label3.Text = "File Transfer Feature:"
        Me.Label3.UseMnemonic = False
        '
        'pnl_Config_3_chkAllowFilesSend
        '
        Me.pnl_Config_3_chkAllowFilesSend.AutoSize = True
        Me.pnl_Config_3_chkAllowFilesSend.Location = New System.Drawing.Point(189, 235)
        Me.pnl_Config_3_chkAllowFilesSend.Name = "pnl_Config_3_chkAllowFilesSend"
        Me.pnl_Config_3_chkAllowFilesSend.Size = New System.Drawing.Size(129, 22)
        Me.pnl_Config_3_chkAllowFilesSend.TabIndex = 58
        Me.pnl_Config_3_chkAllowFilesSend.Text = "Allow Send Files"
        Me.pnl_Config_3_chkAllowFilesSend.UseMnemonic = False
        Me.pnl_Config_3_chkAllowFilesSend.UseVisualStyleBackColor = True
        '
        'CheckBox2
        '
        Me.CheckBox2.AutoSize = True
        Me.CheckBox2.Checked = True
        Me.CheckBox2.CheckState = System.Windows.Forms.CheckState.Checked
        Me.CheckBox2.Enabled = False
        Me.CheckBox2.Location = New System.Drawing.Point(189, 95)
        Me.CheckBox2.Name = "CheckBox2"
        Me.CheckBox2.Size = New System.Drawing.Size(72, 22)
        Me.CheckBox2.TabIndex = 57
        Me.CheckBox2.Text = "Quality"
        Me.CheckBox2.UseMnemonic = False
        Me.CheckBox2.UseVisualStyleBackColor = True
        '
        'pnl_Config_3_Start_CloseConnection_chk2
        '
        Me.pnl_Config_3_Start_CloseConnection_chk2.AutoSize = True
        Me.pnl_Config_3_Start_CloseConnection_chk2.Location = New System.Drawing.Point(189, 192)
        Me.pnl_Config_3_Start_CloseConnection_chk2.Name = "pnl_Config_3_Start_CloseConnection_chk2"
        Me.pnl_Config_3_Start_CloseConnection_chk2.Size = New System.Drawing.Size(306, 22)
        Me.pnl_Config_3_Start_CloseConnection_chk2.TabIndex = 56
        Me.pnl_Config_3_Start_CloseConnection_chk2.Text = "Close Connection after View & Control Closes"
        Me.pnl_Config_3_Start_CloseConnection_chk2.UseMnemonic = False
        Me.pnl_Config_3_Start_CloseConnection_chk2.UseVisualStyleBackColor = True
        '
        'pnl_Config_3_Start_ViewControl_dd_Quality
        '
        Me.pnl_Config_3_Start_ViewControl_dd_Quality.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.pnl_Config_3_Start_ViewControl_dd_Quality.FormattingEnabled = True
        Me.pnl_Config_3_Start_ViewControl_dd_Quality.Items.AddRange(New Object() {"High Speed", "Balance", "High Quality"})
        Me.pnl_Config_3_Start_ViewControl_dd_Quality.Location = New System.Drawing.Point(267, 93)
        Me.pnl_Config_3_Start_ViewControl_dd_Quality.Name = "pnl_Config_3_Start_ViewControl_dd_Quality"
        Me.pnl_Config_3_Start_ViewControl_dd_Quality.Size = New System.Drawing.Size(109, 26)
        Me.pnl_Config_3_Start_ViewControl_dd_Quality.TabIndex = 55
        '
        'pnl_Config_3_Start_ViewControl_chk2
        '
        Me.pnl_Config_3_Start_ViewControl_chk2.AutoSize = True
        Me.pnl_Config_3_Start_ViewControl_chk2.Location = New System.Drawing.Point(189, 168)
        Me.pnl_Config_3_Start_ViewControl_chk2.Name = "pnl_Config_3_Start_ViewControl_chk2"
        Me.pnl_Config_3_Start_ViewControl_chk2.Size = New System.Drawing.Size(121, 22)
        Me.pnl_Config_3_Start_ViewControl_chk2.TabIndex = 50
        Me.pnl_Config_3_Start_ViewControl_chk2.Text = "Remote Mouse"
        Me.pnl_Config_3_Start_ViewControl_chk2.UseMnemonic = False
        Me.pnl_Config_3_Start_ViewControl_chk2.UseVisualStyleBackColor = True
        '
        'pnl_Config_3_Start_ViewControl_chk3
        '
        Me.pnl_Config_3_Start_ViewControl_chk3.AutoSize = True
        Me.pnl_Config_3_Start_ViewControl_chk3.Location = New System.Drawing.Point(189, 144)
        Me.pnl_Config_3_Start_ViewControl_chk3.Name = "pnl_Config_3_Start_ViewControl_chk3"
        Me.pnl_Config_3_Start_ViewControl_chk3.Size = New System.Drawing.Size(92, 22)
        Me.pnl_Config_3_Start_ViewControl_chk3.TabIndex = 48
        Me.pnl_Config_3_Start_ViewControl_chk3.Text = "Control PC"
        Me.pnl_Config_3_Start_ViewControl_chk3.UseMnemonic = False
        Me.pnl_Config_3_Start_ViewControl_chk3.UseVisualStyleBackColor = True
        '
        'pnl_Config_3_Start_ViewControl_chk1
        '
        Me.pnl_Config_3_Start_ViewControl_chk1.AutoSize = True
        Me.pnl_Config_3_Start_ViewControl_chk1.Location = New System.Drawing.Point(189, 120)
        Me.pnl_Config_3_Start_ViewControl_chk1.Name = "pnl_Config_3_Start_ViewControl_chk1"
        Me.pnl_Config_3_Start_ViewControl_chk1.Size = New System.Drawing.Size(95, 22)
        Me.pnl_Config_3_Start_ViewControl_chk1.TabIndex = 47
        Me.pnl_Config_3_Start_ViewControl_chk1.Text = "Full Screen"
        Me.pnl_Config_3_Start_ViewControl_chk1.UseVisualStyleBackColor = True
        '
        'Label38
        '
        Me.Label38.AutoSize = True
        Me.Label38.Location = New System.Drawing.Point(17, 98)
        Me.Label38.Name = "Label38"
        Me.Label38.Size = New System.Drawing.Size(155, 18)
        Me.Label38.TabIndex = 46
        Me.Label38.Text = "Default View & Control:"
        Me.Label38.UseMnemonic = False
        '
        'pnl_Config_3_Start_Actions_chk1
        '
        Me.pnl_Config_3_Start_Actions_chk1.AutoSize = True
        Me.pnl_Config_3_Start_Actions_chk1.Location = New System.Drawing.Point(189, 53)
        Me.pnl_Config_3_Start_Actions_chk1.Name = "pnl_Config_3_Start_Actions_chk1"
        Me.pnl_Config_3_Start_Actions_chk1.Size = New System.Drawing.Size(153, 22)
        Me.pnl_Config_3_Start_Actions_chk1.TabIndex = 45
        Me.pnl_Config_3_Start_Actions_chk1.Text = "Start View & Control"
        Me.pnl_Config_3_Start_Actions_chk1.UseMnemonic = False
        Me.pnl_Config_3_Start_Actions_chk1.UseVisualStyleBackColor = True
        '
        'pnl_Config_3_Start_Actions_chk2
        '
        Me.pnl_Config_3_Start_Actions_chk2.AutoSize = True
        Me.pnl_Config_3_Start_Actions_chk2.Location = New System.Drawing.Point(498, 36)
        Me.pnl_Config_3_Start_Actions_chk2.Name = "pnl_Config_3_Start_Actions_chk2"
        Me.pnl_Config_3_Start_Actions_chk2.Size = New System.Drawing.Size(127, 22)
        Me.pnl_Config_3_Start_Actions_chk2.TabIndex = 44
        Me.pnl_Config_3_Start_Actions_chk2.Text = "Start Audio Chat"
        Me.pnl_Config_3_Start_Actions_chk2.UseVisualStyleBackColor = True
        Me.pnl_Config_3_Start_Actions_chk2.Visible = False
        '
        'Label33
        '
        Me.Label33.AutoSize = True
        Me.Label33.Location = New System.Drawing.Point(16, 54)
        Me.Label33.Name = "Label33"
        Me.Label33.Size = New System.Drawing.Size(145, 18)
        Me.Label33.TabIndex = 42
        Me.Label33.Text = "Actions After Connect:"
        '
        'Button2
        '
        Me.Button2.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.Button2.Location = New System.Drawing.Point(421, 306)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(118, 32)
        Me.Button2.TabIndex = 22
        Me.Button2.Text = "Save Changes"
        Me.Button2.UseVisualStyleBackColor = False
        '
        'Label34
        '
        Me.Label34.BackColor = System.Drawing.Color.LightSteelBlue
        Me.Label34.ForeColor = System.Drawing.Color.Black
        Me.Label34.Location = New System.Drawing.Point(0, -1)
        Me.Label34.Name = "Label34"
        Me.Label34.Size = New System.Drawing.Size(558, 32)
        Me.Label34.TabIndex = 19
        Me.Label34.Text = "Customization"
        Me.Label34.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Panel2
        '
        Me.Panel2.BackColor = System.Drawing.Color.FromArgb(CType(CType(231, Byte), Integer), CType(CType(231, Byte), Integer), CType(CType(231, Byte), Integer))
        Me.Panel2.Controls.Add(Me.Label37)
        Me.Panel2.Controls.Add(Me.lbl_AppVersion)
        Me.Panel2.Controls.Add(Me.lbl_AppStatus)
        Me.Panel2.Controls.Add(Me.Label7)
        Me.Panel2.Controls.Add(Me.Label4)
        Me.Panel2.Location = New System.Drawing.Point(-1, 509)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(856, 27)
        Me.Panel2.TabIndex = 43
        '
        'Label37
        '
        Me.Label37.ForeColor = System.Drawing.Color.FromArgb(CType(CType(88, Byte), Integer), CType(CType(88, Byte), Integer), CType(CType(88, Byte), Integer))
        Me.Label37.Location = New System.Drawing.Point(126, 1)
        Me.Label37.Name = "Label37"
        Me.Label37.Size = New System.Drawing.Size(584, 18)
        Me.Label37.TabIndex = 4
        Me.Label37.Text = "Licensed To: "
        Me.Label37.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'lbl_AppVersion
        '
        Me.lbl_AppVersion.AutoSize = True
        Me.lbl_AppVersion.ForeColor = System.Drawing.Color.FromArgb(CType(CType(88, Byte), Integer), CType(CType(88, Byte), Integer), CType(CType(88, Byte), Integer))
        Me.lbl_AppVersion.Location = New System.Drawing.Point(796, 1)
        Me.lbl_AppVersion.Name = "lbl_AppVersion"
        Me.lbl_AppVersion.Size = New System.Drawing.Size(48, 18)
        Me.lbl_AppVersion.TabIndex = 1
        Me.lbl_AppVersion.Text = "1.0.0.7"
        '
        'lbl_AppStatus
        '
        Me.lbl_AppStatus.AutoSize = True
        Me.lbl_AppStatus.ForeColor = System.Drawing.Color.FromArgb(CType(CType(88, Byte), Integer), CType(CType(88, Byte), Integer), CType(CType(88, Byte), Integer))
        Me.lbl_AppStatus.Location = New System.Drawing.Point(55, 1)
        Me.lbl_AppStatus.Name = "lbl_AppStatus"
        Me.lbl_AppStatus.Size = New System.Drawing.Size(48, 18)
        Me.lbl_AppStatus.TabIndex = 3
        Me.lbl_AppStatus.Text = "1.0.0.7"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.ForeColor = System.Drawing.Color.Gray
        Me.Label7.Location = New System.Drawing.Point(6, 1)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(50, 18)
        Me.Label7.TabIndex = 2
        Me.Label7.Text = "Status:"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.ForeColor = System.Drawing.Color.Gray
        Me.Label4.Location = New System.Drawing.Point(738, 1)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(62, 18)
        Me.Label4.TabIndex = 0
        Me.Label4.Text = "Version: "
        '
        'tmrUserApproval
        '
        Me.tmrUserApproval.Interval = 1000
        '
        'pnl_Config_1_btn_password_MyPC
        '
        Me.pnl_Config_1_btn_password_MyPC.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.pnl_Config_1_btn_password_MyPC.Location = New System.Drawing.Point(420, 47)
        Me.pnl_Config_1_btn_password_MyPC.Name = "pnl_Config_1_btn_password_MyPC"
        Me.pnl_Config_1_btn_password_MyPC.Size = New System.Drawing.Size(118, 32)
        Me.pnl_Config_1_btn_password_MyPC.TabIndex = 40
        Me.pnl_Config_1_btn_password_MyPC.Text = "Show"
        Me.pnl_Config_1_btn_password_MyPC.UseVisualStyleBackColor = False
        '
        'pnl_Config_1_txt_password_myPC
        '
        Me.pnl_Config_1_txt_password_myPC.Location = New System.Drawing.Point(156, 50)
        Me.pnl_Config_1_txt_password_myPC.Name = "pnl_Config_1_txt_password_myPC"
        Me.pnl_Config_1_txt_password_myPC.Size = New System.Drawing.Size(159, 26)
        Me.pnl_Config_1_txt_password_myPC.TabIndex = 39
        Me.pnl_Config_1_txt_password_myPC.UseSystemPasswordChar = True
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Location = New System.Drawing.Point(16, 47)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(101, 36)
        Me.Label10.TabIndex = 38
        Me.Label10.Text = "My Remote PC " & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "Password:"
        '
        'Label30
        '
        Me.Label30.BackColor = System.Drawing.Color.LightSteelBlue
        Me.Label30.ForeColor = System.Drawing.Color.Black
        Me.Label30.Location = New System.Drawing.Point(0, -1)
        Me.Label30.Name = "Label30"
        Me.Label30.Size = New System.Drawing.Size(558, 32)
        Me.Label30.TabIndex = 19
        Me.Label30.Text = "Passwords Configuration"
        Me.Label30.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Button1
        '
        Me.Button1.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.Button1.Location = New System.Drawing.Point(421, 306)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(118, 32)
        Me.Button1.TabIndex = 22
        Me.Button1.Text = "Save Changes"
        Me.Button1.UseVisualStyleBackColor = False
        '
        'pnl_Config_1_chk_password_MyPC
        '
        Me.pnl_Config_1_chk_password_MyPC.AutoSize = True
        Me.pnl_Config_1_chk_password_MyPC.Checked = True
        Me.pnl_Config_1_chk_password_MyPC.CheckState = System.Windows.Forms.CheckState.Checked
        Me.pnl_Config_1_chk_password_MyPC.Enabled = False
        Me.pnl_Config_1_chk_password_MyPC.Location = New System.Drawing.Point(323, 51)
        Me.pnl_Config_1_chk_password_MyPC.Name = "pnl_Config_1_chk_password_MyPC"
        Me.pnl_Config_1_chk_password_MyPC.Size = New System.Drawing.Size(84, 22)
        Me.pnl_Config_1_chk_password_MyPC.TabIndex = 41
        Me.pnl_Config_1_chk_password_MyPC.Text = "Required"
        Me.pnl_Config_1_chk_password_MyPC.UseVisualStyleBackColor = True
        '
        'pnl_Config_1_btn_password_UIAccess
        '
        Me.pnl_Config_1_btn_password_UIAccess.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.pnl_Config_1_btn_password_UIAccess.Location = New System.Drawing.Point(420, 110)
        Me.pnl_Config_1_btn_password_UIAccess.Name = "pnl_Config_1_btn_password_UIAccess"
        Me.pnl_Config_1_btn_password_UIAccess.Size = New System.Drawing.Size(118, 32)
        Me.pnl_Config_1_btn_password_UIAccess.TabIndex = 44
        Me.pnl_Config_1_btn_password_UIAccess.Text = "Show"
        Me.pnl_Config_1_btn_password_UIAccess.UseVisualStyleBackColor = False
        '
        'pnl_Config_1_txt_password_UIAccess
        '
        Me.pnl_Config_1_txt_password_UIAccess.Location = New System.Drawing.Point(156, 113)
        Me.pnl_Config_1_txt_password_UIAccess.Name = "pnl_Config_1_txt_password_UIAccess"
        Me.pnl_Config_1_txt_password_UIAccess.Size = New System.Drawing.Size(159, 26)
        Me.pnl_Config_1_txt_password_UIAccess.TabIndex = 43
        Me.pnl_Config_1_txt_password_UIAccess.UseSystemPasswordChar = True
        '
        'Label25
        '
        Me.Label25.AutoSize = True
        Me.Label25.Location = New System.Drawing.Point(16, 108)
        Me.Label25.Name = "Label25"
        Me.Label25.Size = New System.Drawing.Size(71, 36)
        Me.Label25.TabIndex = 42
        Me.Label25.Text = "UI Access" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "Password:"
        '
        'pnl_Config_1_chk_password_UIAccess
        '
        Me.pnl_Config_1_chk_password_UIAccess.AutoSize = True
        Me.pnl_Config_1_chk_password_UIAccess.Location = New System.Drawing.Point(323, 114)
        Me.pnl_Config_1_chk_password_UIAccess.Name = "pnl_Config_1_chk_password_UIAccess"
        Me.pnl_Config_1_chk_password_UIAccess.Size = New System.Drawing.Size(84, 22)
        Me.pnl_Config_1_chk_password_UIAccess.TabIndex = 45
        Me.pnl_Config_1_chk_password_UIAccess.Text = "Required"
        Me.pnl_Config_1_chk_password_UIAccess.UseVisualStyleBackColor = True
        '
        'pnl_Config_1_btn_password_Config
        '
        Me.pnl_Config_1_btn_password_Config.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.pnl_Config_1_btn_password_Config.Location = New System.Drawing.Point(420, 246)
        Me.pnl_Config_1_btn_password_Config.Name = "pnl_Config_1_btn_password_Config"
        Me.pnl_Config_1_btn_password_Config.Size = New System.Drawing.Size(118, 32)
        Me.pnl_Config_1_btn_password_Config.TabIndex = 48
        Me.pnl_Config_1_btn_password_Config.Text = "Show"
        Me.pnl_Config_1_btn_password_Config.UseVisualStyleBackColor = False
        '
        'pnl_Config_1_txt_password_config
        '
        Me.pnl_Config_1_txt_password_config.Location = New System.Drawing.Point(156, 249)
        Me.pnl_Config_1_txt_password_config.Name = "pnl_Config_1_txt_password_config"
        Me.pnl_Config_1_txt_password_config.Size = New System.Drawing.Size(159, 26)
        Me.pnl_Config_1_txt_password_config.TabIndex = 47
        Me.pnl_Config_1_txt_password_config.UseSystemPasswordChar = True
        '
        'Label28
        '
        Me.Label28.AutoSize = True
        Me.Label28.Location = New System.Drawing.Point(16, 246)
        Me.Label28.Name = "Label28"
        Me.Label28.Size = New System.Drawing.Size(123, 54)
        Me.Label28.TabIndex = 46
        Me.Label28.Text = "Config / Uninstall /" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "Task Mgr /" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "Password:"
        '
        'pnl_Config_1_chk_password_config
        '
        Me.pnl_Config_1_chk_password_config.AutoSize = True
        Me.pnl_Config_1_chk_password_config.Location = New System.Drawing.Point(323, 250)
        Me.pnl_Config_1_chk_password_config.Name = "pnl_Config_1_chk_password_config"
        Me.pnl_Config_1_chk_password_config.Size = New System.Drawing.Size(84, 22)
        Me.pnl_Config_1_chk_password_config.TabIndex = 49
        Me.pnl_Config_1_chk_password_config.Text = "Required"
        Me.pnl_Config_1_chk_password_config.UseVisualStyleBackColor = True
        '
        'pnl_Config_2
        '
        Me.pnl_Config_2.BackColor = System.Drawing.Color.White
        Me.pnl_Config_2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.pnl_Config_2.Controls.Add(Me.pnl_Config_1_chk_password_Exit)
        Me.pnl_Config_2.Controls.Add(Me.Label9)
        Me.pnl_Config_2.Controls.Add(Me.pnl_Config_1_txt_password_Exit)
        Me.pnl_Config_2.Controls.Add(Me.pnl_Config_1_btn_password_Exit)
        Me.pnl_Config_2.Controls.Add(Me.pnl_Config_1_chk_password_config)
        Me.pnl_Config_2.Controls.Add(Me.Label28)
        Me.pnl_Config_2.Controls.Add(Me.pnl_Config_1_txt_password_config)
        Me.pnl_Config_2.Controls.Add(Me.pnl_Config_1_btn_password_Config)
        Me.pnl_Config_2.Controls.Add(Me.pnl_Config_1_chk_password_UIAccess)
        Me.pnl_Config_2.Controls.Add(Me.Label25)
        Me.pnl_Config_2.Controls.Add(Me.pnl_Config_1_txt_password_UIAccess)
        Me.pnl_Config_2.Controls.Add(Me.pnl_Config_1_btn_password_UIAccess)
        Me.pnl_Config_2.Controls.Add(Me.pnl_Config_1_chk_password_MyPC)
        Me.pnl_Config_2.Controls.Add(Me.Button1)
        Me.pnl_Config_2.Controls.Add(Me.Label30)
        Me.pnl_Config_2.Controls.Add(Me.Label10)
        Me.pnl_Config_2.Controls.Add(Me.pnl_Config_1_txt_password_myPC)
        Me.pnl_Config_2.Controls.Add(Me.pnl_Config_1_btn_password_MyPC)
        Me.pnl_Config_2.Location = New System.Drawing.Point(289, 46)
        Me.pnl_Config_2.Name = "pnl_Config_2"
        Me.pnl_Config_2.Size = New System.Drawing.Size(558, 353)
        Me.pnl_Config_2.TabIndex = 40
        '
        'pnl_Config_1_chk_password_Exit
        '
        Me.pnl_Config_1_chk_password_Exit.AutoSize = True
        Me.pnl_Config_1_chk_password_Exit.Location = New System.Drawing.Point(324, 180)
        Me.pnl_Config_1_chk_password_Exit.Name = "pnl_Config_1_chk_password_Exit"
        Me.pnl_Config_1_chk_password_Exit.Size = New System.Drawing.Size(84, 22)
        Me.pnl_Config_1_chk_password_Exit.TabIndex = 53
        Me.pnl_Config_1_chk_password_Exit.Text = "Required"
        Me.pnl_Config_1_chk_password_Exit.UseVisualStyleBackColor = True
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(17, 183)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(121, 18)
        Me.Label9.TabIndex = 50
        Me.Label9.Text = "Exit App Password"
        '
        'pnl_Config_1_txt_password_Exit
        '
        Me.pnl_Config_1_txt_password_Exit.Location = New System.Drawing.Point(157, 179)
        Me.pnl_Config_1_txt_password_Exit.Name = "pnl_Config_1_txt_password_Exit"
        Me.pnl_Config_1_txt_password_Exit.Size = New System.Drawing.Size(159, 26)
        Me.pnl_Config_1_txt_password_Exit.TabIndex = 51
        Me.pnl_Config_1_txt_password_Exit.UseSystemPasswordChar = True
        '
        'pnl_Config_1_btn_password_Exit
        '
        Me.pnl_Config_1_btn_password_Exit.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.pnl_Config_1_btn_password_Exit.Location = New System.Drawing.Point(421, 176)
        Me.pnl_Config_1_btn_password_Exit.Name = "pnl_Config_1_btn_password_Exit"
        Me.pnl_Config_1_btn_password_Exit.Size = New System.Drawing.Size(118, 32)
        Me.pnl_Config_1_btn_password_Exit.TabIndex = 52
        Me.pnl_Config_1_btn_password_Exit.Text = "Show"
        Me.pnl_Config_1_btn_password_Exit.UseVisualStyleBackColor = False
        '
        'tmrAllOnlineStatus
        '
        Me.tmrAllOnlineStatus.Enabled = True
        Me.tmrAllOnlineStatus.Interval = 4000
        '
        'txt_Search
        '
        Me.txt_Search.AcceptsReturn = True
        Me.txt_Search.BackColor = System.Drawing.Color.AliceBlue
        Me.txt_Search.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txt_Search.Font = New System.Drawing.Font("Calibri", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_Search.Location = New System.Drawing.Point(8, 37)
        Me.txt_Search.Name = "txt_Search"
        Me.txt_Search.ShortcutsEnabled = False
        Me.txt_Search.Size = New System.Drawing.Size(258, 31)
        Me.txt_Search.TabIndex = 50
        Me.txt_Search.Visible = False
        Me.txt_Search.WordWrap = False
        '
        'pnlFolderPCs
        '
        Me.pnlFolderPCs.BackColor = System.Drawing.Color.White
        Me.pnlFolderPCs.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.pnlFolderPCs.Controls.Add(Me.treeObj)
        Me.pnlFolderPCs.Controls.Add(Me.lbl_TreeStats_PCs)
        Me.pnlFolderPCs.Controls.Add(Me.lbl_TreeStats_Folders)
        Me.pnlFolderPCs.Controls.Add(Me.txt_Search)
        Me.pnlFolderPCs.Location = New System.Drawing.Point(8, 8)
        Me.pnlFolderPCs.Name = "pnlFolderPCs"
        Me.pnlFolderPCs.Size = New System.Drawing.Size(275, 493)
        Me.pnlFolderPCs.TabIndex = 51
        '
        'frmUserUI
        '
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None
        Me.BackColor = System.Drawing.Color.WhiteSmoke
        Me.ClientSize = New System.Drawing.Size(854, 531)
        Me.Controls.Add(Me.pnl_Icon7)
        Me.Controls.Add(Me.Panel2)
        Me.Controls.Add(Me.pnl_TopManu)
        Me.Controls.Add(Me.btn_option1)
        Me.Controls.Add(Me.btn_option2)
        Me.Controls.Add(Me.btn_option3)
        Me.Controls.Add(Me.btn_option4)
        Me.Controls.Add(Me.pnlFolderPCs)
        Me.Controls.Add(Me.pnl_status)
        Me.Controls.Add(Me.pnl_Config_3)
        Me.Controls.Add(Me.pnl_NewFolder)
        Me.Controls.Add(Me.pnl_Config_2)
        Me.Controls.Add(Me.pnl_Config_1)
        Me.Controls.Add(Me.pnl_NewPC)
        Me.Font = New System.Drawing.Font("Calibri", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MaximizeBox = False
        Me.Name = "frmUserUI"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "AlSooz Remote PC"
        Me.pnl_NewPC.ResumeLayout(False)
        Me.pnl_NewPC.PerformLayout()
        Me.Panel6.ResumeLayout(False)
        Me.Panel6.PerformLayout()
        Me.pnl_NewFolder.ResumeLayout(False)
        Me.pnl_NewFolder.PerformLayout()
        Me.pnl_TopManu.ResumeLayout(False)
        Me.pnl_Icon4.ResumeLayout(False)
        CType(Me.pnl_Icon4_img, System.ComponentModel.ISupportInitialize).EndInit()
        Me.pnl_Icon1.ResumeLayout(False)
        Me.pnl_Icon7.ResumeLayout(False)
        CType(Me.pnl_Icon7_img, System.ComponentModel.ISupportInitialize).EndInit()
        Me.pnl_status.ResumeLayout(False)
        Me.pnl_status.PerformLayout()
        CType(Me.pnl_status_PC1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pnl_status_icon, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pnl_status_wire_remotePC, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pnl_status_wire_MyPC, System.ComponentModel.ISupportInitialize).EndInit()
        Me.pnl_Config_1.ResumeLayout(False)
        Me.pnl_Config_1.PerformLayout()
        Me.Panel4.ResumeLayout(False)
        Me.Panel4.PerformLayout()
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        Me.pnl_Config_1_pnl1.ResumeLayout(False)
        Me.pnl_Config_1_pnl1.PerformLayout()
        Me.pnl_Config_3.ResumeLayout(False)
        Me.pnl_Config_3.PerformLayout()
        Me.Panel2.ResumeLayout(False)
        Me.Panel2.PerformLayout()
        Me.pnl_Config_2.ResumeLayout(False)
        Me.pnl_Config_2.PerformLayout()
        Me.pnlFolderPCs.ResumeLayout(False)
        Me.pnlFolderPCs.PerformLayout()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents btn_fileLocation As Button
    Friend WithEvents popup_folder As FolderBrowserDialog
    Friend WithEvents treeObj As TreeView
    Friend WithEvents btn_option1 As Button
    Friend WithEvents btn_option2 As Button
    Friend WithEvents btn_option4 As Button
    Friend WithEvents btn_option3 As Button
    Friend WithEvents pnl_NewPC As Panel
    Friend WithEvents pnl_NewPC_btn_add As Button
    Friend WithEvents pnl_NewPC_txt_PCIP As TextBox
    Friend WithEvents pnl_NewPC_lbl1 As Label
    Friend WithEvents Label15 As Label
    Friend WithEvents pnl_NewPC_txt_PCName As TextBox
    Friend WithEvents Label17 As Label
    Friend WithEvents TreeViewImgs As ImageList
    Friend WithEvents pnl_NewFolder As Panel
    Friend WithEvents pnl_NewFolder_btn_Add As Button
    Friend WithEvents Label19 As Label
    Friend WithEvents pnl_NewFolder_Txt_FolderName As TextBox
    Friend WithEvents Label20 As Label
    Friend WithEvents pnl_NewFolder_Txt_FolderParent As TextBox
    Friend WithEvents Label18 As Label
    Friend WithEvents pnl_NewPC_txt_PCPassword As TextBox
    Friend WithEvents pnl_NewPC_lbl2 As Label
    Friend WithEvents Label22 As Label
    Friend WithEvents pnl_NewFolder_lbl_PCs As Label
    Friend WithEvents pnl_NewFolder_lbl_folders As Label
    Friend WithEvents pnl_NewPC_btn_PWDShow As Button
    Friend WithEvents Label24 As Label
    Friend WithEvents pnl_NewPC_Txt_FolderParent As TextBox
    Friend WithEvents Label23 As Label
    Friend WithEvents pnl_NewPC_txt_NetBIOSName As Label
    Friend WithEvents lbl_TreeStats_PCs As Label
    Friend WithEvents lbl_TreeStats_Folders As Label
    Friend WithEvents Label26 As Label
    Friend WithEvents pnl_TopManu As Panel
    Friend WithEvents pnl_Icon1 As Panel
    Friend WithEvents pnl_Icon4 As Panel
    Friend WithEvents btn_Install As Label
    Friend WithEvents pnl_Icon4_img As PictureBox
    Friend WithEvents myPcStatus_lbl_Service_1 As Label
    Friend WithEvents myPcStatus_lbl_Service_2 As Label
    Friend WithEvents myPcStatus_lbl_RemotePC_2 As Label
    Friend WithEvents btn_Disconnect_RemotePC As Button
    Friend WithEvents myPcStatus_lbl_MyPC_2 As Label
    Friend WithEvents btn_Disconnect_MyPC As Button
    Friend WithEvents myPcStatus_lbl_RemoteID_2 As Label
    Friend WithEvents myPcStatus_lbl_MyID_2 As Label
    Friend WithEvents myPcStatus_lbl_Unattended_2 As Label
    Friend WithEvents myPcStatus_lbl_Unattended_1 As Label
    Friend WithEvents pnl_status As Panel
    Friend WithEvents pnl_status_PC1 As PictureBox
    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents pnl_status_icon As PictureBox
    Friend WithEvents pnl_status_wire_MyPC As PictureBox
    Friend WithEvents pnl_status_wire_remotePC As PictureBox
    Friend WithEvents pnl_status_lbl As Label
    Friend WithEvents pnl_Config_1 As Panel
    Friend WithEvents Button7 As Button
    Friend WithEvents lbl1 As Label
    Friend WithEvents pnl_Config_3 As Panel
    Friend WithEvents pnl_Config_3_wsProtocol_lbl As Label
    Friend WithEvents Button2 As Button
    Friend WithEvents Label34 As Label
    Friend WithEvents pnl_Config_3_wsURL_lbl As Label
    Friend WithEvents pnl_Config_1_pnl1 As Panel
    Friend WithEvents pnl_Config_1_pnl1_rdo2 As RadioButton
    Friend WithEvents pnl_Config_1_pnl1_rdo1 As RadioButton
    Friend WithEvents pnl_Config_3_wsProtocol As ComboBox
    Friend WithEvents pnl_Config_3_wsURL As TextBox
    Friend WithEvents pnl_Config_1_txt_ID As TextBox
    Friend WithEvents Label31 As Label
    Friend WithEvents pnl_NewFolder_chk_isRoot As CheckBox
    Friend WithEvents Panel6 As Panel
    Friend WithEvents pnl_NewPC_rdo2 As RadioButton
    Friend WithEvents pnl_NewPC_rdo1 As RadioButton
    Friend WithEvents pnl_files_path_receive As TextBox
    Friend WithEvents Label11 As Label
    Friend WithEvents pnl_Icon7 As Panel
    Friend WithEvents pnl_Icon7_lbl As Label
    Friend WithEvents pnl_Icon7_img As PictureBox
    Friend WithEvents Panel1 As Panel
    Friend WithEvents pnl_Config_2_Rdo1 As RadioButton
    Friend WithEvents pnl_Config_2_Rdo2 As RadioButton
    Friend WithEvents Panel2 As Panel
    Friend WithEvents lbl_AppVersion As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents lbl_AppStatus As Label
    Friend WithEvents Label7 As Label
    Friend WithEvents Panel4 As Panel
    Friend WithEvents pnl_Config_1_UserApproval_rdo1 As RadioButton
    Friend WithEvents pnl_Config_1_UserApproval_rdo2 As RadioButton
    Friend WithEvents Label12 As Label
    Friend WithEvents pnl_Config_3_Start_Actions_chk2 As CheckBox
    Friend WithEvents Label33 As Label
    Friend WithEvents pnl_Config_3_Start_Actions_chk1 As CheckBox
    Friend WithEvents myPcStatus_lbl_RemoteNetBIOS As Label
    Friend WithEvents myPcStatus_lbl_MyNetBIOS As Label
    Friend WithEvents tmrUserApproval As Timer
    Friend WithEvents Label37 As Label
    Friend WithEvents pnl_Config_1_UserApproval_chk As CheckBox
    Friend WithEvents pnl_Config_1_txt_AutoDiscoverKeyword As TextBox
    Friend WithEvents Label36 As Label
    Friend WithEvents pnl_Config_3_Start_ViewControl_chk3 As CheckBox
    Friend WithEvents pnl_Config_3_Start_ViewControl_chk1 As CheckBox
    Friend WithEvents Label38 As Label
    Friend WithEvents pnl_Config_3_Start_ViewControl_chk2 As CheckBox
    Friend WithEvents pnl_Config_3_Start_ViewControl_dd_Quality As ComboBox
    Friend WithEvents btnFolder_MoveDown As Button
    Friend WithEvents btnFolder_MoveUp As Button
    Friend WithEvents CheckBox2 As CheckBox
    Friend WithEvents pnl_Config_3_Start_CloseConnection_chk2 As CheckBox
    Friend WithEvents pnl_Config_1_btn_password_MyPC As Button
    Friend WithEvents pnl_Config_1_txt_password_myPC As TextBox
    Friend WithEvents Label10 As Label
    Friend WithEvents Label30 As Label
    Friend WithEvents Button1 As Button
    Friend WithEvents pnl_Config_1_chk_password_MyPC As CheckBox
    Friend WithEvents pnl_Config_1_btn_password_UIAccess As Button
    Friend WithEvents pnl_Config_1_txt_password_UIAccess As TextBox
    Friend WithEvents Label25 As Label
    Friend WithEvents pnl_Config_1_chk_password_UIAccess As CheckBox
    Friend WithEvents pnl_Config_1_btn_password_Config As Button
    Friend WithEvents pnl_Config_1_txt_password_config As TextBox
    Friend WithEvents Label28 As Label
    Friend WithEvents pnl_Config_1_chk_password_config As CheckBox
    Friend WithEvents pnl_Config_2 As Panel
    Friend WithEvents Label1 As Label
    Friend WithEvents btn_ScreenControl_RemotePC As Button
    Friend WithEvents btn_Files_RemotePC As Button
    Friend WithEvents btnTaskmgr As Button
    Friend WithEvents tmrAllOnlineStatus As Timer
    Friend WithEvents txt_Search As TextBox
    Friend WithEvents pnlFolderPCs As Panel
    Friend WithEvents pnl_NewPC_txt_Dateadded As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents pnl_NewPC_txt_Username As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents txtdebug As TextBox
    Friend WithEvents Label3 As Label
    Friend WithEvents pnl_Config_3_chkAllowFilesSend As CheckBox
    Friend WithEvents pnl_Config_3_chkAllowFilesReceive As CheckBox
    Friend WithEvents pnl_Config_3_chkAllowClipboardReceive As CheckBox
    Friend WithEvents Label5 As Label
    Friend WithEvents pnl_Config_3_chkAllowClipboardSend As CheckBox
    Friend WithEvents Label8 As Label
    Friend WithEvents pnl_Config_1_chk_discoveryNotification As CheckBox
    Friend WithEvents pnl_Config_1_chk_password_Exit As CheckBox
    Friend WithEvents Label9 As Label
    Friend WithEvents pnl_Config_1_txt_password_Exit As TextBox
    Friend WithEvents pnl_Config_1_btn_password_Exit As Button
End Class
