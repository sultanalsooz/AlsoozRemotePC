﻿Imports System.ComponentModel

Public Class frmMsgbox

    Friend isSimpleMessage As Boolean = False
    Friend simpleMessage As String = ""

    Friend remoteInstallID As String = ""
    Friend countDown_Current As Integer = 30

    Friend isViewOnly As Boolean = False
    Private Sub frmMsgbox_Closing(sender As Object, e As CancelEventArgs) Handles Me.Closing

        frmMessageObj = Nothing
    End Sub

    Private Sub frmMsgbox_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Using g As Graphics = Me.CreateGraphics
            GenerateFontSizefromScreenDPI(g, lbl_hidden_fontSize, lbl_CountDown)
        End Using

        resizeAllChildControls(Me)


    End Sub

    Private Sub frmMsgbox_Shown(sender As Object, e As EventArgs) Handles Me.Shown
        If isSimpleMessage Then
            pnl_status_desc.Text = simpleMessage
            pnl_status_desc.Text = simpleMessage
            btn_Allow.Visible = False
            btn_Cancel.Visible = False
        Else
            lbl_CountDown.Text = countDown_Current
            btnSimpleMessageClose.Visible = False
        End If
        Timer1.Start()
    End Sub

    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick
        countDown_Current -= 1
        If countDown_Current < 1 Then
            If isSimpleMessage Then

            Else
                myApp.MyConn.SendAuthRequestTimeout(remoteInstallID)
            End If

            Close()
        Else
            lbl_CountDown.Text = countDown_Current
        End If

    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles btn_Cancel.Click
        myApp.MyConn.SendAuthRequestReject(remoteInstallID)
        Close()
    End Sub

    Private Sub btn_option1_Click(sender As Object, e As EventArgs) Handles btn_Allow.Click
        myApp.MyConn.SendAuthRequestAccept(remoteInstallID, isViewOnly)
        Close()
    End Sub

    Private Sub Button1_Click_1(sender As Object, e As EventArgs) Handles btnSimpleMessageClose.Click
        Close()
    End Sub
End Class