﻿Imports System.ComponentModel
Imports System.IO
Imports System.Text

Public Class frmScreenControl

    Private WithEvents fastPanel As New customPaint

    Friend remoteServiceStatus As String = ""
    Private Sub frmreceiver_Closing(sender As Object, e As CancelEventArgs) Handles Me.Closing

        Try
            Timer1.Stop()
        Catch ex As Exception
        End Try

        isthreadContinue = False

        Try
            If Not IsNothing(fastPanel) Then fastPanel.Dispose()
        Catch ex As Exception : End Try

        Try
            If Threading.Monitor.TryEnter(lastMousePosistion_lock, 1000) Then
                Threading.Monitor.PulseAll(lastMousePosistion_lock)
            End If
        Catch ex As Exception : End Try
        Try
            Threading.Monitor.Exit(lastMousePosistion_lock)
        Catch ex As Exception : End Try

        Try
            myApp.Service_ScreenStop(False)
        Catch ex As Exception
        End Try

        myApp.MyConn.autoCloseConnection()

        Try
            If Not IsNothing(frmUserUIObj) Then frmUserUIObj.WindowState = FormWindowState.Normal
        Catch ex As Exception
        End Try

        frmScreenControlObj = Nothing

    End Sub

    Private isSharingMyInput As Boolean = False
    Private lblArry As Label() = Nothing

    Private Sub frmreceiver_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        pnl_main.Location = New Point(0, 0)

        fastPanel.Location = New Point(0, 0)

        fastPanel.TilesBoxSize = gbl_TitleBoxSize


        Me.Controls.Add(fastPanel)


        dd_Quality.SelectedIndex = myApp.Controller_Quality

        frmUserUIObj.WindowState = FormWindowState.Minimized

        Me.WindowState = FormWindowState.Maximized

        resizeAllChildControls(Me)

        If myApp.MyConn.isViewerOnly Then
            Panel2.Visible = False
            Panel3.Visible = False
            Panel4.Visible = False
            lbl_quality.Text = "F1 = FullScreen"
            dd_Quality.Visible = False
        Else
            Timer1.Start()
            myApp.MyConn.SendRequestAsText("CMD_ServiceStatus:")
        End If

    End Sub

    Private Sub frmreceiver_Activated(sender As Object, e As EventArgs) Handles Me.Activated
        isFormFocus = True
        isformLoaded = True
        setFocusToInput()

        If isFormFirstShow Then

        Else
            isFormFirstShow = False
            ' fastPanel.clear() 
        End If



    End Sub
    Private Sub frmreceiver_Deactivate(sender As Object, e As EventArgs) Handles Me.Deactivate
        isFormFocus = False
        If myApp.MyConn.isViewerOnly Then Return
        Try
            If isCNTRL_On > 0 Then
                strb_KeyUp.Clear()
                strb_KeyUp.Append("KU_")
                strb_KeyUp.Append(isCNTRL_On)
                myApp.MyConn.SendRequestAsText(strb_KeyUp.ToString)
                isCNTRL_On = 0
            End If
            If isALT_On > 0 Then
                strb_KeyUp.Clear()
                strb_KeyUp.Append("KU_")
                strb_KeyUp.Append(isALT_On)
                myApp.MyConn.SendRequestAsText(strb_KeyUp.ToString)
                isALT_On = 0
            End If
            If isSHFT_On > 0 Then
                strb_KeyUp.Clear()
                strb_KeyUp.Append("KU_")
                strb_KeyUp.Append(isSHFT_On)
                myApp.MyConn.SendRequestAsText(strb_KeyUp.ToString)
                isSHFT_On = 0
            End If
        Catch ex As Exception
        End Try
        Try
            ' If isFullScreen Then StartFullScreen(False)
        Catch ex As Exception
        End Try

        isformLoaded = False

    End Sub

    Private resize_init As Boolean = False
    Friend ImgDrawHeight As Integer = 0
    Friend ImgDrawWidth As Integer = 0
    Private ImgDrawRatio As Double = 0
    Private originalPnlMainWidth As Integer = 0

    Private isInitialFullScreen As Boolean = False
    Private isIntialRemoteMouse As Boolean = False
    Private Sub frmScreenControl_Shown(sender As Object, e As EventArgs) Handles Me.Shown
        If resize_init = False Then
            resize_init = True
            originalPnlMainWidth = pnl_main.Width
            resizeFastPanel(False)
            requestScreenUpdate()

            If myApp.MyConn.isViewerOnly Then


            Else

                chk_MouseSend.Checked = IIf(myApp.Controller_ControlPC = "yes", True, False)

                If myApp.Controller_RemoteMouse = "yes" Then
                    isIntialRemoteMouse = True
                End If
            End If

            If myApp.Controller_FullScreen = "yes" Then
                isInitialFullScreen = True
            End If

        End If
    End Sub

    Friend Sub updateRemoteServiceStatus()
        ' btn_installService.Enabled = True
        If remoteServiceStatus = "notinstalled" Then
            btn_installService.Text = "Install Service"
            btn_installService.BackColor = Color.LimeGreen
        ElseIf remoteServiceStatus = "notrunnning" Then
            btn_installService.Text = "Service Stopped"
            btn_installService.BackColor = Color.Red
        Else ' "running"
            'btn_installService.Enabled = False
            btn_installService.Text = "Installed"
            btn_installService.BackColor = Color.Gray
        End If
    End Sub
    Friend Sub updateImgViewer(ByRef vimageRef As MyScreenRecorderClass.WS_Image)

        Try
            ' Threading.Monitor.Enter(ImageLock)

            If pauseUpdates Then Return

            If vimageRef.imageType = 1 Then

                fastPanel.Image1 = vimageRef.bm

                If isInitialFullScreen Then
                    isInitialFullScreen = False
                    StartFullScreen(True)
                End If

                If isIntialRemoteMouse Then
                    isIntialRemoteMouse = False
                    chk_RemoteMouseShow.Checked = True
                End If
            Else

                fastPanel.TilesPoints = vimageRef.pt
                fastPanel.ImageTiles = vimageRef.bm
            End If

        Catch ex As Exception
        End Try

    End Sub

    ' Private strb_MouseMove As New StringBuilder

    Dim strb_KeyUp As New StringBuilder

    Dim strb_Keydown As New StringBuilder

    Private isALT_On As Integer = 0
    Private isCNTRL_On As Integer = 0
    Private isSHFT_On As Integer = 0

    Private Sub frmreceiver_PreviewKeyDown(sender As Object, e As PreviewKeyDownEventArgs) Handles txt_input.PreviewKeyDown,
        chk_MouseSend.PreviewKeyDown, chk_RemoteMouseShow.PreviewKeyDown

        ' Debug.Print(e.KeyCode)

        If myApp.MyConn.isViewerOnly Then
            If e.KeyCode = Keys.F1 Then
                StartFullScreen(Not isFullScreen)
            End If
            Return
        End If

        If e.KeyCode = Keys.NumLock OrElse e.KeyCode = Keys.CapsLock Then
            Return
        End If

        If e.KeyCode = Keys.F1 Then

            StartFullScreen(Not isFullScreen)
            Return

        ElseIf e.KeyCode = Keys.F2 Then

            'Dim sindex As Integer = dd_Quality.SelectedIndex
            'If sindex = 2 Then
            '    dd_Quality.SelectedIndex = 0
            'Else
            '    dd_Quality.SelectedIndex = sindex + 1
            'End If

            chk_MouseSend.Checked = Not chk_MouseSend.Checked
            Return

        ElseIf e.KeyCode = Keys.F3 Then

            chk_RemoteMouseShow.Checked = Not chk_RemoteMouseShow.Checked
            Return

        ElseIf e.KeyCode = Keys.F4 Then

            sendKeyboardLocks("144")
            Return
        End If

        If isSharingMyInput = False Then Return
        If myApp.MyConn.connectionType = enum_ConnectType.UDP OrElse myApp.MyConn.isServiceOpen_WS_Mouse Then

            If e.KeyValue = 17 Then
                isCNTRL_On = 17
            ElseIf e.KeyValue = 18 Then
                isALT_On = 18
            ElseIf e.KeyValue = 16 Then
                isSHFT_On = 16
            End If

            strb_Keydown.Clear()
            strb_Keydown.Append("KD_")
            strb_Keydown.Append(e.KeyValue)

            'lblrec1.Text = strb_Keydown.ToString.Remove(0, 6)

            myApp.MyConn.SendRequestAsText(strb_Keydown.ToString)
        End If
    End Sub



    Private Sub frmreceiver_KeyDown(sender As Object, e As KeyEventArgs) Handles txt_input.KeyDown,
        chk_MouseSend.KeyDown, chk_RemoteMouseShow.KeyDown

        e.SuppressKeyPress = True
        'If isSharingMyInput = False Then Return
    End Sub

    Private Sub frmreceiver_KeyUp(sender As Object, e As KeyEventArgs) Handles txt_input.KeyUp,
            chk_MouseSend.KeyUp, chk_RemoteMouseShow.KeyUp


        If e.KeyCode = Keys.F1 OrElse e.KeyCode = Keys.F2 OrElse e.KeyCode = Keys.F3 OrElse e.KeyCode = Keys.F4 Then
            e.SuppressKeyPress = True
            Return
        End If


        If e.KeyCode = Keys.NumLock OrElse e.KeyCode = Keys.CapsLock Then
            updateMyNumLockstatus()
            Return
        End If

        If isSharingMyInput = False Then Return
        If myApp.MyConn.connectionType = enum_ConnectType.UDP OrElse myApp.MyConn.isServiceOpen_WS_Mouse Then

            If e.KeyValue = 17 Then
                isCNTRL_On = 0
            ElseIf e.KeyValue = 18 Then
                isALT_On = 0
            ElseIf e.KeyValue = 16 Then
                isSHFT_On = 0
            End If

            strb_KeyUp.Clear()
            strb_KeyUp.Append("KU_")
            strb_KeyUp.Append(e.KeyValue)

            'lblrec1.Text = strb_KeyUp.ToString.Remove(0, 6)

            myApp.MyConn.SendRequestAsText(strb_KeyUp.ToString)
            e.SuppressKeyPress = True
        End If

    End Sub

    Private Sub chk_MouseSend_CheckedChanged(sender As Object, e As EventArgs) Handles chk_MouseSend.CheckedChanged
        enableInputCapture()

    End Sub

    Private Sub enableInputCapture()
        If myApp.MyConn.isViewerOnly Then Return

        isSharingMyInput = chk_MouseSend.Checked

        If isSharingMyInput Then
            StartMouseLoopCapture()
            tmr_NumCapsLock.Start()

            updateMyNumLockstatus()
            myApp.MyConn.SendRequestAsText("CMD_sendKeyboardNumlock:")

            showUserMsg("Control Remote PC Enabled")

        Else
            isthreadContinue = False
            tmr_NumCapsLock.Stop()
            showUserMsg("Control Remote PC Stopped")
        End If
        setFocusToInput()


    End Sub

    Dim MouseShowTxt As String = "M_show"
    Dim MouseHideTxt As String = "M_hide"

    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick

        If isformLoaded Then
            setFocusToInput()
            Timer1.Stop()
        End If

    End Sub
    Friend isformLoaded As Boolean = False
    Friend isFormFocus As Boolean = True
    Private isFormFirstShow As Boolean = False

    Private Sub txt_input_GotFocus(sender As Object, e As EventArgs) Handles txt_input.GotFocus
        Timer1.Stop()

    End Sub

    Private Sub txt_input_LostFocus(sender As Object, e As EventArgs) Handles txt_input.LostFocus
        If myApp.MyConn.isViewerOnly Then Return
        Timer1.Start()

    End Sub

    Private Sub ComboBox1_DropDownClosed(sender As Object, e As EventArgs)

        If myApp.MyConn.isViewerOnly Then Return
        setFocusToInput()
    End Sub

    Dim strb_Resize As New StringBuilder

    Private Sub requestScreenUpdate()
        If myApp.MyConn.isViewerOnly Then Return
        If isformLoaded Then

            strb_Resize.Clear()

            strb_Resize.Append("CMD_ScreenSize:")

            strb_Resize.Append(dd_Quality.SelectedIndex)

            If myApp.MyConn.IsRemotePCConnected Then
                myApp.MyConn.SendRequestAsText(strb_Resize.ToString)
            Else
                Close()
            End If

            showUserMsg(dd_Quality.SelectedItem)

        End If
    End Sub

    Private Sub showUserMsg(ByVal msg As String)
        If resize_init Then
            tmr_lblmsg.Stop()
            lbl_userMsg.Text = msg
            lbl_userMsg.Visible = True
            tmr_lblmsg.Start()
        End If
    End Sub

    Private lastMouseX As Integer = 0
    Private lastMouseY As Integer = 0

    Private bMouseClick_Left_DownType As Byte() = BitConverter.GetBytes(CUShort(1))
    Private bMouseClick_Left_UpType As Byte() = BitConverter.GetBytes(CUShort(2))
    Private bMouseClick_left_ClickType As Byte() = BitConverter.GetBytes(CUShort(3))
    Private bMouseClick_Right_ClickType As Byte() = BitConverter.GetBytes(CUShort(4))

    Private bMouseScroll_Up As Byte() = BitConverter.GetBytes(CUShort(1))
    Private bMouseScroll_Down As Byte() = BitConverter.GetBytes(CUShort(2))

    Private isMouseDown As Boolean = False
    Private isMouseDrag As Boolean = False
    Private MouseDragSent As Boolean = False

    Private Sub imgViewer_MouseDown(sender As Object, e As MouseEventArgs) Handles fastPanel.MouseDown

        If isSharingMyInput = False Then Return
        If myApp.MyConn.connectionType = enum_ConnectType.UDP OrElse myApp.MyConn.isServiceOpen_WS_Mouse Then
            If e.Button = MouseButtons.Left Then
                isMouseDown = True
                MouseDragSent = False
            Else
                ' Buffer.BlockCopy(BitConverter.GetBytes(MouseClick_Right_Down), 0, mouseArry, 2, 2)
            End If
        End If

    End Sub


    Private Sub imgViewer_MouseUp(sender As Object, e As MouseEventArgs) Handles fastPanel.MouseUp
        If isSharingMyInput = False Then Return
        If myApp.MyConn.connectionType = enum_ConnectType.UDP OrElse myApp.MyConn.isServiceOpen_WS_Mouse Then
            Dim mouseArry(3) As Byte
            Buffer.BlockCopy(sendType_MouseClickType, 0, mouseArry, 0, 2)
            If e.Button = MouseButtons.Left Then
                If isMouseDrag Then
                    Buffer.BlockCopy(bMouseClick_Left_UpType, 0, mouseArry, 2, 2)
                Else
                    Buffer.BlockCopy(bMouseClick_left_ClickType, 0, mouseArry, 2, 2)
                End If

            Else
                Buffer.BlockCopy(bMouseClick_Right_ClickType, 0, mouseArry, 2, 2)
            End If

            isMouseDrag = False
            MouseDragSent = True
            isMouseDown = False
            sendMouseMove(mouseArry)

        End If
    End Sub

    Private lastMousePosistion As Point = New Point(0, 0)
    Private lastMousePosistion_lock As New Object()
    Private Sub fastPanel_MouseMove(sender As Object, e As MouseEventArgs) Handles fastPanel.MouseMove
        If isSharingMyInput = False Then Return
        Try
            If Threading.Monitor.TryEnter(lastMousePosistion_lock, 1000) Then
                lastMousePosistion = e.Location
                Threading.Monitor.PulseAll(lastMousePosistion_lock)
            End If

        Catch ex As Exception
        End Try
        Try
            Threading.Monitor.Exit(lastMousePosistion_lock)
        Catch ex As Exception
        End Try
    End Sub

    Dim isMouseScrollLocked As Boolean = False
    Private Sub fastPanel_MouseWheel(sender As Object, e As MouseEventArgs) Handles fastPanel.MouseWheel
        Try

            If isSharingMyInput = False Then Return
            If myApp.MyConn.connectionType = enum_ConnectType.UDP OrElse myApp.MyConn.isServiceOpen_WS_Mouse Then


                If isMouseScrollLocked Then Return
                isMouseScrollLocked = True

                Dim mouseArryScroll(6) As Byte
                Buffer.BlockCopy(sendType_MouseScrollType, 0, mouseArryScroll, 0, 2)
                If e.Delta > 0 Then
                    Buffer.BlockCopy(bMouseScroll_Down, 0, mouseArryScroll, 2, 2)
                Else
                    Buffer.BlockCopy(bMouseScroll_Up, 0, mouseArryScroll, 2, 2)
                End If

                Dim speed As UShort = CUShort((Math.Abs(e.Delta) * 0.5))
                Dim bspeed As Byte() = BitConverter.GetBytes(speed)
                Buffer.BlockCopy(bspeed, 0, mouseArryScroll, 4, 2)

                sendMouseMove(mouseArryScroll)
                Threading.Thread.Sleep(15)
            End If
        Catch ex As Exception
        End Try
        isMouseScrollLocked = False
    End Sub

    ' Private mouselockObj As New Object
    ' Private lastMouseMoveTime As Long = 0
    Friend Function sendMousePosition() As Boolean

        If isformLoaded = False OrElse isSharingMyInput = False OrElse fastPanel.Width = 0 Then Return False

        Try

            ' Dim pnlLoc As Point = fastPanel.Location
            'Dim frmLoc As Point = Me.Location
            'Dim msLoc As Point = lastMousePosistion
            Dim x As Integer = 0  'msLoc.X - (frmLoc.X + FastPanelLeft)
            Dim y As Integer = 0 'msLoc.Y - (frmLoc.Y + FastPanelTop)

            Try
                If Threading.Monitor.TryEnter(lastMousePosistion_lock, 1000) Then
                    Threading.Monitor.Wait(lastMousePosistion_lock, 1000)
                Else
                    Return False
                End If

                x = lastMousePosistion.X
                y = lastMousePosistion.Y
            Catch ex As Exception
            End Try
            Try
                Threading.Monitor.Exit(lastMousePosistion_lock)
            Catch ex As Exception
            End Try

            If lastMouseX = x AndAlso lastMouseY = y Then Return False

            If x < 0 OrElse y < 0 Then Return False

            'Dim sTimeStamp As Long = Now.Ticks

            'If lastMouseMoveTime + 100000 > sTimeStamp Then Return False
            'lastMouseMoveTime = sTimeStamp

            ' Threading.Monitor.Enter(mouselockObj)

            Dim mouseloc As Point = New Point(x, y)


            lastMouseX = mouseloc.X
            lastMouseY = mouseloc.Y

            If isMouseDown AndAlso MouseDragSent = False Then
                MouseDragSent = True
                isMouseDrag = True
                Dim mouseArryDrag(3) As Byte
                Buffer.BlockCopy(sendType_MouseClickType, 0, mouseArryDrag, 0, 2)
                Buffer.BlockCopy(bMouseClick_Left_DownType, 0, mouseArryDrag, 2, 2)
                sendMouseMove(mouseArryDrag)
                Threading.Thread.Sleep(60)
            End If

            Dim mLocX As UInteger = 0
            Dim mLocY As UInteger = 0

            Dim mDLocX As Single = 0
            Dim mDLocY As Single = 0

            mLocX = (lastMouseX / fastPanel.Width) * 65535
            mLocY = (lastMouseY / fastPanel.Height) * 65535

            mDLocX = (lastMouseX / fastPanel.Width)
            mDLocY = (lastMouseY / fastPanel.Height)

            Dim bLocX As Byte() = BitConverter.GetBytes(mLocX)
            Dim bLocY As Byte() = BitConverter.GetBytes(mLocY)


            'If sTimeStamp > lastsTimeStamp Then
            'lastsTimeStamp = sTimeStamp

            Dim mouseArry(17) As Byte
            'Dim bTime As Byte() = BitConverter.GetBytes(sTimeStamp)
            Buffer.BlockCopy(sendType_MouseMoveType, 0, mouseArry, 0, 2)
            Buffer.BlockCopy(bLocX, 0, mouseArry, 2, 4)
            Buffer.BlockCopy(bLocY, 0, mouseArry, 6, 4)
            Buffer.BlockCopy(BitConverter.GetBytes(mDLocX), 0, mouseArry, 10, 4)
            Buffer.BlockCopy(BitConverter.GetBytes(mDLocY), 0, mouseArry, 14, 4)

            'Try
            '    Threading.Monitor.Exit(mouselockObj)
            'Catch ex As Exception
            'End Try


            sendMouseMove(mouseArry)

            Return True
            ' Debug.Print("Mouse Sent")
        Catch ex As Exception

        End Try

        'Try
        '    Threading.Monitor.Exit(mouselockObj)
        'Catch ex As Exception
        'End Try

        Return False
    End Function


    Friend isthreadContinue As Boolean = True
    Private isInLoop As Boolean = False

    Friend Sub StartMouseLoopCapture()
        If isInLoop Then Return
        If myApp.MyConn.connectionType = enum_ConnectType.UDP OrElse myApp.MyConn.isServiceOpen_WS_Mouse Then

            AllowWsReceiveTime = Now
            isthreadContinue = True

            Clipboard_SaveOSDataToAppData()

            Dim p As New Threading.Thread(Sub()

                                              LoopMouseCapture()
                                          End Sub)

            ' p.SetApartmentState(Threading.ApartmentState.STA)
            p.Start()

        Else
            If myApp.MyConn.connectionType = enum_ConnectType.WS Then
                If myApp.MyConn.WS_Service_Open(wsArry_MouseIndex, True) Then
                    StartMouseLoopCapture()
                End If
            End If
        End If
    End Sub


    Private AllowWsSendTime As Date = Now
    Friend AllowWsReceiveTime As Date = Now
    Private Sub LoopMouseCapture()

        Try
            Try
                Threading.Monitor.Exit(MouseSendLock)
            Catch ex As Exception
            End Try
            Do While isthreadContinue

                If isFormFocus Then

                    isInLoop = True
                    If myApp.MyConn.connectionType = enum_ConnectType.WS Then

                        '  Threading.Thread.Sleep(10)
                        If AllowWsSendTime.Ticks <= AllowWsReceiveTime.Ticks Then
                            AllowWsSendTime = Now
                            If sendMousePosition() Then
                                ' Debug.Print("Mouse Next Sent")
                            Else
                                ' Threading.Thread.Sleep(10)
                                AllowWsReceiveTime = Now
                            End If
                        End If

                    Else
                        sendMousePosition()
                        ' Threading.Thread.Sleep(15)
                    End If

                Else
                    Threading.Thread.Sleep(50)
                End If
            Loop
        Catch ex As Exception
        End Try

        isInLoop = False
    End Sub


    Private MouseSendLock As New Object
    Private Sub sendMouseMove(ByRef barry As Byte())

        Try
            If Threading.Monitor.TryEnter(MouseSendLock, 1000) Then
                myApp.MyConn.SendRequestAsByte(barry, wsArry_MouseIndex)
            End If
        Catch ex As Exception
        End Try
        Try
            Threading.Monitor.Exit(MouseSendLock)
        Catch ex As Exception
        End Try
    End Sub

    Private Sub btn_fixScreen_Click(sender As Object, e As EventArgs)

        If myApp.MyConn.isViewerOnly Then Return

        If isformLoaded Then
            If myApp.MyConn.connectionType = enum_ConnectType.WS Then

            Else
                Return
            End If
            requestScreenUpdate()
        End If

    End Sub

    Private Sub chk_MyMouseShow_CheckedChanged(sender As Object, e As EventArgs) Handles chk_MyMouseShow.CheckedChanged
        If myApp.MyConn.isViewerOnly Then Return
        If chk_RemoteMouseShow.Checked = False Then
            chk_MyMouseShow.Checked = True

        Else
            If chk_MyMouseShow.Checked Then
                fastPanel.Cursor = Cursor.Current
            Else
                fastPanel.Cursor = New Cursor(New MemoryStream(My.Resources.trans))
            End If
            setFocusToInput()

        End If
    End Sub

    Private Sub chk_RemoteMouseShow_CheckedChanged(sender As Object, e As EventArgs) Handles chk_RemoteMouseShow.CheckedChanged
        If myApp.MyConn.isViewerOnly Then Return
        If isformLoaded Then
            Try
                If chk_RemoteMouseShow.Checked Then
                    myApp.MyConn.SendRequestAsText(MouseShowTxt)
                    showUserMsg("Remote PC Mouse Visible")
                Else
                    If chk_MyMouseShow.Checked = False Then
                        chk_MyMouseShow.Checked = True
                        fastPanel.Cursor = Cursor.Current
                    End If
                    myApp.MyConn.SendRequestAsText(MouseHideTxt)

                    showUserMsg("Remote PC Mouse Hidden")
                End If

                setFocusToInput()

            Catch ex As Exception
            End Try

        End If
    End Sub


    Private Sub setFocusToInput()
        Try
            If Not txt_input.Focused Then txt_input.Focus()
        Catch ex As Exception
        End Try
    End Sub
    Private Sub dd_Compression_SelectedIndexChanged(sender As Object, e As EventArgs) Handles dd_Quality.SelectedIndexChanged
        If myApp.MyConn.isViewerOnly Then Return

        If resize_init AndAlso isformLoaded Then
            requestScreenUpdate()
            setFocusToInput()
        End If
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click

        StartFullScreen(True)
        setFocusToInput()
    End Sub

    Private isFullScreen As Boolean = False
    Private pauseUpdates As Boolean = False

    Friend Sub StartFullScreen(isTrue As Boolean)
        Try

            pauseUpdates = True
            Me.Controls.Remove(fastPanel)
            If isTrue Then
                isFullScreen = True
                InitializeScalingFactor()
                Me.WindowState = FormWindowState.Normal
                Me.FormBorderStyle = FormBorderStyle.None
                Dim currentScreen As Screen = Screen.FromControl(Me)
                Me.ClientSize = New System.Drawing.Size(currentScreen.Bounds.Width, currentScreen.Bounds.Height)

                Me.Location = New Point(currentScreen.Bounds.Left, currentScreen.Bounds.Top)
                Me.Size = New Size(ClientSize.Width, ClientSize.Height)
            Else
                ' Me.TopMost = False
                Me.FormBorderStyle = FormBorderStyle.FixedDialog
                Me.WindowState = FormWindowState.Maximized
                isFullScreen = False
            End If

            Me.Controls.Add(fastPanel)
            pauseUpdates = False
            resizeFastPanel(isTrue)

            fastPanel.updateStrechSize()
            If isTrue Then
                ' Me.TopMost = True
                fastPanel.Location = New Point((Me.ClientSize.Width / 2) - (fastPanel.Width / 2), 0)
            End If

            If isFullScreen Then
                showUserMsg("Full Screen")
            Else
                showUserMsg("Normal Screen")
            End If
        Catch ex As Exception

        End Try
    End Sub

    Friend Sub resizeFastPanel(isFullScreen As Boolean)
        If isFullScreen Then
            pnl_main.Size = New Size(0, 0)
            'fastPanel.Location = New Point(0, 0)

        Else
            pnl_main.Size = New Size(originalPnlMainWidth, Me.ClientSize.Height)
            fastPanel.Location = New Point(pnl_main.Width, 0)

        End If

        ImgDrawWidth = Me.ClientSize.Width - pnl_main.Width
        ImgDrawHeight = Me.ClientSize.Height

        lbl_userMsg.Location = New Point(pnl_main.Width + ((ImgDrawWidth / 2) - (lbl_userMsg.Width / 2)), 0)

    End Sub

    Private Sub Button2_Click_1(sender As Object, e As EventArgs) Handles Button2.Click
        If myApp.MyConn.isViewerOnly Then Return
        frmFilesObj = New frmfiles
        frmFilesObj.Show(Me)

        frmFilesObj.Location = New Point(Me.Width - frmFilesObj.Width - 10, Me.Height - frmFilesObj.Height - 10)

    End Sub


    Private Sub tmr_lblmsg_Tick(sender As Object, e As EventArgs) Handles tmr_lblmsg.Tick
        lbl_userMsg.Visible = False
        tmr_lblmsg.Stop()
    End Sub

    Dim strbSpecialkey As New StringBuilder
    Private Sub Button6_Click(sender As Object, e As EventArgs) Handles btn_numlock_remote.Click
        If myApp.MyConn.isViewerOnly Then Return

        sendKeyboardLocks("144")
        setFocusToInput()
    End Sub

    Friend Sub updateMyNumLockstatus()

        Dim numlockstate As Integer() = isKeyboardNumLockOn()
        If numlockstate(0) = 1 Then
            btn_numlock_my.BackColor = Color.LimeGreen
        ElseIf numlockstate(0) = -1 Then
            btn_numlock_my.BackColor = Color.LightGray
        Else ' "Err" 
            btn_numlock_my.BackColor = Color.Red
        End If


        ' add capslock here

    End Sub

    Friend Sub updateRemoteNumLockStatus(ByVal keyboardLockStatus As String) 'Num|Caps, 1 =on, -1 = off, 0 = err

        Dim numlockstatus As String = ""
        Dim capslockstatus As String = ""

        If keyboardLockStatus.IndexOf("|") > -1 Then
            Dim keylockstatus As String() = keyboardLockStatus.Split("|")
            numlockstatus = keylockstatus(0).Trim
            capslockstatus = keylockstatus(1).Trim
        Else
            numlockstatus = keyboardLockStatus
            capslockstatus = ""
        End If


        If numlockstatus = "1" Then
            btn_numlock_remote.BackColor = Color.LimeGreen
        ElseIf numlockstatus = "-1" Then
            btn_numlock_remote.BackColor = Color.LightGray
        Else ' "Err" 
            btn_numlock_remote.BackColor = Color.Red
        End If

        If capslockstatus = 1 Then
            btn_Capslock_remote.BackColor = Color.LimeGreen
        ElseIf capslockstatus = -1 Then
            btn_Capslock_remote.BackColor = Color.LightGray
        Else ' "Err" 
            btn_Capslock_remote.BackColor = Color.Red
        End If
    End Sub

    Private Async Sub toggleMyNumLock()

        Key_Send_Down(Keys.NumLock)
        Await Task.Delay(100)
        Key_Send_Up(Keys.NumLock)

        showUserMsg("My Numpad Lock Updated")

        Await Task.Delay(500)

        updateMyNumLockstatus()
    End Sub


    Private Async Sub sendKeyboardLocks(ByVal txtKeyLock) ' 144= numlock , 20 = capslock
        If isSharingMyInput = False Then
            MsgBox("Remote PC Input Control is OFF")
            Return
        End If
        If myApp.MyConn.connectionType = enum_ConnectType.UDP OrElse myApp.MyConn.isServiceOpen_WS_Mouse Then
            strbSpecialkey.Clear()
            strbSpecialkey.Append("KD_").Append(txtKeyLock)
            ' strbSpecialkey.Append(Keys.NumLock)

            myApp.MyConn.SendRequestAsText(strbSpecialkey.ToString)

            Await Task.Delay(100)

            strbSpecialkey.Clear()
            strbSpecialkey.Append("KU_").Append(txtKeyLock)
            'strbSpecialkey.Append(Keys.NumLock)

            myApp.MyConn.SendRequestAsText(strbSpecialkey.ToString)

            showUserMsg("Remote Numpad Lock Updated")


        End If
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles btn_SAS.Click
        If myApp.MyConn.isViewerOnly Then Return

        send_Cntrl_Alt_Del()
        setFocusToInput()
    End Sub

    Private Sub send_Cntrl_Alt_Del()

        If isSharingMyInput = False Then Return
        If myApp.MyConn.connectionType = enum_ConnectType.UDP OrElse myApp.MyConn.isServiceOpen_WS_Mouse Then
            myApp.MyConn.SendRequestAsText(sendType_SendSAS)
            setFocusToInput()
        End If
    End Sub

    Private Sub Button7_Click(sender As Object, e As EventArgs) Handles btnReboot.Click
        If myApp.MyConn.isViewerOnly Then Return
        Dim result As MsgBoxResult = MsgBox("Rebooting Remote PC, Are You Sure?", vbYesNo)
        If result = MsgBoxResult.Yes Then
            myApp.MyConn.SendRequestAsText("RCMD_Reboot")
        End If
    End Sub

    Private Sub btn_installService_Click(sender As Object, e As EventArgs) Handles btn_installService.Click
        If myApp.MyConn.isViewerOnly Then Return
        If remoteServiceStatus = "notinstalled" Then
            frmAccountDetailsObj = New frmAccountDetails()
            frmAccountDetailsObj.Show(Me)
        ElseIf remoteServiceStatus = "notrunnning" Then
            MsgBox("User Needs To Start the App Service from Task Manager.")
        Else ' "running"
            MsgBox("App Service Already Installed, All Options Are Available.")
        End If

    End Sub

    Private Sub btn_numlock_my_Click(sender As Object, e As EventArgs) Handles btn_numlock_my.Click
        toggleMyNumLock()
        setFocusToInput()
    End Sub

    Private Sub tmr_NumCapsLock_Tick(sender As Object, e As EventArgs) Handles tmr_NumCapsLock.Tick
        If chk_MouseSend.Checked Then
            updateMyNumLockstatus()
            Try
                myApp.MyConn.SendRequestAsText("CMD_sendKeyboardNumlock:")
            Catch ex As Exception
            End Try
        End If

    End Sub

    Private Sub btn_Capslock_remote_Click(sender As Object, e As EventArgs) Handles btn_Capslock_remote.Click
        If myApp.MyConn.isViewerOnly Then Return

        sendKeyboardLocks("20")
        setFocusToInput()
    End Sub

    Private Sub Button3_Click_1(sender As Object, e As EventArgs) Handles Button3.Click
        If myApp.MyConn.isViewerOnly Then Return
        If isSharingMyInput = False Then Return


        If myApp.MyConn.connectionType = enum_ConnectType.UDP OrElse myApp.MyConn.isServiceOpen_WS_Mouse Then
            Dim msgboxanswer As MsgBoxResult = MsgBox("is Login Screen Visible?", MsgBoxStyle.YesNoCancel)
            If msgboxanswer = MsgBoxResult.Yes Then
                myApp.MyConn.SendRequestAsText("CMD_OnScreenKeyboard:login")
            ElseIf msgboxanswer = MsgBoxResult.No Then
                myApp.MyConn.SendRequestAsText("CMD_OnScreenKeyboard:desktop")
            End If


        End If
        setFocusToInput()
    End Sub
End Class