﻿Imports System.ComponentModel

Public Class frmStart

    Private Sub frmStart_Closing(sender As Object, e As CancelEventArgs) Handles Me.Closing

        Try
            If Not IsNothing(myApp) Then
                Try
                    myApp.ReConnectionThread_Stop()
                Catch ex As Exception : End Try
                Try
                    If Not IsNothing(myApp.MyConn) Then
                        myApp.MyConn.Disconnect()
                        Try
                            If Not IsNothing(myApp.MyConn.MyUDP) Then myApp.MyConn.MyUDP.closeConnection()
                        Catch ex As Exception : End Try
                    End If
                Catch ex As Exception : End Try
                Try
                    myApp.LockScreenListener_Remove()
                Catch ex As Exception : End Try

                Try
                    If Not IsNothing(frmScreenControlObj) Then myApp.CloseRemoteScreenController()
                Catch ex As Exception : End Try

            End If
        Catch ex As Exception : End Try

        Try
            stopUDPListener_Service()
        Catch ex As Exception : End Try

        Try
            CMDS_Thread_End()
        Catch ex As Exception
        End Try

        Try
            If Not IsNothing(frmPasswordObj) Then frmPasswordObj.Close()
        Catch ex As Exception : End Try

        Try
            If Not IsNothing(frmMessageObj) Then frmMessageObj.Close()
        Catch ex As Exception : End Try

        Try
            If Not IsNothing(frmUserUIObj) Then frmUserUIObj.Close()
        Catch ex As Exception : End Try

        Try
            If Not IsNothing(frmTrayObj) Then frmTrayObj.Close()
        Catch ex As Exception : End Try

        Try
            Process.GetCurrentProcess().Kill()
        Catch ex As Exception
        End Try
    End Sub

    Private Sub frmUIController_Load(sender As Object, e As EventArgs) Handles Me.Load

        Me.Hide()
        frmStartObj = Me

        Try

            Gbl_DesktopName = GetCurrentThreadDesktopName()

            If Gbl_DesktopName = "winlogon" Then

                isGodPower = True

                If isDublicateApp() Then
                    Close()
                    Return
                End If

                StartUDPListener()
                myApp = New myAppClass()

                myApp.initDiskVariablesState()
                OpenTrayFrm()

                Timer1.Start()
                myApp.LockScreenListener_Add()

                checkServiceVersionAndUpdate()

            Else

                isGodPower = False

                'If isAppStartFromWrongPath() Then
                '    Return
                'End If

                If isDublicateApp() Then
                    Close()
                    Return
                End If

                If isUpdateApp() Then Return

                StartUDPListener()

                myApp = New myAppClass()

                If My.Computer.FileSystem.FileExists(Gbl_UpdateAppCopy_Path_User) Then
                    myApp.App__DeleteUpdateClientFile()
                End If

                If myApp.myService.currentServiceState = Enum_Servicestate.Running Then
                    sendUDPToService("CMD_StartDesktopApp:")
                    Close()
                    Return
                End If

                frmTrayObj = New frmTray()
                frmTrayObj.Show()

                myApp.LockScreenListener_Add()

            End If

            myApp.ReConnectionThread_Start()

            Me.Visible = False
        Catch ex As Exception
            ' writeLogLine("appstart : " & ex.Message)
        End Try
    End Sub

    Private Function isSingleApp() As Boolean
        Dim len As Integer = 5
        Try
            For i As Integer = 0 To len
                If Process.GetProcessesByName(Process.GetCurrentProcess.ProcessName).Length > 1 Then
                    Threading.Thread.Sleep(1000)
                Else
                    Return True
                End If
            Next
        Catch ex As Exception
        End Try
        Return False
    End Function

    Private Function isDublicateApp() As Boolean
        Try
            If Process.GetProcessesByName(Process.GetCurrentProcess.ProcessName).Length > 1 Then

                If Process.GetProcessesByName(Process.GetCurrentProcess.ProcessName).Length > 2 Then
                    Return True
                Else
                    If isGodPower = False Then

                        If My.Computer.FileSystem.FileExists(Gbl_UpdateAppCopy_Path_User) Then

                            Return False

                        ElseIf Application.ExecutablePath.IndexOf(Gbl_MainAppCopy_Path_User) > -1 Then

                            If isSingleApp() Then
                                Return False
                            Else
                                Return True
                            End If

                        Else
                            Return True
                        End If
                    Else
                        Return True
                    End If
                End If
            End If
        Catch ex As Exception
        End Try
        Return False
    End Function


    Private Function isUpdateApp() As Boolean
        Try

            If Application.ExecutablePath.IndexOf("_update.exe") > -1 Then

                Dim p As New Threading.Thread(Sub()
                                                  UpdateApp()
                                              End Sub)
                p.Start()

                Return True
            End If
        Catch ex As Exception
        End Try
        Return False
    End Function

    Private Function isAppStartFromWrongPath() As Boolean
        Try
            Dim exepath As String = Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments) & "\AlSooz Remote PC\"
            If Application.ExecutablePath.IndexOf(exepath) = -1 Then
                Dim expectedPath As String = exepath & "AlSoozRemotePC.exe"
                If My.Computer.FileSystem.FileExists(expectedPath) Then
                    runAppWithoutGodPower(expectedPath, True)
                    Return True
                End If
            End If
        Catch ex As Exception
        End Try
        Return False
    End Function

    Private Sub UpdateApp()
        Dim isLoopContinue As Boolean = True
        Dim loopRetries As Integer = 0
        Dim loopRetriesLimit As Integer = 5
        Dim newFileCreated As Boolean = False

        Do While isLoopContinue
            Try
                Threading.Thread.Sleep(2000)
                If My.Computer.FileSystem.FileExists(Gbl_MainAppCopy_Path_User) AndAlso newFileCreated = False Then
                    My.Computer.FileSystem.DeleteFile(Gbl_MainAppCopy_Path_User)

                End If
                If My.Computer.FileSystem.FileExists(Gbl_MainAppCopy_Path_User) = False Then
                    My.Computer.FileSystem.CopyFile(Application.ExecutablePath, Gbl_MainAppCopy_Path_User)

                    newFileCreated = True
                End If
                If My.Computer.FileSystem.FileExists(Gbl_MainAppCopy_Path_User) AndAlso newFileCreated Then

                    isLoopContinue = False
                    runAppWithoutGodPower(Gbl_MainAppCopy_Path_User, True)
                    Return
                End If

            Catch ex As Exception
                'frmStartObj.BeginInvoke(Sub()
                '                            MsgBox("2 : " & ex.Message)
                '                        End Sub)
            End Try

            If loopRetries > loopRetriesLimit Then
                isLoopContinue = False
            Else
                loopRetries += 1
            End If
        Loop

    End Sub

    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick
        OpenTrayFrm()

    End Sub

    Private doublecheck As Integer = 0
    Private Sub OpenTrayFrm()
        Try
            If myApp.readDiskVariablesState(myAppClass.Gbl_DiskVariables.IsTrayFormObjNull, True) = "yes" Then

                doublecheck += 1
                If doublecheck > 4 Then
                    Timer1.Stop()
                    ' writeLogLine("Timer Stop:")
                    Return
                Else
                    ' writeLogLine("Timer doublecheck:")
                End If

            Else
                doublecheck = 0
                Dim inputdeskname As String = GetInputThreadDesktopName()
                ' writeLogLine("inputdeskname:" & inputdeskname)
                If myApp.isScreenLocked = False OrElse
                    inputdeskname = "default" Then
                    openFormInAnotherDesktop("default", "tray")
                End If


            End If
        Catch ex As Exception
            ' writeLogLine("inputdeskname ex:" & ex.Message)
        End Try
    End Sub

    Private Sub checkServiceVersionAndUpdate()
        Dim p As New Threading.Thread(Sub()
                                          Try

                                              Dim localVersion As String = myApp.myService.getServiceVersion_LocalFile()
                                              Dim latestVersion As String = myApp.myService.getServiceVersion_Embedded()
                                              If latestVersion.IndexOf(".") > -1 Then
                                                  If localVersion <> latestVersion Then

                                                      If myApp.myService.Service_Stop() Then

                                                          My.Computer.FileSystem.DeleteFile(Gbl_Serivce_Path)

                                                          My.Computer.FileSystem.WriteAllBytes(Gbl_Serivce_Path, My.Resources.AlSoozRemotePCService, False)

                                                          myApp.myService.Service_Start()

                                                      End If
                                                  Else
                                                      ' writeLogLine("Service - Same Version")
                                                  End If
                                              End If
                                          Catch ex As Exception
                                              'writeLogLine("Service - " & ex.Message)
                                          End Try
                                      End Sub)

        p.Start()
        'myApp.myService.Service_Stop()

    End Sub
End Class