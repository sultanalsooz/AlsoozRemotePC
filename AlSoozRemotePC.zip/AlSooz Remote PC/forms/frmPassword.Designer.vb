﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmPassword
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmPassword))
        Me.btn_Allow = New System.Windows.Forms.Button()
        Me.txt_pass = New System.Windows.Forms.TextBox()
        Me.btn_show = New System.Windows.Forms.Button()
        Me.btn_Cancel = New System.Windows.Forms.Button()
        Me.lbl_hidden_fontSize = New System.Windows.Forms.Label()
        Me.lbl_CountDown = New System.Windows.Forms.Label()
        Me.lbl = New System.Windows.Forms.Label()
        Me.lbl_wrong = New System.Windows.Forms.Label()
        Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
        Me.SuspendLayout()
        '
        'btn_Allow
        '
        Me.btn_Allow.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.btn_Allow.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btn_Allow.Font = New System.Drawing.Font("Calibri", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_Allow.Location = New System.Drawing.Point(380, 140)
        Me.btn_Allow.Name = "btn_Allow"
        Me.btn_Allow.Size = New System.Drawing.Size(136, 34)
        Me.btn_Allow.TabIndex = 32
        Me.btn_Allow.Text = "Submit"
        Me.btn_Allow.UseVisualStyleBackColor = False
        '
        'txt_pass
        '
        Me.txt_pass.AcceptsReturn = True
        Me.txt_pass.Font = New System.Drawing.Font("Verdana", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_pass.Location = New System.Drawing.Point(14, 52)
        Me.txt_pass.Name = "txt_pass"
        Me.txt_pass.Size = New System.Drawing.Size(502, 31)
        Me.txt_pass.TabIndex = 34
        Me.txt_pass.UseSystemPasswordChar = True
        '
        'btn_show
        '
        Me.btn_show.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.btn_show.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btn_show.Font = New System.Drawing.Font("Calibri", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_show.Location = New System.Drawing.Point(522, 52)
        Me.btn_show.Name = "btn_show"
        Me.btn_show.Size = New System.Drawing.Size(81, 30)
        Me.btn_show.TabIndex = 35
        Me.btn_show.Text = "Show"
        Me.btn_show.UseVisualStyleBackColor = False
        '
        'btn_Cancel
        '
        Me.btn_Cancel.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.btn_Cancel.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btn_Cancel.Font = New System.Drawing.Font("Calibri", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_Cancel.Location = New System.Drawing.Point(69, 140)
        Me.btn_Cancel.Name = "btn_Cancel"
        Me.btn_Cancel.Size = New System.Drawing.Size(136, 34)
        Me.btn_Cancel.TabIndex = 37
        Me.btn_Cancel.Text = "Cancel"
        Me.btn_Cancel.UseVisualStyleBackColor = False
        '
        'lbl_hidden_fontSize
        '
        Me.lbl_hidden_fontSize.AutoSize = True
        Me.lbl_hidden_fontSize.Font = New System.Drawing.Font("Calibri", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_hidden_fontSize.Location = New System.Drawing.Point(174, 146)
        Me.lbl_hidden_fontSize.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.lbl_hidden_fontSize.Name = "lbl_hidden_fontSize"
        Me.lbl_hidden_fontSize.Size = New System.Drawing.Size(23, 23)
        Me.lbl_hidden_fontSize.TabIndex = 38
        Me.lbl_hidden_fontSize.Text = "T:"
        '
        'lbl_CountDown
        '
        Me.lbl_CountDown.AutoSize = True
        Me.lbl_CountDown.Font = New System.Drawing.Font("Calibri", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_CountDown.Location = New System.Drawing.Point(214, 146)
        Me.lbl_CountDown.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.lbl_CountDown.Name = "lbl_CountDown"
        Me.lbl_CountDown.Size = New System.Drawing.Size(30, 23)
        Me.lbl_CountDown.TabIndex = 36
        Me.lbl_CountDown.Text = "30"
        Me.lbl_CountDown.Visible = False
        '
        'lbl
        '
        Me.lbl.BackColor = System.Drawing.Color.Transparent
        Me.lbl.Font = New System.Drawing.Font("Verdana", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl.ForeColor = System.Drawing.SystemColors.ControlText
        Me.lbl.Location = New System.Drawing.Point(13, 8)
        Me.lbl.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.lbl.Name = "lbl"
        Me.lbl.Size = New System.Drawing.Size(590, 41)
        Me.lbl.TabIndex = 31
        Me.lbl.Text = "Enter Password To "
        Me.lbl.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lbl_wrong
        '
        Me.lbl_wrong.BackColor = System.Drawing.Color.Transparent
        Me.lbl_wrong.Font = New System.Drawing.Font("Verdana", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_wrong.ForeColor = System.Drawing.Color.Red
        Me.lbl_wrong.Location = New System.Drawing.Point(13, 85)
        Me.lbl_wrong.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.lbl_wrong.Name = "lbl_wrong"
        Me.lbl_wrong.Size = New System.Drawing.Size(590, 32)
        Me.lbl_wrong.TabIndex = 39
        Me.lbl_wrong.Text = "Wrong Password !!"
        Me.lbl_wrong.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.lbl_wrong.Visible = False
        '
        'Timer1
        '
        Me.Timer1.Interval = 1500
        '
        'frmPassword
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(616, 185)
        Me.Controls.Add(Me.lbl_wrong)
        Me.Controls.Add(Me.btn_Cancel)
        Me.Controls.Add(Me.lbl_hidden_fontSize)
        Me.Controls.Add(Me.lbl_CountDown)
        Me.Controls.Add(Me.btn_show)
        Me.Controls.Add(Me.txt_pass)
        Me.Controls.Add(Me.btn_Allow)
        Me.Controls.Add(Me.lbl)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "frmPassword"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Password"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents btn_Allow As Button
    Friend WithEvents txt_pass As TextBox
    Friend WithEvents btn_show As Button
    Friend WithEvents btn_Cancel As Button
    Friend WithEvents lbl_hidden_fontSize As Label
    Friend WithEvents lbl_CountDown As Label
    Friend WithEvents lbl As Label
    Friend WithEvents lbl_wrong As Label
    Friend WithEvents Timer1 As Timer
End Class
