﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmMsgbox
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.pnl_status_desc = New System.Windows.Forms.Label()
        Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
        Me.lbl_CountDown = New System.Windows.Forms.Label()
        Me.btn_Allow = New System.Windows.Forms.Button()
        Me.btn_Cancel = New System.Windows.Forms.Button()
        Me.lbl_hidden_fontSize = New System.Windows.Forms.Label()
        Me.btnSimpleMessageClose = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'pnl_status_desc
        '
        Me.pnl_status_desc.BackColor = System.Drawing.Color.White
        Me.pnl_status_desc.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.pnl_status_desc.Font = New System.Drawing.Font("Verdana", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.pnl_status_desc.Location = New System.Drawing.Point(13, 15)
        Me.pnl_status_desc.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.pnl_status_desc.Name = "pnl_status_desc"
        Me.pnl_status_desc.Size = New System.Drawing.Size(737, 81)
        Me.pnl_status_desc.TabIndex = 28
        Me.pnl_status_desc.Text = "Allow One Time Sharing Of This PC's Screen ?" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "Requester: Remote PC"
        Me.pnl_status_desc.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Timer1
        '
        Me.Timer1.Interval = 1000
        '
        'lbl_CountDown
        '
        Me.lbl_CountDown.AutoSize = True
        Me.lbl_CountDown.Font = New System.Drawing.Font("Calibri", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_CountDown.Location = New System.Drawing.Point(218, 127)
        Me.lbl_CountDown.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.lbl_CountDown.Name = "lbl_CountDown"
        Me.lbl_CountDown.Size = New System.Drawing.Size(30, 23)
        Me.lbl_CountDown.TabIndex = 29
        Me.lbl_CountDown.Text = "30"
        '
        'btn_Allow
        '
        Me.btn_Allow.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.btn_Allow.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btn_Allow.Font = New System.Drawing.Font("Calibri", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_Allow.Location = New System.Drawing.Point(554, 121)
        Me.btn_Allow.Name = "btn_Allow"
        Me.btn_Allow.Size = New System.Drawing.Size(136, 34)
        Me.btn_Allow.TabIndex = 30
        Me.btn_Allow.Text = "Allow"
        Me.btn_Allow.UseVisualStyleBackColor = False
        '
        'btn_Cancel
        '
        Me.btn_Cancel.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.btn_Cancel.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btn_Cancel.Font = New System.Drawing.Font("Calibri", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_Cancel.Location = New System.Drawing.Point(73, 121)
        Me.btn_Cancel.Name = "btn_Cancel"
        Me.btn_Cancel.Size = New System.Drawing.Size(136, 34)
        Me.btn_Cancel.TabIndex = 31
        Me.btn_Cancel.Text = "Cancel"
        Me.btn_Cancel.UseVisualStyleBackColor = False
        '
        'lbl_hidden_fontSize
        '
        Me.lbl_hidden_fontSize.AutoSize = True
        Me.lbl_hidden_fontSize.Font = New System.Drawing.Font("Calibri", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_hidden_fontSize.Location = New System.Drawing.Point(178, 127)
        Me.lbl_hidden_fontSize.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.lbl_hidden_fontSize.Name = "lbl_hidden_fontSize"
        Me.lbl_hidden_fontSize.Size = New System.Drawing.Size(23, 23)
        Me.lbl_hidden_fontSize.TabIndex = 32
        Me.lbl_hidden_fontSize.Text = "T:"
        '
        'btnSimpleMessageClose
        '
        Me.btnSimpleMessageClose.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.btnSimpleMessageClose.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnSimpleMessageClose.Font = New System.Drawing.Font("Calibri", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnSimpleMessageClose.Location = New System.Drawing.Point(73, 121)
        Me.btnSimpleMessageClose.Name = "btnSimpleMessageClose"
        Me.btnSimpleMessageClose.Size = New System.Drawing.Size(136, 34)
        Me.btnSimpleMessageClose.TabIndex = 33
        Me.btnSimpleMessageClose.Text = "Close"
        Me.btnSimpleMessageClose.UseVisualStyleBackColor = False
        '
        'frmMsgbox
        '
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None
        Me.ClientSize = New System.Drawing.Size(763, 171)
        Me.Controls.Add(Me.btnSimpleMessageClose)
        Me.Controls.Add(Me.btn_Cancel)
        Me.Controls.Add(Me.lbl_hidden_fontSize)
        Me.Controls.Add(Me.btn_Allow)
        Me.Controls.Add(Me.lbl_CountDown)
        Me.Controls.Add(Me.pnl_status_desc)
        Me.Font = New System.Drawing.Font("Calibri", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.Margin = New System.Windows.Forms.Padding(4)
        Me.Name = "frmMsgbox"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Message"
        Me.TopMost = True
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents pnl_status_desc As Label
    Friend WithEvents Timer1 As Timer
    Friend WithEvents lbl_CountDown As Label
    Friend WithEvents btn_Allow As Button
    Friend WithEvents btn_Cancel As Button
    Friend WithEvents lbl_hidden_fontSize As Label
    Friend WithEvents btnSimpleMessageClose As Button
End Class
