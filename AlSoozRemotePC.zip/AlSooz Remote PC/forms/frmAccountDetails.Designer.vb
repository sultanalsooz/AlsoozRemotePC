﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmAccountDetails
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmAccountDetails))
        Me.btn_Cancel = New System.Windows.Forms.Button()
        Me.lbl_hidden_fontSize = New System.Windows.Forms.Label()
        Me.lbl_CountDown = New System.Windows.Forms.Label()
        Me.btn_show = New System.Windows.Forms.Button()
        Me.txt_Username = New System.Windows.Forms.TextBox()
        Me.btn_Submit = New System.Windows.Forms.Button()
        Me.lbl_TreeStats_PCs = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.txt_domain = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.txt_pass = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.rdo_ByAdmin = New System.Windows.Forms.RadioButton()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.rdo_ByUser = New System.Windows.Forms.RadioButton()
        Me.Panel1.SuspendLayout()
        Me.SuspendLayout()
        '
        'btn_Cancel
        '
        Me.btn_Cancel.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.btn_Cancel.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btn_Cancel.Font = New System.Drawing.Font("Calibri", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_Cancel.Location = New System.Drawing.Point(141, 181)
        Me.btn_Cancel.Name = "btn_Cancel"
        Me.btn_Cancel.Size = New System.Drawing.Size(136, 34)
        Me.btn_Cancel.TabIndex = 6
        Me.btn_Cancel.Text = "Cancel"
        Me.btn_Cancel.UseVisualStyleBackColor = False
        '
        'lbl_hidden_fontSize
        '
        Me.lbl_hidden_fontSize.AutoSize = True
        Me.lbl_hidden_fontSize.Font = New System.Drawing.Font("Calibri", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_hidden_fontSize.Location = New System.Drawing.Point(246, 187)
        Me.lbl_hidden_fontSize.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.lbl_hidden_fontSize.Name = "lbl_hidden_fontSize"
        Me.lbl_hidden_fontSize.Size = New System.Drawing.Size(23, 23)
        Me.lbl_hidden_fontSize.TabIndex = 46
        Me.lbl_hidden_fontSize.Text = "T:"
        '
        'lbl_CountDown
        '
        Me.lbl_CountDown.AutoSize = True
        Me.lbl_CountDown.Font = New System.Drawing.Font("Calibri", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_CountDown.Location = New System.Drawing.Point(286, 187)
        Me.lbl_CountDown.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.lbl_CountDown.Name = "lbl_CountDown"
        Me.lbl_CountDown.Size = New System.Drawing.Size(30, 23)
        Me.lbl_CountDown.TabIndex = 44
        Me.lbl_CountDown.Text = "30"
        Me.lbl_CountDown.Visible = False
        '
        'btn_show
        '
        Me.btn_show.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.btn_show.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btn_show.Font = New System.Drawing.Font("Calibri", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_show.Location = New System.Drawing.Point(541, 78)
        Me.btn_show.Name = "btn_show"
        Me.btn_show.Size = New System.Drawing.Size(81, 30)
        Me.btn_show.TabIndex = 5
        Me.btn_show.Text = "Show"
        Me.btn_show.UseVisualStyleBackColor = False
        '
        'txt_Username
        '
        Me.txt_Username.Font = New System.Drawing.Font("Verdana", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_Username.Location = New System.Drawing.Point(137, 42)
        Me.txt_Username.Name = "txt_Username"
        Me.txt_Username.Size = New System.Drawing.Size(391, 27)
        Me.txt_Username.TabIndex = 2
        '
        'btn_Submit
        '
        Me.btn_Submit.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.btn_Submit.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btn_Submit.Font = New System.Drawing.Font("Calibri", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_Submit.Location = New System.Drawing.Point(395, 181)
        Me.btn_Submit.Name = "btn_Submit"
        Me.btn_Submit.Size = New System.Drawing.Size(136, 34)
        Me.btn_Submit.TabIndex = 4
        Me.btn_Submit.Text = "Submit"
        Me.btn_Submit.UseVisualStyleBackColor = False
        '
        'lbl_TreeStats_PCs
        '
        Me.lbl_TreeStats_PCs.BackColor = System.Drawing.Color.FromArgb(CType(CType(76, Byte), Integer), CType(CType(76, Byte), Integer), CType(CType(76, Byte), Integer))
        Me.lbl_TreeStats_PCs.Font = New System.Drawing.Font("Calibri", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_TreeStats_PCs.ForeColor = System.Drawing.Color.White
        Me.lbl_TreeStats_PCs.Location = New System.Drawing.Point(8, 40)
        Me.lbl_TreeStats_PCs.Name = "lbl_TreeStats_PCs"
        Me.lbl_TreeStats_PCs.Size = New System.Drawing.Size(116, 32)
        Me.lbl_TreeStats_PCs.TabIndex = 48
        Me.lbl_TreeStats_PCs.Text = "Username"
        Me.lbl_TreeStats_PCs.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label1
        '
        Me.Label1.BackColor = System.Drawing.Color.FromArgb(CType(CType(76, Byte), Integer), CType(CType(76, Byte), Integer), CType(CType(76, Byte), Integer))
        Me.Label1.Font = New System.Drawing.Font("Calibri", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.Color.White
        Me.Label1.Location = New System.Drawing.Point(8, 3)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(116, 32)
        Me.Label1.TabIndex = 51
        Me.Label1.Text = "Domain"
        Me.Label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'txt_domain
        '
        Me.txt_domain.Font = New System.Drawing.Font("Verdana", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_domain.Location = New System.Drawing.Point(137, 5)
        Me.txt_domain.Name = "txt_domain"
        Me.txt_domain.Size = New System.Drawing.Size(391, 27)
        Me.txt_domain.TabIndex = 1
        '
        'Label2
        '
        Me.Label2.BackColor = System.Drawing.Color.FromArgb(CType(CType(76, Byte), Integer), CType(CType(76, Byte), Integer), CType(CType(76, Byte), Integer))
        Me.Label2.Font = New System.Drawing.Font("Calibri", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.ForeColor = System.Drawing.Color.White
        Me.Label2.Location = New System.Drawing.Point(7, 77)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(116, 32)
        Me.Label2.TabIndex = 54
        Me.Label2.Text = "Password"
        Me.Label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'txt_pass
        '
        Me.txt_pass.AcceptsReturn = True
        Me.txt_pass.Font = New System.Drawing.Font("Verdana", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_pass.Location = New System.Drawing.Point(137, 79)
        Me.txt_pass.Name = "txt_pass"
        Me.txt_pass.Size = New System.Drawing.Size(391, 27)
        Me.txt_pass.TabIndex = 3
        Me.txt_pass.UseSystemPasswordChar = True
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Calibri", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(537, 5)
        Me.Label3.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(89, 23)
        Me.Label3.TabIndex = 55
        Me.Label3.Text = "(Optional)"
        Me.Label3.Visible = False
        '
        'Label4
        '
        Me.Label4.BackColor = System.Drawing.Color.FromArgb(CType(CType(76, Byte), Integer), CType(CType(76, Byte), Integer), CType(CType(76, Byte), Integer))
        Me.Label4.Font = New System.Drawing.Font("Calibri", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.ForeColor = System.Drawing.Color.White
        Me.Label4.Location = New System.Drawing.Point(12, 9)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(116, 32)
        Me.Label4.TabIndex = 56
        Me.Label4.Text = "Enter Details"
        Me.Label4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'rdo_ByAdmin
        '
        Me.rdo_ByAdmin.AutoSize = True
        Me.rdo_ByAdmin.Checked = True
        Me.rdo_ByAdmin.Font = New System.Drawing.Font("Calibri", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.rdo_ByAdmin.Location = New System.Drawing.Point(141, 13)
        Me.rdo_ByAdmin.Name = "rdo_ByAdmin"
        Me.rdo_ByAdmin.Size = New System.Drawing.Size(48, 23)
        Me.rdo_ByAdmin.TabIndex = 57
        Me.rdo_ByAdmin.TabStop = True
        Me.rdo_ByAdmin.Text = "Me"
        Me.rdo_ByAdmin.UseVisualStyleBackColor = True
        '
        'Panel1
        '
        Me.Panel1.Controls.Add(Me.txt_pass)
        Me.Panel1.Controls.Add(Me.txt_Username)
        Me.Panel1.Controls.Add(Me.Label3)
        Me.Panel1.Controls.Add(Me.btn_show)
        Me.Panel1.Controls.Add(Me.Label2)
        Me.Panel1.Controls.Add(Me.lbl_TreeStats_PCs)
        Me.Panel1.Controls.Add(Me.txt_domain)
        Me.Panel1.Controls.Add(Me.Label1)
        Me.Panel1.Location = New System.Drawing.Point(4, 45)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(634, 120)
        Me.Panel1.TabIndex = 58
        '
        'rdo_ByUser
        '
        Me.rdo_ByUser.AutoSize = True
        Me.rdo_ByUser.Font = New System.Drawing.Font("Calibri", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.rdo_ByUser.Location = New System.Drawing.Point(229, 13)
        Me.rdo_ByUser.Name = "rdo_ByUser"
        Me.rdo_ByUser.Size = New System.Drawing.Size(279, 23)
        Me.rdo_ByUser.TabIndex = 59
        Me.rdo_ByUser.Text = "Remote PC already logged-in as Admin"
        Me.rdo_ByUser.UseVisualStyleBackColor = True
        '
        'frmAccountDetails
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(637, 226)
        Me.Controls.Add(Me.rdo_ByUser)
        Me.Controls.Add(Me.rdo_ByAdmin)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.btn_Cancel)
        Me.Controls.Add(Me.lbl_hidden_fontSize)
        Me.Controls.Add(Me.lbl_CountDown)
        Me.Controls.Add(Me.btn_Submit)
        Me.Controls.Add(Me.Panel1)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "frmAccountDetails"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Installation User Account Details"
        Me.TopMost = True
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents btn_Cancel As Button
    Friend WithEvents lbl_hidden_fontSize As Label
    Friend WithEvents lbl_CountDown As Label
    Friend WithEvents btn_show As Button
    Friend WithEvents txt_Username As TextBox
    Friend WithEvents btn_Submit As Button
    Friend WithEvents lbl_TreeStats_PCs As Label
    Friend WithEvents Label1 As Label
    Friend WithEvents txt_domain As TextBox
    Friend WithEvents Label2 As Label
    Friend WithEvents txt_pass As TextBox
    Friend WithEvents Label3 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents rdo_ByAdmin As RadioButton
    Friend WithEvents Panel1 As Panel
    Friend WithEvents rdo_ByUser As RadioButton
End Class
