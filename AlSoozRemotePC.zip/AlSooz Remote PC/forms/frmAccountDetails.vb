﻿Imports System.ComponentModel
Imports System.Text

Public Class frmAccountDetails

    Private Sub frmInstallAccount_Closing(sender As Object, e As CancelEventArgs) Handles Me.Closing
        frmAccountDetailsObj = Nothing
    End Sub

    Private Sub frmInstallAccount_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Using g As Graphics = Me.CreateGraphics
            GenerateFontSizefromScreenDPI(g, lbl_hidden_fontSize, lbl_CountDown)
        End Using

        resizeAllChildControls(Me)

    End Sub

    Private Sub processInstallTask()
        Dim strb As New StringBuilder
        strb.Append("CMD_RemoteInstall:")

        If rdo_ByAdmin.Checked Then
            If txt_Username.Text.Trim = "" Then
                MsgBox("Please Enter A Valid User Name.")
                Return
            End If

            strb.Append("byadmin|")
            strb.Append(txt_domain.Text)
            strb.Append("|")
            strb.Append(txt_Username.Text)
            strb.Append("|")
            strb.Append(txt_pass.Text)
        Else
            strb.Append("byuser|||")

        End If

        myApp.MyConn.SendRequestAsText(strb.ToString)

        MsgBox("Remote PC is showing UAC allow screen." & vbCrLf & vbCrLf & "Request from the user on the remote PC to click on 'Allow' or 'Yes' button.")

        Me.Close()
    End Sub

    Private Sub btn_Cancel_Click(sender As Object, e As EventArgs) Handles btn_Cancel.Click
        Me.Close()
    End Sub

    Private Sub btn_show_Click(sender As Object, e As EventArgs) Handles btn_show.Click
        If txt_pass.UseSystemPasswordChar Then
            txt_pass.UseSystemPasswordChar = False
            btn_show.Text = "Hide"
        Else
            txt_pass.UseSystemPasswordChar = True
            btn_show.Text = "Show"
        End If
    End Sub

    Private Sub txt_pass_KeyDown(sender As Object, e As KeyEventArgs) Handles txt_pass.KeyDown
        If e.KeyCode = Keys.Enter Then
            processInstallTask()
            e.Handled = True
        End If
    End Sub

    Private Sub txt_pass_KeyUp(sender As Object, e As KeyEventArgs) Handles txt_pass.KeyUp
        If e.KeyCode = Keys.Enter Then
            e.Handled = True
        End If
    End Sub

    Private Sub btn_Submit_Click(sender As Object, e As EventArgs) Handles btn_Submit.Click
        processInstallTask()
    End Sub

    Private Sub rdo_ByAdmin_CheckedChanged(sender As Object, e As EventArgs) Handles rdo_ByAdmin.CheckedChanged
        Panel1.Show()
    End Sub

    Private Sub rdo_ByUser_CheckedChanged(sender As Object, e As EventArgs) Handles rdo_ByUser.CheckedChanged
        Panel1.Hide()

    End Sub

    Private Sub frmAccountDetails_Shown(sender As Object, e As EventArgs) Handles Me.Shown
        txt_domain.Focus()
    End Sub
End Class