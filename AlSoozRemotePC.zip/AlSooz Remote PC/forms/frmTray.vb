﻿Imports System.ComponentModel

Public Class frmTray
    Private Sub frmTrayMenu_Closing(sender As Object, e As CancelEventArgs) Handles Me.Closing
        Try
            Threading.Monitor.Enter(tryLoadLockObj)
            Try
                If Not IsNothing(frmTrayObj) Then Clipboard_Listen_End(Me.Handle)
                Clipboard_IsListen_On = False
            Catch ex As Exception
            End Try

            MyTrayIcon.Dispose()

        Catch ex As Exception
        End Try
        Try
            If isGodPower Then
                myApp.writeDiskVariablesState(myAppClass.Gbl_DiskVariables.IsTrayFormObjNull, "no")
            End If
            frmTrayObj = Nothing
        Catch ex As Exception

        End Try

        Try
            Threading.Monitor.Exit(tryLoadLockObj)
        Catch ex As Exception
        End Try

    End Sub

    Private Sub frmtray_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Try
            Threading.Monitor.Enter(tryLoadLockObj)

            If isGodPower = False OrElse (IsNothing(frmTrayObj) AndAlso isDesktopReady()) Then

                frmTrayObj = Me
                MyTrayIcon.Text = Application.ProductName & " v" & myApp.AppVersion

                Me.Text = ""
                Me.Width = 1
                Me.Height = 1

                Me.Hide()

                Clipboard_Listen_Start(Me.Handle)

                If myApp.MyConn.IsRemotePCConnected = True Then
                    MyTrayIcon.Icon = My.Resources.newgreen
                ElseIf myApp.MyConn.IsMyPCConnected = True Then
                    MyTrayIcon.Icon = My.Resources.neworange
                Else
                    MyTrayIcon.Icon = My.Resources.newred
                End If


                Try
                    Threading.Monitor.Exit(tryLoadLockObj)
                Catch ex As Exception
                End Try

                If isGodPower = False Then
                    OpenTaskManagerToolStripMenuItem.Visible = False
                End If
                ' setDenyAdminShutdownAccess(True)
                myApp.isScreenLocked = False
                Return
            Else
                frmTrayObj = Nothing
                Try
                    Threading.Monitor.Exit(tryLoadLockObj)
                Catch ex As Exception
                End Try
                Me.Close()
                Return
            End If
        Catch ex As Exception
        End Try
        Try
            Threading.Monitor.Exit(tryLoadLockObj)
        Catch ex As Exception
        End Try
        Me.Close()
    End Sub

    Private Sub frmtray_Deactivate(sender As Object, e As EventArgs) Handles Me.Deactivate
        Me.Hide()

    End Sub

    Private Sub MyTrayIcon_MouseDoubleClick(sender As Object, e As MouseEventArgs) Handles MyTrayIcon.MouseDoubleClick
        If e.Button = MouseButtons.Left Then
            If myApp.Password_UIAccess_chk = "yes" Then
                myApp.showPasswordForm(myAppClass.PasswordType.UIAccess)
            Else
                openControlForm("")
            End If
        Else

        End If
    End Sub

    Private Sub myNotifyIcon_MouseClick(sender As Object, e As MouseEventArgs) Handles MyTrayIcon.MouseClick
        If e.Button = MouseButtons.Right Then

            If myApp.myService.UnattendedType = Enum_UnAttendedType.Online_ID Then
                Tray_MyIP.Text = "My ID: " & myApp.MyInstallationID
            Else
                Tray_MyIP.Text = "My IP: " & getMyIP()
            End If


            Tray_MyStatus.Text = "Status: " & IIf(myApp.MyConn.IsMyPCConnected, IIf(myApp.MyConn.IsRemotePCConnected, "CONNECTED", "ONLINE"), "DISABLED")

            Me.Show()
            myTrayMnu.Show(Cursor.Position) 'Shows the Form that is the parent of "traymenu"
            Me.Activate() 'Set the Form to "Active", that means that that will be the "selected" window
            'Me.Width = 1 'Set the Form width to 1 pixel, that is needed because later we will set it behind the "traymenu"
            'Me.Height = 1

        Else
            Me.Hide()
        End If
    End Sub

    Private Sub Mnu0_Exit_Click(sender As Object, e As EventArgs) Handles Mnu0_Exit.Click

        If myApp.Password_ExitApp_chk = "yes" Then
            myApp.showPasswordForm(myAppClass.PasswordType.ExitApp)
        Else
            myApp.App_Close()
            Me.Close()
        End If

    End Sub

    Private Sub OpenRemoteControlToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles OpenRemoteControlToolStripMenuItem.Click
        If myApp.Password_UIAccess_chk = "yes" Then
            myApp.showPasswordForm(myAppClass.PasswordType.UIAccess)
        Else
            openControlForm("")
        End If
    End Sub

    Private Sub TestFuncToolStripMenuItem_Click(sender As Object, e As EventArgs)
        gbl_ImpersonateContext = setThread_RunUnderLoggedInUserAccount()

    End Sub

    Friend Sub openControlForm(ByVal showPanel As String)
        Me.BeginInvoke(Sub()
                           If IsNothing(frmUserUIObj) Then
                               frmUserUIObj = New frmUserUI
                               frmUserUIObj.Show()
                           Else
                               frmUserUIObj.Show()
                           End If
                           frmUserUIObj.WindowState = FormWindowState.Normal
                           ShowFormOnTop(frmUserUIObj)

                           If showPanel = "files" Then
                               'frmUserUIObj.ShowPage_Config()
                           ElseIf showPanel = "config" Then
                               frmUserUIObj.ShowPage_Config()

                           ElseIf showPanel = "passwords" Then
                               frmUserUIObj.ShowPage_Passwords()

                           End If
                       End Sub)

    End Sub


    Private Sub Tray_MyIP_Click(sender As Object, e As EventArgs) Handles Tray_MyIP.Click

        Dim copiedTxt As String = Tray_MyIP.Text.Split(":")(1).Trim
        Clipboard.SetText(copiedTxt)
        MsgBox("Copied To Clipboard")
    End Sub

    '<System.Security.Permissions.PermissionSetAttribute(System.Security.Permissions.SecurityAction.Demand, Name:="FullTrust")>
    Protected Overrides Sub WndProc(ByRef m As Message)

        If Clipboard_IsListen_On Then
            If m.Msg = WM_CLIPBOARDUPDATE Then
                Try

                    If Not IsNothing(frmScreenControlObj) AndAlso frmScreenControlObj.isformLoaded Then

                    Else
                        If Now > Clipboard_IsListen_ResumeTime Then
                            Clipboard_SaveOSDataToAppData()
                        End If
                    End If

                Catch ex As Exception
                End Try
            End If
        End If

        MyBase.WndProc(m)
    End Sub

    Private Sub OpenTaskManagerToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles OpenTaskManagerToolStripMenuItem.Click

        If myApp.Password_UIAccess_chk = "yes" Then
            myApp.showPasswordForm(myAppClass.PasswordType.TaskMgr)
        Else
            StartAppFromName("taskmgr")
        End If

    End Sub
End Class