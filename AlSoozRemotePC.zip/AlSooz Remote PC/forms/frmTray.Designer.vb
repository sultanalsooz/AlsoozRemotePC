﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class frmTray
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmTray))
        Me.myTrayMnu = New System.Windows.Forms.ContextMenuStrip(Me.components)
        Me.OpenRemoteControlToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripSeparator1 = New System.Windows.Forms.ToolStripSeparator()
        Me.Tray_MyStatus = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripSeparator2 = New System.Windows.Forms.ToolStripSeparator()
        Me.Tray_MyIP = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripSeparator3 = New System.Windows.Forms.ToolStripSeparator()
        Me.Mnu0_Exit = New System.Windows.Forms.ToolStripMenuItem()
        Me.MyTrayIcon = New System.Windows.Forms.NotifyIcon(Me.components)
        Me.OpenTaskManagerToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.myTrayMnu.SuspendLayout()
        Me.SuspendLayout()
        '
        'myTrayMnu
        '
        Me.myTrayMnu.Font = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.myTrayMnu.ImageScalingSize = New System.Drawing.Size(28, 28)
        Me.myTrayMnu.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.OpenRemoteControlToolStripMenuItem, Me.OpenTaskManagerToolStripMenuItem, Me.ToolStripSeparator1, Me.Tray_MyStatus, Me.ToolStripSeparator2, Me.Tray_MyIP, Me.ToolStripSeparator3, Me.Mnu0_Exit})
        Me.myTrayMnu.Name = "trayMnu"
        Me.myTrayMnu.Size = New System.Drawing.Size(246, 174)
        '
        'OpenRemoteControlToolStripMenuItem
        '
        Me.OpenRemoteControlToolStripMenuItem.Font = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.OpenRemoteControlToolStripMenuItem.Name = "OpenRemoteControlToolStripMenuItem"
        Me.OpenRemoteControlToolStripMenuItem.Size = New System.Drawing.Size(245, 26)
        Me.OpenRemoteControlToolStripMenuItem.Text = "Open Remote Control"
        '
        'ToolStripSeparator1
        '
        Me.ToolStripSeparator1.Name = "ToolStripSeparator1"
        Me.ToolStripSeparator1.Size = New System.Drawing.Size(242, 6)
        '
        'Tray_MyStatus
        '
        Me.Tray_MyStatus.Name = "Tray_MyStatus"
        Me.Tray_MyStatus.Size = New System.Drawing.Size(245, 26)
        Me.Tray_MyStatus.Text = "Status:"
        '
        'ToolStripSeparator2
        '
        Me.ToolStripSeparator2.Name = "ToolStripSeparator2"
        Me.ToolStripSeparator2.Size = New System.Drawing.Size(242, 6)
        '
        'Tray_MyIP
        '
        Me.Tray_MyIP.Name = "Tray_MyIP"
        Me.Tray_MyIP.Size = New System.Drawing.Size(245, 26)
        Me.Tray_MyIP.Text = "My IP: 192.168.50.220"
        '
        'ToolStripSeparator3
        '
        Me.ToolStripSeparator3.Name = "ToolStripSeparator3"
        Me.ToolStripSeparator3.Size = New System.Drawing.Size(242, 6)
        '
        'Mnu0_Exit
        '
        Me.Mnu0_Exit.Name = "Mnu0_Exit"
        Me.Mnu0_Exit.Size = New System.Drawing.Size(245, 26)
        Me.Mnu0_Exit.Text = "Exit"
        '
        'MyTrayIcon
        '
        Me.MyTrayIcon.Icon = CType(resources.GetObject("MyTrayIcon.Icon"), System.Drawing.Icon)
        Me.MyTrayIcon.Text = "AlSoozRemotePC"
        Me.MyTrayIcon.Visible = True
        '
        'OpenTaskManagerToolStripMenuItem
        '
        Me.OpenTaskManagerToolStripMenuItem.Name = "OpenTaskManagerToolStripMenuItem"
        Me.OpenTaskManagerToolStripMenuItem.Size = New System.Drawing.Size(245, 26)
        Me.OpenTaskManagerToolStripMenuItem.Text = "Open Task Manager"
        '
        'frmTray
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(164, 33)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Location = New System.Drawing.Point(-301, -61)
        Me.Margin = New System.Windows.Forms.Padding(2)
        Me.Name = "frmTray"
        Me.ShowIcon = False
        Me.ShowInTaskbar = False
        Me.StartPosition = System.Windows.Forms.FormStartPosition.Manual
        Me.Text = "AlSoozSKMTray"
        Me.TopMost = True
        Me.myTrayMnu.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents myTrayMnu As ContextMenuStrip
    Friend WithEvents OpenRemoteControlToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ToolStripSeparator1 As ToolStripSeparator
    Friend WithEvents ToolStripSeparator2 As ToolStripSeparator
    Friend WithEvents Tray_MyIP As ToolStripMenuItem
    Friend WithEvents ToolStripSeparator3 As ToolStripSeparator
    Friend WithEvents Mnu0_Exit As ToolStripMenuItem
    Friend WithEvents MyTrayIcon As NotifyIcon
    Friend WithEvents Tray_MyStatus As ToolStripMenuItem
    Friend WithEvents OpenTaskManagerToolStripMenuItem As ToolStripMenuItem
End Class
