﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmfiles
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmfiles))
        Me.pnl_files_btn_log = New System.Windows.Forms.Button()
        Me.TextBox1 = New System.Windows.Forms.TextBox()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.btnSendFile = New System.Windows.Forms.Button()
        Me.lbl_FileProgress2 = New System.Windows.Forms.Label()
        Me.lbl_FileProgress1 = New System.Windows.Forms.Label()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.pnl_files_txt_log = New System.Windows.Forms.TextBox()
        Me.popup_files = New System.Windows.Forms.OpenFileDialog()
        Me.SuspendLayout()
        '
        'pnl_files_btn_log
        '
        Me.pnl_files_btn_log.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.pnl_files_btn_log.Font = New System.Drawing.Font("Calibri", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.pnl_files_btn_log.Location = New System.Drawing.Point(324, 63)
        Me.pnl_files_btn_log.Name = "pnl_files_btn_log"
        Me.pnl_files_btn_log.Size = New System.Drawing.Size(97, 32)
        Me.pnl_files_btn_log.TabIndex = 40
        Me.pnl_files_btn_log.Text = "Show Log"
        Me.pnl_files_btn_log.UseMnemonic = False
        Me.pnl_files_btn_log.UseVisualStyleBackColor = False
        '
        'TextBox1
        '
        Me.TextBox1.Location = New System.Drawing.Point(86, 5)
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.Size = New System.Drawing.Size(213, 20)
        Me.TextBox1.TabIndex = 39
        Me.TextBox1.UseSystemPasswordChar = True
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(3, 7)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(75, 13)
        Me.Label9.TabIndex = 38
        Me.Label9.Text = "Files To Send:"
        '
        'btnSendFile
        '
        Me.btnSendFile.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.btnSendFile.Font = New System.Drawing.Font("Calibri", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnSendFile.Location = New System.Drawing.Point(324, 4)
        Me.btnSendFile.Name = "btnSendFile"
        Me.btnSendFile.Size = New System.Drawing.Size(97, 32)
        Me.btnSendFile.TabIndex = 15
        Me.btnSendFile.Text = "Browse"
        Me.btnSendFile.UseMnemonic = False
        Me.btnSendFile.UseVisualStyleBackColor = False
        '
        'lbl_FileProgress2
        '
        Me.lbl_FileProgress2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lbl_FileProgress2.Font = New System.Drawing.Font("Calibri", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_FileProgress2.Location = New System.Drawing.Point(86, 65)
        Me.lbl_FileProgress2.Name = "lbl_FileProgress2"
        Me.lbl_FileProgress2.Size = New System.Drawing.Size(213, 27)
        Me.lbl_FileProgress2.TabIndex = 20
        Me.lbl_FileProgress2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lbl_FileProgress1
        '
        Me.lbl_FileProgress1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lbl_FileProgress1.Font = New System.Drawing.Font("Calibri", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_FileProgress1.Location = New System.Drawing.Point(86, 34)
        Me.lbl_FileProgress1.Name = "lbl_FileProgress1"
        Me.lbl_FileProgress1.Size = New System.Drawing.Size(213, 27)
        Me.lbl_FileProgress1.TabIndex = 19
        Me.lbl_FileProgress1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Location = New System.Drawing.Point(3, 39)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(68, 13)
        Me.Label13.TabIndex = 29
        Me.Label13.Text = "Send Status:"
        '
        'pnl_files_txt_log
        '
        Me.pnl_files_txt_log.Location = New System.Drawing.Point(0, 3)
        Me.pnl_files_txt_log.Multiline = True
        Me.pnl_files_txt_log.Name = "pnl_files_txt_log"
        Me.pnl_files_txt_log.ReadOnly = True
        Me.pnl_files_txt_log.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.pnl_files_txt_log.Size = New System.Drawing.Size(320, 92)
        Me.pnl_files_txt_log.TabIndex = 41
        Me.pnl_files_txt_log.Visible = False
        '
        'popup_files
        '
        Me.popup_files.FileName = "OpenFileDialog1"
        Me.popup_files.Multiselect = True
        Me.popup_files.SupportMultiDottedExtensions = True
        '
        'frmfiles
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(426, 98)
        Me.Controls.Add(Me.pnl_files_txt_log)
        Me.Controls.Add(Me.pnl_files_btn_log)
        Me.Controls.Add(Me.TextBox1)
        Me.Controls.Add(Me.Label9)
        Me.Controls.Add(Me.Label13)
        Me.Controls.Add(Me.btnSendFile)
        Me.Controls.Add(Me.lbl_FileProgress1)
        Me.Controls.Add(Me.lbl_FileProgress2)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "frmfiles"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "File Transfer"
        Me.TopMost = True
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents pnl_files_btn_log As Button
    Friend WithEvents TextBox1 As TextBox
    Friend WithEvents Label9 As Label
    Friend WithEvents btnSendFile As Button
    Friend WithEvents lbl_FileProgress2 As Label
    Friend WithEvents lbl_FileProgress1 As Label
    Friend WithEvents Label13 As Label
    Friend WithEvents pnl_files_txt_log As TextBox
    Friend WithEvents popup_files As OpenFileDialog
End Class
