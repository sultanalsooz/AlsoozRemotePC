﻿Imports System.ComponentModel
Imports System.IO
Imports System.Text

Public Class frmUserUI

    Private Sub Form1_Closing(sender As Object, e As CancelEventArgs) Handles Me.Closing
        frmUserUIObj = Nothing
        clearDebugTxt()
    End Sub

    Private isFormLoaded As Boolean = False
    Private Sub frmUserUI_Shown(sender As Object, e As EventArgs) Handles Me.Shown
        If Not isFormLoaded Then
            isFormLoaded = True
            'Try
            '    Task.Delay(500).ContinueWith(Sub() Me.BeginInvoke(Sub() gbl_Tree.RequestPCsOnlineStatus()))
            'Catch ex As Exception
            'End Try
            gbl_Tree.RequestPCsOnlineStatus()
        End If
    End Sub
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        If isDebugOn = False Then txtdebug.Visible = False

        popup_folder.SelectedPath = myApp.myFileShare.ReceivePath ' My.Computer.FileSystem.SpecialDirectories.Desktop

        lbl_AppVersion.Text = myApp.AppVersion
        'Label12.Text = WindowsIdentity.GetCurrent.Name

        gbl_Tree.setTreeObj(treeObj)

        If treeObj.Nodes.Count = 0 Then
            Dim folderid1 As UInt64 = gbl_Tree.Add_Folder(0, "Auto Discovery", 0, False)
            Dim folderid2 As UInt64 = gbl_Tree.Add_Folder(0, "Personal", 0, False)
            'gbl_Tree.Add_PC("Computer 1", "", "ip", "0.0.0.0", folderid1)
            Dim folderid3 As UInt64 = gbl_Tree.Add_Folder(0, "Work", 0, False)

            treeObj.ExpandAll()
        Else
            treeObj.Nodes(0).Expand()

        End If

        updatefullTreeStats()
        '
        'Dim folderid1 As UInt64 = gbl_FolderTree.Add_Folder(1, "Group 11", folderid)
        'Dim folderid2 As UInt64 = gbl_FolderTree.Add_Folder(1, "Group 112", folderid1)
        'Dim folderid4 As UInt64 = gbl_FolderTree.Add_Folder(1, "Group 113", folderid1)
        'Dim folderid3 As UInt64 = gbl_FolderTree.Add_Folder(0, "Group 2", 0)


        UpdateUI_FromAppClass()

        showStatusPanel()

        Using g As Graphics = Me.CreateGraphics
            GenerateFontSizefromScreenDPI(g, pnl_Config_1_pnl1_rdo2, pnl_Config_1_pnl1_rdo1)
        End Using

        resizeAllChildControls(Me)

        myPcStatus_lbl_MyNetBIOS.Text = My.Computer.Name


        If isGodPower = False Then
            btnTaskmgr.Visible = False
        End If


    End Sub


    Friend Sub updatefullTreeStats()
        Dim stats As Integer() = gbl_Tree.getTreeStats()
        lbl_TreeStats_Folders.Text = "Folders:  " & stats(0)
        lbl_TreeStats_PCs.Text = "PCs:  " & stats(1)
    End Sub

    Private lastSelectedNode As TreeNode = Nothing

    Private Sub treeObj_MouseDoubleClick(sender As Object, e As MouseEventArgs) Handles treeObj.MouseDoubleClick
        btnOption1Click()
    End Sub

    Private Sub tree_MouseDown(sender As Object, e As MouseEventArgs) Handles treeObj.MouseDown

        Try

            Dim targetNode As TreeNode = treeObj.GetNodeAt(e.X, e.Y)

            If IsNothing(targetNode) Then
                ' treeObj.ContextMenuStrip = Nothing
                Return
            Else
                'treeObj.ContextMenuStrip = Nothing
            End If


            'If Not IsNothing(treeObj.SelectedNode) Then
            '    If treeObj.SelectedNode.Tag <> targetNode.Tag Then Return
            'End If


            ' If targetNode.Equals(lastSelectedNode) Then Return

            hideAllBtnOptions()
            hideAllPanels()

            treeObj.SelectedNode = targetNode

            lastSelectedNode = targetNode

            Dim nodetype As String = gbl_Tree.getNodeTypeFromNodeTag(lastSelectedNode.Tag)

            If nodetype = "pc" Then
                Dim pcObj As UserSettings_ClientsPCClass = gbl_Tree.myPCs(gbl_Tree.getPCIndexFromPcID(lastSelectedNode.Tag))
                Dim folderParentObj As UserSettings_ClientsFolderClass = gbl_Tree.myFolders(gbl_Tree.getFolderIndexFromFolderID(pcObj.FolderParentID))

                showPCPanel("Save Changes", pcObj.Name, pcObj.Password, pcObj.ConType, pcObj.InstallID, folderParentObj.FolderName, pcObj.NetBIOSName, pcObj.UserName, pcObj.DateAdded)
                ShowPCBtnOptions()

            ElseIf nodetype = "folder" Then

                Dim folderObj As UserSettings_ClientsFolderClass = gbl_Tree.myFolders(gbl_Tree.getFolderIndexFromFolderID(lastSelectedNode.Tag))
                If folderObj.FolderLevel = 0 Then
                    ShowFolderBtnOptions()
                    showFolderPanel("Save Changes", folderObj.FolderName, "Root", folderObj.getStats())

                Else
                    ShowFolderBtnOptions()
                    Dim folderParentObj As UserSettings_ClientsFolderClass = gbl_Tree.myFolders(gbl_Tree.getFolderIndexFromFolderID(folderObj.FolderParentID))
                    showFolderPanel("Save Changes", folderObj.FolderName, folderParentObj.FolderName, folderObj.getStats())

                End If

            End If

        Catch ex As Exception
        End Try
    End Sub


    Friend Sub Connect_UDPClient(ByVal targetIP As String)
        myApp.MyConn.Connect_UDP_Client(targetIP)
    End Sub

    Friend Sub UpdateUI_FromAppClass()
        If frmUserUIObj.InvokeRequired Then
            Try
                Dim d As New functionWithNoParam(AddressOf UpdateUI_FromAppClass)
                frmUserUIObj.BeginInvoke(d, New Object() {})
            Catch ex As Exception
            End Try

        Else

            UpdateMyPCStatus()
            updateServiceUnattended()
            updateServiceInstalled()
            updateConfigUI()

            Try
                If Not IsNothing(frmScreenControlObj) AndAlso myApp.isService_ScreenViewOn = False AndAlso myApp.MyConn.isServiceOpen_WS_Screen = False Then
                    myApp.CloseRemoteScreenController()
                End If
            Catch ex As Exception : End Try
        End If

    End Sub


    Private Sub ShowConnected(ByVal isConnected As Boolean)
        pnl_status_lbl.ForeColor = Color.Black
        If isConnected Then
            pnl_status_icon.Image = My.Resources.connected3
            pnl_status_wire_remotePC.Visible = True
            pnl_status_lbl.Text = "CONNECTED"

        Else
            pnl_status_icon.Image = My.Resources.disconnected
            pnl_status_wire_remotePC.Visible = False
            pnl_status_lbl.Text = "DISCONNECTED"

        End If

    End Sub

    Private LastTreeNodeConnected As TreeNode = Nothing
    Private Sub UpdateMyPCStatus()


        ShowConnected(False)

        If myApp.MyConn.IsMyPCConnected Then
            myPcStatus_lbl_MyPC_2.Text = "Online"
            pnl_status_wire_MyPC.Visible = True
            If myApp.myService.UnattendedConnectionType = "auto" Then
                btn_Disconnect_MyPC.Text = "Refresh"
            Else
                btn_Disconnect_MyPC.Text = "Disconnect"
            End If

            btn_Disconnect_MyPC.Enabled = True
            myPcStatus_lbl_MyPC_2.ForeColor = Color.DarkGreen
            myPcStatus_lbl_RemotePC_2.ForeColor = Color.Red

            If myApp.MyConn.IsRemotePCConnected Then

                If myApp.MyConn.IsRemotePCConnected_startActions Then
                    myApp.MyConn.IsRemotePCConnected_startActions = False


                    If myApp.MyConn.isViewerOnly Then

                        startRemoteScreenControlRequest()

                    ElseIf myApp.AfterConnectAutoStartActions.IndexOf("control") > -1 Then

                        startRemoteScreenControlRequest()
                    End If


                End If
                Dim pcIndex As Integer = gbl_Tree.getPCIndexFromPcInstallationID(myApp.MyConn.RemotePC_InstallID)
                If pcIndex > -1 Then

                    Dim pcObj As UserSettings_ClientsPCClass = gbl_Tree.myPCs(pcIndex)
                    If Not IsNothing(pcObj) Then
                        If pcObj.TNode.ImageIndex <> enum_PCOnlineStatus.Connected Then
                            pcObj.onlineStatus = enum_PCOnlineStatus.Connected
                            pcObj.TNode.ImageIndex = pcObj.onlineStatus
                            pcObj.TNode.SelectedImageIndex = pcObj.onlineStatus
                        End If
                        LastTreeNodeConnected = pcObj.TNode
                    End If
                End If
                myPcStatus_lbl_RemotePC_2.Text = "Connected"
                myPcStatus_lbl_RemotePC_2.ForeColor = Color.DarkGreen
                btn_Disconnect_RemotePC.Text = "Disconnect"
                btn_Disconnect_RemotePC.Visible = True
                If myApp.Controller_AllowFilesSend = "yes" Then
                    btn_Files_RemotePC.Visible = True
                Else
                    btn_Files_RemotePC.Visible = False
                End If
                btn_ScreenControl_RemotePC.Visible = True
                If myApp.MyConn.connectionType = enum_ConnectType.WS Then
                    myPcStatus_lbl_RemoteID_2.Text = myApp.MyConn.RemotePC_InstallID
                    myPcStatus_lbl_RemoteNetBIOS.Text = myApp.MyConn.RemotePC_NetBIOSName
                Else
                    myPcStatus_lbl_RemoteID_2.Text = getMyIP()
                    myPcStatus_lbl_RemoteNetBIOS.Text = ""
                End If
                ShowConnected(True)
            Else

                If Not IsNothing(LastTreeNodeConnected) AndAlso myPcStatus_lbl_RemotePC_2.Text = "Connected" Then
                    Try
                        Dim pcObj As UserSettings_ClientsPCClass = gbl_Tree.myPCs(gbl_Tree.getPCIndexFromPcID(LastTreeNodeConnected.Tag))
                        If Not IsNothing(pcObj) Then
                            pcObj.onlineStatus = enum_PCOnlineStatus.Online
                            LastTreeNodeConnected.ImageIndex = pcObj.onlineStatus
                            LastTreeNodeConnected.SelectedImageIndex = pcObj.onlineStatus
                        End If
                    Catch ex As Exception
                    End Try
                End If

                If myPcStatus_lbl_RemotePC_2.Text = "Connected" Then
                    myPcStatus_lbl_RemotePC_2.Text = "Disconnected"
                End If

                btn_Disconnect_RemotePC.Visible = False
                btn_Files_RemotePC.Visible = False
                btn_ScreenControl_RemotePC.Visible = False
                myPcStatus_lbl_RemoteID_2.Text = ""
                myPcStatus_lbl_RemoteNetBIOS.Text = ""
            End If

            If myApp.MyConn.connectionType = enum_ConnectType.WS Then
                myPcStatus_lbl_MyID_2.Text = myApp.MyInstallationID

            Else
                myPcStatus_lbl_MyID_2.Text = getMyIP()
            End If

            myPcStatus_lbl_RemotePC_2.ForeColor = Color.Red

            If myApp.MyConn.RemotePC_State_Rejected Then
                myApp.MyConn.RemotePC_State_Rejected = False
                myPcStatus_lbl_RemotePC_2.Text = "User Rejected"
            ElseIf myApp.MyConn.RemotePC_State_Locked Then
                myApp.MyConn.RemotePC_State_Locked = False
                myPcStatus_lbl_RemotePC_2.Text = "PC is Locked"

            ElseIf myApp.MyConn.RemotePC_State_UserAction Then
                myApp.MyConn.RemotePC_State_UserAction = False
                myPcStatus_lbl_RemotePC_2.Text = "User Approval Shown"
                tmrUserApproval.Start()
            ElseIf myApp.MyConn.RemotePC_State_Timeout Then
                myApp.MyConn.RemotePC_State_Timeout = False
                myPcStatus_lbl_RemotePC_2.Text = "User No Response"

            ElseIf myApp.MyConn.RemotePC_State_WrongPassword Then
                myApp.MyConn.RemotePC_State_WrongPassword = False
                myPcStatus_lbl_RemotePC_2.Text = "Wrong Password"

            ElseIf myApp.MyConn.RemotePC_State_Forward Then
                myApp.MyConn.RemotePC_State_Forward = False
                myPcStatus_lbl_RemotePC_2.Text = "Request Forwarded"

            ElseIf myApp.MyConn.RemotePC_State_Busy Then
                myApp.MyConn.RemotePC_State_Busy = False
                myPcStatus_lbl_RemotePC_2.Text = "PC is Busy"
                requestViewOnlyConnectionAfterBusy()

            ElseIf myApp.MyConn.RemotePC_State_BusyMe Then
                myApp.MyConn.RemotePC_State_BusyMe = False
                myPcStatus_lbl_RemotePC_2.Text = "Retry Again"

            ElseIf myApp.MyConn.RemotePC_State_BusyView Then
                myApp.MyConn.RemotePC_State_BusyView = False
                myPcStatus_lbl_RemotePC_2.Text = "Busy Viewing"

            ElseIf myApp.MyConn.RemotePC_State_BusyControl Then
                myApp.MyConn.RemotePC_State_BusyControl = False
                myPcStatus_lbl_RemotePC_2.Text = "Busy Controlling"

            ElseIf myApp.MyConn.RemotePC_State_Offline Then
                myApp.MyConn.RemotePC_State_Offline = False
                myPcStatus_lbl_RemotePC_2.Text = "PC is Offline"

            Else
                If myPcStatus_lbl_RemotePC_2.Text = "Disconnected" Then
                    myPcStatus_lbl_RemotePC_2.ForeColor = Color.Black
                End If

            End If

        Else
            myPcStatus_lbl_MyPC_2.Text = "Offline"
            myPcStatus_lbl_MyPC_2.ForeColor = Color.Red
            myPcStatus_lbl_RemotePC_2.Text = "Disconnected"
            myPcStatus_lbl_RemotePC_2.ForeColor = Color.Black
            myPcStatus_lbl_MyID_2.Text = ""
            myPcStatus_lbl_RemoteID_2.Text = ""
            myPcStatus_lbl_RemoteNetBIOS.Text = ""
            If myApp.myService.UnattendedConnectionType = "auto" Then
                btn_Disconnect_MyPC.Text = "Refresh"
                btn_Disconnect_MyPC.Enabled = False
            Else
                btn_Disconnect_MyPC.Text = "Start Listening"
            End If
            btn_Disconnect_RemotePC.Visible = False
            btn_Files_RemotePC.Visible = False
            btn_ScreenControl_RemotePC.Visible = False
            pnl_status_wire_MyPC.Visible = False

            If myApp.MyConn.Server_WS_State_NotReachable Then
                myApp.MyConn.Server_WS_State_NotReachable = False
                pnl_status_lbl.Text = "Server Offline"
                pnl_status_lbl.ForeColor = Color.Red

            End If

        End If

        If myPcStatus_lbl_RemotePC_2.Text = "Connected" Then
            lbl_AppStatus.Text = "Connected"
        Else
            lbl_AppStatus.Text = myPcStatus_lbl_MyPC_2.Text
        End If

    End Sub

    Private Sub requestViewOnlyConnectionAfterBusy()

        Dim ScreenPCInstallID As String = myApp.MyConn.RemotePC_State_Busy_ScreenSenderInstallID
        Dim BusyReason As String = myApp.MyConn.RemotePC_State_Busy_Reason
        Dim ScreenPCIndex As Integer = gbl_Tree.getPCIndexFromPcInstallationID(ScreenPCInstallID)
        Dim ScreenPcObj As UserSettings_ClientsPCClass = Nothing
        If ScreenPCIndex > -1 Then
            ScreenPcObj = gbl_Tree.myPCs(ScreenPCIndex)
        End If

        Dim targetPCIndex As Integer = gbl_Tree.getPCIndexFromPcInstallationID(myApp.MyConn.RemotePC_InstallID)
        Dim targetPcObj As UserSettings_ClientsPCClass = gbl_Tree.myPCs(targetPCIndex)


        Dim strb As New StringBuilder
        strb.Append("PC (").Append(targetPcObj.Name)
        If BusyReason = "screen" Then
            strb.Append(") is being CONTROLLED by another PC.")
        Else
            If BusyReason = "control" Then
                strb.Append(") is CONTROLLING another PC (")
                If ScreenPCIndex > -1 Then
                    strb.Append(ScreenPcObj.Name)
                Else
                    strb.Append("UNKNOWN")
                End If
                strb.Append(").")

            ElseIf BusyReason = "view" Then
                strb.Append(") is VIEWING another PC (")
                If ScreenPCIndex > -1 Then
                    strb.Append(ScreenPcObj.Name)
                Else
                    strb.Append("UNKNOWN")
                End If
                strb.Append(").")
            End If
        End If

        If ScreenPCIndex > -1 Then
            strb.Append(vbNewLine).Append(vbNewLine)
            strb.Append("Would you like to only view PC (")
            strb.Append(targetPcObj.Name).Append(") ?")

            If MsgBox(strb.ToString, MsgBoxStyle.YesNo) = MsgBoxResult.Yes Then
                myApp.MyConn.Connect(enum_ConnectType.WS, ScreenPcObj.InstallID, ScreenPcObj.Password, True)
            End If
        Else
            strb.Append(vbNewLine).Append(vbNewLine)
            strb.Append("You cannot connect to an unknown PC.")
            MsgBox(strb.ToString, MsgBoxStyle.OkOnly)
        End If


    End Sub
    Friend Sub Log(ByRef txt As String)

        If frmUserUIObj.InvokeRequired Then
            Try
                Dim d As New functionWithParamString(AddressOf Log)
                frmUserUIObj.BeginInvoke(d, New Object() {txt})
            Catch ex As Exception
            End Try

        Else
            ' txt_error.Text = txt
        End If

    End Sub

    Private Sub updateFilesReceivePath()
        myApp.myFileShare.ReceivePath = popup_folder.SelectedPath
        pnl_files_path_receive.Text = popup_folder.SelectedPath
    End Sub

    Private Sub Button6_Click_1(sender As Object, e As EventArgs) Handles btn_fileLocation.Click

        Try
            gbl_ImpersonateContext = setThread_RunUnderLoggedInUserAccount()


            Dim sfolder As DialogResult = popup_folder.ShowDialog()
            If sfolder = DialogResult.OK Then
                updateFilesReceivePath()
                'MsgBox(popup_folder.SelectedPath)

            End If
        Catch ex As Exception
        End Try
        Try
            UnsetThread_RunUnderLoggedInUserAccount(gbl_ImpersonateContext)
        Catch ex As Exception
        End Try

    End Sub


    Private Sub Pnl_NewFolder_btn_Add_Click(sender As Object, e As EventArgs) Handles pnl_NewFolder_btn_Add.Click

        If pnl_NewFolder_btn_Add.Text = "Add" Then

            If pnl_NewFolder_chk_isRoot.Checked Then
                Dim folderName As String = pnl_NewFolder_Txt_FolderName.Text.Trim
                Dim folderID As UInt64 = gbl_Tree.Add_Folder(0, folderName, 0, True)
                treeObj.SelectedNode = gbl_Tree.getTNodeFromObjID(folderID, treeObj.Nodes)
                lastSelectedNode = treeObj.SelectedNode
                treeObj.Focus()
                updatefullTreeStats()
            ElseIf Not IsNothing(treeObj.SelectedNode) Then

                Dim parentID As UInt64 = treeObj.SelectedNode.Tag

                Dim isFolderObj As Boolean = gbl_Tree.getFolderIndexFromFolderID(parentID) > -1
                If isFolderObj Then
                    Dim folderName As String = pnl_NewFolder_Txt_FolderName.Text.Trim
                    If folderName.Length > 0 Then
                        Dim folderID As UInt64 = gbl_Tree.Add_Folder(1, folderName, parentID, True)
                        treeObj.SelectedNode = gbl_Tree.getTNodeFromObjID(folderID, treeObj.Nodes)
                        lastSelectedNode = treeObj.SelectedNode
                        treeObj.Focus()
                        updatefullTreeStats()
                    End If

                Else
                    MsgBox("Please Select A Folder")
                End If
            End If
        Else
            Dim folderName As String = pnl_NewFolder_Txt_FolderName.Text.Trim

            Dim folderObj As UserSettings_ClientsFolderClass = gbl_Tree.myFolders(gbl_Tree.getFolderIndexFromFolderID(lastSelectedNode.Tag))

            folderObj.FolderName = folderName
            lastSelectedNode.Text = folderName

            myApp.saveSettings()
        End If
    End Sub

    Private Sub Pnl_NewPC_btn_add_Click(sender As Object, e As EventArgs) Handles pnl_NewPC_btn_add.Click

        Dim PCName As String = pnl_NewPC_txt_PCName.Text.Trim
        Dim PCPassword As String = pnl_NewPC_txt_PCPassword.Text.Trim
        Dim PcConnectionType As String = IIf(pnl_NewPC_rdo1.Checked, "ip", "id")
        Dim PCIP As String = pnl_NewPC_txt_PCIP.Text.Trim

        If pnl_NewPC_btn_add.Text = "Add" Then

            If Not IsNothing(treeObj.SelectedNode) Then
                Dim parentID As UInt64 = treeObj.SelectedNode.Tag
                Dim isFolderObj As Boolean = gbl_Tree.getFolderIndexFromFolderID(parentID) > -1
                If isFolderObj Then
                    If PCName.Length > 0 Then
                        Dim PCID As UInt64 = gbl_Tree.Add_PC(PCName, PCPassword, PcConnectionType, PCIP, parentID, "", "Connect once to get name")
                        treeObj.SelectedNode = gbl_Tree.getTNodeFromObjID(PCID, treeObj.Nodes)
                        treeObj.Focus()
                        lastSelectedNode = treeObj.SelectedNode
                        updatefullTreeStats()
                    End If
                Else
                    MsgBox("Please Select A Folder")
                End If
            End If
        Else
            Dim pcObj As UserSettings_ClientsPCClass = gbl_Tree.myPCs(gbl_Tree.getPCIndexFromPcID(lastSelectedNode.Tag))
            If Not IsNothing(pcObj) Then
                pcObj.Name = PCName
                pcObj.Password = PCPassword
                pcObj.ConType = PcConnectionType
                pcObj.InstallID = PCIP
                lastSelectedNode.Text = PCName
                myApp.saveSettings()
            End If

        End If
    End Sub


    Private Sub showFolderPanel(ByVal btn_Add_Text As String, ByVal txt_FolderName_Text As String, ByVal txt_FolderParent_Text As String, ByVal int_Stats As Integer())
        hideAllPanels()
        isConfigMenu = False
        pnl_NewFolder_btn_Add.Text = btn_Add_Text
        If txt_FolderName_Text = "Auto Discovery" Then
            pnl_NewFolder_Txt_FolderName.Enabled = False
        Else
            pnl_NewFolder_Txt_FolderName.Enabled = True
        End If
        pnl_NewFolder_Txt_FolderName.Text = txt_FolderName_Text
        pnl_NewFolder_Txt_FolderParent.Text = txt_FolderParent_Text
        If btn_Add_Text = "Add" Then
            pnl_NewFolder_chk_isRoot.Visible = True
        Else
            pnl_NewFolder_chk_isRoot.Visible = False
        End If
        pnl_NewFolder_lbl_folders.Text = "Folders: " & int_Stats(0)
        pnl_NewFolder_lbl_PCs.Text = "PCs: " & int_Stats(1)
        pnl_NewFolder.Location = pnl_NewPC.Location
        pnl_NewFolder.Visible = True

        If txt_FolderParent_Text = "Root" Then
            btn_option3.Visible = False
            btnFolder_MoveUp.Visible = False
            btnFolder_MoveDown.Visible = False
        Else
            btnFolder_MoveUp.Visible = True
            btnFolder_MoveDown.Visible = True
        End If

    End Sub

    Private Sub showPCPanel(ByVal btn_Add_Text As String, ByVal txt_PCName As String, ByVal txt_PCPassword As String, ByVal txt_PCConnectionType As String, ByVal txt_PCIP As String, ByVal txt_PCParentFolder As String, ByVal txt_PC_NetBIOSName As String, ByVal txt_PC_UserName As String, ByVal txt_PC_DateAdded As String)
        hideAllPanels()
        isConfigMenu = False
        If txt_PCConnectionType = "ip" Then
            pnl_NewPC_rdo1.Checked = True
        Else
            pnl_NewPC_rdo2.Checked = True
        End If

        pnl_NewPC_btn_add.Text = btn_Add_Text
        pnl_NewPC_txt_PCName.Text = txt_PCName
        pnl_NewPC_txt_PCIP.Text = txt_PCIP

        pnl_NewPC_txt_Username.Text = txt_PC_UserName
        pnl_NewPC_txt_Dateadded.Text = txt_PC_DateAdded

        pnl_NewPC_txt_PCPassword.Text = txt_PCPassword
        pnl_NewPC_Txt_FolderParent.Text = txt_PCParentFolder
        pnl_NewPC.Visible = True

        pnl_NewPC_txt_NetBIOSName.Text = txt_PC_NetBIOSName

        update_NewPCConnectionType()
    End Sub

    Private Sub hideAllPanels()
        pnl_NewPC.Visible = False
        pnl_NewFolder.Visible = False
        pnl_status.Visible = False
        pnl_Config_1.Visible = False
        pnl_Config_2.Visible = False
        pnl_Config_3.Visible = False
    End Sub

    Private Sub hideAllBtnOptions()

        btn_option1.Visible = False
        btn_option2.Visible = False
        btn_option3.Visible = False
        btn_option3.ForeColor = Color.FromKnownColor(KnownColor.ControlText)
        btn_option4.Visible = False
    End Sub

    Private Sub ShowPCBtnOptions()
        btn_option1.Visible = True
        btn_option1.Text = "Connect"
        btn_option2.Visible = False
        btn_option2.Text = "Connect IP"
        btn_option3.Visible = True
        btn_option3.Text = "Delete"
        btn_option3.ForeColor = Color.Red
        btn_option4.Visible = True
        btn_option4.Text = "Close"
    End Sub

    Private Sub ShowConfigurationBtnOptions()
        btn_option1.Visible = True
        btn_option1.Text = "Main"
        btn_option2.Visible = True
        btn_option2.Text = "Passwords"
        btn_option3.Visible = True
        btn_option3.Text = "Customization"
        btn_option4.Visible = True
        btn_option4.Text = "Close"
    End Sub

    Private Sub ShowFolderBtnOptions()
        btn_option1.Visible = True
        btn_option1.Text = "Add PC"
        btn_option2.Visible = True
        btn_option2.Text = "Add Folder"
        btn_option3.Visible = True
        btn_option3.Text = "Delete"
        btn_option3.ForeColor = Color.Red

        btn_option4.Visible = True
        btn_option4.Text = "Close"
    End Sub

    Private Sub ShowAudioOptions()
        btn_option1.Visible = False
        btn_option1.Text = ""
        btn_option2.Visible = False
        btn_option2.Text = ""
        btn_option3.Visible = False
        btn_option3.Text = ""
        btn_option3.ForeColor = Color.FromKnownColor(KnownColor.ControlText)
        btn_option4.Visible = True
        btn_option4.Text = "Close"
    End Sub

    Private isConfigMenu As Boolean = False
    Private Sub btnOption1Click()
        If isConfigMenu Then
            hideAllPanels()
            pnl_Config_1.Visible = True

        Else

            Dim nodetype As String = gbl_Tree.getNodeTypeFromNodeTag(lastSelectedNode.Tag)
            If nodetype = "pc" Then
                Dim pcObj As UserSettings_ClientsPCClass = gbl_Tree.myPCs(gbl_Tree.getPCIndexFromPcID(lastSelectedNode.Tag))

                If myApp.MyConn.IsMyPCConnected OrElse myApp.myService.UnattendedType = Enum_UnAttendedType.IP_Address Then

                    If myPcStatus_lbl_RemotePC_2.Text = "User Approval Shown" OrElse myPcStatus_lbl_RemotePC_2.Text = "Connected" Then
                        MsgBox("Active Remote PC Connection Must Be Disconnected.")
                    Else
                        If pcObj.ConType = "id" AndAlso myApp.MyConn.connectionType = enum_ConnectType.WS Then
                            myApp.MyConn.Connect(enum_ConnectType.WS, pcObj.InstallID, pcObj.Password, False)
                        ElseIf pcObj.ConType = "ip" Then
                            myApp.MyConn.Connect(enum_ConnectType.UDP, pcObj.InstallID, Nothing, False)
                        Else
                            MsgBox("Selected PC Connection Type Does Not Match Configuration Connection Type.")
                        End If
                    End If


                Else
                    MsgBox("Not Connected")
                End If

                showStatusPanel()

            ElseIf nodetype = "folder" Then

                Dim folderObj As UserSettings_ClientsFolderClass = gbl_Tree.myFolders(gbl_Tree.getFolderIndexFromFolderID(lastSelectedNode.Tag))
                'Dim folderParentObj As UserSettings_ClientsFolderClass = gbl_Tree.myFolders(gbl_Tree.getFolderIndexFromFolderID(folderObj.FolderParentID))
                showPCPanel("Add", "", "", "id", "", folderObj.FolderName, "", "", "")
                btn_option1.Visible = False
                btn_option2.Visible = False
            End If
        End If
    End Sub

    Private Sub btnOption2Click()
        If isConfigMenu Then

            hideAllPanels()
            pnl_Config_2.Visible = True

        Else
            Dim nodetype As String = gbl_Tree.getNodeTypeFromNodeTag(lastSelectedNode.Tag)
            If nodetype = "pc" Then
                Dim pcObj As UserSettings_ClientsPCClass = gbl_Tree.myPCs(gbl_Tree.getPCIndexFromPcID(lastSelectedNode.Tag))


            ElseIf nodetype = "folder" Then
                Dim folderObj As UserSettings_ClientsFolderClass = gbl_Tree.myFolders(gbl_Tree.getFolderIndexFromFolderID(lastSelectedNode.Tag))

                showFolderPanel("Add", "", folderObj.FolderName, folderObj.getStats())
                btn_option1.Visible = False
                btn_option2.Visible = False
            End If
        End If
    End Sub

    Private isEditPC As Boolean = False

    Private Sub btnOption3Click()
        If isConfigMenu Then
            hideAllPanels()
            pnl_Config_3.Visible = True
        Else

            Dim nodetype As String = gbl_Tree.getNodeTypeFromNodeTag(lastSelectedNode.Tag)
            If nodetype = "pc" Then

                Dim pcObj As UserSettings_ClientsPCClass = gbl_Tree.myPCs(gbl_Tree.getPCIndexFromPcID(lastSelectedNode.Tag))
                If MsgBoxResult.Yes = MsgBox("Deleting PC, Are You Sure?", MsgBoxStyle.YesNo) Then
                    gbl_Tree.Del_PC(lastSelectedNode.Tag)
                    updatefullTreeStats()
                End If

            ElseIf nodetype = "folder" Then

                If MsgBoxResult.Yes = MsgBox("Deleting Folder, Are You Sure?", MsgBoxStyle.YesNo) Then
                    gbl_Tree.Del_Folder(lastSelectedNode.Tag, False)
                    updatefullTreeStats()
                End If
            End If
        End If
    End Sub

    Private Sub btnOption4Click()
        showStatusPanel()
    End Sub


    Private Sub showStatusPanel()
        hideAllBtnOptions()
        hideAllPanels()
        pnl_status.Visible = True
    End Sub
    Private Sub Btn_option1_Click(sender As Object, e As EventArgs) Handles btn_option1.Click
        btnOption1Click()
    End Sub

    Private Sub Btn_option2_Click(sender As Object, e As EventArgs) Handles btn_option2.Click
        btnOption2Click()
    End Sub

    Private Sub Btn_option3_Click(sender As Object, e As EventArgs) Handles btn_option3.Click
        btnOption3Click()
    End Sub

    Private Sub Btn_option4_Click(sender As Object, e As EventArgs) Handles btn_option4.Click
        btnOption4Click()
    End Sub


    Private Sub pnl_NewPC_btn_PWDShow_Click(sender As Object, e As EventArgs) Handles pnl_NewPC_btn_PWDShow.Click
        If pnl_NewPC_txt_PCPassword.UseSystemPasswordChar Then
            pnl_NewPC_txt_PCPassword.UseSystemPasswordChar = False
            pnl_NewPC_btn_PWDShow.Text = "Hide"
        Else
            pnl_NewPC_txt_PCPassword.UseSystemPasswordChar = True
            pnl_NewPC_btn_PWDShow.Text = "Show"
        End If
    End Sub


    'Private Sub pnl_Icon1_MouseClick(sender As Object, e As EventArgs) Handles pnl_Icon1.MouseClick
    '    If isMainMenuDisabled Then
    '        showStatusPanel()
    '    Else
    '        showStatusPanel()
    '        startRemoteScreenControlRequest()

    '    End If

    'End Sub

    Private Sub startRemoteScreenControlRequest()
        If myApp.MyConn.connectionType = enum_ConnectType.WS Then
            If myApp.MyConn.WS_Service_Open(wsArry_ScreenIndex, True) Then
                myApp.SendScreenRequest()
            End If
        Else
            myApp.SendScreenRequest()
        End If
    End Sub


    Private Sub pnl_Icon4_MouseClick(sender As Object, e As EventArgs) Handles pnl_Icon4.MouseClick, btn_Install.MouseClick, pnl_Icon4_img.MouseClick


        If myPcStatus_lbl_Service_2.Text = "Not Installed" Then
            myApp.installService()

        ElseIf myPcStatus_lbl_Service_2.Text = "Not Running" Then
            MsgBox("Please open Task Manager > Services Tab, and start the service.")

        ElseIf myPcStatus_lbl_Service_2.Text = "Running" Then
            If MsgBoxResult.Yes = MsgBox("Uninstalling app service from this PC, are you sure?", MsgBoxStyle.YesNo) Then
                If myApp.Password_Config_chk = "yes" Then
                    myApp.showPasswordForm(myAppClass.PasswordType.Uninstall)
                Else
                    myApp.unInstallServiceWithApp(False)
                End If

            End If

        End If

    End Sub

    Private Sub pnl_Icon7_MouseClick(sender As Object, e As EventArgs) Handles pnl_Icon7.MouseClick, pnl_Icon7_lbl.MouseClick, pnl_Icon7_img.MouseClick
        If myApp.Password_Config_chk = "yes" Then
            myApp.showPasswordForm(myAppClass.PasswordType.Config)
        Else
            ShowPage_Config()
        End If

    End Sub

    Friend Sub ShowPage_Config()
        hideAllBtnOptions()
        hideAllPanels()
        isConfigMenu = True
        updateConfigUI()
        ShowConfigurationBtnOptions()
        updateConfigPnls()

        updateFilesReceivePath()

        pnl_Config_1.Visible = True
    End Sub

    Friend Sub ShowPage_Passwords()
        hideAllBtnOptions()
        hideAllPanels()
        isConfigMenu = True
        updateConfigUI()
        ShowConfigurationBtnOptions()
        updateConfigPnls()

        pnl_Config_2.Visible = True
    End Sub



    Private Sub updateServiceInstalled()
        If myApp.myService.currentServiceState = Enum_Servicestate.NotInstalled Then
            myPcStatus_lbl_Service_2.Text = "Not Installed"
            myPcStatus_lbl_Unattended_2.ForeColor = Color.Red
            myPcStatus_lbl_Unattended_1.ForeColor = Color.Red
            myPcStatus_lbl_Unattended_1.Text = "Install to get"
            myPcStatus_lbl_Unattended_2.Text = "All Options"

            btn_Install.Text = "Install Service"
            btn_Install.Visible = True
            pnl_Icon4_img.Image = My.Resources.install
        ElseIf myApp.myService.currentServiceState = Enum_Servicestate.Installed Then
            myPcStatus_lbl_Service_2.Text = "Not Running"
            myPcStatus_lbl_Unattended_2.ForeColor = Color.Red
            myPcStatus_lbl_Unattended_1.ForeColor = Color.Red
            myPcStatus_lbl_Unattended_1.Text = "Run to get"
            myPcStatus_lbl_Unattended_2.Text = "All Options"

            btn_Install.Text = "Run Service"
            btn_Install.Visible = True
            pnl_Icon4_img.Image = My.Resources.icon4new
        ElseIf myApp.myService.currentServiceState = Enum_Servicestate.Running Then
            myPcStatus_lbl_Service_2.Text = "Running"

            btn_Install.Text = "Uninstall Service"
            btn_Install.Visible = True
            pnl_Icon4_img.Image = My.Resources.uninstall
        End If

    End Sub

    Private Sub updateServiceUnattended()

        If myApp.myService.UnattendedType = Enum_UnAttendedType.IP_Address Then
            myPcStatus_lbl_Unattended_2.Text = "IP Address"
            btn_Install.Visible = False
            myPcStatus_lbl_Unattended_2.ForeColor = Color.Black
            myPcStatus_lbl_Unattended_1.ForeColor = Color.Black
        ElseIf myApp.myService.UnattendedType = Enum_UnAttendedType.Online_ID Then
            myPcStatus_lbl_Unattended_2.Text = "Online ID"
            btn_Install.Visible = False
            myPcStatus_lbl_Unattended_2.ForeColor = Color.Black
            myPcStatus_lbl_Unattended_1.ForeColor = Color.Black
        End If

        If myApp.myService.currentServiceState = Enum_Servicestate.Running Then
            If isGodPower Then

            Else
                myPcStatus_lbl_Unattended_2.ForeColor = Color.Red
                myPcStatus_lbl_Unattended_1.ForeColor = Color.Red

                myPcStatus_lbl_Unattended_1.Text = "App did not"
                myPcStatus_lbl_Unattended_2.Text = "start from service"
                btn_Install.Visible = False
            End If

        End If
    End Sub

    Private Sub updateConfigPnls()
        If myApp.myService.UnattendedType = Enum_UnAttendedType.IP_Address Then
            pnl_Config_1_pnl1_rdo1.Checked = True
        Else
            pnl_Config_1_pnl1_rdo2.Checked = True
        End If

    End Sub

    Private Sub Btn_Disconnect_MyPC_Click(sender As Object, e As EventArgs) Handles btn_Disconnect_MyPC.Click

        If btn_Disconnect_MyPC.Text = "Start Listening" Then
            If myApp.myService.UnattendedType = Enum_UnAttendedType.IP_Address Then
                myApp.MyConn.Connect_UDP_Server()
            Else
                myApp.MyConn.Connect_WS_Server()
            End If

        ElseIf btn_Disconnect_MyPC.Text = "Refresh" Then
            myApp.MyConn.IsMyPCConnected_Allow = False
            myApp.MyConn.IsRemotePCConnected_startActions = False
            myApp.MyConn.Disconnect()
            'Dim taskTimer As Task = Task.Delay(2000).Run(Sub()
            '                                                 myApp.MyConn.Connect_WS_Server()
            '                                             End Sub)

        ElseIf btn_Disconnect_MyPC.Text = "Disconnect" Then
            myApp.MyConn.IsMyPCConnected_Allow = False
            myApp.MyConn.IsRemotePCConnected_startActions = False
            myApp.MyConn.Disconnect()

        End If
    End Sub




    Private isUpdtaingConfig As Boolean = False
    Private Sub updateConfigUI()
        isUpdtaingConfig = True
        If myApp.myService.UnattendedType = Enum_UnAttendedType.IP_Address Then
            pnl_Config_1_pnl1_rdo1.Checked = True
        Else
            pnl_Config_1_pnl1_rdo2.Checked = True
        End If

        If myApp.RemotePcAccessApproval = "no" Then
            pnl_Config_1_UserApproval_rdo1.Checked = True
        Else
            pnl_Config_1_UserApproval_rdo2.Checked = True
            If myApp.RemotePcAccessApproveAtLocked = "yes" Then
                pnl_Config_1_UserApproval_chk.Checked = True
            Else
                pnl_Config_1_UserApproval_chk.Checked = False
            End If
        End If

        If myApp.AfterConnectAutoStartActions.IndexOf("control") > -1 Then
            pnl_Config_3_Start_Actions_chk1.Checked = True
        Else
            pnl_Config_3_Start_Actions_chk1.Checked = False
        End If
        If myApp.AfterConnectAutoStartActions.IndexOf("audio") > -1 Then
            pnl_Config_3_Start_Actions_chk2.Checked = True
        Else
            pnl_Config_3_Start_Actions_chk2.Checked = False
        End If

        pnl_Config_3_Start_ViewControl_dd_Quality.SelectedIndex = IIf(myApp.Controller_Quality = "", 1, CInt(myApp.Controller_Quality))
        pnl_Config_3_Start_ViewControl_chk1.Checked = IIf(myApp.Controller_FullScreen = "yes", True, False)
        pnl_Config_3_Start_ViewControl_chk2.Checked = IIf(myApp.Controller_RemoteMouse = "yes", True, False)
        pnl_Config_3_Start_ViewControl_chk3.Checked = IIf(myApp.Controller_ControlPC = "yes", True, False)
        pnl_Config_3_Start_CloseConnection_chk2.Checked = IIf(myApp.Controller_CloseConnection = "yes", True, False)
        pnl_Config_3_chkAllowFilesSend.Checked = IIf(myApp.Controller_AllowFilesSend = "yes", True, False)
        pnl_Config_3_chkAllowFilesReceive.Checked = IIf(myApp.Controller_AllowFilesReceive = "yes", True, False)
        pnl_Config_3_chkAllowClipboardSend.Checked = IIf(myApp.Controller_AllowClipboardSend = "yes", True, False)
        pnl_Config_3_chkAllowClipboardReceive.Checked = IIf(myApp.Controller_AllowClipboardReceive = "yes", True, False)
        pnl_Config_1_chk_discoveryNotification.Checked = IIf(myApp.Controller_AllowAutoDiscoveryNotification = "yes", True, False)


        pnl_Config_1_txt_AutoDiscoverKeyword.Text = myApp.AutoDiscoverKeyword

        pnl_Config_1_txt_password_myPC.Text = myApp.Password_MyPC

        pnl_Config_1_txt_password_UIAccess.Text = myApp.Password_UIAccess
        pnl_Config_1_txt_password_config.Text = myApp.Password_Config
        pnl_Config_1_txt_password_Exit.Text = myApp.Password_ExitApp


        pnl_Config_1_chk_password_UIAccess.Checked = IIf(myApp.Password_UIAccess_chk = "yes", True, False)
        pnl_Config_1_chk_password_Exit.Checked = IIf(myApp.Password_ExitApp_chk = "yes", True, False)


        pnl_Config_3_wsProtocol.Text = myApp.MyConn.WS_URLProtocol
        pnl_Config_3_wsURL.Text = myApp.MyConn.WS_URLDomain

        pnl_Config_1_txt_ID.Text = myApp.MyInstallationID

        If myApp.myService.UnattendedConnectionType = "auto" Then
            pnl_Config_2_Rdo1.Checked = True
        Else
            pnl_Config_2_Rdo2.Checked = True
        End If

        isUpdtaingConfig = False
        configUnattendedRadios()
    End Sub

    Private Sub saveNewConfig()
        If pnl_Config_1_pnl1_rdo1.Checked = True Then
            myApp.myService.UnattendedType = Enum_UnAttendedType.IP_Address
        Else
            myApp.myService.UnattendedType = Enum_UnAttendedType.Online_ID
        End If

        If pnl_Config_1_UserApproval_rdo1.Checked Then
            myApp.RemotePcAccessApproval = "no"
        Else
            myApp.RemotePcAccessApproval = "yes"
            If pnl_Config_1_UserApproval_chk.Checked Then
                myApp.RemotePcAccessApproveAtLocked = "yes"
            Else
                myApp.RemotePcAccessApproveAtLocked = "no"
            End If
        End If

        Dim autoStartActions As New StringBuilder
        If pnl_Config_3_Start_Actions_chk1.Checked Then
            autoStartActions.Append("control")
        End If
        If pnl_Config_3_Start_Actions_chk2.Checked Then
            autoStartActions.Append("audio")
        End If
        myApp.AfterConnectAutoStartActions = autoStartActions.ToString

        myApp.Controller_Quality = pnl_Config_3_Start_ViewControl_dd_Quality.SelectedIndex
        myApp.Controller_FullScreen = IIf(pnl_Config_3_Start_ViewControl_chk1.Checked, "yes", "no")
        myApp.Controller_RemoteMouse = IIf(pnl_Config_3_Start_ViewControl_chk2.Checked, "yes", "no")
        myApp.Controller_ControlPC = IIf(pnl_Config_3_Start_ViewControl_chk3.Checked, "yes", "no")
        myApp.Controller_CloseConnection = IIf(pnl_Config_3_Start_CloseConnection_chk2.Checked, "yes", "no")
        myApp.Controller_AllowFilesSend = IIf(pnl_Config_3_chkAllowFilesSend.Checked, "yes", "no")
        myApp.Controller_AllowFilesReceive = IIf(pnl_Config_3_chkAllowFilesReceive.Checked, "yes", "no")
        myApp.Controller_AllowClipboardSend = IIf(pnl_Config_3_chkAllowClipboardSend.Checked, "yes", "no")
        myApp.Controller_AllowClipboardReceive = IIf(pnl_Config_3_chkAllowClipboardReceive.Checked, "yes", "no")
        myApp.Controller_AllowAutoDiscoveryNotification = IIf(pnl_Config_1_chk_discoveryNotification.Checked, "yes", "no")


        myApp.MyConn.WS_URLProtocol = pnl_Config_3_wsProtocol.Text

        If myApp.MyConn.WS_URLDomain <> pnl_Config_3_wsURL.Text.Trim Then
            myApp.MyConn.WS_URLDomain = pnl_Config_3_wsURL.Text.Trim
            myApp.MyConn.Disconnect()
        End If


        If pnl_Config_2_Rdo1.Checked Then
            myApp.myService.UnattendedConnectionType = "auto"
            'btn_Disconnect_MyPC.Visible = False
        Else
            myApp.myService.UnattendedConnectionType = "manual"
            btn_Disconnect_MyPC.Enabled = True
            'btn_Disconnect_MyPC.Visible = True
        End If


        myApp.Password_MyPC = pnl_Config_1_txt_password_myPC.Text
        pnl_Config_1_txt_password_myPC.UseSystemPasswordChar = True
        pnl_Config_1_btn_password_MyPC.Text = "Show"

        myApp.Password_UIAccess = pnl_Config_1_txt_password_UIAccess.Text
        myApp.Password_Config = pnl_Config_1_txt_password_config.Text
        myApp.Password_ExitApp = pnl_Config_1_txt_password_Exit.Text

        pnl_Config_1_txt_password_UIAccess.UseSystemPasswordChar = True
        pnl_Config_1_txt_password_config.UseSystemPasswordChar = True
        pnl_Config_1_txt_password_Exit.UseSystemPasswordChar = True

        pnl_Config_1_btn_password_UIAccess.Text = "Show"
        pnl_Config_1_btn_password_Config.Text = "Show"
        pnl_Config_1_btn_password_Exit.Text = "Show"

        myApp.Password_UIAccess_chk = IIf(pnl_Config_1_chk_password_UIAccess.Checked, "yes", "no")
        myApp.Password_Config_chk = IIf(pnl_Config_1_chk_password_config.Checked, "yes", "no")
        myApp.Password_ExitApp_chk = IIf(pnl_Config_1_chk_password_Exit.Checked, "yes", "no")

        If myApp.AutoDiscoverKeyword <> pnl_Config_1_txt_AutoDiscoverKeyword.Text.Trim Then
            myApp.AutoDiscoverKeyword = pnl_Config_1_txt_AutoDiscoverKeyword.Text.Trim
            If myApp.AutoDiscoverKeyword <> "" Then
                myApp.MyConn.SendRequestAsText("SvrCMD:RemoteDiscoverStart|" & myApp.AutoDiscoverKeyword)
            End If
        End If

        myApp.saveSettings()
    End Sub

    Private Sub Button7_Click(sender As Object, e As EventArgs) Handles Button7.Click, Button2.Click, Button1.Click
        saveNewConfig()
        showStatusPanel()
    End Sub


    Private Sub update_NewPCConnectionType()
        If pnl_NewPC_rdo1.Checked Then
            pnl_NewPC_lbl1.Text = "Network IP:"
            pnl_NewPC_lbl2.Text = "Password:"

        Else
            pnl_NewPC_lbl1.Text = "Installation ID:"
            pnl_NewPC_lbl2.Text = "Password:"

        End If
    End Sub

    Private Sub myPcStatus_lbl_RemoteID_2_Click(sender As Object, e As EventArgs) Handles myPcStatus_lbl_RemoteID_2.Click
        If myPcStatus_lbl_RemoteID_2.Text.Length > 5 Then
            Clipboard.SetText(myPcStatus_lbl_RemoteID_2.Text)
            MsgBox("Copied Remote PC Installation ID")
        End If

    End Sub

    Private Sub myPcStatus_lbl_MyID_2_Click(sender As Object, e As EventArgs) Handles myPcStatus_lbl_MyID_2.Click
        If myPcStatus_lbl_MyID_2.Text.Length > 5 Then
            Clipboard.SetText(myPcStatus_lbl_MyID_2.Text)
            MsgBox("Copied My PC Installation ID")
        End If

    End Sub

    Private Sub pnl_Config_1_pnl1_rdo2_CheckedChanged(sender As Object, e As EventArgs) Handles pnl_Config_1_pnl1_rdo2.CheckedChanged
        configUnattendedRadios()
    End Sub

    Private Sub configUnattendedRadios()
        If pnl_Config_1_pnl1_rdo2.Checked Then
            pnl_Config_3_wsProtocol.Visible = True
            pnl_Config_3_wsProtocol_lbl.Visible = True
            pnl_Config_3_wsURL.Visible = True
            pnl_Config_3_wsURL_lbl.Visible = True
        Else
            pnl_Config_3_wsProtocol.Visible = False
            pnl_Config_3_wsProtocol_lbl.Visible = False
            pnl_Config_3_wsURL.Visible = False
            pnl_Config_3_wsURL_lbl.Visible = False
        End If
    End Sub
    Private Sub pnl_NewPC_rdo2_CheckedChanged(sender As Object, e As EventArgs) Handles pnl_NewPC_rdo2.CheckedChanged
        update_NewPCConnectionType()
    End Sub




    Private UserApprovalCounter As Integer = 30
    Private Sub tmrUserApproval_Tick(sender As Object, e As EventArgs) Handles tmrUserApproval.Tick
        If UserApprovalCounter > 0 AndAlso myPcStatus_lbl_RemotePC_2.Text = "User Approval Shown" Then

            UserApprovalCounter -= 1
            myPcStatus_lbl_RemoteID_2.Text = UserApprovalCounter
            btn_Disconnect_RemotePC.Visible = True
        Else
            tmrUserApproval.Stop()
            UserApprovalCounter = 30
        End If


    End Sub

    Private Sub btn_Disconnect_RemotePC_Click(sender As Object, e As EventArgs) Handles btn_Disconnect_RemotePC.Click

        If myPcStatus_lbl_RemotePC_2.Text = "User Approval Shown" Then
            tmrUserApproval.Stop()
            UserApprovalCounter = 30
            myPcStatus_lbl_RemotePC_2.Text = "Disconnected"
            UpdateMyPCStatus()
            myApp.MyConn.Cancel_Connect_WS_Client()
        Else
            If myApp.myService.UnattendedType = Enum_UnAttendedType.IP_Address Then
                myApp.MyConn.IsMyPCConnected_Allow = False
                myApp.MyConn.Disconnect()
            Else
                myApp.MyConn.WS_Remote_Disconnect()
            End If
        End If

    End Sub

    Private Sub Pnl_Config_1_btn_showPassword_Click(sender As Object, e As EventArgs) Handles pnl_Config_1_btn_password_MyPC.Click
        If pnl_Config_1_txt_password_myPC.UseSystemPasswordChar Then
            pnl_Config_1_txt_password_myPC.UseSystemPasswordChar = False
            pnl_Config_1_btn_password_MyPC.Text = "Hide"
        Else
            pnl_Config_1_txt_password_myPC.UseSystemPasswordChar = True
            pnl_Config_1_btn_password_MyPC.Text = "Show"
        End If
    End Sub

    Private Sub pnl_Config_1_btn_password_UIAccess_Click(sender As Object, e As EventArgs) Handles pnl_Config_1_btn_password_UIAccess.Click
        If pnl_Config_1_txt_password_UIAccess.UseSystemPasswordChar Then
            pnl_Config_1_txt_password_UIAccess.UseSystemPasswordChar = False
            pnl_Config_1_btn_password_UIAccess.Text = "Hide"
        Else
            pnl_Config_1_txt_password_UIAccess.UseSystemPasswordChar = True
            pnl_Config_1_btn_password_UIAccess.Text = "Show"
        End If
    End Sub

    Private Sub pnl_Config_1_btn_password_Config_Click(sender As Object, e As EventArgs) Handles pnl_Config_1_btn_password_Config.Click
        If pnl_Config_1_txt_password_config.UseSystemPasswordChar Then
            pnl_Config_1_txt_password_config.UseSystemPasswordChar = False
            pnl_Config_1_btn_password_Config.Text = "Hide"
        Else
            pnl_Config_1_txt_password_config.UseSystemPasswordChar = True
            pnl_Config_1_btn_password_Config.Text = "Show"
        End If
    End Sub



    Private Sub pnl_Config_1_UserApproval_rdo2_CheckedChanged(sender As Object, e As EventArgs) Handles pnl_Config_1_UserApproval_rdo2.CheckedChanged
        If pnl_Config_1_UserApproval_rdo2.Checked Then
            pnl_Config_1_UserApproval_chk.Visible = True

        End If
    End Sub

    Private Sub pnl_Config_1_UserApproval_rdo1_CheckedChanged(sender As Object, e As EventArgs) Handles pnl_Config_1_UserApproval_rdo1.CheckedChanged
        If pnl_Config_1_UserApproval_rdo1.Checked Then
            pnl_Config_1_UserApproval_chk.Visible = False

        End If
    End Sub


    Private Sub pnl_Config_1_txt_AutoDiscoverKeyword_KeyPress(sender As Object, e As KeyPressEventArgs) Handles pnl_Config_1_txt_AutoDiscoverKeyword.KeyPress
        If Not Char.IsLetterOrDigit(e.KeyChar) Then
            If e.KeyChar = CChar(ChrW(Keys.Back)) Or e.KeyChar = CChar(ChrW(Keys.Space)) Then
                e.Handled = False
            Else
                e.Handled = True
            End If
        End If
    End Sub



    Private Sub tree_DragDrop(sender As Object, e As DragEventArgs) Handles treeObj.DragDrop

        Try

            If e.Data.GetDataPresent("System.Windows.Forms.TreeNode", True) Then

                Dim DestinationNode As TreeNode = treeObj.GetNodeAt(treeObj.PointToClient(New System.Drawing.Point(e.X, e.Y)))
                If IsNothing(DestinationNode) Then
                    e.Effect = DragDropEffects.None
                    Return
                End If
                Dim DestinationNodetype As String = gbl_Tree.getNodeTypeFromNodeTag(DestinationNode.Tag)

                Dim SelectedNode As TreeNode = CType(e.Data.GetData("System.Windows.Forms.TreeNode"), TreeNode)
                Dim SelectedNodetype As String = gbl_Tree.getNodeTypeFromNodeTag(SelectedNode.Tag)

                If SelectedNodetype = "folder" AndAlso DestinationNodetype = "pc" Then
                    e.Effect = DragDropEffects.None
                Else

                    'Dim pcObj As UserSettings_ClientsPCClass = gbl_Tree.myPCs(gbl_Tree.getPCIndexFromPcID(lastSelectedNode.Tag))

                    If SelectedNodetype = "folder" AndAlso DestinationNodetype = "folder" Then
                        Dim folderObj_Selected As UserSettings_ClientsFolderClass = gbl_Tree.myFolders(gbl_Tree.getFolderIndexFromFolderID(SelectedNode.Tag))
                        Dim folderObj_Destination As UserSettings_ClientsFolderClass = gbl_Tree.myFolders(gbl_Tree.getFolderIndexFromFolderID(DestinationNode.Tag))

                        If folderObj_Selected.FolderName = "Auto Discovery" OrElse folderObj_Destination.FolderName = "Auto Discovery" Then Return

                        SelectedNode.Remove()
                        DestinationNode.Nodes.Insert(0, SelectedNode)

                        folderObj_Selected.FolderParentID = folderObj_Destination.FolderID

                        gbl_Tree.ReProvideSubObjsSortIndex(DestinationNode.Nodes)

                        treeObj.SelectedNode = SelectedNode
                        lastSelectedNode = treeObj.SelectedNode

                        myApp.saveSettings()
                        DestinationNode.Expand()

                    ElseIf SelectedNodetype = "pc" AndAlso DestinationNodetype = "folder" Then

                        Dim pcObj As UserSettings_ClientsPCClass = gbl_Tree.myPCs(gbl_Tree.getPCIndexFromPcID(SelectedNode.Tag))
                        Dim folderObj_Destination As UserSettings_ClientsFolderClass = gbl_Tree.myFolders(gbl_Tree.getFolderIndexFromFolderID(DestinationNode.Tag))
                        If folderObj_Destination.FolderName = "Auto Discovery" Then Return

                        If pcObj.FolderParentID = folderObj_Destination.FolderID Then Return

                        SelectedNode.Remove()
                        '  gbl_Tree.SortSubObjsIndex() ' If ParentFolderID > 0 Then

                        Dim nodePos As Integer = 0
                        For i As Integer = 0 To DestinationNode.Nodes.Count - 1
                            nodePos = i
                            Dim tmpNodetype As String = gbl_Tree.getNodeTypeFromNodeTag(DestinationNode.Nodes(i).Tag)
                            If tmpNodetype = "pc" Then Exit For
                        Next

                        DestinationNode.Nodes.Insert(nodePos, SelectedNode)

                        pcObj.FolderParentID = folderObj_Destination.FolderID

                        gbl_Tree.ReProvideSubObjsSortIndex(DestinationNode.Nodes)

                        treeObj.SelectedNode = SelectedNode
                        lastSelectedNode = treeObj.SelectedNode

                        myApp.saveSettings()
                        DestinationNode.Expand()

                    ElseIf SelectedNodetype = "pc" AndAlso DestinationNodetype = "pc" Then

                        'Dim pcObj_Source As UserSettings_ClientsPCClass = gbl_Tree.myPCs(gbl_Tree.getPCIndexFromPcID(SelectedNode.Tag))

                        Dim pcObj_Dest As UserSettings_ClientsPCClass = gbl_Tree.myPCs(gbl_Tree.getPCIndexFromPcID(DestinationNode.Tag))
                        Dim folderObj_Dest As UserSettings_ClientsFolderClass = gbl_Tree.myFolders(gbl_Tree.getFolderIndexFromFolderID(pcObj_Dest.FolderParentID))
                        Dim parentFolderNode As TreeNode = gbl_Tree.getTNodeFromObjID(folderObj_Dest.FolderID, treeObj.Nodes)
                        SelectedNode.Remove()
                        parentFolderNode.Nodes.Insert(pcObj_Dest.ParentSortIndex, SelectedNode)
                        gbl_Tree.ReProvideSubObjsSortIndex(parentFolderNode.Nodes)

                        treeObj.SelectedNode = SelectedNode
                        lastSelectedNode = treeObj.SelectedNode

                        myApp.saveSettings()
                    End If

                End If

            Else
                e.Effect = DragDropEffects.None
            End If


        Catch ex As Exception
            MsgBox(ex.Message)
        End Try

    End Sub

    Private Sub treeObj_DragOver(sender As Object, e As DragEventArgs) Handles treeObj.DragOver
        If e.Data.GetDataPresent("System.Windows.Forms.TreeNode", True) Then

            Dim DestinationNode As TreeNode = treeObj.GetNodeAt(treeObj.PointToClient(New System.Drawing.Point(e.X, e.Y)))
            If IsNothing(DestinationNode) Then
                e.Effect = DragDropEffects.None
                Return
            End If
            Dim DestinationNodetype As String = gbl_Tree.getNodeTypeFromNodeTag(DestinationNode.Tag)

            Dim SelectedNode As TreeNode = CType(e.Data.GetData("System.Windows.Forms.TreeNode"), TreeNode)
            Dim SelectedNodetype As String = gbl_Tree.getNodeTypeFromNodeTag(SelectedNode.Tag)

            If SelectedNodetype = "folder" AndAlso DestinationNodetype = "pc" Then
                e.Effect = DragDropEffects.None
            Else
                e.Effect = DragDropEffects.Move
            End If

        Else
            e.Effect = DragDropEffects.None
        End If
    End Sub
    Private Sub tree_DragEnter(sender As Object, e As DragEventArgs) Handles treeObj.DragEnter
        e.Effect = DragDropEffects.Move
    End Sub

    Private Sub tree_ItemDrag(sender As Object, e As ItemDragEventArgs) Handles treeObj.ItemDrag
        DoDragDrop(e.Item, DragDropEffects.Move)
    End Sub

    Private Sub btnFolder_MoveUp_Click(sender As Object, e As EventArgs) Handles btnFolder_MoveUp.Click
        MoveUpDownTreeFolder(True)
    End Sub

    Private Sub btnFolder_MoveDown_Click(sender As Object, e As EventArgs) Handles btnFolder_MoveDown.Click
        MoveUpDownTreeFolder(False)
    End Sub

    Private Sub MoveUpDownTreeFolder(isUp As Boolean)
        Dim SelectedNode As TreeNode = treeObj.SelectedNode

        Dim folderObj_Selected As UserSettings_ClientsFolderClass = gbl_Tree.myFolders(gbl_Tree.getFolderIndexFromFolderID(SelectedNode.Tag))

        Dim parentFolder As TreeNode = gbl_Tree.getTNodeFromObjID(folderObj_Selected.FolderParentID, treeObj.Nodes)

        '  gbl_Tree.SortSubObjsIndex() ' If ParentFolderID > 0 Then

        Dim nodePos As Integer = SelectedNode.Index

        If isUp Then
            If nodePos = 0 Then
                Return
            End If
            nodePos -= 1
            Dim DestinationNodetype As String = gbl_Tree.getNodeTypeFromNodeTag(parentFolder.Nodes(nodePos).Tag)
            If DestinationNodetype = "pc" Then
                Return
            End If
        Else
            If nodePos = parentFolder.Nodes.Count - 1 Then
                Return
            End If
            nodePos += 1
            Dim DestinationNodetype As String = gbl_Tree.getNodeTypeFromNodeTag(parentFolder.Nodes(nodePos).Tag)
            If DestinationNodetype = "pc" Then
                Return
            End If
        End If

        SelectedNode.Remove()
        parentFolder.Nodes.Insert(nodePos, SelectedNode)
        gbl_Tree.ReProvideSubObjsSortIndex(parentFolder.Nodes)

        treeObj.SelectedNode = SelectedNode
        lastSelectedNode = treeObj.SelectedNode

        myApp.saveSettings()
    End Sub

    Private Sub btn_Files_RemotePC_Click(sender As Object, e As EventArgs) Handles btn_Files_RemotePC.Click
        If IsNothing(frmFilesObj) Then
            frmFilesObj = New frmfiles
            frmFilesObj.Show(Me)
            frmFilesObj.Location = New Point(Me.Width - frmFilesObj.Width - 10, Me.Height - frmFilesObj.Height - 10)
        Else
            MsgBox("Files Window Already Opened.")
        End If

    End Sub

    Private Sub btn_ScreenControl_RemotePC_Click(sender As Object, e As EventArgs) Handles btn_ScreenControl_RemotePC.Click
        If myApp.MyConn.isServiceOpen_WS_Screen Then
            MsgBox("Screen Control Already Connected")
        Else
            startRemoteScreenControlRequest()
        End If

    End Sub

    Private Sub btnTaskmgr_Click(sender As Object, e As EventArgs) Handles btnTaskmgr.Click
        If myApp.Password_Config_chk = "yes" Then
            myApp.showPasswordForm(myAppClass.PasswordType.TaskMgr)
        Else
            StartAppFromName("taskmgr")
        End If

    End Sub

    Private Sub tmrAllOnlineStatus_Tick(sender As Object, e As EventArgs) Handles tmrAllOnlineStatus.Tick

        If myApp.MyConn.IsMyPCConnected AndAlso Not myApp.MyConn.IsRemotePCConnected Then
            gbl_Tree.RequestPCsOnlineStatus()
        End If

    End Sub


    Private Sub txt_Search_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txt_Search.KeyPress
        If e.KeyChar = Chr(13) Then
            MsgBox("Enter")
        End If
    End Sub

    Private Sub pnl_Config_1_btn_password_Exit_Click(sender As Object, e As EventArgs) Handles pnl_Config_1_btn_password_Exit.Click
        If pnl_Config_1_txt_password_Exit.UseSystemPasswordChar Then
            pnl_Config_1_txt_password_Exit.UseSystemPasswordChar = False
            pnl_Config_1_btn_password_Exit.Text = "Hide"
        Else
            pnl_Config_1_txt_password_Exit.UseSystemPasswordChar = True
            pnl_Config_1_btn_password_Exit.Text = "Show"
        End If
    End Sub


End Class
