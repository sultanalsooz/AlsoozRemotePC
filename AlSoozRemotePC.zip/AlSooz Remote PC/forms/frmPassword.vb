﻿Imports System.ComponentModel

Public Class frmPassword

    Private Sub frmPassword_Closing(sender As Object, e As CancelEventArgs) Handles Me.Closing
        frmPasswordObj = Nothing
    End Sub

    Private Sub frmPassword_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Using g As Graphics = Me.CreateGraphics
            GenerateFontSizefromScreenDPI(g, lbl_hidden_fontSize, lbl_CountDown)
        End Using

        resizeAllChildControls(Me)

        If myApp.Password_CurrentRequest = myAppClass.PasswordType.ExitApp Then
            lbl.Text = "Enter Password To Exit App"
        ElseIf myApp.Password_CurrentRequest = myAppClass.PasswordType.UIAccess Then
            lbl.Text = "Enter Password To Access User Interface (UI)"
        ElseIf myApp.Password_CurrentRequest = myAppClass.PasswordType.Config Then
            lbl.Text = "Enter Password To Access Configuration"
        ElseIf myApp.Password_CurrentRequest = myAppClass.PasswordType.TaskMgr Then
            lbl.Text = "Enter Password To Access Task Manager"
        ElseIf myApp.Password_CurrentRequest = myAppClass.PasswordType.Uninstall Then
            lbl.Text = "Enter Password To Uninstall App"
        End If

    End Sub

    Private Sub btn_show_Click(sender As Object, e As EventArgs) Handles btn_show.Click
        If txt_pass.UseSystemPasswordChar Then
            txt_pass.UseSystemPasswordChar = False
            btn_show.Text = "Hide"
        Else
            txt_pass.UseSystemPasswordChar = True
            btn_show.Text = "Show"
        End If
    End Sub

    Private Sub btn_Cancel_Click(sender As Object, e As EventArgs) Handles btn_Cancel.Click
        Close()
    End Sub

    Private Sub btn_Allow_Click(sender As Object, e As EventArgs) Handles btn_Allow.Click

        processPassword()
    End Sub

    Private Sub processPassword()
        If myApp.Password_CurrentRequest = myAppClass.PasswordType.ExitApp Then
            If myApp.Password_ExitApp = txt_pass.Text Then
                myApp.App_Close()
            Else
                wrongPassword()
            End If

        ElseIf myApp.Password_CurrentRequest = myAppClass.PasswordType.UIAccess Then
            If myApp.Password_UIAccess = txt_pass.Text Then
                frmTrayObj.openControlForm("")
                Close()
            Else
                wrongPassword()
            End If
        ElseIf myApp.Password_CurrentRequest = myAppClass.PasswordType.Config Then
            If myApp.Password_Config = txt_pass.Text Then
                frmTrayObj.openControlForm("config")
                Close()
            Else
                wrongPassword()
            End If

        ElseIf myApp.Password_CurrentRequest = myAppClass.PasswordType.Uninstall Then
            If myApp.Password_Config = txt_pass.Text Then
                myApp.unInstallServiceWithApp(False)
                Close()
            Else
                wrongPassword()
            End If

        ElseIf myApp.Password_CurrentRequest = myAppClass.PasswordType.TaskMgr Then
            If myApp.Password_Config = txt_pass.Text Then
                StartAppFromName("taskmgr")
                Close()
            Else
                wrongPassword()
            End If
        End If
    End Sub
    Private Sub wrongPassword()
        Timer1.Stop()
        lbl_wrong.Visible = True
        Timer1.Start()
    End Sub

    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick
        lbl_wrong.Visible = False
        Timer1.Stop()
    End Sub


    Private Sub txt_pass_KeyDown(sender As Object, e As KeyEventArgs) Handles txt_pass.KeyDown
        If e.KeyCode = Keys.Enter Then
            processPassword()
            e.Handled = True
        End If
    End Sub

    Private Sub txt_pass_KeyUp(sender As Object, e As KeyEventArgs) Handles txt_pass.KeyUp
        If e.KeyCode = Keys.Enter Then
            e.Handled = True
        End If
    End Sub

    Private Sub frmPassword_Shown(sender As Object, e As EventArgs) Handles Me.Shown
        txt_pass.Focus()
    End Sub


End Class