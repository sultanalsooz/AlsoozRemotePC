﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class frmScreenControl
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmScreenControl))
        Me.pnl_main = New System.Windows.Forms.Panel()
        Me.Panel4 = New System.Windows.Forms.Panel()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Panel3 = New System.Windows.Forms.Panel()
        Me.btnReboot = New System.Windows.Forms.Button()
        Me.btn_installService = New System.Windows.Forms.Button()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.lblScreenSizeRemote = New System.Windows.Forms.Label()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.dd_Quality = New System.Windows.Forms.ComboBox()
        Me.lbl_quality = New System.Windows.Forms.Label()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.Button3 = New System.Windows.Forms.Button()
        Me.btn_Capslock_remote = New System.Windows.Forms.Button()
        Me.btn_numlock_my = New System.Windows.Forms.Button()
        Me.btn_numlock_remote = New System.Windows.Forms.Button()
        Me.Label27 = New System.Windows.Forms.Label()
        Me.chk_MyMouseShow = New System.Windows.Forms.CheckBox()
        Me.chk_MouseSend = New System.Windows.Forms.CheckBox()
        Me.chk_RemoteMouseShow = New System.Windows.Forms.CheckBox()
        Me.btn_SAS = New System.Windows.Forms.Button()
        Me.txt_input = New System.Windows.Forms.TextBox()
        Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
        Me.lbl_userMsg = New System.Windows.Forms.Label()
        Me.tmr_lblmsg = New System.Windows.Forms.Timer(Me.components)
        Me.tmr_NumCapsLock = New System.Windows.Forms.Timer(Me.components)
        Me.pnl_main.SuspendLayout()
        Me.Panel4.SuspendLayout()
        Me.Panel3.SuspendLayout()
        Me.Panel1.SuspendLayout()
        Me.Panel2.SuspendLayout()
        Me.SuspendLayout()
        '
        'pnl_main
        '
        Me.pnl_main.BackColor = System.Drawing.Color.WhiteSmoke
        Me.pnl_main.Controls.Add(Me.Panel4)
        Me.pnl_main.Controls.Add(Me.Panel3)
        Me.pnl_main.Controls.Add(Me.Panel1)
        Me.pnl_main.Controls.Add(Me.Panel2)
        Me.pnl_main.Controls.Add(Me.txt_input)
        Me.pnl_main.Location = New System.Drawing.Point(0, 0)
        Me.pnl_main.Name = "pnl_main"
        Me.pnl_main.Size = New System.Drawing.Size(130, 655)
        Me.pnl_main.TabIndex = 0
        '
        'Panel4
        '
        Me.Panel4.BackColor = System.Drawing.Color.White
        Me.Panel4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel4.Controls.Add(Me.Label3)
        Me.Panel4.Controls.Add(Me.Label1)
        Me.Panel4.Location = New System.Drawing.Point(-4, 537)
        Me.Panel4.Name = "Panel4"
        Me.Panel4.Size = New System.Drawing.Size(133, 119)
        Me.Panel4.TabIndex = 35
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(4, 35)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(127, 76)
        Me.Label3.TabIndex = 33
        Me.Label3.Text = "F1 = Full Screen" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "F2 = Control PC" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "F3 = Remt Mouse" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "F4 = Numpad Lock"
        '
        'Label1
        '
        Me.Label1.BackColor = System.Drawing.Color.FromArgb(CType(CType(76, Byte), Integer), CType(CType(76, Byte), Integer), CType(CType(76, Byte), Integer))
        Me.Label1.ForeColor = System.Drawing.Color.White
        Me.Label1.Location = New System.Drawing.Point(3, -1)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(132, 32)
        Me.Label1.TabIndex = 32
        Me.Label1.Text = "Shortcuts"
        Me.Label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.Label1.UseMnemonic = False
        '
        'Panel3
        '
        Me.Panel3.BackColor = System.Drawing.Color.White
        Me.Panel3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel3.Controls.Add(Me.btnReboot)
        Me.Panel3.Controls.Add(Me.btn_installService)
        Me.Panel3.Controls.Add(Me.Button2)
        Me.Panel3.Controls.Add(Me.Label5)
        Me.Panel3.Location = New System.Drawing.Point(-4, 392)
        Me.Panel3.Name = "Panel3"
        Me.Panel3.Size = New System.Drawing.Size(133, 139)
        Me.Panel3.TabIndex = 35
        '
        'btnReboot
        '
        Me.btnReboot.Location = New System.Drawing.Point(6, 103)
        Me.btnReboot.Name = "btnReboot"
        Me.btnReboot.Size = New System.Drawing.Size(121, 28)
        Me.btnReboot.TabIndex = 34
        Me.btnReboot.Text = "Reboot PC"
        Me.btnReboot.UseVisualStyleBackColor = True
        '
        'btn_installService
        '
        Me.btn_installService.Location = New System.Drawing.Point(6, 69)
        Me.btn_installService.Name = "btn_installService"
        Me.btn_installService.Size = New System.Drawing.Size(120, 28)
        Me.btn_installService.TabIndex = 38
        Me.btn_installService.Text = "Install Service"
        Me.btn_installService.UseVisualStyleBackColor = True
        '
        'Button2
        '
        Me.Button2.Location = New System.Drawing.Point(6, 35)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(120, 28)
        Me.Button2.TabIndex = 34
        Me.Button2.Text = "File Transfer"
        Me.Button2.UseVisualStyleBackColor = True
        '
        'Label5
        '
        Me.Label5.BackColor = System.Drawing.Color.FromArgb(CType(CType(76, Byte), Integer), CType(CType(76, Byte), Integer), CType(CType(76, Byte), Integer))
        Me.Label5.ForeColor = System.Drawing.Color.White
        Me.Label5.Location = New System.Drawing.Point(3, -1)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(132, 32)
        Me.Label5.TabIndex = 32
        Me.Label5.Text = "Other Services"
        Me.Label5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.Label5.UseMnemonic = False
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.Color.White
        Me.Panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel1.Controls.Add(Me.lblScreenSizeRemote)
        Me.Panel1.Controls.Add(Me.Button1)
        Me.Panel1.Controls.Add(Me.Label4)
        Me.Panel1.Controls.Add(Me.dd_Quality)
        Me.Panel1.Controls.Add(Me.lbl_quality)
        Me.Panel1.Location = New System.Drawing.Point(-4, 1)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(133, 133)
        Me.Panel1.TabIndex = 34
        '
        'lblScreenSizeRemote
        '
        Me.lblScreenSizeRemote.Location = New System.Drawing.Point(4, 170)
        Me.lblScreenSizeRemote.Name = "lblScreenSizeRemote"
        Me.lblScreenSizeRemote.Size = New System.Drawing.Size(124, 19)
        Me.lblScreenSizeRemote.TabIndex = 36
        Me.lblScreenSizeRemote.Text = "_"
        Me.lblScreenSizeRemote.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(6, 96)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(121, 28)
        Me.Button1.TabIndex = 35
        Me.Button1.Text = "Full Screen"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'Label4
        '
        Me.Label4.BackColor = System.Drawing.Color.FromArgb(CType(CType(76, Byte), Integer), CType(CType(76, Byte), Integer), CType(CType(76, Byte), Integer))
        Me.Label4.ForeColor = System.Drawing.Color.White
        Me.Label4.Location = New System.Drawing.Point(3, 0)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(132, 32)
        Me.Label4.TabIndex = 34
        Me.Label4.Text = "Remote Screen"
        Me.Label4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.Label4.UseMnemonic = False
        '
        'dd_Quality
        '
        Me.dd_Quality.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.dd_Quality.FormattingEnabled = True
        Me.dd_Quality.Items.AddRange(New Object() {"High Speed", "Balance", "High Quality"})
        Me.dd_Quality.Location = New System.Drawing.Point(9, 58)
        Me.dd_Quality.Name = "dd_Quality"
        Me.dd_Quality.Size = New System.Drawing.Size(114, 27)
        Me.dd_Quality.TabIndex = 26
        '
        'lbl_quality
        '
        Me.lbl_quality.AutoSize = True
        Me.lbl_quality.Location = New System.Drawing.Point(6, 36)
        Me.lbl_quality.Name = "lbl_quality"
        Me.lbl_quality.Size = New System.Drawing.Size(56, 19)
        Me.lbl_quality.TabIndex = 27
        Me.lbl_quality.Text = "Quality"
        '
        'Panel2
        '
        Me.Panel2.BackColor = System.Drawing.Color.White
        Me.Panel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel2.Controls.Add(Me.Button3)
        Me.Panel2.Controls.Add(Me.btn_Capslock_remote)
        Me.Panel2.Controls.Add(Me.btn_numlock_my)
        Me.Panel2.Controls.Add(Me.btn_numlock_remote)
        Me.Panel2.Controls.Add(Me.Label27)
        Me.Panel2.Controls.Add(Me.chk_MyMouseShow)
        Me.Panel2.Controls.Add(Me.chk_MouseSend)
        Me.Panel2.Controls.Add(Me.chk_RemoteMouseShow)
        Me.Panel2.Controls.Add(Me.btn_SAS)
        Me.Panel2.Location = New System.Drawing.Point(-4, 139)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(133, 248)
        Me.Panel2.TabIndex = 33
        '
        'Button3
        '
        Me.Button3.Location = New System.Drawing.Point(68, 111)
        Me.Button3.Name = "Button3"
        Me.Button3.Size = New System.Drawing.Size(56, 28)
        Me.Button3.TabIndex = 36
        Me.Button3.Text = "Keys"
        Me.Button3.UseVisualStyleBackColor = True
        '
        'btn_Capslock_remote
        '
        Me.btn_Capslock_remote.Location = New System.Drawing.Point(6, 145)
        Me.btn_Capslock_remote.Name = "btn_Capslock_remote"
        Me.btn_Capslock_remote.Size = New System.Drawing.Size(121, 28)
        Me.btn_Capslock_remote.TabIndex = 35
        Me.btn_Capslock_remote.Text = "Rmot CapsLock"
        Me.btn_Capslock_remote.UseMnemonic = False
        Me.btn_Capslock_remote.UseVisualStyleBackColor = True
        '
        'btn_numlock_my
        '
        Me.btn_numlock_my.Location = New System.Drawing.Point(6, 211)
        Me.btn_numlock_my.Name = "btn_numlock_my"
        Me.btn_numlock_my.Size = New System.Drawing.Size(121, 28)
        Me.btn_numlock_my.TabIndex = 34
        Me.btn_numlock_my.Text = "My NumLock"
        Me.btn_numlock_my.UseMnemonic = False
        Me.btn_numlock_my.UseVisualStyleBackColor = True
        '
        'btn_numlock_remote
        '
        Me.btn_numlock_remote.Location = New System.Drawing.Point(6, 178)
        Me.btn_numlock_remote.Name = "btn_numlock_remote"
        Me.btn_numlock_remote.Size = New System.Drawing.Size(121, 28)
        Me.btn_numlock_remote.TabIndex = 33
        Me.btn_numlock_remote.Text = "Rmot NumLock"
        Me.btn_numlock_remote.UseMnemonic = False
        Me.btn_numlock_remote.UseVisualStyleBackColor = True
        '
        'Label27
        '
        Me.Label27.BackColor = System.Drawing.Color.FromArgb(CType(CType(76, Byte), Integer), CType(CType(76, Byte), Integer), CType(CType(76, Byte), Integer))
        Me.Label27.ForeColor = System.Drawing.Color.White
        Me.Label27.Location = New System.Drawing.Point(3, -1)
        Me.Label27.Name = "Label27"
        Me.Label27.Size = New System.Drawing.Size(132, 32)
        Me.Label27.TabIndex = 32
        Me.Label27.Text = "Mouse & Keys"
        Me.Label27.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.Label27.UseMnemonic = False
        '
        'chk_MyMouseShow
        '
        Me.chk_MyMouseShow.AutoSize = True
        Me.chk_MyMouseShow.Checked = True
        Me.chk_MyMouseShow.CheckState = System.Windows.Forms.CheckState.Checked
        Me.chk_MyMouseShow.Location = New System.Drawing.Point(6, 83)
        Me.chk_MyMouseShow.Name = "chk_MyMouseShow"
        Me.chk_MyMouseShow.Size = New System.Drawing.Size(96, 23)
        Me.chk_MyMouseShow.TabIndex = 31
        Me.chk_MyMouseShow.Text = "My Mouse"
        Me.chk_MyMouseShow.UseVisualStyleBackColor = True
        '
        'chk_MouseSend
        '
        Me.chk_MouseSend.AutoSize = True
        Me.chk_MouseSend.Location = New System.Drawing.Point(6, 35)
        Me.chk_MouseSend.Name = "chk_MouseSend"
        Me.chk_MouseSend.Size = New System.Drawing.Size(96, 23)
        Me.chk_MouseSend.TabIndex = 0
        Me.chk_MouseSend.Text = "Control PC"
        Me.chk_MouseSend.UseVisualStyleBackColor = True
        '
        'chk_RemoteMouseShow
        '
        Me.chk_RemoteMouseShow.AutoSize = True
        Me.chk_RemoteMouseShow.Location = New System.Drawing.Point(6, 59)
        Me.chk_RemoteMouseShow.Name = "chk_RemoteMouseShow"
        Me.chk_RemoteMouseShow.Size = New System.Drawing.Size(126, 23)
        Me.chk_RemoteMouseShow.TabIndex = 3
        Me.chk_RemoteMouseShow.Text = "Remote Mouse"
        Me.chk_RemoteMouseShow.UseVisualStyleBackColor = True
        '
        'btn_SAS
        '
        Me.btn_SAS.Location = New System.Drawing.Point(6, 111)
        Me.btn_SAS.Name = "btn_SAS"
        Me.btn_SAS.Size = New System.Drawing.Size(56, 28)
        Me.btn_SAS.TabIndex = 28
        Me.btn_SAS.Text = "CAD"
        Me.btn_SAS.UseVisualStyleBackColor = True
        '
        'txt_input
        '
        Me.txt_input.AcceptsReturn = True
        Me.txt_input.AcceptsTab = True
        Me.txt_input.Location = New System.Drawing.Point(1052, 4)
        Me.txt_input.Name = "txt_input"
        Me.txt_input.Size = New System.Drawing.Size(0, 27)
        Me.txt_input.TabIndex = 4
        Me.txt_input.WordWrap = False
        '
        'Timer1
        '
        Me.Timer1.Interval = 5000
        '
        'lbl_userMsg
        '
        Me.lbl_userMsg.BackColor = System.Drawing.Color.DodgerBlue
        Me.lbl_userMsg.Font = New System.Drawing.Font("Verdana", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_userMsg.ForeColor = System.Drawing.Color.White
        Me.lbl_userMsg.Location = New System.Drawing.Point(320, 4)
        Me.lbl_userMsg.Name = "lbl_userMsg"
        Me.lbl_userMsg.Size = New System.Drawing.Size(449, 38)
        Me.lbl_userMsg.TabIndex = 37
        Me.lbl_userMsg.Text = "Quality"
        Me.lbl_userMsg.TextAlign = System.Drawing.ContentAlignment.TopCenter
        Me.lbl_userMsg.Visible = False
        '
        'tmr_lblmsg
        '
        Me.tmr_lblmsg.Interval = 1500
        '
        'tmr_NumCapsLock
        '
        Me.tmr_NumCapsLock.Interval = 2500
        '
        'frmScreenControl
        '
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None
        Me.BackColor = System.Drawing.Color.Black
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.ClientSize = New System.Drawing.Size(1284, 656)
        Me.Controls.Add(Me.lbl_userMsg)
        Me.Controls.Add(Me.pnl_main)
        Me.Font = New System.Drawing.Font("Calibri", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MinimizeBox = False
        Me.Name = "frmScreenControl"
        Me.ShowIcon = False
        Me.StartPosition = System.Windows.Forms.FormStartPosition.Manual
        Me.Text = "Controller"
        Me.WindowState = System.Windows.Forms.FormWindowState.Maximized
        Me.pnl_main.ResumeLayout(False)
        Me.pnl_main.PerformLayout()
        Me.Panel4.ResumeLayout(False)
        Me.Panel4.PerformLayout()
        Me.Panel3.ResumeLayout(False)
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        Me.Panel2.ResumeLayout(False)
        Me.Panel2.PerformLayout()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents pnl_main As Panel
    Friend WithEvents chk_MouseSend As CheckBox
    Friend WithEvents chk_RemoteMouseShow As CheckBox
    Friend WithEvents txt_input As TextBox
    Friend WithEvents Timer1 As Timer
    Friend WithEvents lbl_quality As Label
    Friend WithEvents dd_Quality As ComboBox
    Friend WithEvents btn_SAS As Button
    Friend WithEvents chk_MyMouseShow As CheckBox
    Friend WithEvents Panel2 As Panel
    Friend WithEvents Label27 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents Panel1 As Panel
    Friend WithEvents Panel3 As Panel
    Friend WithEvents Label5 As Label
    Friend WithEvents Button1 As Button
    Friend WithEvents btn_installService As Button
    Friend WithEvents Button2 As Button
    Friend WithEvents lblScreenSizeRemote As Label
    Friend WithEvents Panel4 As Panel
    Friend WithEvents Label3 As Label
    Friend WithEvents Label1 As Label
    Friend WithEvents lbl_userMsg As Label
    Friend WithEvents tmr_lblmsg As Timer
    Friend WithEvents tmr_NumCapsLock As Timer
    Friend WithEvents btn_numlock_remote As Button
    Friend WithEvents btnReboot As Button
    Friend WithEvents btn_numlock_my As Button
    Friend WithEvents btn_Capslock_remote As Button
    Friend WithEvents Button3 As Button
End Class
