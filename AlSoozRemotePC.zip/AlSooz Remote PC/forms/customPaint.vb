﻿Imports System.Drawing.Drawing2D

Public Class customPaint
    Inherits Control

    Private mImg As Bitmap = Nothing

    Private mImgTiles As Bitmap = Nothing
    Private mTileBoxSize As Integer
    Private mTilesPoints() As Point = Nothing

    Private PnlDrawWidth_p As Integer = 0
    Private PnlDrawHeight_p As Integer = 0

    Private operation As Byte = 0

    Friend Overloads Sub Dispose()

        Dispose(True)
    End Sub
    Protected Overrides Sub Dispose(disposing As Boolean)
        MyBase.Dispose(disposing)
        Dispose_Images()

    End Sub

    Friend Sub Dispose_Images()
        Try

            If Not IsNothing(mImg) Then mImg.Dispose()
        Catch ex As Exception
        End Try
        Try
            If Not IsNothing(mImgTiles) Then mImgTiles.Dispose()
        Catch ex As Exception

        End Try
    End Sub
    Sub New()
        ' Me.DoubleBuffered = True

        SetStyle(ControlStyles.UserPaint, True)
        SetStyle(ControlStyles.OptimizedDoubleBuffer, False)
        SetStyle(ControlStyles.Opaque, True)

    End Sub

    Friend Sub clear()
        operation = 1
        Invalidate()
        'Update()
    End Sub


    Public Property TilesPoints As Point()
        Get
            Return mTilesPoints
        End Get
        Set
            mTilesPoints = Value
        End Set
    End Property

    Public Property TilesBoxSize As Integer
        Get
            Return mTileBoxSize
        End Get
        Set
            mTileBoxSize = Value
        End Set
    End Property

    Public Property ImageTiles As Image
        Get
            Return mImgTiles
        End Get
        Set

            If IsNothing(bmGraphics) Then Return

            Try
                Threading.Monitor.Enter(imgTilesLock)
                mImgTiles = Value
            Catch ex As Exception
            End Try

            Try
                Threading.Monitor.Exit(imgTilesLock)
            Catch ex As Exception
            End Try
            operation = 2
            BitmapPaint()
            Invalidate()


            'Update()
        End Set

    End Property

    Public Property Image1 As Image
        Get
            Return mImg
        End Get
        Set

            Try

                Try
                    Threading.Monitor.Enter(imgTilesLock)
                    mImg = Value
                    operation = 3
                    InitDrawFullImage()
                Catch ex As Exception
                End Try

                Try
                    Threading.Monitor.Exit(imgTilesLock)
                Catch ex As Exception
                End Try

                Invalidate()

                'Update()
            Catch ex As Exception

            End Try

        End Set
    End Property

    Private ss_GraphicsHandle As IntPtr
    Private ss_GraphicsDC As IntPtr = IntPtr.Zero
    Private ss_hBmp As IntPtr
    Private ss_hOldBmp As IntPtr
    Private bmGraphics As Graphics = Nothing

    Friend Sub InitDrawFullImage()
        Try


            If myApp.MyConn.connectionType = enum_ConnectType.WS OrElse lastImgHeight <> mImg.Height OrElse lastImgWidth <> mImg.Width Then
                destRect = New Rectangle(0, 0, mTileBoxSize, mTileBoxSize)
                srcRect = New Rectangle(0, 0, mTileBoxSize, mTileBoxSize)

                If Not IsNothing(bmGraphics) Then
                    DeleteDC(ss_GraphicsDC)
                    bmGraphics.Dispose()
                End If

                bmGraphics = Graphics.FromImage(mImg)

                ss_GraphicsHandle = bmGraphics.GetHdc()

                ss_GraphicsDC = CreateCompatibleDC(ss_GraphicsHandle)

                bmGraphics.ReleaseHdc(ss_GraphicsHandle)

                updateStrechSize()
            End If
        Catch ex As Exception

        End Try
    End Sub

    Private lastImgHeight As Integer = 0
    Private lastImgWidth As Integer = 0
    Friend Sub updateStrechSize()

        lastImgHeight = mImg.Height
        lastImgWidth = mImg.Width
        frmScreenControlObj.lblScreenSizeRemote.Text = "Size: " & lastImgWidth & " x " & lastImgHeight
        PnlDrawHeight_p = frmScreenControlObj.ImgDrawHeight
        PnlDrawWidth_p = frmScreenControlObj.ImgDrawWidth

        Dim ImgHeight As Integer = mImg.Height
        Dim ImgWidth As Integer = mImg.Width

        Dim ImgDrawRatio As Decimal = ImgWidth / ImgHeight

        If ImgWidth <> PnlDrawWidth_p OrElse ImgHeight <> PnlDrawHeight_p Then

            ImgWidth = PnlDrawHeight_p * ImgDrawRatio
            ImgHeight = ImgWidth / ImgDrawRatio
            If ImgWidth > PnlDrawWidth_p Then
                ImgHeight = PnlDrawWidth_p / ImgDrawRatio
                ImgWidth = ImgHeight * ImgDrawRatio
            End If

        End If

        PnlDrawHeight_p = ImgHeight
        PnlDrawWidth_p = ImgWidth

        Me.Height = PnlDrawHeight_p
        Me.Width = PnlDrawWidth_p
    End Sub

    Private destRect As Rectangle
    Private srcRect As Rectangle

    Private imgTilesLock As New Object()


    Protected Overrides Sub OnPaint(e As PaintEventArgs)

        If operation = 2 OrElse operation = 3 Then 'draw imagetiles on bitmap
                Try
                    Threading.Monitor.Enter(imgTilesLock)
                    e.Graphics.CompositingQuality = CompositingQuality.HighSpeed
                    e.Graphics.SmoothingMode = SmoothingMode.HighSpeed
                    e.Graphics.PixelOffsetMode = PixelOffsetMode.HighSpeed
                    'e.Graphics.InterpolationMode = InterpolationMode.HighQualityBicubic

                    e.Graphics.DrawImage(mImg, 0, 0, PnlDrawWidth_p, PnlDrawHeight_p)
                Catch ex As Exception
                End Try

                Try
                    Threading.Monitor.Exit(imgTilesLock)
                Catch ex As Exception
                End Try


            ElseIf operation = 1 Then  'clear and redraw background
                Try
                    Using brush As SolidBrush = New SolidBrush(Color.Gray)
                        e.Graphics.FillRectangle(brush, New Rectangle(0, 0, PnlDrawWidth_p, PnlDrawHeight_p))

                    End Using
                Catch ex As Exception
                End Try

            End If

    End Sub
    Private Sub BitmapPaint()

        If operation = 2 Then

            Try
                Threading.Monitor.Enter(imgTilesLock)
                Dim hBmp As IntPtr = mImgTiles.GetHbitmap()
                If IsNothing(mImgTiles) Then Return
                Dim len As Integer = mTilesPoints.Count - 1

                ss_GraphicsHandle = bmGraphics.GetHdc()


                Dim hOldBmp As IntPtr = SelectObject(ss_GraphicsDC, hBmp)

                For i As Integer = 0 To len

                    destRect.X = mTilesPoints(i).X * mTileBoxSize
                    destRect.Y = mTilesPoints(i).Y * mTileBoxSize
                    srcRect.Y = i * mTileBoxSize

                    BitBlt(ss_GraphicsHandle, destRect.X, destRect.Y, mTileBoxSize, mTileBoxSize, ss_GraphicsDC, 0, srcRect.Y, CopyPixelOperation.SourceCopy)

                Next

                SelectObject(ss_GraphicsDC, hOldBmp)
                DeleteObject(hBmp)
                DeleteObject(hOldBmp)

                bmGraphics.ReleaseHdc(ss_GraphicsHandle)

                mImgTiles.Dispose()

            Catch ex As Exception
            End Try
            Try
                Threading.Monitor.Exit(imgTilesLock)
            Catch ex As Exception
            End Try

            'For i As Integer = 0 To len

            '    destRect = New Rectangle(mTilesPoints(i).X * mTileBoxSize, mTilesPoints(i).Y * TilesBoxSize, TilesBoxSize, TilesBoxSize)
            '    srcRect = New Rectangle(0, i * mTileBoxSize, mTileBoxSize, mTileBoxSize)
            '    e.Graphics.DrawImage(mImgTiles, destRect, srcRect, GraphicsUnit.Pixel)

            'Next

        ElseIf operation = 3 Then

            '  Try

            'ss_GraphicsHandle = bmGraphics.GetHdc()
            'ss_GraphicsDC = CreateCompatibleDC(ss_GraphicsHandle)

            'ss_hBmp = mImg.GetHbitmap()

            'ss_hOldBmp = SelectObject(ss_GraphicsDC, ss_hBmp)

            'BitBlt(ss_GraphicsHandle, 0, 0, mImg.Width, mImg.Height, ss_GraphicsDC, 0, 0, CopyPixelOperation.SourceCopy)

            'SelectObject(ss_GraphicsDC, ss_hOldBmp)
            'DeleteObject(ss_hBmp)
            'DeleteObject(ss_hOldBmp)
            'DeleteDC(ss_GraphicsDC)
            'bmGraphics.ReleaseHdc(ss_GraphicsHandle)

            'mImg.Dispose()

            ' Catch ex As Exception
            ' End Try
            ' e.Graphics.DrawImage(mImg, 0, 0)

        ElseIf operation = 1 Then
            Try
                Using brush As SolidBrush = New SolidBrush(Color.Gray)
                    bmGraphics.FillRectangle(brush, New Rectangle(0, 0, Width, Height))

                End Using
            Catch ex As Exception
            End Try

        End If


        '  MyBase.OnPaint(e)
    End Sub



End Class
