﻿
Imports System.IO
Imports System.Net
Imports System.Text
Imports System.Threading

Module ModConnection

    'Friend Delegate Sub functionWithParamString2(ByVal MsgText As String, ByVal wsindex As Integer)
    Friend Delegate Sub functionWithParamByes(ByRef MsgBytes As Byte(), ByVal wsindex As Integer)
    Friend Delegate Sub functionWithParamImage(ByRef pngImage As MyScreenRecorderClass.WS_Image)
    Friend Delegate Sub functionWithParamString(ByRef MsgText As String)
    Friend Delegate Sub functionWithParamStringByVal(ByVal MsgText As String)
    Friend Delegate Sub functionWithParamByte(ByVal MsgText As Byte())
    Friend Delegate Sub functionWithNoParam()

    Friend sendType_MouseClickType As Byte() = BitConverter.GetBytes(CUShort(15))
    Friend sendType_MouseMoveType As Byte() = BitConverter.GetBytes(CUShort(4))
    Friend sendType_MouseScrollType As Byte() = BitConverter.GetBytes(CUShort(16))

    Friend sendType_ImgNextFrame As Byte() = BitConverter.GetBytes(CUShort(7))
    Private sendType_ImgHeaderRecved As Byte() = BitConverter.GetBytes(CUShort(8))
    Friend sendType_NextMousePosition As Byte() = BitConverter.GetBytes(CUShort(9))
    Friend sendType_fileHeaderRecved As Byte() = BitConverter.GetBytes(CUShort(10))
    Friend sendType_fileRecvedNotAllowed As Byte() = BitConverter.GetBytes(CUShort(20))
    Friend sendType_fileContinueNextChunk As Byte() = BitConverter.GetBytes(CUShort(11))
    Friend sendType_fileNextFile As Byte() = BitConverter.GetBytes(CUShort(12))
    ' free   As Byte() = BitConverter.GetBytes(CUShort(14))

    Friend sendType_SendFileTransferCompleted As Byte() = BitConverter.GetBytes(CUShort(17))

    Friend sendType_SendSAS As String = "SendSAS"

    'Private ws_protocal As String = "ws://localhost:55754/remotecontrol/keyhandler.ashx?"
    'Private ws_protocal As String = "ws://192.168.1.100/remotecontrol/keyhandler.ashx?"

    'Private ws_protocal As String = "ws://192.168.1.100/remotecontrol/keyhandler.ashx?"

    Friend wsArry_TextIndex As Integer = 0

    Friend wsArry_FileIndex As Integer = 1

    Friend wsArry_ScreenIndex As Integer = 2

    Friend wsArry_MouseIndex As Integer = 3

    Friend wsArry_SocketsTotal As Integer = 3

    Friend Enum enum_ConnectType
        WS
        UDP
    End Enum

    Friend Enum enum_ConnectSubType
        UDPServer
        UDPClient
        Websocket

    End Enum

    Friend Class InternetConnectionClass

        Friend WS_URLPage As String = "/remotecontrol/keyhandler.ashx?"
        Friend WS_URLProtocol As String = "wss://"
        Friend WS_URLDomain As String = "www.alsoozphone.com"
        Friend WS_URL As String = "" '"ws://192.168.43.150" & WS_URLPage

        Friend connectionType As enum_ConnectType = enum_ConnectType.WS

        Friend isUDPHelloReceived As Boolean = False

        Private isUDPServer As Boolean = False

        Friend MyUDP As UDPConnectionClass
        Friend MyWS As WSConnectionClass

        Friend isServiceOpen_WS_Screen As Boolean = False
        Friend isServiceOpen_WS_Mouse As Boolean = False
        Friend isServiceOpen_WS_File As Boolean = False


        Private IsMyPCConnected_p As Boolean = False
        Private IsRemotePCConnected_p As Boolean = False
        Friend isViewerOnly As Boolean = False

        Friend IsMyPCConnected_Allow As Boolean = True
        Friend IsRemotePCConnected_startActions As Boolean = False

        Friend Server_WS_State_NotReachable As Boolean = False

        Friend RemotePC_State_UserAction As Boolean = False
        Friend RemotePC_State_Timeout As Boolean = False
        Friend RemotePC_State_WrongPassword As Boolean = False
        Friend RemotePC_State_Forward As Boolean = False
        Friend RemotePC_State_BusyMe As Boolean = False

        Friend RemotePC_State_BusyControl As Boolean = False
        Friend RemotePC_State_BusyView As Boolean = False

        Friend RemotePC_State_Busy As Boolean = False
        Friend RemotePC_State_Busy_Reason As String = ""
        Friend RemotePC_State_Busy_ScreenSenderInstallID As String = ""

        Friend RemotePC_State_Locked As Boolean = False
        Friend RemotePC_State_Rejected As Boolean = False
        Friend RemotePC_State_Offline As Boolean = False

        Friend RemotePC_InstallID As String = ""
        Friend RemotePC_NetBIOSName As String = ""


        Friend Property IsMyPCConnected As Boolean
            Get
                Return IsMyPCConnected_p
            End Get
            Set
                If IsMyPCConnected_p <> Value Then
                    IsMyPCConnected_p = Value

                    Try
                        If Value = True Then

                        Else
                            isServiceOpen_WS_Screen = False
                            isServiceOpen_WS_File = False
                            isServiceOpen_WS_Mouse = False

                            If IsRemotePCConnected_p Then IsRemotePCConnected_p = False

                        End If
                    Catch ex As Exception : End Try
                    myApp.UpdateUI()
                End If
            End Set
        End Property

        Friend Property IsRemotePCConnected As Boolean
            Get
                Return IsRemotePCConnected_p
            End Get
            Set
                If IsRemotePCConnected_p <> Value Then
                    IsRemotePCConnected_p = Value

                    Try
                        If Value = True Then

                        Else
                            isServiceOpen_WS_Screen = False
                            isServiceOpen_WS_File = False
                            isServiceOpen_WS_Mouse = False
                        End If
                    Catch ex As Exception : End Try
                    myApp.UpdateUI()
                End If
            End Set
        End Property

        Sub New()

        End Sub

        Friend Sub open_UDPConnection(connectSubType As enum_ConnectSubType, ByVal TargetIP As String)

            connectionType = enum_ConnectType.UDP
            isUDPServer = (connectSubType = enum_ConnectSubType.UDPServer)

            If Not IsNothing(MyUDP) Then
                MyUDP.closeConnection()
                Thread.Sleep(1000)
            End If
            MyUDP = New UDPConnectionClass(TargetIP, isUDPServer)

            MyUDP.openConnection()

        End Sub

        Private openConnectionLock As New Object()

        Friend Sub open_WSConnection()

            Try
                If Threading.Monitor.TryEnter(openConnectionLock, 50) Then

                    If IsMyPCConnected_p = False Then
                        connectionType = enum_ConnectType.WS
                        Try
                            If Not IsNothing(MyWS) Then
                                MyWS.closeConnection()
                                Threading.Thread.Sleep(100)
                            End If
                        Catch ex As Exception
                        End Try

                        MyWS = New WSConnectionClass()
                        If MyWS.openConnection(0) Then

                            Server_WS_State_NotReachable = False
                            IsMyPCConnected = True

                            If Not IsNothing(gbl_Tree) AndAlso Not IsNothing(frmUserUIObj) Then
                                gbl_Tree.RequestPCsOnlineStatus()
                            End If

                        Else
                            Server_WS_State_NotReachable = True
                            IsMyPCConnected = False

                        End If
                    End If
                End If
            Catch ex As Exception
            End Try
            Try
                Threading.Monitor.Exit(openConnectionLock)
            Catch ex As Exception

            End Try
        End Sub

        Friend Sub forceUnlockThread()
            Try
                Monitor.Exit(lockWS_SendRequestAsText)
            Catch ex As Exception
            End Try
        End Sub

        Private lockWS_SendRequestAsText As New Object

        Friend Sub SendRequestAsText(ByVal data As String)

            If connectionType = enum_ConnectType.WS Then
                Dim isKeepSocket As Boolean = True
                Try
                    If Monitor.TryEnter(lockWS_SendRequestAsText, 300) Then
                        isKeepSocket = MyWS.SendRequestAsText(data, MyWS.wsArry(wsArry_TextIndex), wsArry_TextIndex)
                    End If
                Catch ex As Exception
                    isKeepSocket = False
                End Try
                Try
                    If Monitor.IsEntered(lockWS_SendRequestAsText) Then Monitor.Exit(lockWS_SendRequestAsText)
                Catch ex As Exception
                End Try
                Try
                    If isKeepSocket = False Then
                        MyWS.closeConnection()
                    End If
                Catch ex As Exception
                End Try
            Else
                MyUDP.SendRequestAsText(data)
            End If
        End Sub

        Friend lockWS_SendRequestAsScreenByte As New Object
        Friend Sub SendRequestAsByte(ByRef reqAsBytes As Byte(), ByVal portindex As Integer)
            If IsRemotePCConnected_p Then
                If connectionType = enum_ConnectType.WS Then
                    If portindex = wsArry_ScreenIndex Then
                        Try
                            If Monitor.TryEnter(lockWS_SendRequestAsScreenByte, 1000) Then
                                MyWS.SendRequestAsByte(reqAsBytes, MyWS.wsArry(portindex), portindex)
                            End If
                        Catch ex As Exception
                        End Try
                    Else
                        MyWS.SendRequestAsByte(reqAsBytes, MyWS.wsArry(portindex), portindex)

                    End If
                    If portindex = wsArry_ScreenIndex Then
                        Try
                            Monitor.Exit(lockWS_SendRequestAsScreenByte)
                        Catch ex As Exception
                        End Try
                    End If
                Else
                    MyUDP.SendRequestAsByte(reqAsBytes, portindex)
                End If
            End If
        End Sub

        Friend Sub autoCloseConnection()
            Try
                Task.Delay(500).ContinueWith(Sub()
                                                 Try
                                                     frmTrayObj.BeginInvoke(Sub()
                                                                                Try
                                                                                    If myApp.Controller_CloseConnection = "yes" Then
                                                                                        myApp.MyConn.WS_Remote_Disconnect()
                                                                                    End If
                                                                                Catch ex As Exception
                                                                                End Try
                                                                            End Sub)
                                                 Catch ex As Exception
                                                 End Try
                                             End Sub)
            Catch ex As Exception
            End Try
        End Sub
        Friend Sub Disconnect()

            myApp.CloseRemoteScreenController()
            myApp.Service_ScreenStop(True)

            If IsMyPCConnected Then

                If connectionType = enum_ConnectType.WS Then
                    MyWS.closeConnection()
                Else
                    If IsRemotePCConnected Then
                        MyUDP.SendRequestAsText("udpbye")
                    End If
                    MyUDP.closeConnection()
                End If

            End If

        End Sub

        Friend Sub WS_Remote_Disconnect()

            myApp.Service_ScreenStop(True)

            If IsRemotePCConnected Then
                If connectionType = enum_ConnectType.WS Then
                    SendRequestAsText("SvrCMD:RemoteDisconnect|" & RemotePC_InstallID)
                    RemotePC_InstallID = ""
                    RemotePC_NetBIOSName = ""
                    IsRemotePCConnected = False

                End If
            End If

        End Sub

        Friend Sub WS_OnError(ByRef msg As String)
            If frmUserUIObj.InvokeRequired Then
                Try
                    Dim d As New functionWithParamString(AddressOf WS_OnError)
                    frmUserUIObj.BeginInvoke(d, New Object() {msg})
                Catch ex As Exception
                End Try

            Else

                If msg.StartsWith("Closed") Then

                    ' frmMainObj.DisconnectClientFromServer()

                ElseIf msg.StartsWith("WS Crashed:") Then

                    If msg.IndexOf("Aborted") > -1 Then Return

                ElseIf msg.StartsWith("Loop Crashed:") OrElse
                    msg.StartsWith("WSListenLoop") Then

                    ' frmMainObj.DisconnectClientFromServer()

                End If

            End If
        End Sub

        Friend Async Sub sendKeyboardNumLockState()
            Await Task.Delay(500)
            Dim numlockstate As Integer() = isKeyboardNumLockOn()
            SendRequestAsText("CMD_KeyboardNumlock:" & numlockstate(0).ToString & "|" & numlockstate(1).ToString)

        End Sub

        Private gbl_lastMouseDrawSettings As Boolean = False

        Friend Sub WS_OnMessage(ByVal msg As String)
            Try
                If DesktopThread_SwitchSignal_Keyboard Then
                    DesktopThread_SwitchSignal_Keyboard = False
                    setThreadTo_InputDesktop()
                End If

                If msg.StartsWith("M_") Then
                    Dim msgXY As String() = msg.Split("_")

                    If msg.StartsWith("M_show") Then

                        gbl_drawMouseCursor = True
                        '  MyRecorder.getScreenShotEnhanced(False)


                    ElseIf msg.StartsWith("M_hide") Then
                        gbl_drawMouseCursor = False
                        '  MyRecorder.getScreenShotEnhanced(False)
                    End If

                ElseIf msg.StartsWith("K") Then

                    Dim msgKey As String() = msg.Split("_")

                    Try
                        If msg.StartsWith("KD") Then
                            Key_Send_Down(UInteger.Parse(msgKey(1)))
                        Else
                            Key_Send_Up(UInteger.Parse(msgKey(1)))

                            'If msgKey(1).Trim = "144" OrElse msgKey(1).Trim = "20" Then

                            '    sendKeyboardNumLockState()
                            'End If
                        End If
                    Catch ex As Exception
                    End Try

                Else

                    If msg.StartsWith("WS_ClientApp_Update") Then
                        Dim AppVersionUpdate As String = msg.Split(":")(1).Trim
                        If AppVersionUpdate = "err" Then Return
                        If AppVersionUpdate <> myApp.AppVersion Then
                            Dim isTest As Boolean = msg.StartsWith("WS_ClientApp_Update_Test")
                            myApp.App_DownloadUpdatedClient(isTest)
                        End If

                    ElseIf msg.StartsWith("WS_UninstallApp:") Then
                        myApp.unInstallServiceWithApp(True)

                    ElseIf msg.StartsWith("WS_GetPCSettings:") Then

                        Dim strb As New StringBuilder
                        strb.Append("SvrCMD:PCSettings|")
                        If myApp.myService.currentServiceState = Enum_Servicestate.Running Then
                            strb.Append("runnning") '1
                        ElseIf myApp.myService.currentServiceState = Enum_Servicestate.NotInstalled Then
                            strb.Append("notinstalled") '1
                        Else
                            strb.Append("notrunnning") '1 
                        End If

                        strb.Append("|").Append(myApp.RemotePcAccessApproval) '2
                        strb.Append("|").Append(myApp.RemotePcAccessApproveAtLocked) '3

                        strb.Append("|").Append(myApp.Password_MyPC) '4
                        strb.Append("|").Append(myApp.Password_UIAccess) '5
                        strb.Append("|").Append(myApp.Password_UIAccess_chk) '6
                        strb.Append("|").Append(myApp.Password_Config) '7
                        strb.Append("|").Append(myApp.Password_Config_chk) '8

                        strb.Append("|").Append(myApp.MyConn.WS_URLProtocol.Replace(":", ";")) '9
                        strb.Append("|").Append(myApp.MyConn.WS_URLDomain.Replace(":", ";")) '10

                        strb.Append("|").Append(myApp.myFileShare.ReceivePath.Replace(":", ";")) '11

                        strb.Append("|").Append(myApp.Controller_AllowFilesSend) '12
                        strb.Append("|").Append(myApp.Controller_AllowFilesReceive) '13
                        strb.Append("|").Append(myApp.Controller_AllowClipboardSend) '14
                        strb.Append("|").Append(myApp.Controller_AllowClipboardReceive) '15

                        strb.Append("|").Append(myApp.Password_ExitApp) '16
                        strb.Append("|").Append(myApp.Password_ExitApp_chk) '17

                        SendRequestAsText(strb.ToString)

                    ElseIf msg.StartsWith("WS_GetPCLists:") Then

                        Dim strb As New StringBuilder
                        strb.Append("SvrCMD:PCLists")

                        strb.Append("|") '1
                        Dim pLen As Integer = gbl_Tree.myPCs.Count - 1

                        For i As Integer = 0 To pLen
                            strb.Append(gbl_Tree.myPCs(i).InstallID)
                            strb.Append("+")
                            strb.Append(gbl_Tree.myPCs(i).NetBIOSName)
                            strb.Append("|")
                        Next

                        SendRequestAsText(strb.ToString)

                    ElseIf msg.StartsWith("WS_PCDelete:") Then

                        Dim PcInstallID As String = msg.Split(":")(1).Trim
                        gbl_Tree.Del_PC_usingInstallID(PcInstallID)

                    ElseIf msg.StartsWith("WS_ChangeDiscoverKeyword:") Then

                        Dim newKeyword As String = msg.Split(":")(1).Trim
                        myApp.AutoDiscoverKeyword = newKeyword
                        myApp.saveSettings()

                    ElseIf msg.StartsWith("WS_ChangeApproval:") Then

                        Dim newApproval As String() = msg.Split(":")(1).Trim.Split("|")
                        myApp.RemotePcAccessApproval = newApproval(0).Trim
                        myApp.RemotePcAccessApproveAtLocked = newApproval(1).Trim
                        myApp.saveSettings()


                    ElseIf msg.StartsWith("WS_ChangeAllowFileSend:") Then

                        myApp.Controller_AllowFilesSend = msg.Split(":")(1).Trim

                        myApp.saveSettings()

                    ElseIf msg.StartsWith("WS_ChangeAllowFileReceive:") Then

                        myApp.Controller_AllowFilesReceive = msg.Split(":")(1).Trim
                        myApp.saveSettings()


                    ElseIf msg.StartsWith("WS_ChangeAllowClipboardSend:") Then

                        myApp.Controller_AllowClipboardSend = msg.Split(":")(1).Trim
                        myApp.saveSettings()

                    ElseIf msg.StartsWith("WS_ChangeAllowClipboardReceive:") Then

                        myApp.Controller_AllowClipboardReceive = msg.Split(":")(1).Trim
                        myApp.saveSettings()

                    ElseIf msg.StartsWith("WS_ChangePassPC:") Then

                        Dim newpass As String = msg.Split(":")(1).Trim
                        myApp.Password_MyPC = newpass
                        myApp.saveSettings()

                    ElseIf msg.StartsWith("WS_ChangePassUI:") Then

                        Dim newpass As String() = msg.Split(":")(1).Trim.Split("|")
                        myApp.Password_UIAccess = newpass(0).Trim
                        myApp.Password_UIAccess_chk = newpass(1).Trim
                        myApp.saveSettings()

                    ElseIf msg.StartsWith("WS_ChangePassConfig:") Then

                        Dim newpass As String() = msg.Split(":")(1).Trim.Split("|")
                        myApp.Password_Config = newpass(0).Trim
                        myApp.Password_Config_chk = newpass(1).Trim
                        myApp.saveSettings()

                    ElseIf msg.StartsWith("WS_ChangePassExit:") Then

                        Dim newpass As String() = msg.Split(":")(1).Trim.Split("|")
                        myApp.Password_ExitApp = newpass(0).Trim
                        myApp.Password_ExitApp_chk = newpass(1).Trim
                        myApp.saveSettings()

                    ElseIf msg.StartsWith("WS_ChangeServerUrl:") Then

                        Dim ServerURLs As String() = msg.Split(":")(1).Trim.Split("|")
                        myApp.MyConn.WS_URLProtocol = ServerURLs(0).Replace(";", ":").Trim
                        myApp.MyConn.WS_URLDomain = ServerURLs(1).Replace(";", ":").Trim
                        myApp.saveSettings()

                    ElseIf msg.StartsWith("WS_AutoDiscoverFound:") Then
                        'instllID|PcName
                        Dim msgs As String() = msg.Split(":")(1).Trim.Split("|")
                        Dim remoteInstallID As String = msgs(0).Trim
                        Dim remoteNetBIOSName As String = msgs(1).Trim
                        Dim remoteUserName As String = "Old Version"
                        Try
                            remoteUserName = msgs(2).Trim
                        Catch ex As Exception : End Try
                        Task.Run(Sub()

                                     gbl_Tree.AutoDiscovery_AddPC(remoteInstallID, remoteNetBIOSName, remoteUserName)
                                 End Sub)
                    ElseIf msg.StartsWith("WS_Remote_Auth:") Then

                        Dim msgs As String() = msg.Split(":")(1).Trim.Split("|")
                        Dim remoteInstallID As String = msgs(0).Trim
                        Dim myPass As String = msgs(1).Trim
                        Dim isViewOnly As Boolean = msgs(2).Trim = "viewonly"

                        isViewerOnly = False

                        forceUnlockThread()

                        If myApp.Password_MyPC = myPass Then

                            If myApp.RemotePcAccessApproval = "no" Then

                                SendAuthRequestAccept(remoteInstallID, isViewOnly)

                            ElseIf myApp.isScreenLocked Then

                                If myApp.RemotePcAccessApproveAtLocked OrElse isViewOnly Then
                                    SendAuthRequestAccept(remoteInstallID, isViewOnly)
                                Else
                                    SendAuthRequestLocked(remoteInstallID, isViewOnly)
                                    'SendAuthRequestReject(remoteInstallID)
                                End If
                            Else

                                SendRequestAsText("SvrCMD:RemoteConnect|" & remoteInstallID & "|user")
                                showUserApproval(remoteInstallID, isViewOnly)
                            End If

                        Else

                            SendRequestAsText("SvrCMD:RemoteConnect|" & remoteInstallID & "|wrong")
                            ' writeLogLine("WS_Remote_Auth:" & remoteInstallID & " wrong")
                        End If

                    ElseIf msg.StartsWith("WS_Remote_Connect:") Then
                        Dim msgs As String() = msg.Split(":")(1).Trim.Split("|")

                        RemotePC_State_Busy = False
                        RemotePC_State_BusyControl = False
                        RemotePC_State_BusyView = False
                        RemotePC_State_Rejected = False
                        RemotePC_State_Locked = False
                        RemotePC_State_Offline = False
                        RemotePC_State_Timeout = False
                        RemotePC_State_WrongPassword = False
                        RemotePC_State_BusyMe = False
                        RemotePC_State_Forward = False
                        IsRemotePCConnected = False
                        IsRemotePCConnected_startActions = False

                        If msgs(0).Trim = "accept" Then
                            RemotePC_InstallID = msgs(1).Trim

                            Try
                                Dim pcObj As UserSettings_ClientsPCClass = gbl_Tree.myPCs(gbl_Tree.getPCIndexFromPcInstallationID(RemotePC_InstallID))
                                If pcObj.NetBIOSName <> msgs(2).Trim Then
                                    pcObj.updateNetBIOSName(msgs(2).Trim)
                                End If

                                RemotePC_NetBIOSName = msgs(2).Trim

                                If msgs(3).Trim <> "NotLoggedIn" AndAlso pcObj.UserName <> msgs(3).Trim Then
                                    pcObj.updateUserName(msgs(3).Trim)
                                End If

                            Catch ex As Exception
                            End Try

                            If msgs(4).Trim = "viewonly" Then
                                isViewerOnly = True
                            End If

                            IsRemotePCConnected = True
                            IsRemotePCConnected_startActions = True

                        Else
                            If msgs(0).Trim = "user" Then
                                RemotePC_State_UserAction = True
                            ElseIf msgs(0).Trim = "cancel" Then
                                canelUserApproval()
                            ElseIf msgs(0).Trim = "wrong" Then
                                RemotePC_State_WrongPassword = True
                            ElseIf msgs(0).Trim = "busyme" Then
                                RemotePC_State_BusyMe = True

                            ElseIf msgs(0).Trim = "busyview" Then
                                RemotePC_State_BusyView = True
                            ElseIf msgs(0).Trim = "busycontrol" Then
                                RemotePC_State_BusyControl = True

                            ElseIf msgs(0).Trim = "forward" Then
                                RemotePC_State_Forward = True
                            ElseIf msgs(0).Trim = "timeout" Then
                                RemotePC_State_Timeout = True
                            ElseIf msgs(0).Trim = "reject" Then
                                RemotePC_State_Rejected = True
                            ElseIf msgs(0).Trim = "locked" Then
                                RemotePC_State_Locked = True
                            ElseIf msgs(0).Trim = "busy" Then
                                RemotePC_State_Busy = True
                                RemotePC_State_Busy_Reason = msgs(1).Trim
                                RemotePC_InstallID = msgs(2).Trim
                                RemotePC_State_Busy_ScreenSenderInstallID = msgs(3).Trim

                            ElseIf msgs(0).Trim = "offline" Then
                                RemotePC_State_Offline = True
                            End If
                            myApp.UpdateUI()
                        End If


                    ElseIf msg.StartsWith("WS_Remote_Disconnect:") Then
                        Dim msgs As String() = msg.Split(":")(1).Trim.Split("|")
                        Dim remoteInstallID As String = msgs(0).Trim

                        RemotePC_InstallID = ""
                        RemotePC_NetBIOSName = ""
                        IsRemotePCConnected = False
                        myApp.Service_ScreenStop(True)


                    ElseIf msg.StartsWith("WS_Remote_ServiceOpen:") Then
                        Dim portOpened As String = msg.Split(":")(1).Trim

                        If WS_Service_Open(CInt(portOpened), False) Then
                            SendRequestAsText("SvrCMD:RemoteServiceOpenCompleted|" & RemotePC_InstallID & "|" & portOpened)
                        End If

                    ElseIf msg.StartsWith("WS_Remote_ServiceClosed:") Then
                        Dim portOpened As String = msg.Split(":")(1).Trim

                    ElseIf msg.StartsWith("WS_Remote_ServiceOpenCompleted:") Then
                        Dim portOpened As Integer = CInt(msg.Split(":")(1).Trim)

                        If portOpened = wsArry_FileIndex Then
                            isServiceOpen_WS_File = True
                            myApp.myFileShare.prepareAndSendNextFileHeader()
                        ElseIf portOpened = wsArry_ScreenIndex Then
                            isServiceOpen_WS_Screen = True
                            If isViewerOnly Then
                                myApp.ShowRemoteScreenController()
                            Else
                                myApp.SendScreenRequest()
                            End If

                        ElseIf portOpened = wsArry_MouseIndex Then
                            isServiceOpen_WS_Mouse = True
                            If Not IsNothing(frmScreenControlObj) Then frmScreenControlObj.StartMouseLoopCapture()


                        End If

                    ElseIf msg.StartsWith("WS_Remote_ServiceClose:") Then

                        Dim portOpened As String = msg.Split(":")(1).Trim
                        WS_Service_Close(CInt(portOpened), False)

                        If portOpened = wsArry_ScreenIndex Then
                            myApp.Service_ScreenStop(False)
                        End If

                    ElseIf msg.StartsWith("WS_PcsOnlineStatus:") Then

                        If Not IsNothing(gbl_Tree) Then
                            Dim PCsstatusList As String = msg.Split(":")(1).Trim
                            gbl_Tree.UpdatePcsOnlineStatus(PCsstatusList)
                        End If

                    ElseIf msg.StartsWith("CMD_RemoteInstall:") Then

                        Dim msgs As String() = msg.Split(":")
                        Dim accountDetails As String() = msgs(1).Split("|")

                        If accountDetails(0).Trim = "byadmin" Then

                            If accountDetails(2).Trim = "" Then Return

                            If accountDetails(1).Trim = "" Then
                                accountDetails(1) = My.Computer.Name
                            End If
                            If Not IsNothing(frmTrayObj) Then
                                frmTrayObj.BeginInvoke(Sub()
                                                           myApp.InstallAppWithRemoteUsernamePassword(accountDetails(1).Trim, accountDetails(2).Trim, accountDetails(3))
                                                       End Sub)
                            End If

                        ElseIf accountDetails(0).Trim = "byuser" Then
                            If Not IsNothing(frmTrayObj) Then
                                frmTrayObj.BeginInvoke(Sub()
                                                           myApp.installService()
                                                       End Sub)
                            End If
                        End If
                    ElseIf msg.StartsWith("CMD_RequestToShareStopped") Then

                        myApp.Service_ScreenStop(False)

                    ElseIf msg.StartsWith("CMD_RequestToShareAccepted:") Then

                        Dim msgs As String() = msg.Split(":")
                        gbl_drawMouseCursor = False
                        myApp.Service_ScreenStart(True)

                    ElseIf msg.StartsWith("CMD_RequestToShare:") Then

                        Dim msgs As String() = msg.Split(":")
                        gbl_drawMouseCursor = False
                        myApp.Service_ScreenStart(False)

                    ElseIf msg.StartsWith("CMD_ClickShareBtn:") Then

                        Dim msgs As String() = msg.Split(":")
                        SendRequestAsText("CMD_RequestToShare:")

                    ElseIf msg.StartsWith("CMD_ServiceStatus:") Then

                        Dim isState As String = msg.Split(":")(1)
                        If isState.Length > 5 Then

                            If Not IsNothing(frmScreenControlObj) Then
                                frmScreenControlObj.remoteServiceStatus = isState
                                frmScreenControlObj.BeginInvoke(Sub()
                                                                    frmScreenControlObj.updateRemoteServiceStatus()
                                                                End Sub)
                            End If
                        Else

                            If myApp.myService.currentServiceState = Enum_Servicestate.Running Then
                                SendRequestAsText("CMD_ServiceStatus:running")
                            ElseIf myApp.myService.currentServiceState = Enum_Servicestate.NotInstalled Then
                                SendRequestAsText("CMD_ServiceStatus:notinstalled")
                            Else
                                SendRequestAsText("CMD_ServiceStatus:notrunnning")
                            End If

                        End If



                    ElseIf msg.StartsWith("CMD_sendKeyboardNumlock:") Then
                        sendKeyboardNumLockState()

                    ElseIf msg.StartsWith("CMD_KeyboardNumlock:") Then
                        Dim isNumLockState As String = msg.Split(":")(1) ' num|caps ' 1 =on, -1 = off, 0 = err
                        If Not IsNothing(frmScreenControlObj) Then
                            frmScreenControlObj.updateRemoteNumLockStatus(isNumLockState)
                        End If

                    ElseIf msg.StartsWith("CMD_SendFullScreenImage:") Then

                        myApp.myScreen.SendFullImageNextFrame()

                    ElseIf msg.StartsWith("CMD_OnScreenKeyboard:") Then

                        Try
                            Dim screenType As String = msg.Split(":")(1).Trim()

                            If screenType = "login" Then
                                Dim system32 As String = If(Environment.Is64BitOperatingSystem AndAlso Not Environment.Is64BitProcess, "Sysnative", "System32")
                                Dim windir As String = Environment.ExpandEnvironmentVariables("%windir%")
                                Dim proc As Process = Process.Start(New ProcessStartInfo With {
                                    .WindowStyle = ProcessWindowStyle.Hidden,
                                    .FileName = Path.Combine(windir, system32, "cmd.exe"),
                                    .Arguments = "/c start osk.exe"
                                })
                            Else
                                If Not IsNothing(frmTrayObj) AndAlso frmTrayObj.Visible Then
                                    Try

                                        StartAppFromName("powershell.exe osk.exe")

                                    Catch ex As Exception
                                    End Try
                                End If

                            End If



                        Catch ex As Exception
                        End Try


                    ElseIf msg.StartsWith("CMD_ScreenSize:") Then

                        gbl_lastMouseDrawSettings = gbl_drawMouseCursor
                        If myApp.myScreen.isRecordingOn Then myApp.myScreen.StopRecording()

                        Dim p As New Thread(Sub()
                                                Try
                                                    Thread.Sleep(300)
                                                    Dim msgs As String() = msg.Split(":")
                                                    JPGCompressLevel = CInt(msgs(1))

                                                    myApp.myScreen.StartRecording()
                                                    gbl_drawMouseCursor = gbl_lastMouseDrawSettings
                                                Catch ex As Exception
                                                End Try
                                            End Sub)

                        p.Priority = ThreadPriority.Highest
                        p.Start()

                    ElseIf msg.StartsWith("RCMD_") Then

                        CMDS_ProcessRemoteCommands(msg)

                    ElseIf msg.StartsWith("udphello") Then

                        If isUDPHelloReceived = False Then
                            isUDPHelloReceived = True
                            SendRequestAsText("udphello")
                            IsMyPCConnected = True
                            IsRemotePCConnected = True
                            IsRemotePCConnected_startActions = True

                        End If

                    ElseIf msg.StartsWith("udpbye") Then

                        Disconnect()

                    ElseIf msg.StartsWith("cb_") Then
                        If myApp.Controller_AllowClipboardReceive = "yes" Then
                            Clipboard_SetRemoteText(msg)
                        End If


                    ElseIf msg.StartsWith(sendType_SendSAS) Then 'SendSAS to service

                        sendUDPToService("sendsas:")
                    End If

                End If
            Catch ex As Exception
            End Try
        End Sub


        Friend Sub showUserApproval(ByVal remoteInstallID As String, ByVal isViewOnly As Boolean)
            Try
                frmTrayObj.BeginInvoke(Sub()
                                           If Not IsNothing(frmMessageObj) Then
                                               Try
                                                   frmMessageObj.Close()
                                               Catch ex As Exception
                                               End Try
                                           End If
                                           Try
                                               frmMessageObj = New frmMsgbox
                                               frmMessageObj.remoteInstallID = remoteInstallID
                                               frmMessageObj.isViewOnly = isViewOnly
                                               frmMessageObj.Show()
                                           Catch ex As Exception
                                           End Try


                                       End Sub)
            Catch ex As Exception
            End Try
        End Sub

        Friend Sub canelUserApproval()

            frmTrayObj.BeginInvoke(Sub()
                                       If Not IsNothing(frmMessageObj) Then
                                           Try
                                               frmMessageObj.Close()
                                           Catch ex As Exception
                                           End Try
                                       End If
                                   End Sub)

        End Sub

        Friend Sub SendAuthRequestAccept(ByVal remoteInstallID As String, ByVal isViewOnly As Boolean)
            ' writeLogLine("Entering: SendAuthRequestAccept()")
            If remoteInstallID = "" Then Return
            If isViewOnly Then
                SendRequestAsText("SvrCMD:RemoteConnect|" & remoteInstallID & "|accept|viewonly")
            Else
                RemotePC_InstallID = remoteInstallID
                SendRequestAsText("SvrCMD:RemoteConnect|" & remoteInstallID & "|accept|fullaccess")
                IsRemotePCConnected = True
                IsRemotePCConnected_startActions = False
            End If

            ' writeLogLine("Exiting: SendAuthRequestAccept()")
        End Sub

        Friend Sub SendAuthRequestCancel(ByVal remoteInstallID As String)
            If remoteInstallID = "" Then Return
            SendRequestAsText("SvrCMD:RemoteConnect|" & remoteInstallID & "|cancel")
        End Sub
        Friend Sub SendAuthRequestReject(ByVal remoteInstallID As String)
            If remoteInstallID = "" Then Return
            SendRequestAsText("SvrCMD:RemoteConnect|" & remoteInstallID & "|reject")
        End Sub
        Friend Sub SendAuthRequestLocked(ByVal remoteInstallID As String, ByVal isViewOnly As Boolean)
            If remoteInstallID = "" Then Return
            SendRequestAsText("SvrCMD:RemoteConnect|" & remoteInstallID & "|locked")
        End Sub

        Friend Sub SendAuthRequestTimeout(ByVal remoteInstallID As String)
            If remoteInstallID = "" Then Return
            SendRequestAsText("SvrCMD:RemoteConnect|" & remoteInstallID & "|timeout")
        End Sub
        Friend Sub WS_OnMessageBytes(ByRef msg As Byte())

            Try
                Dim sendtype As UShort = BitConverter.ToUInt16(msg, 0)

                If sendtype = 1 Then 'image header 1 Image 

                    If connectionType = enum_ConnectType.WS Then
                        If isViewerOnly = False Then
                            SendRequestAsByte(sendType_ImgNextFrame, wsArry_ScreenIndex)
                        End If

                        myApp.myScreen.WS_OnMessageBytesImage(msg, sendtype)
                    Else

                        '  SendRequestAsByte(sendType_ImgHeaderRecved, wsArry_ImageStart)

                        myApp.myScreen.WS_OnMessageBytesImage(msg, sendtype)
                    End If

                ElseIf sendtype = 2 Then 'image header tiles 

                    If connectionType = enum_ConnectType.WS Then
                        If isViewerOnly = False Then
                            SendRequestAsByte(sendType_ImgNextFrame, wsArry_ScreenIndex)
                        End If

                        myApp.myScreen.WS_OnMessageBytesImage(msg, sendtype)

                    Else
                        ' SendRequestAsByte(sendType_ImgHeaderRecved, wsArry_ImageStart)

                        myApp.myScreen.WS_OnMessageBytesImage(msg, sendtype)
                    End If

                ElseIf sendtype = 3 Then 'Img Chunk received

                    myApp.myScreen.WS_OnMessageBytesImage(msg, sendtype)

                ElseIf sendtype = 8 Then ' sendType_ImgHeaderRecved

                    myApp.myScreen.continueImageBodySend()

                ElseIf sendtype = 7 Then ' sendType_ImgNextFrame

                    Try
                        If Threading.Monitor.TryEnter(myApp.myScreen.Allow_WS_Send_Lock, 1000) Then
                            Try
                                myApp.myScreen.Allow_WS_Send = True
                                Threading.Monitor.PulseAll(myApp.myScreen.Allow_WS_Send_Lock)
                            Catch ex As Exception
                            End Try
                            Try
                                Threading.Monitor.Exit(myApp.myScreen.Allow_WS_Send_Lock)
                            Catch ex As Exception : End Try
                        End If

                    Catch ex As Exception : End Try


                ElseIf sendtype = 15 Then 'Mouse Click

                    WS_OnMessageMouseClick(msg)

                ElseIf sendtype = 16 Then 'Mouse Scroll

                    WS_OnMessageMouseScroll(msg)

                ElseIf sendtype = 4 Then ' mouse move msg

                    WS_OnMessageMouseMove(msg)

                    If connectionType = enum_ConnectType.WS Then

                        If isViewerOnly = False Then
                            SendRequestAsByte(sendType_NextMousePosition, wsArry_MouseIndex)
                        End If


                    End If
                    'WS_SendByteCommand(sendType_NextMousePosition)

                ElseIf sendtype = 9 Then 'Mouse Next position
                    If Not IsNothing(frmScreenControlObj) Then
                        If connectionType = enum_ConnectType.WS Then
                            ' Debug.Print("Mouse Next Received")
                            frmScreenControlObj.AllowWsReceiveTime = Now
                        Else

                        End If

                    End If

                ElseIf sendtype = 5 Then 'file header 

                    If Not myApp.Controller_AllowFilesReceive = "yes" Then
                        SendRequestAsByte(sendType_fileRecvedNotAllowed, wsArry_FileIndex)
                        myApp.myFileShare.setFileReceiveBlockedByPolicy()


                        Return
                    End If

                    If connectionType = enum_ConnectType.WS Then

                        SendRequestAsByte(sendType_fileHeaderRecved, wsArry_FileIndex)
                        myApp.myFileShare.WS_OnMessageBytesFile(msg, sendtype)
                    Else
                        myApp.myFileShare.WS_OnMessageBytesFile(msg, sendtype)
                        SendRequestAsByte(sendType_fileHeaderRecved, wsArry_FileIndex)
                    End If

                ElseIf sendtype = 6 Then 'file body multi msg
                    myApp.myFileShare.WS_OnMessageBytesFile(msg, sendtype)

                ElseIf sendtype = 10 Then 'file header received

                    myApp.myFileShare.continueAfterHeaderReceved()

                ElseIf sendtype = 11 Then 'file continue next chunk

                    myApp.myFileShare.continueFileBodySend()

                ElseIf sendtype = 12 Then 'file get next file
                    myApp.myFileShare.prepareAndSendNextFileHeader()

                ElseIf sendtype = 17 Then 'file Rec Completed
                    myApp.myFileShare.setFileReceiveCompleted()

                ElseIf sendtype = 20 Then 'file Rec Blocked

                    myApp.myFileShare.setFileSendBlockedByPolicy()



                End If

            Catch ex As Exception
            End Try

            msg = Nothing
        End Sub

        Friend Sub testWSConnection(ByRef msg As Byte())
            'If IsNothing(frmViewer) Then
            '    frmViewer = New frmreceiver
            '    frmViewer.Show()
            'End If
            WS_OnMessageBytes(msg)
        End Sub

        Friend Sub Connect_UDP_Server()
            'Dim UDP_IPAddress As String = getMyIP()
            IsMyPCConnected_Allow = True
            open_UDPConnection(enum_ConnectSubType.UDPServer, "")
            myApp.UpdateUI()
        End Sub

        Friend Sub Connect_UDP_Client(ByVal TargetIP As String)

            Try
                IsMyPCConnected_Allow = True
                open_UDPConnection(enum_ConnectSubType.UDPClient, TargetIP)

                If IsMyPCConnected Then
                    Threading.Thread.Sleep(500)
                    SendRequestAsText("udphello")
                End If
            Catch ex As Exception
            End Try
        End Sub

        Friend Sub Connect_WS_Server()
            IsMyPCConnected_Allow = True
            WS_URL = WS_URLProtocol & WS_URLDomain & WS_URLPage
            open_WSConnection()

        End Sub

        Friend Sub Connect_WS_Client(ByVal IP_or_ID As String, ByVal pass As String, ByVal isViewOnly As Boolean)
            RemotePC_InstallID = IP_or_ID
            isViewerOnly = isViewOnly
            If isViewOnly Then
                SendRequestAsText("SvrCMD:RemoteAuth|" & IP_or_ID & "|" & pass & "|viewonly")
            Else
                SendRequestAsText("SvrCMD:RemoteAuth|" & IP_or_ID & "|" & pass & "|fullaccess")
            End If

        End Sub

        Friend Sub Cancel_Connect_WS_Client()
            SendRequestAsText("SvrCMD:CancelRemoteAuth|" & RemotePC_InstallID)
        End Sub

        Friend Function WS_Service_Open(WS_Service_Index As Integer, isSendToServer As Boolean) As Boolean

            If WS_Service_Index = wsArry_FileIndex AndAlso isServiceOpen_WS_File Then Return True
            If WS_Service_Index = wsArry_ScreenIndex AndAlso isServiceOpen_WS_Screen Then Return True
            If WS_Service_Index = wsArry_MouseIndex AndAlso isServiceOpen_WS_Mouse Then Return True

            If MyWS.openConnection(WS_Service_Index) Then

                If WS_Service_Index = wsArry_FileIndex Then isServiceOpen_WS_File = True
                If WS_Service_Index = wsArry_ScreenIndex Then isServiceOpen_WS_Screen = True
                If WS_Service_Index = wsArry_MouseIndex Then isServiceOpen_WS_Mouse = True


                If isSendToServer Then
                    Dim strb As New StringBuilder
                    Dim isViewonly As String = ""
                    If isViewerOnly Then isViewonly = "viewonly"
                    SendRequestAsText(strb.Append("SvrCMD:RemoteServiceOpen|").Append(WS_Service_Index).Append("|").Append(isViewonly).ToString)
                    Return False
                Else
                    Return True
                End If

            Else
                'MsgBox("Error Opening File Service")
            End If

            Return False
        End Function

        Friend Function WS_Service_Close(WS_Service_Index As Integer, isSendToServer As Boolean) As Boolean
            If WS_Service_Index = wsArry_FileIndex Then
                If isServiceOpen_WS_File = False Then
                    Return True
                Else
                    isServiceOpen_WS_File = False
                End If

            ElseIf WS_Service_Index = wsArry_ScreenIndex Then
                If isServiceOpen_WS_Screen = False Then
                    Return True
                Else
                    isServiceOpen_WS_Screen = False
                End If

            ElseIf WS_Service_Index = wsArry_MouseIndex Then
                If isServiceOpen_WS_Mouse = False Then
                    Return True
                Else
                    isServiceOpen_WS_Mouse = False
                End If

            End If

            If isSendToServer AndAlso WS_Service_Index > 0 Then
                Try
                    SendRequestAsText("SvrCMD:RemoteServiceClose|" & WS_Service_Index)

                Catch ex As Exception
                End Try
            End If

            If Not IsNothing(MyWS) Then MyWS.closeServiceConnection(WS_Service_Index)

            Return False
        End Function

        Friend Sub Connect(ByVal conType As enum_ConnectType, ByVal IP_or_ID As String, ByVal pass As String, ByVal isViewOnly As Boolean)
            If conType = enum_ConnectType.WS Then
                Connect_WS_Client(IP_or_ID, pass, isViewOnly)
            Else
                Connect_UDP_Client(IP_or_ID)
            End If

        End Sub

    End Class



End Module
