﻿Imports System.Net
Imports System.Net.Sockets
Imports System.Text

Imports System.Threading

Module ModUDP

    Friend isServerThreadOn As Boolean = True
    ' Friend biofrm As frmWinBio

    Private Const Fixed_UDPPortReceiv As Integer = 29100

    Friend Class UDPConnectionClass

        Friend isConnected As Boolean = False
        Friend isServer As Boolean
        Friend UDP_Arry As UDPSocketClass()
        Friend TargetIP As String = ""

        Friend pthreads As Thread()
        Friend pthreadsLoop As Thread()

        Friend isUDPSenderIPAndPortSetup As Boolean = False
        Friend Sub SendRequestAsText(ByRef data As String)
            UDP_Arry(wsArry_TextIndex).sendRequestToTargetAsText(data)
        End Sub

        Friend Sub SendRequestAsByte(ByRef data As Byte(), ByVal portIndex As Integer)
            UDP_Arry(portIndex).sendRequestToTargetAsBytes(data)
        End Sub

        Friend Sub closeConnection()

            isConnected = False
            myApp.MyConn.IsMyPCConnected = False
            myApp.MyConn.IsRemotePCConnected = False
            myApp.MyConn.isUDPHelloReceived = False
            If IsNothing(UDP_Arry) Then Return
            For i As Integer = 0 To wsArry_SocketsTotal
                Try
                    UDP_Arry(i).Dispose()
                Catch ex As Exception
                End Try
                Try
                    pthreads(i).Interrupt()
                Catch ex As Exception
                End Try
                Try
                    pthreads(i).Abort()
                Catch ex As Exception
                End Try
            Next
            myApp.MyConn.MyUDP.isUDPSenderIPAndPortSetup = False
        End Sub

        Sub New(ByVal IPAddress As String, ByVal isUDPServer As Boolean)
            isServer = isUDPServer
            UDP_Arry = New UDPSocketClass(wsArry_SocketsTotal) {}
            pthreads = New Thread(wsArry_SocketsTotal) {}
            pthreadsLoop = New Thread(wsArry_SocketsTotal) {}
            TargetIP = IPAddress

        End Sub

        Friend Function openConnection() As String
            ' MyRecorder.gblTimer = Stopwatch.StartNew
            Dim scount As Integer = 0
            For i As Integer = 0 To wsArry_SocketsTotal
                Dim pIndex As Integer = i
                pthreads(i) = New Thread(Sub()
                                             Try
                                                 UDP_Arry(pIndex) = New UDPSocketClass(TargetIP, pIndex, isServer)

                                                 isConnected = True

                                                 If pIndex = wsArry_TextIndex Then 'text receiver
                                                     myApp.MyConn.IsMyPCConnected = True
                                                     UDP_Arry(pIndex).StartUDPListener(True)
                                                 Else
                                                     UDP_Arry(pIndex).StartUDPListener(False)
                                                 End If

                                             Catch ex As Exception
                                                 closeConnection()
                                             End Try
                                         End Sub)

                pthreads(i).Priority = ThreadPriority.Highest
                pthreads(i).Start()

            Next

            For i As Integer = 0 To wsArry_SocketsTotal

                Dim pIndex As Integer = i
                Try
                    pthreadsLoop(i) = New Thread(Sub()
                                                     Thread.Sleep(500)
                                                     UDP_Arry(pIndex).StartUDPLoop()
                                                 End Sub)
                    pthreads(i).Priority = ThreadPriority.Highest
                    pthreadsLoop(i).Start()

                Catch ex As Exception
                    Return "Error"
                End Try

            Next
            Return "Connected"

        End Function

        Friend Sub setupClientIPAddress(ByVal ClientIP As IPAddress, ByVal ClientPort As Integer)
            For i As Integer = 0 To wsArry_SocketsTotal
                UDP_Arry(i).SetupClientIP(ClientIP, ClientPort)
            Next
            myApp.MyConn.MyUDP.isUDPSenderIPAndPortSetup = True
        End Sub

        Friend Sub pulseAllThreads()
            For i As Integer = 0 To wsArry_SocketsTotal
                If UDP_Arry(i).UDPPort_index = wsArry_ScreenIndex OrElse UDP_Arry(i).UDPPort_index = wsArry_MouseIndex Then
                    Try
                        Monitor.Enter(UDP_Arry(i).lockObj)
                        Monitor.PulseAll(UDP_Arry(i).lockObj)
                        Monitor.Exit(UDP_Arry(i).lockObj)
                    Catch ex As Exception
                    End Try
                End If
            Next

        End Sub

    End Class

    Friend Class UDPSocketClass
        Implements IDisposable

        Friend lockObj As New Object

        Private UDPConnectionReceiv As UdpClient = Nothing
        Private UDPConnectionSend As UdpClient = Nothing
        Private UDPClientReceiv As IPEndPoint = Nothing
        Private UDPClientSend As IPEndPoint = Nothing

        Private UDPPort As Integer = 0

        Friend UDPPort_index As Integer = 0

        Private isServer As Boolean = True

        Private Target_IPAddress As String

        Private FIFO_byte As New UDPData()
        ' Private FIFO_text As List(Of Byte())


        Sub New(ByVal IPAddress As String, ByVal UDPIndex As Integer, ByVal isUDPServer As Boolean)
            Target_IPAddress = IPAddress
            UDPPort_index = UDPIndex
            isServer = isUDPServer

            UDPPort = Fixed_UDPPortReceiv + UDPIndex

        End Sub

        'Friend Sub setupPortBuffers(ByRef client As UdpClient, ByVal isRecevclient As Boolean)
        '    If UDPPort_index = wsArry_ImageStart Then
        '        If isRecevclient Then
        '            ' client.Client.ReceiveBufferSize = 524288
        '        Else
        '            ' client.Client.SendBufferSize = 524288
        '        End If
        '        'client.Client.DualMode = False

        '    End If
        'End Sub

        Friend Sub SetupClientIP(ByVal clientIP As IPAddress, ByVal ClientPort As Integer)

            UDPClientSend = New IPEndPoint(clientIP, UDPPort)
        End Sub

        Private Class UDPData

            Private dataPacket(9)() As Byte
            Private dataPacket_Len(9) As Integer

            Private PIndex_Add As Integer = -1
            Private PIndex_Remove As Integer = -1
            Private PIndex_start As Integer = 0
            Private PIndex_end As Integer = 9

            Private objLock As New Object

            Friend count As Integer = 0

            Sub New()
                For i As Integer = PIndex_start To PIndex_end
                    dataPacket(i) = New Byte(66560) {}
                Next
            End Sub

            Friend Sub Add(ByRef bArry As Byte())

                Try

                    ' Monitor.Enter(objLock)

                    PIndex_Add += 1
                    If PIndex_Add > PIndex_end Then
                        PIndex_Add = PIndex_start
                    End If

                    dataPacket_Len(PIndex_Add) = bArry.Length
                    Buffer.BlockCopy(bArry, 0, dataPacket(PIndex_Add), 0, dataPacket_Len(PIndex_Add))

                    count += 1
                Catch ex As Exception : End Try

                'Try
                '    Monitor.Exit(objLock)
                'Catch ex As Exception : End Try

            End Sub

            Friend Function isDataAvailable() As Boolean
                If count > 0 Then
                    Return True
                Else
                    Return False
                End If
            End Function

            Friend Function remove() As Byte()
                Dim bArry As Byte() = Nothing
                Try

                    '  Monitor.Enter(objLock)

                    PIndex_Remove += 1
                    If PIndex_Remove > PIndex_end Then
                        PIndex_Remove = PIndex_start
                    End If

                    Dim len As Integer = dataPacket_Len(PIndex_Remove)
                    If len > 0 Then
                        bArry = New Byte(len - 1) {}
                        Buffer.BlockCopy(dataPacket(PIndex_Remove), 0, bArry, 0, len)
                        dataPacket_Len(PIndex_Remove) = 0
                        count -= 1
                    End If

                Catch ex As Exception : End Try

                'Try
                '    Monitor.Exit(objLock)
                'Catch ex As Exception : End Try

                Return bArry

            End Function

        End Class

        Friend Sub StartUDPLoop()
            Dim tmpByte As Byte() = Nothing
            While isServerThreadOn

                Try
                    Monitor.Enter(lockObj)
                    If FIFO_byte.isDataAvailable Then

                        ' Debug.Print(UDPPort_index & " - FIFO: " & FIFO_byte.Count)
                        tmpByte = FIFO_byte.remove()

                    Else

                        Monitor.Wait(lockObj, 3000)

                    End If
                Catch ex As Exception : End Try
                Try
                    If Monitor.IsEntered(lockObj) Then Monitor.Exit(lockObj)
                Catch ex As Exception : End Try

                Try
                    If Not IsNothing(tmpByte) Then
                        myApp.MyConn.WS_OnMessageBytes(tmpByte)

                        ' Else
                        '  Thread.Sleep(5)
                    End If

                Catch ex As Exception
                End Try

            End While
        End Sub

        Public Sub StartUDPListener(ByVal isText As Boolean)
            Try
                isServerThreadOn = True

                Try
                    If IsNothing(UDPClientReceiv) Then
                        UDPClientReceiv = New IPEndPoint(IPAddress.Any, UDPPort)

                    End If


                    If IsNothing(UDPConnectionReceiv) Then
                        UDPConnectionReceiv = New UdpClient()
                        '  setupPortBuffers(UDPConnectionReceiv, True)
                        UDPConnectionReceiv.Client.SetSocketOption(SocketOptionLevel.Socket, SocketOptionName.ReuseAddress, True)
                        UDPConnectionReceiv.Client.Bind(UDPClientReceiv)

                    End If

                    While isServerThreadOn
                        Dim msg As Byte() = UDPConnectionReceiv.Receive(UDPClientReceiv)

                        'If UDPPort_index = wsArry_ImageStart Then
                        '    Dim stype As UShort = BitConverter.ToInt16(msg, 0)
                        '    Dim sframe As Long = BitConverter.ToInt64(msg, 2)


                        'End If

                        ' If UDPPort_index = wsArry_MouseMoveStart Then Debug.Print(watch.ElapsedMilliseconds)

                        If myApp.MyConn.MyUDP.isUDPSenderIPAndPortSetup = False Then
                            myApp.MyConn.MyUDP.setupClientIPAddress(UDPClientReceiv.Address, UDPClientReceiv.Port)
                        End If


                        If isText Then
                            Dim msgTxt As String = Encoding.UTF8.GetString(msg)
                            myApp.MyConn.WS_OnMessage(msgTxt)

                        Else
                            ' myApp.MyConn.WS_OnMessageBytes(msg)
                            ' Debug.Print("Enter: " & MyRecorder.gblTimer.ElapsedMilliseconds)

                            Try
                                Monitor.Enter(lockObj)
                                FIFO_byte.Add(msg)
                            Catch ex As Exception : End Try

                            Try

                                Monitor.PulseAll(lockObj)

                            Catch ex As Exception
                            End Try

                            Try
                                Monitor.Exit(lockObj)
                            Catch ex As Exception : End Try


                        End If

                    End While

                Catch ex As Exception
                    '  saveEvent("socketUDP", "UDP", "err2", ex.Message.Replace(",", "").Replace(vbCrLf, " ").Replace("|", "_").Replace("+", "_"))

                    ' strb.Clear()
                    ' strb.Append(vbCrLf).Append("Err: ").Append(ex.Message)
                    ' biofrm.Log(strb.ToString())
                End Try

                If isServerThreadOn Then
                    Dispose()
                End If

                '  biofrm.Log("UDP Exited..")

            Catch ex As Exception
                ' saveEvent("socketUDP", "UDP", "err1", ex.Message.Replace(",", "").Replace(vbCrLf, " ").Replace("|", "_").Replace("+", "_"))
            End Try
        End Sub


        Friend Sub sendRequestToTargetAsText(ByRef dataToSend As String)

            Try
                If IsNothing(UDPClientSend) Then

                    If isServer Then
                        Return
                    Else
                        UDPClientSend = New IPEndPoint(IPAddress.Parse(Target_IPAddress), UDPPort)
                    End If

                End If

                If IsNothing(UDPConnectionSend) Then
                    UDPConnectionSend = New UdpClient()
                    '  setupPortBuffers(UDPConnectionReceiv, False)
                    '     UDPConnectionSend.Client.SetSocketOption(SocketOptionLevel.Socket, SocketOptionName.KeepAlive, True)
                    UDPConnectionSend.Client.SetSocketOption(SocketOptionLevel.Socket, SocketOptionName.ReuseAddress, True)
                    UDPConnectionSend.Connect(UDPClientSend)
                End If


                Dim bytes As Byte() = Encoding.UTF8.GetBytes(dataToSend)

                UDPConnectionSend.Send(bytes, bytes.Length)


            Catch ex As Exception
                '  saveEvent("socketUDP", "UDP", "err3", ex.Message.Replace(",", "").Replace(vbCrLf, " ").Replace("|", "_").Replace("+", "_"))

                ' strb.Append(vbCrLf).Append("Err: ").Append(ex.Message)
                ' biofrm.Log(strb.ToString)
            End Try


        End Sub

        Friend Sub sendRequestToTargetAsBytes(ByRef dataToSend As Byte())

            Try
                If IsNothing(UDPClientSend) Then
                    If isServer Then
                        Return
                    Else
                        UDPClientSend = New IPEndPoint(IPAddress.Parse(Target_IPAddress), UDPPort)
                    End If
                End If


                If IsNothing(UDPConnectionSend) Then
                    UDPConnectionSend = New UdpClient()
                    ' setupPortBuffers(UDPConnectionReceiv, False)

                    UDPConnectionSend.Client.SetSocketOption(SocketOptionLevel.Socket, SocketOptionName.ReuseAddress, True)
                    UDPConnectionSend.Connect(UDPClientSend)
                End If


                'Debug.Print(watch.ElapsedMilliseconds)

                UDPConnectionSend.Send(dataToSend, dataToSend.Length)

                ' Debug.Print(UDPPort & " UDP Send " & watch.ElapsedMilliseconds)

            Catch ex As Exception
                '  saveEvent("socketUDP", "UDP", "err3", ex.Message.Replace(",", "").Replace(vbCrLf, " ").Replace("|", "_").Replace("+", "_"))

                ' strb.Append(vbCrLf).Append("Err: ").Append(ex.Message)
                ' biofrm.Log(strb.ToString)
            End Try


        End Sub

        Friend Sub Dispose() Implements IDisposable.Dispose
            isServerThreadOn = False

            Try
                If Not IsNothing(UDPConnectionReceiv) Then
                    Try
                        UDPConnectionReceiv.Close()
                    Catch ex As Exception : End Try
                    UDPConnectionReceiv.Dispose()
                End If
            Catch ex As Exception
            End Try
            Try
                If Not IsNothing(UDPConnectionSend) Then
                    Try
                        UDPConnectionSend.Close()
                    Catch ex As Exception : End Try
                    UDPConnectionSend.Dispose()
                End If
            Catch ex As Exception
            End Try

            Try
                Monitor.Enter(lockObj)
            Catch ex As Exception : End Try

            Try
                Monitor.PulseAll(lockObj)
            Catch ex As Exception
            End Try

            Try
                Monitor.Exit(lockObj)
            Catch ex As Exception : End Try

            UDPConnectionSend = Nothing
            UDPClientSend = Nothing
            UDPClientReceiv = Nothing
            UDPConnectionReceiv = Nothing
        End Sub
    End Class
End Module
