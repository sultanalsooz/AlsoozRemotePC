﻿Imports System.IO
Imports System.Net.WebSockets
Imports System.Text
Imports System.Threading

Module ModWS

    Friend Class WSConnectionClass

        Friend wsArry As ClientWebSocket() = Nothing

        Private ws_Uri As String = Nothing

        Friend wsOpenCount As Integer = 0

        Sub New()

            wsArry = New ClientWebSocket(wsArry_SocketsTotal) {}
            pthread = New Thread(wsArry_SocketsTotal) {}
            continueListenThread = New Boolean(wsArry_SocketsTotal) {}

            If myApp.MyComputerSerial = "" Then
                myApp.MyComputerSerial = getComputerSerialNumber().Replace("&", "").Replace("=", "").Replace("?", "").Replace("%", "").Replace(":", "")
                myApp.saveSettings()
            End If

            Dim strb As New StringBuilder
            strb.Append(myApp.MyConn.WS_URL)
            strb.Append("myinstallid=").Append(myApp.MyInstallationID)
            strb.Append("&pcname=").Append(My.Computer.Name)
            strb.Append("&username=")
            Try
                strb.Append(getCurrentLoggedOnUserName().Replace("&", "").Replace("=", "").Replace("?", "_").Trim)

            Catch ex As Exception
                strb.Append("NotLoggedIn")
            End Try
            strb.Append("&pcserial=").Append(myApp.MyComputerSerial)
            strb.Append("&autodiscover=").Append(myApp.AutoDiscoverKeyword)
            strb.Append("&lkey=").Append("")
            strb.Append("&wsindex=")

            ws_Uri = strb.ToString

        End Sub


        Private isConnectionClosing As Boolean = False

        Friend Sub closeServiceConnection(WS_Service_Index As Integer)

            If Not IsNothing(wsArry) Then
                If Not IsNothing(wsArry(WS_Service_Index)) Then
                    wsOpenCount -= 1
                    Try
                        Using t As Task = wsArry(WS_Service_Index).CloseAsync(WebSocketCloseStatus.NormalClosure, "", CancellationToken.None)
                            t.Wait(250)
                        End Using
                    Catch ex As Exception : End Try

                    Try
                        wsArry(WS_Service_Index).Dispose()
                    Catch ex As Exception : End Try
                    Try
                        wsArry(WS_Service_Index) = Nothing
                    Catch ex As Exception : End Try
                End If
            End If

            WSStopListen(WS_Service_Index)
        End Sub
        Friend Sub closeConnection()
            Try

                If Not IsNothing(wsArry) AndAlso isConnectionClosing = False Then
                    isConnectionClosing = True
                    myApp.MyConn.IsMyPCConnected = False
                    myApp.MyConn.IsRemotePCConnected = False
                    Try

                        For i As Integer = 0 To wsArry.Length - 1
                            closeServiceConnection(i)
                        Next

                        wsArry = Nothing
                    Catch ex As Exception
                    End Try

                    wsOpenCount = 0
                    isConnectionClosing = False
                    myApp.MyConn.MyWS = Nothing
                    Try
                        myApp.CloseRemoteScreenController()
                        myApp.Service_ScreenStop(True)
                    Catch ex As Exception
                    End Try

                End If
            Catch ex As Exception
            End Try
        End Sub

        Friend Function getConnectionStatus(ByRef ws As ClientWebSocket) As WebSocketState
            If IsNothing(ws) Then Return WebSocketState.None
            Return ws.State
        End Function


        Friend Function openConnection(ByVal wsIndex As Integer) As Boolean

            Try

                If IsNothing(wsArry(wsIndex)) Then wsArry(wsIndex) = New ClientWebSocket()


                If getConnectionStatus(wsArry(wsIndex)) <> WebSocketState.Open AndAlso
                    getConnectionStatus(wsArry(wsIndex)) <> WebSocketState.Connecting Then

                    Dim source As New CancellationTokenSource()
                    Dim token As CancellationToken = source.Token
                    Try
                        Using t As Task = wsArry(wsIndex).ConnectAsync(New Uri(ws_Uri & wsIndex), token)
                            t.Wait(1600)
                        End Using
                    Catch ex As Exception
                        End Try

                    Thread.Sleep(50)

                    If getConnectionStatus(wsArry(wsIndex)) = WebSocketState.Open Then
                        wsOpenCount += 1
                        WSStartListen(wsIndex)
                        source.Dispose()
                        Return True
                    Else
                        source.Cancel()
                        source.Dispose()

                        Return False
                    End If

                Else

                    Return True
                End If

            Catch ex As Exception

            End Try

            Return False
        End Function

        Friend Function SendRequestAsText(ByRef data As String, ByRef ws As ClientWebSocket, ByVal wsIndex As Integer) As Boolean

            Try
                If IsNothing(ws) OrElse ws.State <> WebSocketState.Open Then
                    Return False
                End If

                Dim reqAsBytes = Encoding.UTF8.GetBytes(data)
                Dim ticksRequest = New ArraySegment(Of Byte)(reqAsBytes)

                Using t As Task = ws.SendAsync(ticksRequest, WebSocketMessageType.Text, True, CancellationToken.None)
                    t.Wait(2000)
                End Using

                Return True
            Catch ex As Exception
            End Try
            Return False
        End Function


        Friend Sub SendRequestAsByte(ByRef reqAsBytes As Byte(), ByRef ws As ClientWebSocket, ByVal wsIndex As Integer)
            If IsNothing(ws) OrElse ws.State <> WebSocketState.Open Then
                myApp.MyConn.WS_Service_Close(wsIndex, True)
                Return
            End If


            Try

                Dim ticksRequestbyte As ArraySegment(Of Byte) = New ArraySegment(Of Byte)(reqAsBytes)

                Using t As Task = ws.SendAsync(ticksRequestbyte, WebSocketMessageType.Binary, True, CancellationToken.None)
                    t.Wait(3000)
                End Using
                ' dont remove or will crash at big screen size
                ' ticksRequestbyte = Nothing
                ' reqAsBytes = Nothing

                Return
            Catch ex As Exception
                ' Return "err" '"err: SendRequest : " & ex.Message
            End Try
        End Sub

        Private pthread As Thread() = Nothing
        Private continueListenThread As Boolean()

        Friend Sub WSStopListen(ByVal wsIndex As Integer)

            continueListenThread(wsIndex) = False
            If Not IsNothing(pthread) AndAlso Not IsNothing(pthread(wsIndex)) Then

                Try
                    pthread(wsIndex).Interrupt()
                Catch ex As Exception
                End Try
                Try
                    pthread(wsIndex).Abort()
                Catch ex As Exception
                End Try

            End If

        End Sub
        Friend Sub WSStartListen(ByVal wsIndex As Integer)
            If Not IsNothing(pthread) AndAlso Not IsNothing(pthread(wsIndex)) Then
                WSStopListen(wsIndex)
            End If
            pthread(wsIndex) = New Thread(Sub()
                                              Try
                                                  continueListenThread(wsIndex) = True
                                                  WSListenLoop(wsIndex)

                                              Catch ex As Exception

                                              End Try

                                          End Sub)

            pthread(wsIndex).Start()
        End Sub

        Private Sub WSListenLoop(wsIndex As Integer)
            Try

                Dim bufferSize As Integer = WS_bufferSize_CMD

                If wsIndex = wsArry_MouseIndex Then
                    bufferSize = WS_bufferSize_MouseMove
                ElseIf wsIndex = wsArry_ScreenIndex Then
                    bufferSize = WS_bufferSize_Image
                ElseIf wsIndex = wsArry_FileIndex Then
                    bufferSize = WS_bufferSize_File
                End If


                Do While continueListenThread(wsIndex)

                    Dim strb As New StringBuilder
                    Dim ms As New MemoryStream
                    'Dim continuecount As Integer = 0

                    If Me.wsArry(wsIndex).State <> WebSocketState.Open Then
                        Return
                    End If

                    Dim incomingData(bufferSize) As Byte
                    Dim tResult As WebSocketReceiveResult
                    ' Dim t As Task(Of WebSocketReceiveResult)
                    Dim buffer As ArraySegment(Of Byte) = New ArraySegment(Of Byte)(incomingData)

                    'Dim tokenSource As New CancellationTokenSource()
                    'Dim token As CancellationToken = tokenSource.Token

socketContinue:
                    'continuecount += 1
                    'If (continuecount > 10) Then WS_OnMessage(strb.ToString)


                    tResult = wsArry(wsIndex).ReceiveAsync(buffer, CancellationToken.None).Result

                    'tResult = t.Result

                    'SocketException: A socket operation was attempted to an unreachable network

                    If (tResult.CloseStatus.HasValue) Then
                        continueListenThread(wsIndex) = False
                        '  WS_OnError("Closed " & tResult.CloseStatus & ", " & tResult.CloseStatusDescription)

                        Return

                    Else

                        If tResult.EndOfMessage Then

                            If tResult.MessageType = WebSocketMessageType.Text Then
                                If tResult.Count > 0 Then strb.Append(Encoding.UTF8.GetString(incomingData, 0, tResult.Count))
                                If strb.Length > 0 Then myApp.MyConn.WS_OnMessage(strb.ToString)

                            ElseIf tResult.MessageType = WebSocketMessageType.Binary Then
                                ' If result.Count > 0 Then arry = addArrayBytes(arry, incomingData)
                                If tResult.Count > 0 Then ms.Write(buffer.Array, buffer.Offset, tResult.Count)

                                If ms.Length > 0 Then

                                    myApp.MyConn.WS_OnMessageBytes(ms.ToArray)

                                End If
                                buffer = Nothing
                                incomingData = Nothing

                            End If

                        Else
                            If tResult.MessageType = WebSocketMessageType.Text Then
                                strb.Append(Encoding.UTF8.GetString(incomingData, 0, tResult.Count))

                            ElseIf tResult.MessageType = WebSocketMessageType.Binary Then
                                '   arry = addArrayBytes(arry, incomingData)
                                ms.Write(buffer.Array, buffer.Offset, tResult.Count)
                            End If
                            GoTo socketContinue
                        End If

                    End If
                Loop
            Catch ex As Exception

                setCrashedWsIndex(wsIndex)
            End Try

        End Sub

        Private Sub setCrashedWsIndex(ByVal wsIndex As Integer)

            Try
                If wsIndex = 0 Then
                    myApp.MyConn.forceUnlockThread()
                End If
            Catch ex As Exception
            End Try

            Try
                myApp.MyConn.WS_Service_Close(wsIndex, True)
            Catch ex As Exception
            End Try

            Try
                If wsIndex = wsArry_ScreenIndex Then
                    myApp.myScreen.StopRecording()
                End If
            Catch ex As Exception
            End Try

            Try
                If wsIndex = 0 Then
                    closeConnection()
                End If
            Catch ex As Exception
            End Try

        End Sub

    End Class


End Module
