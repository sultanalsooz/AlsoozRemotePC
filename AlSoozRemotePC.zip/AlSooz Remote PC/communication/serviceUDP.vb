﻿Imports System.Net
Imports System.Net.Sockets
Imports System.Text

Module serviceUDP

    Friend isServerThreadOn As Boolean = True

    Private Gbl_UDP_PortReceiv As Integer = 29151

    Private Gbl_UDP_PortSend As Integer = 29150

    Private UDPConnectionReceiv As UdpClient = Nothing
    Private UDPClientReceiv As IPEndPoint = Nothing

    Private UDPConnectionSend As UdpClient = Nothing
    Private UDPClientSend_Service As IPEndPoint = Nothing

    Friend Sub stopUDPListener_Service()
        isServerThreadOn = False

        Try
            UDPConnectionReceiv.Close()
        Catch ex As Exception
        End Try

        Try
            p.Abort()
        Catch ex As Exception
        End Try
    End Sub


    Private p As Threading.Thread

    Public Sub StartUDPListener()

        isServerThreadOn = True

        UDPConnectionSend = New UdpClient()
        UDPConnectionSend.Client.SetSocketOption(SocketOptionLevel.Socket, SocketOptionName.ReuseAddress, True)
        UDPClientSend_Service = New IPEndPoint(IPAddress.Parse("127.0.0.1"), Gbl_UDP_PortSend)



        UDPClientReceiv = New IPEndPoint(IPAddress.Parse("127.0.0.1"), Gbl_UDP_PortReceiv)


        p = New Threading.Thread(Sub()

                                     Dim strb As New StringBuilder
                                     Try

                                         If IsNothing(UDPClientReceiv) Then UDPClientReceiv = New IPEndPoint(IPAddress.Parse("127.0.0.1"), Gbl_UDP_PortSend)

                                         If IsNothing(UDPConnectionReceiv) Then
                                             UDPConnectionReceiv = New UdpClient()
                                             UDPConnectionReceiv.Client.SetSocketOption(SocketOptionLevel.Socket, SocketOptionName.ReuseAddress, True)

                                             UDPConnectionReceiv.Client.Bind(UDPClientReceiv)
                                         End If

                                         While isServerThreadOn

                                             ' strb.Clear()

                                             Dim data As Byte() = UDPConnectionReceiv.Receive(UDPClientReceiv)

                                             Dim datarec As String = Encoding.UTF8.GetString(data)

                                             processUDPCommand(datarec)

                                             ' strb.Append(vbCrLf).Append("Receive from: ").Append(Client1.Address.ToString)
                                             '  strb.Append(vbCrLf).Append("Received data:").Append(datarec) 
                                             ' biofrm.Log(strb.ToString)

                                             'If datarec <> "ok" Then sendUDPToServer("ok")

                                         End While


                                     Catch ex As Exception
                                         'strb.Clear()
                                         'strb.Append(vbCrLf).Append("Err: ").Append(ex.Message)
                                         'processUDPCommand(strb.ToString())
                                     End Try

                                     'processUDPCommand("UDP Exited")
                                 End Sub)

        p.Start()

    End Sub


    Public Sub sendUDPToService(ByVal dataToSend As String)

        Dim strb As New StringBuilder
        Try

            'strb.Append(vbCrLf).Append("Sending: ").Append(dataToSend)
            '  biofrm.Log(strb.ToString())
            'strb.Clear()

            UDPConnectionSend.Send(Encoding.UTF8.GetBytes(dataToSend), dataToSend.Length, UDPClientSend_Service)

        Catch ex As Exception
            ' strb.Append(vbCrLf).Append("Err: ").Append(ex.Message)
            ' biofrm.Log(strb.ToString)
        End Try


    End Sub


    Private Sub processUDPCommand(ByVal Cmd_Data As String)


        ' writeLogLine("processUDPCommand: " & Cmd_Data)

        If Cmd_Data.StartsWith("CMD_:") Then
            Try
                If Cmd_Data.Split(":")(1).ToLower = "default" Then

                Else

                End If

            Catch ex As Exception
            End Try

        ElseIf Cmd_Data.StartsWith("SessionLogon") OrElse Cmd_Data.StartsWith("SessionUnlock") Then

            If IsNothing(frmTrayObj) Then
                openFormInAnotherDesktop("default", "tray")
            End If

        Else
            ' writeLogLine(Cmd_Data)

        End If

    End Sub


End Module
