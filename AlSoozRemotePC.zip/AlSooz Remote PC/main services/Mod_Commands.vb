﻿Module Mod_Commands


    Private Sub processCommand(ByVal cmd As String)

        If cmd = "RCMD_Reboot" Then
            CMD_ComputerShutdown(CMD_ComputerShutdown_Options.Reboot)

        ElseIf cmd = "" Then

        End If
    End Sub


    Private CMD_List As New List(Of String)
    Private CMD_List_Lock As New Object
    Private CMD_List_Thread As Threading.Thread
    Private CMD_List_IsContinue As Boolean = False
    Friend Sub CMDS_ProcessRemoteCommands(ByVal msg As String)

        CMDS_Tread_Start()

        Try
            Threading.Monitor.Enter(CMD_List_Lock)
            CMD_List.Add(msg)
            Threading.Monitor.PulseAll(CMD_List_Lock)
        Catch ex As Exception
        End Try

        Try
            If Threading.Monitor.IsEntered(CMD_List_Lock) Then Threading.Monitor.Exit(CMD_List_Lock)
        Catch ex As Exception : End Try


    End Sub

    Friend Sub CMDS_Tread_Start()
        Try
            If CMD_List_IsContinue Then Return
            CMD_List_IsContinue = True
            CMD_List_Thread = New Threading.Thread(Sub()
                                                       CMDS_Thread_Loop()
                                                   End Sub)

            CMD_List_Thread.Start()
        Catch ex As Exception
        End Try

    End Sub

    Friend Sub CMDS_Thread_End()
        CMD_List_IsContinue = False
        Try
            Threading.Monitor.Enter(CMD_List_Lock)
            Threading.Monitor.PulseAll(CMD_List_Lock)
        Catch ex As Exception : End Try
        Try
            Threading.Monitor.Exit(CMD_List_Lock)
        Catch ex As Exception : End Try
    End Sub

    Private Sub CMDS_Thread_Loop()

        Try
            Do While CMD_List_IsContinue
                Dim CurrentCMD As String = ""
                Try
                    Threading.Monitor.Enter(CMD_List_Lock)
                    If CMD_List.Count > 0 Then
                        CurrentCMD = CMD_List(0)
                        CMD_List.RemoveAt(0)
                    Else
                        Threading.Monitor.Wait(CMD_List_Lock, 3000)
                    End If
                Catch ex As Exception
                End Try

                Try
                    If Threading.Monitor.IsEntered(CMD_List_Lock) Then Threading.Monitor.Exit(CMD_List_Lock)
                Catch ex As Exception : End Try

                processCommand(CurrentCMD)
            Loop
        Catch ex As Exception
        End Try
        CMD_List_IsContinue = False
    End Sub


End Module
