﻿Imports System.Drawing.Imaging
Imports System.IO
Imports System.Runtime.ExceptionServices
Imports System.Runtime.InteropServices


Module Mod_Screen

    Friend Class MyScreenRecorderClass

        ' Friend gblTimer As Stopwatch = Nothing

        Friend DesktopImgWidth As Integer() = {1280, ' jpeg
                                               1920,'  png
                                               2560} ' png 1280 , 1920 ,2560  = 2k is max realimage  

        Friend isDestroyBm As Boolean = False
        Friend isRecordingOn As Boolean = False

        Private pthread As Threading.Thread
        ' Private pthread2 As Threading.Thread

        Friend Sub StartRecording()
            ' gblTimer = Stopwatch.StartNew

            initScreenShotNative()
            startBackgroundThread()

        End Sub

        Friend Sub resetRecordingVariables()
            isInitialImage_1 = True
            isInitialImage_2 = False
            imgRect.Width = 0
            lst_imgTiles = New List(Of Byte())
            gbl_drawMouseCursor = False
            isRecordingOn = False
            gbl_WS_ImgBytes_Current = Nothing

            If DesktopImgWidth(JPGCompressLevel) > MyScreenWidth Then
                imageSizeToRecord = New Size(MyScreenWidth, MyScreenHeight)
            Else
                imageSizeToRecord = New Size(DesktopImgWidth(JPGCompressLevel), DesktopImgWidth(JPGCompressLevel))
            End If

            If JPGCompressLevel = 0 Then

                If IsNothing(gblEncoderInfoJpeg) Then
                    gblEncoderInfoJpeg = GetImgEncoder(ImageFormat.Jpeg)
                    gblEncoderParameterJpeg = New EncoderParameter(System.Drawing.Imaging.Encoder.Quality, 82L)
                    gblEncoderParametersJpeg.Param(0) = gblEncoderParameterJpeg

                End If

                gbl_ImgBitWidthLen = 2
                JPGBits = Imaging.PixelFormat.Format16bppRgb555

            ElseIf JPGCompressLevel = 1 Then

                gbl_ImgBitWidthLen = 2
                JPGBits = Imaging.PixelFormat.Format16bppRgb555

            ElseIf JPGCompressLevel = 2 Then

                gbl_ImgBitWidthLen = 4
                JPGBits = Imaging.PixelFormat.Format32bppArgb
            End If

            Try
                Threading.Monitor.Exit(myApp.MyConn.lockWS_SendRequestAsScreenByte)
            Catch ex As Exception : End Try
            Try
                Threading.Monitor.Exit(Allow_WS_Send_Lock)
            Catch ex As Exception : End Try
            Try
                Threading.Monitor.Exit(gbl_WS_img_Lock)
            Catch ex As Exception : End Try
        End Sub

        Friend Sub StopRecording()
            isRecordingOn = False

            Try
                Threading.Monitor.Exit(Allow_WS_Send_Lock)
            Catch ex As Exception : End Try
            Try
                Threading.Monitor.Enter(Allow_WS_Send_Lock)
                Threading.Monitor.PulseAll(Allow_WS_Send_Lock)
            Catch ex As Exception : End Try

            Try
                Threading.Monitor.Exit(Allow_WS_Send_Lock)
            Catch ex As Exception : End Try

            Try
                Threading.Monitor.Exit(gbl_WS_img_Lock)
            Catch ex As Exception : End Try

            Try
                Threading.Monitor.Enter(gbl_WS_img_Lock)
                Threading.Monitor.PulseAll(gbl_WS_img_Lock)
            Catch ex As Exception : End Try

            Try
                Threading.Monitor.Exit(gbl_WS_img_Lock)
            Catch ex As Exception : End Try

            'DisableBorderWhenDragging()

            endScreenShotNative()
        End Sub

        'Private Sub EnableBorderWhenDragging()
        '    Try
        '        SetSystemParametersInfo(SPI_SETDRAGFULLWINDOWS, 0, 0, 0)
        '    Catch ex As Exception
        '    End Try
        'End Sub
        'Private Sub DisableBorderWhenDragging()
        '    Try
        '        SetSystemParametersInfo(SPI_SETDRAGFULLWINDOWS, 1, 0, 0)
        '    Catch ex As Exception
        '    End Try
        'End Sub
        Private Sub startBackgroundThread()

            resetRecordingVariables()

            If isRecordingOn Then

                Return
            End If

            'EnableBorderWhenDragging()

            Try
                pthread = New Threading.Thread(Sub()

                                                   loopForChanges()
                                               End Sub)


                pthread.Priority = Threading.ThreadPriority.Highest
                pthread.Start()
            Catch ex As Exception
            End Try

        End Sub

        Friend Sub loopForChanges()
            Try
                If isRecordingOn Then Return
                isRecordingOn = True
                Do While isRecordingOn
                    If myApp.MyConn.connectionType = enum_ConnectType.WS Then

                        getScreenShotEnhanced_WebSocket()

                        Threading.Thread.Sleep(20)

                        'If JPGCompressLevel = 0 Then
                        '    Threading.Thread.Sleep(5)
                        'Else
                        '    Threading.Thread.Sleep(25)
                        'End If

                    Else
                        getScreenShotEnhanced_UDP()

                        Threading.Thread.Sleep(5)

                    End If

                Loop

            Catch ex As Exception
                sendUDPToService("loopForChanges: " & ex.Message)
            End Try
            isRecordingOn = False
        End Sub

        Private lastWsUsed As Integer = wsArry_ScreenIndex
        Private ImageLockObj As New Object

        Private imgRect As Rectangle = New Rectangle(0, 0, 0, 0)

        Private Class TileInfo
            Friend index As Integer
            Friend Index_Y(1) As Byte
            Friend Index_X(1) As Byte
            Friend byteArry As Byte()
            Friend tileBlockheightSize As Integer
            Friend Sub New(ByVal indx_X As UInt16, ByVal indx_Y As UInt16, ByVal indx As Integer, ByRef arry As Byte(), ByRef blockheight As Integer)
                index = indx
                byteArry = arry
                Index_Y = BitConverter.GetBytes(indx_Y)
                Index_X = BitConverter.GetBytes(indx_X)

                tileBlockheightSize = blockheight
            End Sub

        End Class

        Private lst_imgTiles_Count_Limit As Integer = 0
        Private lst_imgTiles As New List(Of Byte())
        Private lst_imgTilesUpdated As New List(Of TileInfo)
        Private lstUpdate As New List(Of TileInfo)
        Private Function populateTilesList(ByRef arrybyte As Byte(), ByRef len_bytes As Integer, ByRef imgWidth As Integer, ByRef imgHeight As Integer, ByRef imageWidthStride As Integer) As List(Of TileInfo)

            Try
                lstUpdate.Clear()

                Dim tileWidthCount As Integer = (imgWidth / gbl_TitleBoxSize) - 1
                Dim tileHeightCount As Integer = Math.Floor(imgHeight / gbl_TitleBoxSize) - 1
                Dim tileHeightReminder As Integer = imgHeight Mod gbl_TitleBoxSize

                'Dim remainder As Int16 = imgHeight Mod gbl_TitleBoxSize
                If tileHeightReminder > 0 Then
                    tileHeightCount += 1
                End If

                Dim tileBitsWidth As Integer = gbl_TitleBoxSize * gbl_ImgBitWidthLen ' 2 = 16 bit = 2pixels per color
                Dim titleLocX, titleLocY As Integer

                Dim tileBuffer As Integer = (tileBitsWidth * gbl_TitleBoxSize) - 1
                Dim tileBufferLen As Integer = gbl_TitleBoxSize - 1

                Dim isCompare As Boolean = (lst_imgTiles.Count > 0)
                Dim lstindex As Integer = -1
                For y As Integer = 0 To tileHeightCount
                    titleLocY = gbl_TitleBoxSize * y
                    For x As Integer = 0 To tileWidthCount
                        titleLocX = tileBitsWidth * x

                        lstindex += 1

                        Dim arryTile(tileBuffer) As Byte

                        If y = tileHeightCount AndAlso tileHeightReminder > 0 Then
                            tileBufferLen = tileHeightReminder - 1
                        End If
                        For i As Integer = 0 To tileBufferLen ' fill byte arry vertically with 32*32 pixles (16 bit= 64*64 pixels)
                            Try
                                Dim start As Integer = titleLocX + ((titleLocY + i) * imageWidthStride)

                                Buffer.BlockCopy(arrybyte, start, arryTile, tileBitsWidth * i, tileBitsWidth)

                            Catch ex As Exception
                                'tileBufferLen = i - 1

                                'Exit For
                            End Try

                        Next


                        If isCompare Then
                            If Not ByteArrayCompare(lst_imgTiles(lstindex), arryTile) Then
                                lstUpdate.Add(New TileInfo(x, y, lstindex, arryTile, tileBitsWidth))
                                lst_imgTiles(lstindex) = arryTile
                            End If

                            'If y = tileHeightCount AndAlso tileHeightReminder > 0 Then
                            '    lstUpdate.Add(New TileInfo(x, y, lstindex, arryTile, tileHeightReminder))
                            'Else
                            '    lstUpdate.Add(New TileInfo(x, y, lstindex, arryTile, tileBitsWidth))
                            'End If
                        Else
                            lst_imgTiles.Add(arryTile)

                        End If

                    Next
                Next
            Catch ex As Exception
            End Try

            Return lstUpdate
        End Function

        Private isInitialImage_1 As Boolean = True
        Private isInitialImage_2 As Boolean = False
        Private isInitialImage_3 As Boolean = True
        Private gbl_WS_Img As Bitmap

        Friend Sub SendFullImageNextFrame()
            Try
                Threading.Monitor.Enter(gbl_WS_img_Lock)
                isSkipLargeFrame_1 = True
                Threading.Thread.Sleep(1200)
            Catch ex As Exception
            End Try
            Try
                Threading.Monitor.Exit(gbl_WS_img_Lock)
            Catch ex As Exception
            End Try
        End Sub
        '<HandleProcessCorruptedStateExceptions>
        '<System.Security.SecurityCritical>
        Friend Sub getScreenShotEnhanced_WebSocket()

            'lastRun_ScreenShot = Now.Ticks
            ' Debug.Print("start: " & gblTimer.ElapsedMilliseconds)
            gbl_WS_Img = getScreenShotNative()

            If IsNothing(gbl_WS_Img) Then Return

            '   Debug.Print("After getScreenShotNative: " & gblTimer.ElapsedMilliseconds)
            Try
                If imgRect.Width = 0 Then
                    imgRect = New Rectangle(0, 0, gbl_WS_Img.Width, gbl_WS_Img.Height)
                End If

                Threading.Monitor.Enter(gbl_WS_img_Lock)
                If isInitialImage_1 OrElse isSkipLargeFrame_1 Then
                    isSkipLargeFrame_1 = False
                    isSkipLargeFrame_2 = True
                    gbl_WS_Img_Current = gbl_WS_Img.Clone()

                    isInitialImage_1 = False
                    isInitialImage_2 = True

                End If

                Dim ImgPixelData As BitmapData = gbl_WS_Img.LockBits(imgRect, ImageLockMode.ReadOnly, JPGBits)

                gbl_WS_ImgBytes_Current_Stride = Math.Abs(ImgPixelData.Stride) ' width * bytesPerPixel
                gbl_WS_ImgBytes_Current_len = gbl_WS_ImgBytes_Current_Stride * imgRect.Height

                If IsNothing(gbl_WS_ImgBytes_Current) Then
                    gbl_WS_ImgBytes_Current = New Byte(gbl_WS_ImgBytes_Current_len * 1.5) {}
                    gbl_WS_ImgBytes_Send = New Byte(gbl_WS_ImgBytes_Current_len * 1.5) {}
                End If

                Marshal.Copy(ImgPixelData.Scan0, gbl_WS_ImgBytes_Current, 0, gbl_WS_ImgBytes_Current_len)
                gbl_WS_Img.UnlockBits(ImgPixelData)

                isNewImgFrame = True
                Threading.Monitor.PulseAll(gbl_WS_img_Lock)
                If isDestroyBm Then gbl_WS_Img.Dispose()
            Catch ex As Exception
                'sendUDPToService("getScreenShotEnhanced_WebSocket Err: " & ex.Message)
            End Try

            Try
                Threading.Monitor.Exit(gbl_WS_img_Lock)
            Catch ex As Exception
            End Try

            If isWS_Img_thread_running = False Then
                Allow_WS_Send = True
                gbl_WS_img_UDP_Thread = New Threading.Thread(Sub() compressAndSendLoop_WS())
                gbl_WS_img_UDP_Thread.Priority = Threading.ThreadPriority.Highest
                gbl_WS_img_UDP_Thread.Start()
            End If

            Return

        End Sub

        Private gbl_imgArryByte As Byte() = Nothing

        Private gbl_WS_ImgBytes_Current As Byte()
        Private gbl_WS_ImgBytes_Current_len As Integer
        Private gbl_WS_ImgBytes_Current_Stride As Integer

        Private gbl_WS_ImgBytes_Send As Byte()
        Private gbl_WS_ImgBytes_Send_len As Integer
        Private gbl_WS_ImgBytes_Send_Stride As Integer

        Friend Allow_WS_Send_Lock As New Object
        Friend Allow_WS_Send As Boolean = False
        Private Allow_WS_Send_Limit As Integer = 4
        Private Allow_WS_Send_Count As Integer = 0
        ' Private Allow_WS_Send_lcl As Boolean = False

        Private isSkipLargeFrame_1 As Boolean = False
        Private isSkipLargeFrame_2 As Boolean = False

        <HandleProcessCorruptedStateExceptions>
        <System.Security.SecurityCritical>
        Friend Sub compressAndSendLoop_WS()

            Do While isRecordingOn

                isWS_Img_thread_running = True
                Try
                    Threading.Monitor.Enter(Allow_WS_Send_Lock)
                    If Allow_WS_Send OrElse isSkipLargeFrame_2 Then
                        Allow_WS_Send = False
                        'Allow_WS_Send_lcl = True
                    Else

                        Threading.Monitor.Wait(Allow_WS_Send_Lock, 2000)
                        If Allow_WS_Send Then
                            Allow_WS_Send_Count = 0
                        Else
                            Allow_WS_Send_Count += 1
                            If Allow_WS_Send_Count > Allow_WS_Send_Limit Then
                                Allow_WS_Send_Count = 0
                            Else
                                Try
                                    Threading.Monitor.Exit(Allow_WS_Send_Lock)
                                Catch ex As Exception : End Try
                                Continue Do
                            End If

                        End If

                        ' Allow_WS_Send_lcl = False

                    End If

                Catch ex As Exception : End Try

                Try
                    Threading.Monitor.Exit(Allow_WS_Send_Lock)
                Catch ex As Exception : End Try


                Try

                    Threading.Monitor.Enter(gbl_WS_img_Lock)

                    If isNewImgFrame Then

                        gbl_WS_ImgBytes_Send_len = gbl_WS_ImgBytes_Current_len
                        gbl_WS_ImgBytes_Send_Stride = gbl_WS_ImgBytes_Current_Stride
                        Buffer.BlockCopy(gbl_WS_ImgBytes_Current, 0, gbl_WS_ImgBytes_Send, 0, gbl_WS_ImgBytes_Send_len)

                        If Not IsNothing(gbl_WS_Img_Current) AndAlso (isInitialImage_2 OrElse isSkipLargeFrame_2) Then

                            gbl_WS_Img_Send = gbl_WS_Img_Current.Clone()

                            gbl_WS_Img_Current.Dispose()
                            gbl_WS_Img_Current = Nothing
                            isSkipLargeFrame_2 = False
                            isInitialImage_2 = False
                            isInitialImage_3 = True
                        End If

                        isNewImgFrame = False
                        isNewImgSkipSend = False
                    Else
                        isNewImgSkipSend = True
                        Allow_WS_Send = True
                        Threading.Monitor.Wait(gbl_WS_img_Lock, 1000)
                    End If

                Catch ex As Exception
                End Try

                Try
                    Threading.Monitor.Exit(gbl_WS_img_Lock)
                Catch ex As Exception
                End Try

                If isNewImgSkipSend = False Then
                    Try

                        Dim tilesUpdated As List(Of TileInfo) = populateTilesList(gbl_WS_ImgBytes_Send, gbl_WS_ImgBytes_Send_len, imgRect.Width, imgRect.Height, gbl_WS_ImgBytes_Send_Stride)


                        If isInitialImage_3 Then
                            isInitialImage_3 = False

                            ' takes 30 miliseconds
                            Using ms As MemoryStream = compressPhotoToJPG(gbl_WS_Img_Send, JPGCompressLevel)
                                PrepareImageAndSend(ms.ToArray, 1, 0, Nothing)
                            End Using

                            ' populateTilesList(gbl_WS_ImgBytes_Send, gbl_WS_ImgBytes_Send_len, imgRect.Width, imgRect.Height, gbl_WS_ImgBytes_Send_Stride)


                            lst_imgTiles_Count_Limit = CInt(lst_imgTiles.Count * 0.8)

                            gbl_WS_Img_Send.Dispose()


                        Else

                            If JPGCompressLevel > 0 AndAlso tilesUpdated.Count > lst_imgTiles_Count_Limit Then
                                Try
                                    Threading.Monitor.Enter(gbl_WS_img_Lock)
                                    isSkipLargeFrame_1 = True
                                    Allow_WS_Send = True
                                Catch ex As Exception
                                End Try
                                Try
                                    Threading.Monitor.Exit(gbl_WS_img_Lock)
                                Catch ex As Exception
                                End Try


                            Else

                                ' isSkipLargeFrame_2 = False

                                Dim tilescount As UShort = CUShort(tilesUpdated.Count)
                                If tilescount > 0 Then


                                    Dim mergedTiles As Byte() = MergeByteArrysFromList(tilesUpdated)
                                    Dim mergedPoints As Byte() = MergePixelLocations(tilescount, tilesUpdated)
                                    Using newBitmap As Bitmap = createBitmapFromBytes(tilescount, mergedTiles)


                                        ' takes 30 miliseconds
                                        Using ms As MemoryStream = compressPhotoToJPG(newBitmap, JPGCompressLevel) '  CompressPhotoToPNG(newBitmap)

                                            PrepareImageAndSend(ms.ToArray, 2, tilescount, mergedPoints)
                                        End Using

                                        ' PrepareImageAndSend(compressPhotoToWebp(newBitmap, JPGCompressLevel), 2, tilescount, mergedPoints)

                                    End Using


                                    '  Return True

                                Else
                                    Allow_WS_Send = True
                                End If
                            End If

                            ' End If

                        End If
                    Catch ex As Exception
                    End Try

                Else
                    Allow_WS_Send = True
                End If
                ' End If

            Loop

            isWS_Img_thread_running = False

        End Sub


        Private gbl_WS_Img_Current As Bitmap
        Friend gbl_WS_img_Lock As New Object

        Private gbl_WS_img_UDP_Thread As Threading.Thread = Nothing

        Friend isNewImgFrame As Boolean = False

        <HandleProcessCorruptedStateExceptions>
        <System.Security.SecurityCritical>
        Friend Sub getScreenShotEnhanced_UDP()

            ' Debug.Print("start: " & gblTimer.ElapsedMilliseconds)
            gbl_WS_Img = getScreenShotNative()
            If IsNothing(gbl_WS_Img) Then Return

            Try
                Threading.Monitor.Enter(gbl_WS_img_Lock)
                'If Not IsNothing(gbl_WS_Img_Current) Then
                '    gbl_WS_Img_Current.Dispose()
                'End If
                gbl_WS_Img_Current = gbl_WS_Img.Clone()
                isNewImgFrame = True
                Threading.Monitor.PulseAll(gbl_WS_img_Lock)
            Catch ex As Exception
            End Try

            Try
                Threading.Monitor.Exit(gbl_WS_img_Lock)
            Catch ex As Exception
            End Try

            If isWS_Img_thread_running = False Then
                gbl_WS_img_UDP_Thread = New Threading.Thread(Sub() compressAndSendLoop_UDP())
                gbl_WS_img_UDP_Thread.Priority = Threading.ThreadPriority.Highest
                gbl_WS_img_UDP_Thread.Start()
            End If

            Return

        End Sub


        Private gbl_WS_Img_Send As Bitmap
        Private isWS_Img_thread_running As Boolean = False

        Private isNewImgSkipSend As Boolean = False

        Friend Sub compressAndSendLoop_UDP()

            Do While isRecordingOn


                isWS_Img_thread_running = True
                Try
                    Threading.Monitor.Enter(gbl_WS_img_Lock)
                    If isNewImgFrame Then
                        gbl_WS_Img_Send = gbl_WS_Img_Current.Clone()
                        isNewImgFrame = False
                        isNewImgSkipSend = False
                    Else
                        isNewImgSkipSend = True
                        Threading.Monitor.Wait(gbl_WS_img_Lock, 3000)
                    End If
                Catch ex As Exception
                End Try

                Try
                    Threading.Monitor.Exit(gbl_WS_img_Lock)
                Catch ex As Exception
                End Try
                If isNewImgSkipSend = False Then
                    Try
                        Using ms As MemoryStream = compressPhotoToJPG(gbl_WS_Img_Send, JPGCompressLevel)
                            PrepareImageAndSend(ms.ToArray, 1, 0, Nothing)
                        End Using

                        ' PrepareImageAndSend(compressPhotoToWebp(gbl_WS_Img_Send, JPGCompressLevel), 1, 0, Nothing)

                    Catch ex As Exception
                    End Try
                    gbl_WS_Img_Send.Dispose()
                End If

            Loop

            isWS_Img_thread_running = False

        End Sub

        Private Function MergePixelLocations(tilesCount As UShort, ByRef tilesUpdated As List(Of TileInfo)) As Byte()
            Dim len As Integer = tilesCount - 1
            Dim intArry((tilesCount * 4) - 1) As Byte
            Dim x As Integer = 0
            For i As Integer = 0 To len
                x = i * 4

                Buffer.BlockCopy(tilesUpdated(i).Index_X, 0, intArry, x, 2)
                Buffer.BlockCopy(tilesUpdated(i).Index_Y, 0, intArry, x + 2, 2)

            Next
            Return intArry
        End Function

        Private Function createBitmapFromBytes(tilesCount As UShort, ByRef mergeArry As Byte()) As Bitmap
            Dim newrect As New Rectangle(0, 0, gbl_TitleBoxSize, tilesCount * gbl_TitleBoxSize)
            Dim newBitmap As New Bitmap(newrect.Width, newrect.Height, JPGBits)

            Dim ImgPixelData As BitmapData = newBitmap.LockBits(newrect, ImageLockMode.WriteOnly, JPGBits)

            Dim imageColumnPixlWidth As Integer = Math.Abs(ImgPixelData.Stride) ' width * bytesPerPixel
            Dim len_bytes As Integer = imageColumnPixlWidth * newrect.Height
            Marshal.Copy(mergeArry, 0, ImgPixelData.Scan0, len_bytes)
            newBitmap.UnlockBits(ImgPixelData)

            Return newBitmap
        End Function

        Private Function MergeByteArrysFromList(ByRef tilesUpdated As List(Of TileInfo)) As Byte()
            Dim len As Integer = tilesUpdated.Count
            Dim tileBytesWidth As Integer = gbl_TitleBoxSize * (gbl_TitleBoxSize * gbl_ImgBitWidthLen) ' gbl_PixlWidthLen = 2 = 16 bit = 2pixels per color

            Dim byteArry((len * tileBytesWidth) - 1) As Byte
            Try
                For i As Integer = 0 To len - 1
                    Array.Copy(tilesUpdated(i).byteArry, 0, byteArry, i * tileBytesWidth, tileBytesWidth)
                Next
            Catch ex As Exception
            End Try

            Return byteArry
        End Function

        Friend Record_framenumber As Long = 0
        Private Record_framenumber_MAX As Long = Long.MaxValue - 10
        Private Sub PrepareImageAndSend(ByRef byteArry As Byte(), ByVal sendType As UShort, ByRef TilesCount As UShort, ByRef PointsArry As Byte())
            Try

                If Record_framenumber > Record_framenumber_MAX Then
                    Record_framenumber = 2
                Else
                    Record_framenumber += 1
                End If


                Dim bframe As Byte() = BitConverter.GetBytes(Record_framenumber)
                Dim btype As Byte() = BitConverter.GetBytes(sendType)
                Dim ImgByteLen As Integer = byteArry.Length
                Dim numOfChunks As UShort = 0

                If ImgByteLen < gbl_chunkSize Then ' 10 kb
                    numOfChunks = 0
                Else


                    Dim chunksLen As Integer = Math.Floor(ImgByteLen / gbl_chunkSize) - 1
                    Dim ReminderLen As Integer = ImgByteLen Mod gbl_chunkSize

                    last_chunksLen = chunksLen
                    last_ReminderLen = ReminderLen

                    If ReminderLen > 0 Then
                        numOfChunks = chunksLen + 1
                    Else
                        numOfChunks = chunksLen
                    End If
                End If


                Dim bNumOfChunks As Byte() = BitConverter.GetBytes(numOfChunks)
                Dim bImgArryLen As Byte() = BitConverter.GetBytes(ImgByteLen)


                last_numOfChunks = numOfChunks
                last_ImgByteLen = ImgByteLen
                last_bImgArryLen = bImgArryLen
                last_byteArry = byteArry
                last_bframe = bframe


                If sendType = 1 Then ' 1=fullimage, 2= tiles

                    ' Debug.Print("Sending Full Image  ")

                    Dim chunkObj As Byte()

                    If myApp.MyConn.connectionType = enum_ConnectType.WS Then ' full image one shot
                        chunkObj = New Byte(15 + ImgByteLen) {}
                    Else
                        chunkObj = New Byte(15) {}
                    End If

                    Buffer.BlockCopy(btype, 0, chunkObj, 0, 2) ' send type = 1
                    Buffer.BlockCopy(bframe, 0, chunkObj, 2, 8)  ' bframe stamp
                    Buffer.BlockCopy(bNumOfChunks, 0, chunkObj, 10, 2)  ' Num Of Chunks
                    Buffer.BlockCopy(bImgArryLen, 0, chunkObj, 12, 4)  ' image byte len

                    If myApp.MyConn.connectionType = enum_ConnectType.WS Then
                        Buffer.BlockCopy(byteArry, 0, chunkObj, 16, ImgByteLen) ' img byte arry
                        sendImageArry(chunkObj)

                    Else 'udp
                        sendImageArry(chunkObj)

                        continueImageBodySend()
                    End If


                ElseIf sendType = 2 Then

                    Dim pointsArryLen As Integer = PointsArry.Length
                    Dim bTilesCount As Byte() = BitConverter.GetBytes(TilesCount)
                    Dim bPointsArryLen As Byte() = BitConverter.GetBytes(pointsArryLen)

                    Dim chunkObj As Byte()

                    If myApp.MyConn.connectionType = enum_ConnectType.WS Then ' full tiles one shot
                        chunkObj = New Byte(21 + pointsArryLen + ImgByteLen) {}
                    Else
                        chunkObj = New Byte(21 + pointsArryLen) {}
                    End If

                    Buffer.BlockCopy(btype, 0, chunkObj, 0, 2) ' send type = 2
                    Buffer.BlockCopy(bframe, 0, chunkObj, 2, 8)  ' bframe stamp
                    Buffer.BlockCopy(bNumOfChunks, 0, chunkObj, 10, 2)  ' Num Of Chunks
                    Buffer.BlockCopy(bImgArryLen, 0, chunkObj, 12, 4)  ' image byte len

                    Buffer.BlockCopy(bTilesCount, 0, chunkObj, 16, 2)  ' Tiles Count
                    Buffer.BlockCopy(bPointsArryLen, 0, chunkObj, 18, 4) ' points byte arry len
                    Buffer.BlockCopy(PointsArry, 0, chunkObj, 22, pointsArryLen)  ' pointsarry

                    If myApp.MyConn.connectionType = enum_ConnectType.WS Then

                        Buffer.BlockCopy(byteArry, 0, chunkObj, 22 + pointsArryLen, ImgByteLen) ' img byte arry
                        sendImageArry(chunkObj)
                    Else
                        sendImageArry(chunkObj)

                        continueImageBodySend()
                    End If

                End If

                ' Threading.Monitor.Enter(ImageLockObj)


            Catch ex As Exception
            End Try

            'Try
            '    Threading.Monitor.Exit(ImageLockObj)
            'Catch ex As Exception : End Try
        End Sub

        Private last_chunksLen As Integer
        Private last_ReminderLen As Integer
        Private last_numOfChunks As UShort
        Private last_ImgByteLen As Integer
        Private last_bImgArryLen As Byte()
        Private last_byteArry As Byte()
        Private last_bframe As Byte()


        Friend Sub continueImageBodySend()
            Try

                ' Debug.Print("Sending continueImageBodySend ")
                Dim bSubType As Byte() = BitConverter.GetBytes(CUShort(3))
                Using ms As New MemoryStream

                    If last_ImgByteLen < gbl_chunkSize Then ' 62 kb
                        'Debug.Print("Sending Chunk Len  Only 1")
                        Dim bChunkPosition As Byte() = BitConverter.GetBytes(CUShort(0))

                        Dim chunkObj As Byte() = New Byte(15 + last_ImgByteLen) {}
                        Buffer.BlockCopy(bSubType, 0, chunkObj, 0, 2) ' send type = 3
                        Buffer.BlockCopy(last_bframe, 0, chunkObj, 2, 8)  ' bframe stamp
                        Buffer.BlockCopy(bChunkPosition, 0, chunkObj, 10, 2)  ' chunk arry position
                        Buffer.BlockCopy(last_bImgArryLen, 0, chunkObj, 12, 4) ' chunk byte Len
                        Buffer.BlockCopy(last_byteArry, 0, chunkObj, 16, last_ImgByteLen) ' img byte arry
                        sendImageArry(chunkObj)

                    Else

                        '  Debug.Print("Sending Chunk Len  " & last_chunksLen & " / " & last_numOfChunks)

                        For x As Integer = 0 To last_chunksLen
                            If isRecordingOn Then
                                Dim bChunkPosition As Byte() = BitConverter.GetBytes(CUShort(x))
                                Dim bChunkLen As Byte() = BitConverter.GetBytes(gbl_chunkSize)

                                Dim chunkObj As Byte() = New Byte(15 + gbl_chunkSize) {}
                                Buffer.BlockCopy(bSubType, 0, chunkObj, 0, 2) ' send type = 3
                                Buffer.BlockCopy(last_bframe, 0, chunkObj, 2, 8)  ' bframe stamp
                                Buffer.BlockCopy(bChunkPosition, 0, chunkObj, 10, 2)  ' chunk arry position
                                Buffer.BlockCopy(bChunkLen, 0, chunkObj, 12, 4) ' chunk byte Len
                                Buffer.BlockCopy(last_byteArry, x * gbl_chunkSize, chunkObj, 16, gbl_chunkSize) ' img byte arry

                                sendImageArry(chunkObj)
                                'Try
                                '    If myApp.MyConn.connectionType = enum_ConnectType.WS Then Threading.Thread.Sleep(10)
                                'Catch ex As Exception
                                'End Try

                            End If
                        Next

                        If last_ReminderLen > 0 AndAlso isRecordingOn Then
                            Dim x As Integer = last_chunksLen + 1
                            Dim bChunkPosition As Byte() = BitConverter.GetBytes(CUShort(x))
                            Dim bChunkLen As Byte() = BitConverter.GetBytes(last_ReminderLen)

                            Dim chunkObj As Byte() = New Byte(15 + last_ReminderLen) {}

                            Buffer.BlockCopy(bSubType, 0, chunkObj, 0, 2) ' send type = 3
                            Buffer.BlockCopy(last_bframe, 0, chunkObj, 2, 8)  ' bframe stamp
                            Buffer.BlockCopy(bChunkPosition, 0, chunkObj, 10, 2)  ' chunk arry position
                            Buffer.BlockCopy(bChunkLen, 0, chunkObj, 12, 4) ' chunk byte Len
                            Buffer.BlockCopy(last_byteArry, x * gbl_chunkSize, chunkObj, 16, last_ReminderLen) ' img byte arry
                            sendImageArry(chunkObj)

                        End If

                    End If
                End Using
            Catch ex As Exception

            End Try
        End Sub


        Friend Sub sendImageArry(ByRef barry As Byte())

            If myApp.MyConn.IsRemotePCConnected Then myApp.MyConn.SendRequestAsByte(barry, wsArry_ScreenIndex)

        End Sub

        Private ws_CurrentImage As WS_Image


        Friend Sub WS_OnMessageBytesImage(ByRef msg As Byte(), ByRef sendType As UShort)
            If IsNothing(frmScreenControlObj) Then Return

            Try

                If myApp.MyConn.connectionType = enum_ConnectType.WS Then
                    ws_CurrentImage = New WS_Image(msg, sendType)


                    Dim d As New functionWithParamImage(AddressOf frmScreenControlObj.updateImgViewer)
                    frmScreenControlObj.BeginInvoke(d, New Object() {ws_CurrentImage})

                    '  End If
                Else

                    If sendType = 1 Then 'image header  full 

                        Dim sframe As Long = BitConverter.ToInt64(msg, 2)
                        Dim NumOfChunks As UShort = BitConverter.ToInt16(msg, 10)
                        Dim imgLen As Integer = BitConverter.ToInt32(msg, 12)

                        '  Debug.Print("Before ImageHeader: " & gblTimer.ElapsedMilliseconds)

                        ws_CurrentImage = New WS_Image(sendType, sframe, NumOfChunks, imgLen)

                        '  Debug.Print("After ImageHeader: " & gblTimer.ElapsedMilliseconds)

                    ElseIf sendType = 2 Then 'image header tiles 

                        Dim sframe As Long = BitConverter.ToInt64(msg, 2)
                        Dim NumOfChunks As UShort = BitConverter.ToInt16(msg, 10)
                        Dim imgLen As Integer = BitConverter.ToInt32(msg, 12)

                        Dim TilesCount As UShort = BitConverter.ToInt16(msg, 16)

                        Dim bPointsLen As Integer = BitConverter.ToInt32(msg, 18)
                        Dim bPoints(bPointsLen - 1) As Byte
                        Buffer.BlockCopy(msg, 22, bPoints, 0, bPointsLen)

                        Dim pointslen As Integer = TilesCount - 1
                        Dim points(pointslen) As Point

                        Dim x As Integer = 0
                        For i As Integer = 0 To pointslen
                            x = i * 4
                            points(i) = New Point
                            points(i).X = BitConverter.ToUInt16(bPoints, x)
                            points(i).Y = BitConverter.ToUInt16(bPoints, x + 2)
                        Next


                        ws_CurrentImage = New WS_Image(sendType, sframe,
                                                                          NumOfChunks, imgLen,
                                                                          TilesCount, points)

                    ElseIf sendType = 3 Then 'image body multi part msg

                        Dim sframe As Long = BitConverter.ToInt64(msg, 2)
                        If sframe = ws_CurrentImage.frame Then

                            If ws_CurrentImage.addChunk(msg) Then
                                ' Debug.Print("After chunk End: " & gblTimer.ElapsedMilliseconds)

                                'Try
                                '    If frmViewerObj.firstImageReceived Then
                                '        'frmViewerObj.gbl_image.Dispose()

                                '    Else
                                '         
                                '    End If
                                'Catch ex As Exception
                                'End Try

                                Dim d As New functionWithParamImage(AddressOf frmScreenControlObj.updateImgViewer)
                                frmScreenControlObj.BeginInvoke(d, New Object() {ws_CurrentImage})


                                If myApp.MyConn.connectionType = enum_ConnectType.WS Then
                                    myApp.MyConn.SendRequestAsByte(sendType_ImgNextFrame, wsArry_ScreenIndex)

                                Else

                                End If

                            End If

                        Else
                            ' Debug.Print("Frame Skipped: " & gblTimer.ElapsedMilliseconds)

                        End If
                    End If
                End If

                msg = Nothing

            Catch ex As Exception
            End Try

            Try
                ' Threading.Monitor.Exit(ImageLock)
                ' lblArry(wsIndex).Text = CInt(imageByte.Length / 1024)
            Catch ex As Exception
            End Try
        End Sub

        Friend Class WS_Image

            Friend imageType As UShort = 2
            Friend bm_Length As Integer
            Friend bm As Bitmap = Nothing
            Friend bm_bArry As Byte() = Nothing
            Friend pt As Point() = Nothing
            Friend frame As Long
            Friend numOfChunks As UShort
            Friend tileCount As UShort

            Friend isReady As Boolean = False

            Friend chunkCounter As Integer = 0

            Private LocalImageLock As New Object

            Friend Function addChunk(ByRef msg As Byte()) As Boolean
                ' Dim isNextFrameSent As Boolean = False
                Try
                    Threading.Monitor.Enter(LocalImageLock)

                    'Dim sframe As Long = BitConverter.ToInt64(msg, 2)
                    Dim chunkPosition As UShort = BitConverter.ToInt16(msg, 10)
                    Dim chunkLen As Integer = BitConverter.ToInt32(msg, 12)

                    ' If numOfChunks = chunkCounter Then Return True

                    Buffer.BlockCopy(msg, 16, bm_bArry, chunkPosition * gbl_chunkSize, chunkLen)
                    chunkCounter += 1
                    ' Debug.Print("Chunk " & chunkCounter & " / " & numOfChunks)
                    If numOfChunks = chunkCounter Then

                        'Using WebPObj As New WebP()
                        '    bm = WebPObj.Decode(bm_bArry)
                        'End Using

                        Using ms As MemoryStream = New MemoryStream(bm_bArry)
                            Try
                                bm = Bitmap.FromStream(ms, False, True)
                            Catch ex As Exception
                            End Try
                        End Using

                        Try
                            Threading.Monitor.Exit(LocalImageLock)
                        Catch ex As Exception
                        End Try
                        isReady = True
                        Return True

                    End If
                Catch ex As Exception
                    ' Debug.Print("Error Chunk " & ex.Message)
                    ' Dispose()
                    ' WS_SendByteCommand(sendType_NextFrame)
                    ' Debug.Print("Err addChunk")
                End Try

                Try
                    Threading.Monitor.Exit(LocalImageLock)
                Catch ex As Exception
                End Try
                Return False
            End Function

            Sub New(ByRef msg As Byte(), ByRef ws_imageType As Integer)
                Try

                    imageType = ws_imageType

                    Dim imgLen As Integer = BitConverter.ToInt32(msg, 12)
                    bm_bArry = New Byte(imgLen - 1) {}

                    If ws_imageType = 1 Then

                        Buffer.BlockCopy(msg, 16, bm_bArry, 0, imgLen)

                    ElseIf ws_imageType = 2 Then

                        tileCount = BitConverter.ToInt16(msg, 16)

                        Dim bPointsLen As Integer = BitConverter.ToInt32(msg, 18)
                        Dim bPoints(bPointsLen - 1) As Byte
                        Buffer.BlockCopy(msg, 22, bPoints, 0, bPointsLen)

                        Dim pointslen As Integer = tileCount - 1
                        pt = New Point(pointslen) {}

                        Dim x As Integer = 0
                        For i As Integer = 0 To pointslen
                            x = i * 4
                            pt(i) = New Point
                            pt(i).X = BitConverter.ToUInt16(bPoints, x)
                            pt(i).Y = BitConverter.ToUInt16(bPoints, x + 2)
                        Next

                        Buffer.BlockCopy(msg, 22 + bPointsLen, bm_bArry, 0, imgLen)

                    End If

                    'Using WebPObj As New WebP()
                    '    bm = WebPObj.Decode(bm_bArry)
                    'End Using

                    Using ms As MemoryStream = New MemoryStream(bm_bArry)
                        Try
                            bm = Bitmap.FromStream(ms, False, True)
                        Catch ex As Exception
                        End Try
                    End Using
                Catch ex As Exception

                End Try
            End Sub


            Sub New(ByRef ws_imageType As Integer, ByRef ws_frame As Long, ByRef ws_numOfChunks As UShort, ByRef ws_bm_Length As Integer)
                Try
                    Threading.Monitor.Enter(LocalImageLock)
                    imageType = ws_imageType
                    frame = ws_frame
                    numOfChunks = ws_numOfChunks + 1
                    bm_Length = ws_bm_Length

                    bm_bArry = New Byte(bm_Length - 1) {}
                Catch ex As Exception
                End Try

                Try
                    Threading.Monitor.Exit(LocalImageLock)
                Catch ex As Exception
                End Try
            End Sub

            Sub New(ByRef ws_imageType As Integer, ByRef ws_frame As Long,
                    ByRef ws_numOfChunks As UShort, ByRef ws_bm_Length As Integer,
                    ByRef ws_tileCount As UShort, ByRef ws_pt As Point())
                Try
                    Threading.Monitor.Enter(LocalImageLock)
                    imageType = ws_imageType
                    frame = ws_frame
                    numOfChunks = ws_numOfChunks + 1
                    bm_Length = ws_bm_Length
                    tileCount = ws_tileCount
                    pt = ws_pt

                    bm_bArry = New Byte(bm_Length - 1) {}

                Catch ex As Exception
                End Try

                Try
                    Threading.Monitor.Exit(LocalImageLock)
                Catch ex As Exception
                End Try
            End Sub

            Friend Sub Dispose()
                Try
                    If Not IsNothing(bm) Then bm.Dispose()
                Catch ex As Exception
                End Try

                bm = Nothing
                bm_bArry = Nothing
                pt = Nothing
            End Sub

        End Class
    End Class

End Module
