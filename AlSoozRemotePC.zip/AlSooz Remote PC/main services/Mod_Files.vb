﻿Imports System.IO
Imports System.Text

Module Mod_Files

    Private fileReadBuffer As Integer = 20480
    Friend Sub UpdateUiFileAction(ByRef msg As String)
        Try

            If Not IsNothing(frmFilesObj) AndAlso frmFilesObj.Visible Then

                If frmFilesObj.InvokeRequired Then

                    Try
                        Dim d As New functionWithParamString(AddressOf UpdateUiFileAction)
                        frmFilesObj.BeginInvoke(d, New Object() {msg})
                    Catch ex As Exception
                    End Try


                Else
                    Dim txtArry As String() = msg.Split("|")
                    frmFilesObj.lbl_FileProgress1.Text = txtArry(0)
                    frmFilesObj.lbl_FileProgress2.Text = txtArry(1)

                End If
            End If
        Catch ex As Exception

        End Try
    End Sub



    Friend Class fileShareClass

        Friend ReceivePath As String = ""

        Friend LastLog As New List(Of String())
        Private Class fileChunkClass
            Friend chunkIndex As Integer
            Friend chunkByteArry As Byte() = Nothing
        End Class

        Private last_files As String()
        Private lst_file_len As Integer = 0

        Private fbytelenInKb As UInteger = 0
        Friend Sub FileShare_SendFiles(ByVal files As String())

            last_files = files
            lst_file_len = files.Count - 1
            last_file_Index = -1
            If myApp.MyConn.connectionType = enum_ConnectType.WS Then
                If myApp.MyConn.WS_Service_Open(wsArry_FileIndex, True) Then prepareAndSendNextFileHeader()
            Else
                prepareAndSendNextFileHeader()
            End If

        End Sub

        Private isTransferSendCompleted As Boolean = True
        Private isTransferRecvCompleted As Boolean = True

        Friend Sub setFileSendBlockedByPolicy()
            isTransferRecvCompleted = True
            LastLog.Add(New String() {"fileSentBlocked", "", myApp.getDateTime})
            Dim strb As New StringBuilder

            isTransferSendCompleted = True


            strb.Append("Sent Blocked: ").Append((lst_file_len + 1))
            strb.Append("|")
            UpdateUiFileAction(strb.ToString)

            sendFileArry(sendType_SendFileTransferCompleted)

            myApp.MyConn.WS_Service_Close(wsArry_FileIndex, True)
        End Sub

        Friend Sub setFileReceiveBlockedByPolicy()
            isTransferRecvCompleted = True
            isTransferRecvCompleted = True
            LastLog.Add(New String() {"fileReceiveBlocked", "", myApp.getDateTime})
            myApp.MyConn.WS_Service_Close(wsArry_FileIndex, True)
        End Sub

        Friend Sub setFileReceiveCompleted()
            isTransferRecvCompleted = True
            LastLog.Add(New String() {"fileRecCompleted", "", myApp.getDateTime})
        End Sub

        Friend Sub fileSendTransferCompleted()
            Dim strb As New StringBuilder

            isTransferSendCompleted = True
            LastLog.Add(New String() {"fileSendCompleted", "", myApp.getDateTime})

            strb.Append("Sent Files: ").Append((lst_file_len + 1))
            strb.Append("|")
            UpdateUiFileAction(strb.ToString)

            sendFileArry(sendType_SendFileTransferCompleted)

            myApp.MyConn.WS_Service_Close(wsArry_FileIndex, True)
        End Sub

        Friend Sub prepareAndSendNextFileHeader()

            last_file_Index += 1

            Dim strb As New StringBuilder

            If myApp.MyConn.connectionType = enum_ConnectType.WS Then
                If myApp.MyConn.isServiceOpen_WS_File = False Then
                    LastLog.Add(New String() {"fileSendError", "", myApp.getDateTime})
                    strb.Append("Send Error:|Service Not Opened")
                    UpdateUiFileAction(strb.ToString)
                    Return
                End If
            Else

            End If

            If last_file_Index > lst_file_len Then

                fileSendTransferCompleted()

                Return 'completed transfer all files

            Else
                isTransferSendCompleted = False
                Dim filename As String = last_files(last_file_Index).Substring(last_files(last_file_Index).LastIndexOf("\") + 1)
                LastLog.Add(New String() {"fileSend", filename, myApp.getDateTime})

            End If

            Dim fInfo As New FileInfo(last_files(last_file_Index))

            Dim fByteLen As Long = fInfo.Length

            fbytelenInKb = Math.Ceiling(fByteLen / 1024)
            strb.Append("Sending File: ").Append((last_file_Index + 1)).Append(" of ").Append((lst_file_len + 1))
            strb.Append("|")
            strb.Append(fbytelenInKb).Append(" Kb").Append("  /  ")
            strb.Append("0 %")
            UpdateUiFileAction(strb.ToString)

            Dim lst_chunk As New List(Of fileChunkClass)
            Try

                Using fs As FileStream = New FileStream(last_files(last_file_Index), FileMode.Open, FileAccess.Read, FileShare.Read, fileReadBuffer, FileOptions.SequentialScan)


                    If fByteLen < gbl_chunkSize Then ' 10 kb
                        Dim chunkObj As Byte() = New Byte(fByteLen - 1) {}
                        fs.Read(chunkObj, 0, fByteLen)
                        addFileChunkToList(lst_chunk, chunkObj, 0)
                    Else

                        Dim chunksLen As Integer = Math.Floor(fByteLen / gbl_chunkSize) - 1
                        Dim ReminderLen As Integer = fByteLen Mod gbl_chunkSize

                        For x As Integer = 0 To chunksLen  ' out of Memory error in here
                            Dim chunkObj As Byte() = New Byte(gbl_chunkSize - 1) {}
                            fs.Read(chunkObj, 0, gbl_chunkSize)
                            addFileChunkToList(lst_chunk, chunkObj, x)
                        Next

                        If ReminderLen > 0 Then  ' out of Memory error in here
                            Dim x As Integer = chunksLen + 1
                            Dim chunkObj As Byte() = New Byte(ReminderLen - 1) {}
                            fs.Read(chunkObj, 0, ReminderLen)
                            addFileChunkToList(lst_chunk, chunkObj, x)

                        End If

                    End If

                End Using


                last_lst_chunk_Count = lst_chunk.Count - 1

                last_lst_chunk = lst_chunk

                last_chunkSentIndex = -1

                Using ms As New MemoryStream
                    Dim filename As String = last_files(last_file_Index).Substring(last_files(last_file_Index).LastIndexOf("\") + 1)
                    Dim bfilename As Byte() = Text.Encoding.UTF8.GetBytes(filename)

                    Dim sendType As UShort = 5 ' file share - header

                    ms.Write(BitConverter.GetBytes(sendType), 0, 2) ' send type
                    ms.Write(BitConverter.GetBytes(last_file_Index), 0, 4) ' File Transfer Unique ID

                    ms.Write(BitConverter.GetBytes(fByteLen), 0, 8) ' file size
                    ms.Write(BitConverter.GetBytes(lst_file_len), 0, 4) ' lst_file_len

                    ms.Write(BitConverter.GetBytes((last_lst_chunk_Count + 1)), 0, 4) ' file chunk count
                    ms.Write(BitConverter.GetBytes(bfilename.Length), 0, 4) ' filename size
                    ms.Write(bfilename, 0, bfilename.Length)

                    sendFileArry(ms.ToArray)

                End Using

            Catch ex As Exception

                prepareAndSendNextFileHeader()

            End Try
        End Sub

        Friend Sub continueAfterHeaderReceved()
            'Dim len As Integer = 1
            'If last_lst_chunk_Count < len Then len = last_lst_chunk_Count
            'For i As Integer = 0 To len
            'If myApp.MyConn.mySocketType = "ws" Then

            'Else
            '    Threading.Thread.Sleep(20)
            'End If

            continueFileBodySend()
            '    Threading.Thread.Sleep(500)
            'Next
        End Sub

        Private last_lst_chunk As List(Of fileChunkClass) = Nothing
        Private last_file_Index As Integer = 0
        Private last_lst_chunk_Count As Integer = 0


        Private last_chunkSentIndex As Integer = 0

        Private lockFileContinueObj As New Object

        Friend Sub continueFileBodySend()
            Dim chunkindex As Integer = 0

            Try
                Threading.Monitor.Enter(lockFileContinueObj)
                chunkindex = last_chunkSentIndex + 1
                last_chunkSentIndex += 1

                If last_chunkSentIndex > last_lst_chunk_Count Then
                    Try
                        Threading.Monitor.Exit(lockFileContinueObj)
                    Catch ex As Exception
                    End Try
                    Return
                End If

            Catch ex As Exception
            End Try
            Try
                Threading.Monitor.Exit(lockFileContinueObj)
            Catch ex As Exception
            End Try

            Using ms As New MemoryStream
                Dim sendType As UShort = 6 ' file share - chunks

                ms.Write(BitConverter.GetBytes(sendType), 0, 2) ' send type
                ms.Write(BitConverter.GetBytes(last_file_Index), 0, 4) ' File Transfer Unique ID

                ms.Write(BitConverter.GetBytes(last_lst_chunk(chunkindex).chunkIndex), 0, 4) ' chunk index
                ms.Write(BitConverter.GetBytes(last_lst_chunk(chunkindex).chunkByteArry.Length), 0, 4) ' chunk size
                ms.Write(last_lst_chunk(chunkindex).chunkByteArry, 0, last_lst_chunk(chunkindex).chunkByteArry.Length)  ' chunk

                sendFileArry(ms.ToArray)

            End Using

            Dim strb As New StringBuilder
            strb.Append("Sending: ").Append((last_file_Index + 1)).Append(" of ").Append((lst_file_len + 1))
            strb.Append("|")
            strb.Append(fbytelenInKb).Append(" Kb").Append("  /  ")

            Dim progress As Integer = (chunkindex / (last_lst_chunk_Count + 1)) * 100
            strb.Append(progress).Append(" %")
            UpdateUiFileAction(strb.ToString)

            'If myApp.MyConn.mySocketType = "ws" Then

            'Else

            '    Threading.Thread.Sleep(30)
            '    continueFileBodySend()

            'End If
        End Sub


        Friend Sub sendFileArry(ByRef barry As Byte())

            myApp.MyConn.SendRequestAsByte(barry, wsArry_FileIndex)

        End Sub

        Private ws_CurrentFile As WS_File

        Private Class WS_File

            Friend filename As String
            Friend fileID As Integer = 0
            Friend filesize As Long = 0
            Friend fileByteArry As Byte()
            Private numOfChunks As Integer = 0
            Private chunkCounter As Integer = 0
            Private LocalFileLock As New Object
            Friend isReady As Boolean = False
            Friend numOfFiles As Integer = 0
            Sub New(ByRef ws_numOfFiles As Integer, ByRef ws_fileID As Integer, ByRef ws_filename As String, ByRef ws_numOfChunks As UShort, ByRef ws_filesize As Integer)
                numOfFiles = ws_numOfFiles
                fileID = ws_fileID
                filename = ws_filename

                numOfChunks = ws_numOfChunks
                filesize = ws_filesize

                fileByteArry = New Byte(filesize - 1) {}

            End Sub

            Friend Function addChunk(ByRef msg As Byte()) As Boolean
                Try
                    Threading.Monitor.Enter(LocalFileLock)

                    ' Dim ws_fileID As Integer = BitConverter.ToInt32(msg, 2)
                    Dim chunkIndex As Integer = BitConverter.ToInt32(msg, 6)
                    Dim chunkLen As Integer = BitConverter.ToInt32(msg, 10)

                    Buffer.BlockCopy(msg, 14, fileByteArry, chunkIndex * gbl_chunkSize, chunkLen)
                    chunkCounter += 1

                    Dim strb As New StringBuilder
                    strb.Append("Receiving: ").Append((fileID + 1)).Append(" of ").Append((numOfFiles + 1))
                    strb.Append("|")
                    Dim filesizeInKb As Integer = Math.Ceiling(filesize / 1024)
                    strb.Append(filesizeInKb).Append(" Kb").Append("  /  ")


                    If numOfChunks = chunkCounter Then

                        strb.Append("100 %")
                        UpdateUiFileAction(strb.ToString)

                        Try
                            Threading.Monitor.Exit(LocalFileLock)
                        Catch ex As Exception
                        End Try
                        isReady = True
                        Return True

                    Else
                        Dim progress As Integer = (chunkCounter / (numOfChunks)) * 100
                        strb.Append(progress).Append(" %")
                        UpdateUiFileAction(strb.ToString)

                        If progress = 100 Then
                            Dim t As String = ""
                        End If
                    End If
                Catch ex As Exception
                End Try


                Try
                    Threading.Monitor.Exit(LocalFileLock)
                Catch ex As Exception
                End Try

                Return False
            End Function
        End Class



        Friend Sub WS_OnMessageBytesFile(ByRef msg As Byte(), ByRef sendType As UShort)

            If sendType = 5 Then

                If isTransferRecvCompleted Then


                    isTransferRecvCompleted = False
                End If

                'MS.Write(BitConverter.GetBytes(fByteLen), 0, 8) ' file size
                'MS.Write(BitConverter.GetBytes(lst_file_len), 0, 4) ' lst_file_len

                'MS.Write(BitConverter.GetBytes((last_lst_chunk_Count + 1)), 0, 4) ' file chunk count

                Dim ws_fileID As Integer = BitConverter.ToInt32(msg, 2)
                Dim ws_filesize As Integer = BitConverter.ToInt64(msg, 6)

                Dim ws_NumOfFiles As Integer = BitConverter.ToInt32(msg, 14)

                Dim ws_numOfChunks As Integer = BitConverter.ToInt32(msg, 18)
                Dim ws_bfilenameLen As Integer = BitConverter.ToInt32(msg, 22)
                Dim ws_filename As String = Text.Encoding.UTF8.GetString(msg, 26, ws_bfilenameLen)

                ws_CurrentFile = New WS_File(ws_NumOfFiles, ws_fileID, ws_filename, ws_numOfChunks, ws_filesize)

                LastLog.Add(New String() {"fileRec", ws_filename, myApp.getDateTime})

                Dim strb As New StringBuilder
                strb.Append("Receiving: ").Append((ws_fileID + 1)).Append(" of ").Append((ws_NumOfFiles + 1))
                strb.Append("|")
                Dim filesizeInKb As Integer = Math.Ceiling(ws_filesize / 1024)
                strb.Append(filesizeInKb).Append(" Kb").Append("  /  ")

                strb.Append("0 %")
                UpdateUiFileAction(strb.ToString)

            ElseIf sendType = 6 Then

                If ws_CurrentFile.addChunk(msg) Then

                    Dim strb As New StringBuilder

                    strb.Append(ReceivePath).Append("\").Append(ws_CurrentFile.filename)

                    Dim fileFoundCount As Integer = 0

newfilepath:

                    If My.Computer.FileSystem.FileExists(strb.ToString) Then
                        fileFoundCount += 1

                        Dim fileExten As String = ws_CurrentFile.filename.Substring(ws_CurrentFile.filename.LastIndexOf("."))
                        Dim fileNameNoExten As String = ws_CurrentFile.filename.Substring(0, ws_CurrentFile.filename.LastIndexOf("."))
                        strb.Clear()
                        strb.Append(ReceivePath).Append("\")
                        strb.Append(fileNameNoExten)
                        strb.Append("_")
                        strb.Append(fileFoundCount)
                        strb.Append(fileExten)
                        GoTo newfilepath

                    End If
                    Try
                        Using fs As New FileStream(strb.ToString, FileMode.CreateNew, FileAccess.Write, FileShare.Read)
                            fs.Write(ws_CurrentFile.fileByteArry, 0, ws_CurrentFile.filesize)
                        End Using
                    Catch ex As Exception

                    End Try

                    myApp.MyConn.SendRequestAsByte(sendType_fileNextFile, wsArry_FileIndex)

                    If ws_CurrentFile.fileID >= ws_CurrentFile.numOfFiles Then

                        strb.Clear()

                        strb.Append("Receive Completed: ").Append((ws_CurrentFile.numOfFiles + 1))
                        strb.Append("|")
                        UpdateUiFileAction(strb.ToString)

                    End If
                Else

                    myApp.MyConn.SendRequestAsByte(sendType_fileContinueNextChunk, wsArry_FileIndex)

                    'If myApp.MyConn.mySocketType = "ws" Then

                    'Else

                    'End If

                End If

            End If

        End Sub


        Private Sub addFileChunkToList(ByRef lst As List(Of fileChunkClass), ByRef filechunk As Byte(), ByVal chunkindex As Integer)
            Try
                Dim chunkObj As New fileChunkClass
                chunkObj.chunkIndex = chunkindex
                chunkObj.chunkByteArry = filechunk
                lst.Add(chunkObj)
            Catch ex As Exception

            End Try

        End Sub
    End Class
End Module
