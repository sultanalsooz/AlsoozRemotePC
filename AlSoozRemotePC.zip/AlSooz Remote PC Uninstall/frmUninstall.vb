﻿Imports System.ServiceProcess

Public Class frmUninstall

    Private Gbl_FolderPath_User As String = "C:\ProgramData\AlSoozRemotePC\"
    Private Gbl_FolderPath_Admin As String = "C:\Program Files\AlSooz Remote PC\"

    Private Name_Service As String = "AlSoozRemotePCService.exe"
    Private Name_Service1 As String = "AlSoozRemotePCService.InstallLog"
    Private Name_Service2 As String = "AlSoozRemotePCService.InstallState"
    Private Name_Service3 As String = "InstallUtil.InstallLog"

    Private Name_Exe As String = "AlSoozRemotePC.exe"

    Private Name_Exe1 As String = "diskvalues.txt"

    Private Name_Config As String = "Config.txt"

    Friend Gbl_Serivce_Path As String = Gbl_FolderPath_Admin & "AlSoozRemotePCService.exe"
    Friend Gbl_Exe_Path As String = Gbl_FolderPath_Admin & "AlSoozRemotePC.exe"

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        lblstatus.Text = "Started Uninstall Task"
        unInstallService()

    End Sub

    Friend Sub UninstallApp()

        Try

            If My.Computer.FileSystem.DirectoryExists(Gbl_FolderPath_User) Then

                lblstatus.Text = "Removing App Files"

                    DeleteFile(Gbl_FolderPath_User & Name_Service1)
                    DeleteFile(Gbl_FolderPath_User & Name_Service2)
                    DeleteFile(Gbl_FolderPath_User & Name_Service3)
                    DeleteFile(Gbl_FolderPath_User & Name_Exe1)
                    DeleteFile(Gbl_FolderPath_User & Name_Config)
                    DeleteFile(Gbl_FolderPath_User & Name_Service)
                    DeleteFile(Gbl_FolderPath_User & Name_Exe)

            End If

            If My.Computer.FileSystem.DirectoryExists(Gbl_FolderPath_Admin) Then

                DeleteFile(Gbl_FolderPath_Admin & Name_Service1)
                DeleteFile(Gbl_FolderPath_Admin & Name_Service2)
                DeleteFile(Gbl_FolderPath_Admin & Name_Service3)
                DeleteFile(Gbl_FolderPath_Admin & Name_Exe1)
                DeleteFile(Gbl_FolderPath_Admin & Name_Config)
                DeleteFile(Gbl_FolderPath_Admin & Name_Service)

                lblstatus.Text = "Removing Main App"

                Dim p As New Threading.Thread(Sub()

                                                  Try
                                                      Threading.Thread.Sleep(3000)
                                                      If DeleteFile(Gbl_FolderPath_Admin & Name_Exe) Then
                                                          DeleteFolder(Gbl_FolderPath_Admin)
                                                          App_Close("ok")
                                                      Else
                                                          App_Close("err")
                                                      End If


                                                  Catch ex As Exception
                                                  End Try
                                              End Sub)
                p.Start()

            Else
                App_Close("ok")
            End If

        Catch ex As Exception
            App_Close("err")
        End Try


    End Sub


    Private Function DeleteFile(ByVal filename As String) As Boolean
        If My.Computer.FileSystem.FileExists(filename) Then
            Try
                My.Computer.FileSystem.DeleteFile(filename)
            Catch ex As Exception
                Return False
            End Try
        End If
        Return True
    End Function

    Private Sub DeleteFolder(ByVal FolderPath As String)
        If My.Computer.FileSystem.DirectoryExists(FolderPath) Then
            Try
                My.Computer.FileSystem.DeleteDirectory(FolderPath, FileIO.DeleteDirectoryOption.DeleteAllContents)
            Catch ex As Exception : End Try
        End If
    End Sub

    Private Sub App_Close(ByVal ExitString As String)
        Me.BeginInvoke(Sub()
                           Try
                               Label1.Text = "Done:"
                               If ExitString = "ok" Then
                                   lblstatus.Text = "Completed Uninstall Successfully"
                               Else
                                   lblstatus.Text = "Error Uninstalling App"
                               End If
                           Catch ex As Exception
                           End Try

                       End Sub)
        Dim p As New Threading.Thread(Sub()
                                          Try
                                              Threading.Thread.Sleep(2000)
                                              Me.BeginInvoke(Sub()
                                                                 Me.Close()
                                                             End Sub)
                                          Catch ex As Exception

                                          End Try
                                      End Sub)

        p.Start()

    End Sub


    Private InstallProcessErr As Boolean = False
    Friend Sub unInstallService()

        lblstatus.Text = "Uninstalling Service"
        Try

            If My.Computer.FileSystem.FileExists(Gbl_Serivce_Path) Then

                Dim psi As New ProcessStartInfo
                Dim ps As New Process

                With psi
                    .UseShellExecute = True
                    ' .RedirectStandardOutput = True ' must make UseShellExecute = false
                    .FileName = Gbl_Serivce_Path
                    .Arguments = "/u"
                    .WindowStyle = ProcessWindowStyle.Normal
                    .Verb = "runas" ' for admin
                End With

                ps.StartInfo = psi
                ps.EnableRaisingEvents = True

                '   AddHandler ps.OutputDataReceived, AddressOf ProcessOutputHandler

                AddHandler ps.Exited, New EventHandler(AddressOf ProcessUninstallExitedHandler)

                Dim err As String = ""
                Try
                    ps.Start()
                Catch ex As Exception
                    err = ex.Message
                End Try

                If err.Length > 1 Then
                    InstallProcessErr = True
                    MsgBox("Error occurred, service was not installed.")

                    'If err.IndexOf("canceled") > -1 Then

                    'End If
                End If

            Else
                UninstallApp()
            End If

        Catch ex As Exception
            InstallProcessErr = True
            MsgBox("Error: " & ex.Message)
        End Try

    End Sub

    Private Sub ProcessUninstallExitedHandler(sendingProcess As Object, e As System.EventArgs)
        Try

            If InstallProcessErr = False Then
                Threading.Thread.Sleep(500)

                Dim srvState As Enum_Servicestate = getUpdatedServiceState()

                If srvState = Enum_Servicestate.NotInstalled Then

                    Me.BeginInvoke(Sub()

                                       Try
                                           If My.Computer.FileSystem.FileExists(Gbl_Serivce_Path) Then
                                               My.Computer.FileSystem.DeleteFile(Gbl_Serivce_Path)
                                           End If

                                       Catch ex As Exception
                                       End Try

                                       UninstallApp()
                                       Return
                                   End Sub)
                    Return
                Else

                End If

            Else
                ' to be chanage to send back install status over websocket if connected

            End If
        Catch ex As Exception

        End Try
        Try
            Me.BeginInvoke(Sub()
                               lblstatus.Text = "Uninstalling Service Error"
                           End Sub)
        Catch ex As Exception
        End Try

    End Sub

    Friend Enum Enum_Servicestate
        NotInstalled
        Installed
        Running
        Uninstalled
        NoPermission
        ErrorInFunction
        Unknown
    End Enum

    Friend Function getUpdatedServiceState() As Enum_Servicestate
        Return getServiceState()
    End Function

    Friend Function getServiceState() As Enum_Servicestate
        Try
            Dim services As ServiceController() = ServiceController.GetServices()
            Dim len As Integer = services.Count - 1
            For i As Integer = 0 To len
                Dim serviceName As String = services(i).ServiceName
                If serviceName.IndexOf("AlSoozRemotePCService") > -1 Then

                    If services(i).Status = ServiceControllerStatus.Running Then
                        Return Enum_Servicestate.Running
                    Else
                        Return Enum_Servicestate.Installed
                    End If

                End If
            Next

            Return Enum_Servicestate.NotInstalled
        Catch ex As Exception
            Return Enum_Servicestate.NoPermission
        End Try
        Return Enum_Servicestate.Unknown

    End Function

End Class
