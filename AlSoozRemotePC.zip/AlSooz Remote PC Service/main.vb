﻿
Imports System.Reflection
Imports System.ServiceProcess


Public Class main

    <MTAThread()> Shared Sub Main()
        ' To run more than one service you have to add them to the array
        Dim args As System.Collections.ObjectModel.ReadOnlyCollection(Of String) = My.Application.CommandLineArgs

        If args.Count > 0 Then

            Dim str As String() = {}

            If args(0) = "/i" Then
                Try
                    If Not My.Computer.FileSystem.DirectoryExists(Gbl_Txt_FolderPath) Then My.Computer.FileSystem.CreateDirectory(Gbl_Txt_FolderPath)
                    If My.Computer.FileSystem.FileExists(Gbl_Txt_EXE_Service_Path) Then
                        My.Computer.FileSystem.DeleteFile(Gbl_Txt_EXE_Service_Path)
                        If My.Computer.FileSystem.FileExists(Gbl_Txt_LogFile_Path) Then
                            My.Computer.FileSystem.DeleteFile(Gbl_Txt_LogFile_Path)

                        End If

                        Threading.Thread.Sleep(100)
                    End If

                    Dim fullPathWithServiceExe As String = Assembly.GetExecutingAssembly().Location

                    My.Computer.FileSystem.CopyFile(fullPathWithServiceExe, Gbl_Txt_EXE_Service_Path)

                    Dim folderPath As String = fullPathWithServiceExe.Substring(0, fullPathWithServiceExe.LastIndexOf("\") + 1)

                    If My.Computer.FileSystem.FileExists(Gbl_Txt_EXE_TargetApp_Path) Then
                        My.Computer.FileSystem.DeleteFile(Gbl_Txt_EXE_TargetApp_Path)
                    End If

                    My.Computer.FileSystem.CopyFile(folderPath & Gbl_Txt_MainApp_Name, Gbl_Txt_EXE_TargetApp_Path)


                    str = {Gbl_Txt_EXE_Service_Path}
                Catch ex As Exception

                    Console.WriteLine("")
                    Console.WriteLine("(YOU MUST RUN AS ADMINISTRATOR)")
                    Console.WriteLine("err: " & ex.Message)
                    Return
                End Try


            ElseIf args(0) = "/u" Then
                str = {"/u", Gbl_Txt_EXE_Service_Path}

            End If

            If My.Computer.FileSystem.FileExists(Gbl_Txt_EXE_Service_Path) Then
                Try
                    System.Configuration.Install.ManagedInstallerClass.InstallHelper(str)

                Catch ex As Exception
                    Console.WriteLine(ex.Message)
                    Console.WriteLine("")
                    Console.WriteLine("(YOU MUST RUN AS ADMINISTRATOR)")
                    Console.WriteLine("err: " & ex.Message)
                End Try

            End If


        Else
            If Assembly.GetExecutingAssembly().Location = Gbl_Txt_EXE_Service_Path Then
                System.ServiceProcess.ServiceBase.Run(New System.ServiceProcess.ServiceBase() {New myservice})
            Else
                If isServiceInstalled() Then
                    Console.WriteLine("")
                    Console.WriteLine(Gbl_Txt_ServiceNameWithSpaces & " is already installed on this machine.")
                    Dim skey As ConsoleKeyInfo = Console.ReadKey()
                Else
                    Console.WriteLine("")
                    Console.WriteLine("(YOU MUST RUN AS ADMINISTRATOR)")
                    Console.WriteLine("")
                    Console.WriteLine("Do you want to install " & Gbl_Txt_ServiceNameWithSpaces & "? (Y/N)")

                    Dim skey As ConsoleKeyInfo = Console.ReadKey()
                    If skey.Key = ConsoleKey.Y Then
                        installService()
                    End If
                End If

            End If

        End If
    End Sub

    Private Shared Sub installService()
        If Not My.Computer.FileSystem.DirectoryExists(Gbl_Txt_FolderPath) Then My.Computer.FileSystem.CreateDirectory(Gbl_Txt_FolderPath)
        If Not My.Computer.FileSystem.FileExists(Gbl_Txt_EXE_Service_Path) Then My.Computer.FileSystem.CopyFile(Assembly.GetExecutingAssembly().Location, Gbl_Txt_EXE_Service_Path)
        Dim str As String() = {Gbl_Txt_EXE_Service_Path}

        If My.Computer.FileSystem.FileExists(Gbl_Txt_EXE_Service_Path) Then
            System.Configuration.Install.ManagedInstallerClass.InstallHelper(str)

        End If
        Dim skey As ConsoleKeyInfo = Console.ReadKey()
    End Sub


    Private Shared Function isServiceInstalled() As Boolean
        Dim servicesButNotDevices As ServiceController() = ServiceController.GetServices()

        For Each service As ServiceController In servicesButNotDevices
            Try
                If service.ServiceName = Gbl_Txt_ServiceName Then
                    Try
                        service.Start()
                    Catch ex As Exception

                    End Try

                    'service.Close()
                    Return True
                End If
            Catch ex As Exception
            End Try

        Next
        Return False
    End Function

End Class
