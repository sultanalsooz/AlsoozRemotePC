﻿Imports System.ComponentModel

Imports System.Configuration.Install
Imports System.ServiceProcess

<RunInstaller(True)> Public Class ProjectInstaller
    Inherits System.Configuration.Install.Installer


    Protected Overrides Sub OnAfterInstall(savedState As IDictionary)
        MyBase.OnAfterInstall(savedState)
        Using sc As ServiceController = New ServiceController(ServiceInstaller1.ServiceName)
            sc.Start()
        End Using
    End Sub

    <System.Diagnostics.DebuggerNonUserCode()> Protected Overrides Sub Dispose(ByVal disposing As Boolean)

        Try

            If disposing AndAlso components IsNot Nothing Then

                components.Dispose()

            End If

        Finally

            MyBase.Dispose(disposing)

        End Try

    End Sub

    Private components As System.ComponentModel.IContainer


    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.ServiceProcessInstaller1 = New System.ServiceProcess.ServiceProcessInstaller()
        Me.ServiceInstaller1 = New System.ServiceProcess.ServiceInstaller()
        '
        'ServiceProcessInstaller1
        '
        Me.ServiceProcessInstaller1.Account = System.ServiceProcess.ServiceAccount.LocalSystem
        Me.ServiceProcessInstaller1.Password = Nothing
        Me.ServiceProcessInstaller1.Username = Nothing
        '
        'ServiceInstaller1
        '
        Me.ServiceInstaller1.Description = Gbl_Txt_ServiceNameWithSpaces
        Me.ServiceInstaller1.DisplayName = Gbl_Txt_ServiceNameWithSpaces
        Me.ServiceInstaller1.ServiceName = Gbl_Txt_ServiceName
        Me.ServiceInstaller1.StartType = System.ServiceProcess.ServiceStartMode.Automatic
        ' Me.ServiceInstaller1.DelayedAutoStart = True
        '
        'ProjectInstaller
        '
        Me.Installers.AddRange(New System.Configuration.Install.Installer() {Me.ServiceProcessInstaller1, Me.ServiceInstaller1})

    End Sub

    Friend WithEvents ServiceProcessInstaller1 As System.ServiceProcess.ServiceProcessInstaller

    Friend WithEvents ServiceInstaller1 As System.ServiceProcess.ServiceInstaller


    Public Sub New()

        MyBase.New()

        InitializeComponent()

    End Sub
End Class
