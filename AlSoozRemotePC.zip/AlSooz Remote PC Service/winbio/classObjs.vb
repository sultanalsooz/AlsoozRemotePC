﻿Imports System.Runtime.InteropServices

Imports System.IO

Imports Microsoft.Win32

Imports System.Reflection
Imports System.Text
Imports System.ComponentModel

Imports System.Security.Principal

Module classObjs

    Public Class WinBioDatabaseKey
        Inherits WinBioRegistryKeyBase

        Public BiometricType As WinBioBiometricType
        Public Attributes As WinBioDatabaseFlag
        Public AutoCreate As Integer
        Public AutoName As Integer
        Public InitialSize As Integer
        Public Format As Guid
        Public FilePath As String
        Public ConnectionString As String

        Public Sub New()
        End Sub

        Public Sub New(ByVal database As WinBioStorageSchema)
            Attributes = database.Attributes
            Format = database.DataFormat
            BiometricType = WinBioBiometricType.Fingerprint
            AutoCreate = 1
            AutoName = 1
            InitialSize = 32
            FilePath = Environment.SystemDirectory & String.Format("\WINBIODATABASE\{0}.DAT", database.DatabaseId.ToString().ToUpper())
            ConnectionString = ""
        End Sub

    End Class


    Public Class WinBioRegistryKeyBase

        Private Function GetFields() As IEnumerable(Of FieldInfo)
            Return [GetType]().GetFields(BindingFlags.[Public] Or BindingFlags.Instance)

        End Function

        Public Sub Read(ByVal key As RegistryKey)
            For Each field In GetFields()
                Try
                    Dim value = key.GetValue(field.Name)

                    If field.FieldType Is GetType(Guid) Then
                        Dim converter = TypeDescriptor.GetConverter(field.FieldType)
                        value = converter.ConvertFrom(value)
                    End If

                    field.SetValue(Me, value)
                Catch ex As Exception
                End Try

            Next
        End Sub


        Public Sub Write(ByVal key As RegistryKey)
            For Each field In GetFields()
                Try
                    Dim value = field.GetValue(Me)

                    If field.FieldType.IsEnum Then
                        value = Convert.ChangeType(value, field.FieldType.GetEnumUnderlyingType())
                    End If

                    If field.FieldType Is GetType(Guid) Then
                        value = (CType(value, Guid)).ToString("D").ToUpperInvariant()
                    End If

                    key.SetValue(field.Name, value)
                Catch ex As Exception

                End Try

            Next
        End Sub

        Public Overrides Function ToString() As String
            Dim builder = New StringBuilder()

            For Each field In GetFields()
                Try
                    builder.AppendFormat("{0}: {1}" & vbLf, field.Name, field.GetValue(Me))
                Catch ex As Exception
                End Try

            Next

            Return builder.ToString()
        End Function
    End Class

    Public Class WinBioSensorKey
        Inherits WinBioRegistryKeyBase

        Public SensorMode As WinBioSensorMode
        Public SystemSensor As Integer
        Public DatabaseId As Guid
        Public SensorAdapterBinary As String
        Public EngineAdapterBinary As String
        Public StorageAdapterBinary As String
    End Class

    Public Class WinBio
        Protected Const LibName As String = "winbio.dll"

        <DllImport(LibName, EntryPoint:="WinBioOpenSession")>
        Private Shared Function OpenSession(ByVal factor As WinBioBiometricType, ByVal poolType As WinBioPoolType, ByVal flags As WinBioSessionFlag, ByVal unitArray As Integer(), ByVal unitCount As Integer, ByVal databaseId As IntPtr, <Out> ByRef sessionHandle As WinBioSessionHandle) As WinBioErrorCode
        End Function

        <DllImport(LibName, EntryPoint:="WinBioOpenSession")>
        Private Shared Function OpenSession(ByVal factor As WinBioBiometricType, ByVal poolType As WinBioPoolType, ByVal flags As WinBioSessionFlag, ByVal unitArray As Integer(), ByVal unitCount As Integer, <MarshalAs(UnmanagedType.LPStruct)> ByVal databaseId As Guid, <Out> ByRef sessionHandle As WinBioSessionHandle) As WinBioErrorCode
        End Function

        Private Shared Function OpenSession(ByVal factor As WinBioBiometricType, ByVal poolType As WinBioPoolType, ByVal flags As WinBioSessionFlag, ByVal unitArray As Integer(), ByVal databaseId As IntPtr) As WinBioSessionHandle
            Dim sessionHandle As WinBioSessionHandle
            Dim code = OpenSession(factor, poolType, flags, unitArray, If(unitArray Is Nothing, 0, unitArray.Length), databaseId, sessionHandle)
            WinBioException.ThrowOnError(code, "WinBioOpenSession failed")
            Return sessionHandle
        End Function

        Public Shared Function OpenSession(ByVal factor As WinBioBiometricType, ByVal poolType As WinBioPoolType, ByVal flags As WinBioSessionFlag, ByVal unitArray As Integer(), ByVal databaseId As Guid) As WinBioSessionHandle
            Dim sessionHandle As WinBioSessionHandle
            Dim code = OpenSession(factor, poolType, flags, unitArray, unitArray.Length, databaseId, sessionHandle)
            WinBioException.ThrowOnError(code, "WinBioOpenSession failed")
            Return sessionHandle
        End Function

        Public Shared Function OpenSession(ByVal factor As WinBioBiometricType, ByVal poolType As WinBioPoolType, ByVal flags As WinBioSessionFlag, ByVal unitArray As Integer(), ByVal databaseId As WinBioDatabaseId) As WinBioSessionHandle
            Return OpenSession(factor, poolType, flags, unitArray, CType(databaseId, IntPtr))
        End Function

        Public Shared Function OpenSession(ByVal factor As WinBioBiometricType) As WinBioSessionHandle
            Return OpenSession(factor, WinBioPoolType.System, WinBioSessionFlag.[Default], Nothing, WinBioDatabaseId.[Default])
        End Function

        <DllImport(LibName, EntryPoint:="WinBioCloseSession")>
        Private Shared Function WinBioCloseSession(ByVal sessionHandle As WinBioSessionHandle) As WinBioErrorCode
        End Function

        Public Shared Sub CloseSession(ByVal sessionHandle As WinBioSessionHandle)
            If Not sessionHandle.IsValid Then Return
            Dim code = WinBioCloseSession(sessionHandle)
            WinBioException.ThrowOnError(code, "WinBioOpenSession failed")
            sessionHandle.Invalidate()
        End Sub

        <DllImport(LibName, EntryPoint:="WinBioCancel")>
        Private Shared Function WinBioCancel(ByVal sessionHandle As WinBioSessionHandle) As WinBioErrorCode
        End Function

        Public Shared Sub Cancel(ByVal sessionHandle As WinBioSessionHandle)
            Dim code = WinBioCancel(sessionHandle)
            WinBioException.ThrowOnError(code, "WinBioCancel failed")
        End Sub

        <DllImport(LibName, EntryPoint:="WinBioEnumDatabases")>
        Private Shared Function EnumDatabases(ByVal factor As WinBioBiometricType, <Out> ByRef storageSchemaArray As IntPtr, <Out> ByRef storageCount As Integer) As WinBioErrorCode
        End Function

        Public Shared Function EnumDatabases(ByVal factor As WinBioBiometricType) As WinBioStorageSchema()
            Dim pointer As IntPtr
            Dim count As Integer
            Dim code = EnumDatabases(factor, pointer, count)
            WinBioException.ThrowOnError(code, "WinBioEnumDatabases failed")
            Return MarshalArray(Of WinBioStorageSchema)(pointer, count)
        End Function

        <DllImport(LibName, EntryPoint:="WinBioCaptureSample")>
        Private Shared Function CaptureSample(ByVal sessionHandle As WinBioSessionHandle, ByVal purpose As WinBioBirPurpose, ByVal flags As WinBioBirDataFlags, <Out> ByRef unitId As Integer, <Out> ByRef sample As IntPtr, <Out> ByRef sampleSize As Integer, <Out> ByRef rejectDetail As WinBioRejectDetail) As WinBioErrorCode
        End Function

        'Public Shared Function CaptureSample(ByVal sessionHandle As WinBioSessionHandle, ByVal purpose As WinBioBirPurpose, ByVal flags As WinBioBirDataFlags, <Out> ByRef rejectDetail As WinBioRejectDetail, <Out> ByRef fingerprintImage As Bitmap) As Integer
        '    Dim unitId As Integer
        '    Dim sampleSize As Integer
        '    Dim samplePointer As IntPtr
        '    Dim code = CaptureSample(sessionHandle, purpose, flags, unitId, samplePointer, sampleSize, rejectDetail)
        '    WinBioException.ThrowOnError(code, "WinBioCaptureSample failed")
        '    Dim sample As WinBioBir = CType(Marshal.PtrToStructure(samplePointer, GetType(WinBioBir)), WinBioBir)

        '    If sample.StandardDataBlock.Size = 0 Then
        '        Throw New WinBioException("Your fingerprint sensor doesn't support StandardDataBlock")
        '    End If

        '    Dim birHeaderPointer As IntPtr = samplePointer + sample.HeaderBlock.Offset
        '    Dim ansiHeaderPointer As IntPtr = samplePointer + sample.StandardDataBlock.Offset
        '    Dim ansiRecordPointer As IntPtr = ansiHeaderPointer + Marshal.SizeOf(GetType(WinBioBdbAnsi381Header))
        '    Dim ansiRecord As WinBioBdbAnsi381Record = CType(Marshal.PtrToStructure(ansiRecordPointer, GetType(WinBioBdbAnsi381Record)), WinBioBdbAnsi381Record)
        '    Dim imageSize As Size = New Size(ansiRecord.HorizontalLineLength, ansiRecord.VerticalLineLength)
        '    Dim firstPixelPointer As IntPtr = ansiRecordPointer + Marshal.SizeOf(GetType(WinBioBdbAnsi381Record))
        '    fingerprintImage = New Bitmap(imageSize.Width, imageSize.Height, 1 * imageSize.Width, PixelFormat.Format8bppIndexed, firstPixelPointer)
        '    Dim palette As ColorPalette = fingerprintImage.Palette

        '    For i As Integer = 0 To 255
        '        palette.Entries(i) = Color.FromArgb(i, i, i)
        '    Next

        '    fingerprintImage.Palette = palette
        '    Free(samplePointer)
        '    Return unitId
        'End Function

        <DllImport(LibName, EntryPoint:="WinBioLocateSensor")>
        Private Shared Function LocateSensor(ByVal sessionHandle As WinBioSessionHandle, <Out> ByRef unitId As Integer) As WinBioErrorCode
        End Function

        Public Shared Function LocateSensor(ByVal sessionHandle As WinBioSessionHandle) As Integer
            Dim unitId As Integer
            Dim code = LocateSensor(sessionHandle, unitId)
            WinBioException.ThrowOnError(code, "WinBioLocateSensor failed")
            Return unitId
        End Function

        <DllImport(LibName, EntryPoint:="WinBioEnumBiometricUnits")>
        Private Shared Function EnumBiometricUnits(ByVal factor As WinBioBiometricType, <Out> ByRef unitSchemaArray As IntPtr, <Out> ByRef unitCount As Integer) As WinBioErrorCode
        End Function

        Public Shared Function EnumBiometricUnits(ByVal factor As WinBioBiometricType) As WinBioUnitSchema()
            Dim pointer As IntPtr
            Dim count As Integer
            Dim code = EnumBiometricUnits(factor, pointer, count)
            WinBioException.ThrowOnError(code, "WinBioEnumBiometricUnits failed")
            Return MarshalArray(Of WinBioUnitSchema)(pointer, count)
        End Function

        <DllImport(LibName, EntryPoint:="WinBioIdentify")>
        Private Shared Function Identify(ByVal sessionHandle As WinBioSessionHandle, <Out> ByRef unitId As Integer, ByVal identity As IntPtr, <Out> ByRef subFactor As WinBioBiometricSubType, <Out> ByRef rejectDetail As WinBioRejectDetail) As WinBioErrorCode
        End Function


        Public Shared Function Identify(ByVal sessionHandle As WinBioSessionHandle, <Out> ByRef identity As WinBioIdentity, <Out> ByRef subFactor As WinBioBiometricSubType, <Out> ByRef rejectDetail As WinBioRejectDetail) As Integer
            Dim unitId As Integer

            Dim bytes = New Byte(WinBioIdentity.Size - 1) {}


            Dim handle = GCHandle.Alloc(bytes, GCHandleType.Pinned)

                Try

                    Dim code = Identify(sessionHandle, unitId, handle.AddrOfPinnedObject(), subFactor, rejectDetail)

                    WinBioException.ThrowOnError(code, "WinBioIdentify failed")
                Finally
                    handle.Free()
                End Try

                identity = New WinBioIdentity(bytes)

            Return unitId
        End Function

        <DllImport(LibName, EntryPoint:="WinBioEnumEnrollments")>
        Private Shared Function EnumEnrollments(ByVal sessionHandle As WinBioSessionHandle, ByVal unitId As Integer, ByVal identity As IntPtr, <Out> ByRef subFactorArray As IntPtr, <Out> ByRef subFactorCount As Integer) As WinBioErrorCode
        End Function

        Public Shared Function EnumEnrollments(ByVal sessionHandle As WinBioSessionHandle, ByVal unitId As Integer, ByVal identity As WinBioIdentity) As WinBioBiometricSubType()


            Dim subFactorArray As IntPtr
            Dim subFactorCount As Integer

            Dim handle = GCHandle.Alloc(identity.GetBytes(), GCHandleType.Pinned)
                Try

                    Dim code = EnumEnrollments(sessionHandle, unitId, handle.AddrOfPinnedObject(), subFactorArray, subFactorCount)
                    WinBioException.ThrowOnError(code, "WinBioEnumEnrollments failed")

                Finally
                    handle.Free()
                End Try


            Return MarshalArray(Of WinBioBiometricSubType)(subFactorArray, subFactorCount)
        End Function

        <DllImport(LibName, EntryPoint:="WinBioEnrollBegin")>
        Private Shared Function WinBioEnrollBegin(ByVal sessionHandle As WinBioSessionHandle, ByVal subType As WinBioBiometricSubType, ByVal unitId As Integer) As WinBioErrorCode
        End Function

        Public Shared Sub EnrollBegin(ByVal sessionHandle As WinBioSessionHandle, ByVal subType As WinBioBiometricSubType, ByVal unitId As Integer)
            Dim code = WinBioEnrollBegin(sessionHandle, subType, unitId)
            WinBioException.ThrowOnError(code, "WinBioEnrollBegin failed")
        End Sub

        <DllImport(LibName, EntryPoint:="WinBioEnrollCapture")>
        Public Shared Function EnrollCapture(ByVal sessionHandle As WinBioSessionHandle, <Out> ByRef rejectDetail As WinBioRejectDetail) As WinBioErrorCode
        End Function

        <DllImport(LibName, EntryPoint:="WinBioEnrollCommit")>
        Private Shared Function EnrollCommit(ByVal sessionHandle As WinBioSessionHandle, ByVal identity As IntPtr, <Out> ByRef isNewTemplate As Boolean) As WinBioErrorCode
        End Function


        Public Shared Function EnrollCommit(ByVal sessionHandle As WinBioSessionHandle, <Out> ByRef identity As WinBioIdentity) As Boolean
            Dim isNewTemplate As Boolean
            Dim bytes = New Byte(WinBioIdentity.Size - 1) {}


            Dim handle = GCHandle.Alloc(bytes, GCHandleType.Pinned)

                Try
                    Dim code = EnrollCommit(sessionHandle, handle.AddrOfPinnedObject(), isNewTemplate)
                    WinBioException.ThrowOnError(code, "WinBioEnrollCommit failed")
                Finally
                    handle.Free()
                End Try

                identity = New WinBioIdentity(bytes)



            Return isNewTemplate
        End Function


        <DllImport(LibName, EntryPoint:="WinBioEnrollDiscard")>
        Private Shared Function WinBioEnrollDiscard(ByVal sessionHandle As WinBioSessionHandle) As WinBioErrorCode
        End Function

        Public Shared Sub EnrollDiscard(ByVal sessionHandle As WinBioSessionHandle)
            Dim code = WinBioEnrollDiscard(sessionHandle)
            WinBioException.ThrowOnError(code, "WinBioEnrollDiscard failed")
        End Sub

        <DllImport(LibName, EntryPoint:="WinBioVerify")>
        Private Shared Function Verify(ByVal sessionHandle As WinBioSessionHandle, ByVal identity As IntPtr, ByVal subFactor As WinBioBiometricSubType, <Out> ByRef unitId As Integer, <Out> ByRef match As Boolean, <Out> ByRef rejectDetail As WinBioRejectDetail) As WinBioErrorCode
        End Function

        Public Shared Function Verify(ByVal sessionHandle As WinBioSessionHandle, ByVal identity As WinBioIdentity, ByVal subFactor As WinBioBiometricSubType, <Out> ByRef unitId As Integer, <Out> ByRef rejectDetail As WinBioRejectDetail) As Boolean
            Dim match As Boolean


            Dim handle = GCHandle.Alloc(identity.GetBytes(), GCHandleType.Pinned)

                Try
                    Dim code = Verify(sessionHandle, handle.AddrOfPinnedObject(), subFactor, unitId, match, rejectDetail)
                    WinBioException.ThrowOnError(code, "WinBioVerify failed")
                Finally
                    handle.Free()
                End Try


            Return match
        End Function

        <DllImport(LibName, EntryPoint:="WinBioDeleteTemplate")>
        Private Shared Function DeleteTemplate(ByVal sessionHandle As WinBioSessionHandle, ByVal unitId As Integer, ByVal identity As IntPtr, ByVal subFactor As WinBioBiometricSubType) As WinBioErrorCode
        End Function


        Public Shared Function updateUserSID() As WinBioIdentity
            Dim bytes = New Byte(WinBioIdentity.Size - 1) {}
            Return New WinBioIdentity(bytes)
        End Function


        Public Shared Sub DeleteTemplate(ByVal sessionHandle As WinBioSessionHandle, ByVal unitId As Integer, ByVal identity As WinBioIdentity, ByVal subFactor As WinBioBiometricSubType)

            Dim handle = GCHandle.Alloc(identity.GetBytes(), GCHandleType.Pinned)

                Try
                    Dim code = DeleteTemplate(sessionHandle, unitId, handle.AddrOfPinnedObject(), subFactor)
                    WinBioException.ThrowOnError(code, "WinBioDeleteTemplate failed")
                Finally
                    handle.Free()
                End Try


        End Sub

        <DllImport(LibName, EntryPoint:="WinBioEnumServiceProviders")>
        Private Shared Function EnumServiceProviders(ByVal factor As WinBioBiometricType, <Out> ByRef bspSchemaArray As IntPtr, <Out> ByRef bspCount As Integer) As WinBioErrorCode
        End Function

        Public Shared Function EnumServiceProviders(ByVal factor As WinBioBiometricType) As WinBioBspSchema()
            Dim bspSchemaArray As IntPtr
            Dim bspCount As Integer
            Dim code = EnumServiceProviders(factor, bspSchemaArray, bspCount)
            WinBioException.ThrowOnError(code, "WinBioEnumServiceProviders failed")
            Return MarshalArray(Of WinBioBspSchema)(bspSchemaArray, bspCount)
        End Function

        <DllImport(LibName, EntryPoint:="WinBioGetLogonSetting")>
        Private Shared Function GetLogonSetting(<Out> ByRef value As Boolean, <Out> ByRef source As WinBioSettingSourceType) As WinBioErrorCode
        End Function

        Public Shared Function GetLogonSetting(<Out> ByRef source As WinBioSettingSourceType) As Boolean
            Dim value As Boolean

            Dim code = GetLogonSetting(value, source)


                Return value
        End Function

        <DllImport(LibName, EntryPoint:="WinBioGetEnabledSetting")>
        Private Shared Function GetEnabledSetting(<Out> ByRef value As Boolean, <Out> ByRef source As WinBioSettingSourceType) As WinBioErrorCode
        End Function

        Public Shared Function GetEnabledSetting(<Out> ByRef source As WinBioSettingSourceType) As Boolean
            Dim value As Boolean

            Dim code = GetEnabledSetting(value, source)


                Return value
        End Function

        <DllImport(LibName, EntryPoint:="WinBioLogonIdentifiedUser")>
        Public Shared Function LogonIdentifiedUser(ByVal sessionHandle As WinBioSessionHandle) As WinBioErrorCode
        End Function

        <DllImport(LibName, EntryPoint:="WinBioAcquireFocus")>
        Public Shared Function AcquireFocus(ByVal sessionHandle As WinBioSessionHandle) As WinBioErrorCode
        End Function

        <DllImport(LibName, EntryPoint:="WinBioReleaseFocus")>
        Public Shared Function ReleaseFocus(ByVal sessionHandle As WinBioSessionHandle) As WinBioErrorCode
        End Function

        <DllImport(LibName, EntryPoint:="WinBioFree")>
        Private Shared Function Free(ByVal address As IntPtr) As WinBioErrorCode
        End Function

        Private Shared Function MarshalArray(Of T)(ByVal pointer As IntPtr, ByVal count As Integer) As T()
            If pointer = IntPtr.Zero Then Return Nothing

            Try
                Dim offset = pointer
                Dim data = New T(count - 1) {}
                Dim type = GetType(T)
                If type.IsEnum Then type = type.GetEnumUnderlyingType()

                For i = 0 To count - 1
                    data(i) = CType(Marshal.PtrToStructure(offset, type), T)
                    offset += Marshal.SizeOf(type)
                Next

                Return data
            Finally
                Free(pointer)
            End Try
        End Function
    End Class

    Public Class WinBioIdentity
        Public Const Size As Integer = 76
        Public Type As WinBioIdentityType
        Public Null As Integer
        Public Wildcard As Integer
        Public TemplateGuid As Guid
        Public AccountSidSize As Integer
        Public AccountSid As SecurityIdentifier

        Public Sub New(ByVal bytes As Byte())
            FromBytes(bytes)
        End Sub

        Public Sub New()
            AccountSid = System.Security.Principal.WindowsIdentity.GetCurrent().User
            AccountSidSize = AccountSid.BinaryLength
            Type = WinBioIdentityType.SID
        End Sub
        Public Sub FromBytes(ByVal bytes As Byte())

            Using stream = New MemoryStream(bytes, False)

                    Using reader = New BinaryReader(stream)
                        Type = CType(reader.ReadInt32(), WinBioIdentityType)

                        Select Case Type
                            Case WinBioIdentityType.Null
                                Null = reader.ReadInt32()
                            Case WinBioIdentityType.Wildcard
                                Wildcard = reader.ReadInt32()
                            Case WinBioIdentityType.GUID
                                TemplateGuid = New Guid(reader.ReadBytes(16))
                            Case WinBioIdentityType.SID
                                AccountSidSize = reader.ReadInt32()
                                AccountSid = New SecurityIdentifier(reader.ReadBytes(AccountSidSize), 0)
                            Case Else
                                Throw New ArgumentOutOfRangeException()
                        End Select
                    End Using
                End Using


        End Sub

        Public Function GetBytes() As Byte()
            Dim bytes = New Byte(75) {}

            Using stream = New MemoryStream(bytes, True)

                    Using writer = New BinaryWriter(stream)
                        writer.Write(CInt(Type))

                        Select Case Type
                            Case WinBioIdentityType.Null
                                writer.Write(Null)
                            Case WinBioIdentityType.Wildcard
                                writer.Write(Wildcard)
                            Case WinBioIdentityType.GUID
                                writer.Write(TemplateGuid.ToByteArray())
                            Case WinBioIdentityType.SID
                                writer.Write(AccountSidSize)
                                AccountSid.GetBinaryForm(bytes, CInt(stream.Position))
                            Case Else
                                Throw New ArgumentOutOfRangeException()
                        End Select
                    End Using
                End Using


            Return bytes
        End Function

        Public Overrides Function ToString() As String
            Select Case Type
                Case WinBioIdentityType.Null
                    Return String.Format("Null ({0})", Null)
                Case WinBioIdentityType.Wildcard
                    Return String.Format("Wildcard ({0})", Wildcard)
                Case WinBioIdentityType.GUID
                    Return String.Format("GUID ({0})", TemplateGuid)
                Case WinBioIdentityType.SID
                    Return String.Format("SID ({0})", AccountSid)
                Case Else
                    Throw New ArgumentOutOfRangeException()
            End Select
        End Function
    End Class


    Public Class WinBioException
        Inherits Exception

        Public Property ErrorCode As WinBioErrorCode

        Public Sub New(ByVal message As String)
            MyBase.New(message)
        End Sub

        Public Sub New(ByVal errorCode As WinBioErrorCode)
            MyBase.New(errorCode.ToString())
            errorCode = errorCode
        End Sub

        Public Sub New(ByVal errorCode As WinBioErrorCode, ByVal message As String)
            MyBase.New(String.Format("{0}: {1}", message, errorCode))
            HResult = CInt(errorCode)
            errorCode = errorCode
        End Sub

        Public Shared Sub ThrowOnError(ByVal errorCode As WinBioErrorCode, ByVal message As String)
            If errorCode = WinBioErrorCode.Ok Then Return
            Throw New WinBioException(errorCode, message)
        End Sub

        Public Shared Sub ThrowOnError(ByVal errorCode As WinBioErrorCode)
            If errorCode = WinBioErrorCode.Ok Then Return
            Throw New WinBioException(errorCode)
        End Sub
    End Class

    Public Class WinBioConfiguration
        Private Const DatabaseKeyName As String = "SYSTEM\CurrentControlSet\Services\WbioSrvc\Databases"
        Private Const UnitKeyName As String = "System\CurrentControlSet\Enum\{0}\Device Parameters\WinBio\Configurations"

        Private Shared Function KeyGuid(ByVal guid As Guid) As String
            Return guid.ToString("B").ToUpperInvariant()
        End Function

        Public Shared Function DatabaseExists(ByVal databaseId As Guid) As Boolean
            Return WinBio.EnumDatabases(WinBioBiometricType.Fingerprint).Any(Function(__) __.DatabaseId = databaseId)
        End Function

        Public Shared Sub AddDatabase(ByVal databaseId As Guid, ByVal unitId As Integer)
            Dim databases = WinBio.EnumDatabases(WinBioBiometricType.Fingerprint)

            If databases.Any(Function(__) __.DatabaseId = databaseId) Then
                Throw New WinBioException(String.Format("Database already exists: {0}", databaseId))
            End If

            Dim unitSchema = WinBio.EnumBiometricUnits(WinBioBiometricType.Fingerprint).Single(Function(__) __.UnitId = unitId)
            Dim unitName = String.Format(UnitKeyName, unitSchema.DeviceInstanceId)
            Dim systemSensorConfig As WinBioSensorKey = Nothing

            Using unitKey = Registry.LocalMachine.OpenSubKey(unitName, True)
                If unitKey Is Nothing Then Throw New Exception("wtf")

                For Each confName In unitKey.GetSubKeyNames()
                    Dim number As Integer
                    If Not Integer.TryParse(confName, number) Then Continue For
                    Dim config = New WinBioSensorKey()

                    Using confKey = unitKey.OpenSubKey(confName)
                        config.Read(confKey)
                    End Using

                    If config.SystemSensor = 1 Then
                        systemSensorConfig = config
                        Exit For
                    End If
                Next
            End Using

            If systemSensorConfig Is Nothing Then Throw New Exception("dafuq")
            Dim database = databases.Single(Function(__) __.DatabaseId = systemSensorConfig.DatabaseId)
            Dim newDatabase = New WinBioDatabaseKey(database)

            Using databasesKey = Registry.LocalMachine.OpenSubKey(DatabaseKeyName, True)
                If databasesKey Is Nothing Then Throw New Exception("wat?")

                Using newKey = databasesKey.CreateSubKey(KeyGuid(databaseId))
                    newDatabase.Write(newKey)
                End Using
            End Using
        End Sub

        Public Shared Sub RemoveDatabase(ByVal databaseId As Guid)
            Dim database = WinBio.EnumDatabases(WinBioBiometricType.Fingerprint).Single(Function(__) __.DatabaseId = databaseId)

            If File.Exists(database.FilePath) Then
                File.Delete(database.FilePath)
            Else
                Dim windowsPath As String = Environment.GetFolderPath(Environment.SpecialFolder.Windows)
                Dim filePath As String = String.Format("{0}\SYSTEM32", windowsPath)
                Dim filePathSysNative As String = String.Format("{0}\SysNative", windowsPath)

                If File.Exists(database.FilePath.Replace(filePath, filePathSysNative)) Then
                    File.Delete(database.FilePath.Replace(filePath, filePathSysNative))
                End If
            End If

            For Each unitSchema In WinBio.EnumBiometricUnits(WinBioBiometricType.Fingerprint)
                Dim unitName = String.Format(UnitKeyName, unitSchema.DeviceInstanceId)

                Using unitKey = Registry.LocalMachine.OpenSubKey(unitName, True)
                    If unitKey Is Nothing Then Continue For

                    For Each confName In unitKey.GetSubKeyNames()
                        Dim number As Integer
                        If Not Integer.TryParse(confName, number) Then Continue For
                        Dim config = New WinBioSensorKey()

                        Using confKey = unitKey.OpenSubKey(confName)
                            config.Read(confKey)
                        End Using

                        If config.DatabaseId = databaseId Then
                            unitKey.DeleteSubKey(confName)
                        End If
                    Next
                End Using
            Next

            Using databasesKey = Registry.LocalMachine.OpenSubKey(DatabaseKeyName, True)
                If databasesKey Is Nothing Then Throw New Exception("wat?")
                databasesKey.DeleteSubKey(KeyGuid(databaseId))
            End Using
        End Sub

        Public Shared Sub AddUnit(ByVal databaseId As Guid, ByVal unitId As Integer)
            Dim unitSchema = WinBio.EnumBiometricUnits(WinBioBiometricType.Fingerprint).Single(Function(__) __.UnitId = unitId)
            Dim unitName = String.Format(UnitKeyName, unitSchema.DeviceInstanceId)
            Dim highest = -1
            Dim newConfig As WinBioSensorKey = Nothing

            Using unitKey = Registry.LocalMachine.OpenSubKey(unitName, True)
                Try
                    If unitKey Is Nothing Then Throw New Exception("wtf")

                    For Each confName In unitKey.GetSubKeyNames()
                        Dim number As Integer
                        If Not Integer.TryParse(confName, number) Then Continue For
                        If number > highest Then highest = number
                        If newConfig IsNot Nothing Then Continue For
                        Dim config = New WinBioSensorKey()

                        Using confKey = unitKey.OpenSubKey(confName)
                            config.Read(confKey)
                        End Using

                        If config.SystemSensor = 1 Then
                            newConfig = config
                        End If
                    Next

                    If newConfig Is Nothing OrElse highest < 0 Then Throw New Exception("dafuq")
                    highest += 1
                    newConfig.DatabaseId = databaseId
                    newConfig.SystemSensor = 0

                    Using confKey = unitKey.CreateSubKey(highest.ToString())
                        newConfig.Write(confKey)
                    End Using
                Catch ex As Exception

                End Try

            End Using
        End Sub

        Public Shared Sub RemoveUnit(ByVal databaseId As Guid, ByVal unitId As Integer)
            Dim unitSchema = WinBio.EnumBiometricUnits(WinBioBiometricType.Fingerprint).Single(Function(__) __.UnitId = unitId)
            Dim unitName = String.Format(UnitKeyName, unitSchema.DeviceInstanceId)

            Using unitKey = Registry.LocalMachine.OpenSubKey(unitName, True)
                Try
                    If unitKey Is Nothing Then Throw New Exception("wtf")

                    For Each confName In unitKey.GetSubKeyNames()
                        Dim number As Integer
                        If Not Integer.TryParse(confName, number) Then Continue For
                        Dim config = New WinBioSensorKey()

                        Using confKey = unitKey.OpenSubKey(confName)
                            config.Read(confKey)
                        End Using

                        If config.DatabaseId = databaseId Then
                            unitKey.DeleteSubKey(confName)
                        End If
                    Next
                Catch ex As Exception
                End Try

            End Using
        End Sub
    End Class

End Module
