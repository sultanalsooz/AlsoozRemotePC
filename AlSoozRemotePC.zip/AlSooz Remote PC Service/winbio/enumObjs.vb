﻿Imports System


Module enumObjs


    Public Enum WinBioBiometricSubType As Byte
        Unknown = 0
        RhThumb = 1
        RhIndexFinger = 2
        RhMiddleFinger = 3
        RhRingFinger = 4
        RhLittleFinger = 5
        LhThumb = 6
        LhIndexFinger = 7
        LhMiddleFinger = 8
        LhRingFinger = 9
        LhLittleFinger = 10
        ' Any = 255
    End Enum


    Public Enum WinBioBiometricType
        Fingerprint = 8
    End Enum

    <Flags>
    Public Enum WinBioBirDataFlags
        Integrity = &H1
        Privacy = &H2
        Signed = &H4
        Raw = &H20
        Intermediate = &H40
        Processed = &H80
    End Enum


    <Flags>
    Public Enum WinBioBirPurpose
        NoPurposeAvailable = 0
        Verify = 1
        Identify = 2
        Enroll = 4
        EnrollForVerification = 8
        EnrollForIdentification = 16
    End Enum

    <Flags>
    Public Enum WinBioCapabilitySensor
        Sensor = &H1
        Matching = &H2
        Database = &H4
        Processing = &H8
        Encryption = &H10
        Navigation = &H20
        Indicator = &H40
    End Enum



    <Flags>
    Public Enum WinBioDatabaseFlag
        FlagRemovable = &H10000
        FlagRemote = &H20000
        TypeFile = &H1
        TypeDbms = &H2
        TypeOnchip = &H3
        TypeSmartcard = &H4
    End Enum


    Public Enum WinBioDatabaseId
        [Default] = 1
        Bootstrap = 2
        OnChip = 3
    End Enum


    Public Enum WinBioSettingSourceType
        Invalid = 0
        [Default] = 1
        Policy = 2
        Local = 3
    End Enum

    <Flags>
    Public Enum WinBioSessionFlag
        [Default] = 0
        Basic = 1 << 16
        Advanced = 2 << 16
        Raw = 1
        Maintenance = 2
    End Enum

    Public Enum WinBioSensorSubType
        Unknown = 0
        FpSwipe = 1
        FpTouch = 2
    End Enum


    Public Enum WinBioSensorMode
        Unknown = 0
        Basic = 1
        Advanced = 2
        Navigation = 3
        Sleep = 4
    End Enum


    Public Enum WinBioRejectDetail
        None = 0
        FpTooHigh = 1
        FpTooLow = 2
        FpTooLeft = 3
        FpTooRight = 4
        FpTooFast = 5
        FpTooSlow = 6
        FpPoorQuality = 7
        FpTooSkewed = 8
        FpTooShort = 9
        FpMergeFailure = 10
    End Enum


    Public Enum WinBioPoolType
        Unknown = 0
        System = 1
        [Private] = 2
        Unassigned = 3
    End Enum


    Public Enum WinBioIdentityType
        Null = 0
        Wildcard = 1
        GUID = 2
        SID = 3
    End Enum



    Public Enum WinBioErrorCode
        Ok = 0
        [False] = 1
        AccessDenied = &H80070005
        NotImplemented = &H80004001
        InvalidArguments = &H80070057
        InvalidPointer = &H80004003
        InvalidHandle = &H80070006
        UnsupportedFactor = &H80098001
        InvalidUnit = &H80098002
        UnknownID = &H80098003
        Canceled = &H80098004
        NoMatch = &H80098005
        CaptureAborted = &H80098006
        EnrollmentInProgress = &H80098007
        BadCapture = &H80098008
        InvalidControlCode = &H80098009
        DataCollectionInProgress = &H8009800B
        UnsupportedDataFormat = &H8009800C
        UnsupportedDataType = &H8009800D
        UnsupportedPurpose = &H8009800E
        InvalidDeviceState = &H8009800F
        DeviceBusy = &H80098010
        DatabaseCantCreate = &H80098011
        DatabaseCantOpen = &H80098012
        DatabaseCantClose = &H80098013
        DatabaseCantErase = &H80098014
        DatabaseCantFind = &H80098015
        DatabaseAlreadyExists = &H80098016
        DatabaseFull = &H80098018
        DatabaseLocked = &H80098019
        DatabaseCorrupted = &H8009801A
        DatabaseNoSuchRecord = &H8009801B
        DuplicateEnrollment = &H8009801C
        DatabaseReadError = &H8009801D
        DatabaseWriteError = &H8009801E
        DatabaseNoResults = &H8009801F
        DatabaseNoMoreRecords = &H80098020
        DatabaseEof = &H80098021
        DatabaseBadIndexVector = &H80098022
        IncorrectBsp = &H80098024
        IncorrectSensorPool = &H80098025
        NoCaptureData = &H80098026
        InvalidSensorMode = &H80098027
        LockViolation = &H8009802A
        DuplicateTemplate = &H8009802B
        InvalidOperation = &H8009802C
        SessionBusy = &H8009802D
        CredProvDisabled = &H80098030
        CredProvNoCredential = &H80098031
        Disabled = &H80098032
        ConfigurationFailure = &H80098033
        SensorUnavailable = &H80098034
        SasEnabled = &H80098035
        DeviceFailure = &H80098036
        FastUserSwitchDisabled = &H80098037
        NotActiveConsole = &H80098038
        EventMonitorActive = &H80098039
        InvalidPropertyType = &H8009803A
        InvalidPropertyID = &H8009803B
        UnsupportedProperty = &H8009803C
        AdapterIntegrityFailure = &H8009803D
        MoreData = &H90001
    End Enum

End Module
