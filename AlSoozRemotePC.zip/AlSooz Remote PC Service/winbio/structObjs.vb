﻿Imports System.Runtime.InteropServices

Module structObjs


    <StructLayout(LayoutKind.Explicit, Size:=8)>
    Public Structure LargeInteger
        <FieldOffset(0)>
        Public QuadPart As Long
        <FieldOffset(0)>
        Public LowPart As UInteger
        <FieldOffset(4)>
        Public HighPart As Integer
    End Structure


    Public Structure WinBioBdbAnsi381Header
        Public RecordLength As ULong
        Public FormatIdentifier As UInteger
        Public VersionNumber As UInteger
        Public ProductId As WinBioRegisteredFormat
        Public CaptureDeviceId As UShort
        Public ImageAcquisitionLevel As UShort
        Public HorizontalScanResolution As UShort
        Public VerticalScanResolution As UShort
        Public HorizontalImageResolution As UShort
        Public VerticalImageResolution As UShort
        Public ElementCount As Byte
        Public ScaleUnits As Byte
        Public PixelDepth As Byte
        Public ImageCompressionAlg As Byte
        Public Reserved As UShort
    End Structure


    Public Structure WinBioBdbAnsi381Record
        Public BlockLength As UInteger
        Public HorizontalLineLength As UShort
        Public VerticalLineLength As UShort
        Public Position As Byte
        Public CountOfViews As Byte
        Public ViewNumber As Byte
        Public ImageQuality As Byte
        Public ImpressionType As Byte
        Public Reserved As Byte
    End Structure

    Public Structure WinBioBir
        Public HeaderBlock As WinBioBirData
        Public StandardDataBlock As WinBioBirData
        Public VendorDataBlock As WinBioBirData
        Public SignatureBlock As WinBioBirData
    End Structure


    Public Structure WinBioBirData
        Public Size As Integer
        Public Offset As Integer
    End Structure


    Public Structure WinBioBirHeader
        Public ValidFields As UShort
        Public HeaderVersion As Byte
        Public PatronHeaderVersion As Byte
        Public DataFlags As Byte
        Public Type As UInteger
        Public Subtype As Byte
        Public Purpose As Byte
        Public DataQuality As SByte
        Public CreationDate As LargeInteger
        Public ValidityPeriod As Period
        Public BiometricDataFormat As WinBioRegisteredFormat
        Public ProductId As WinBioRegisteredFormat
    End Structure

    Public Structure Period
        Public BeginDate As LargeInteger
        Public EndDate As LargeInteger
    End Structure



    <StructLayout(LayoutKind.Sequential, CharSet:=CharSet.Unicode)>
    Public Structure WinBioBspSchema
        Public BiometricFactor As WinBioBiometricType
        Public BspId As Guid
        <MarshalAs(UnmanagedType.ByValTStr, SizeConst:=256)>
        Public Description As String
        <MarshalAs(UnmanagedType.ByValTStr, SizeConst:=256)>
        Public Vendor As String
        Public Version As WinBioVersion
    End Structure


    Public Structure WinBioRegisteredFormat
        Public Owner As UShort
        Public Type As UShort
    End Structure

    Public Structure WinBioSessionHandle
        <DebuggerBrowsable(DebuggerBrowsableState.Never)>
        Private _value As IntPtr

        Public ReadOnly Property IsValid As Boolean
            Get
                Return _value <> IntPtr.Zero
            End Get
        End Property

        Public ReadOnly Property Value As IntPtr
            Get
                Return _value
            End Get
        End Property

        Public Sub Invalidate()
            _value = IntPtr.Zero
        End Sub
    End Structure


    <StructLayout(LayoutKind.Sequential, CharSet:=CharSet.Unicode)>
    Public Structure WinBioStorageSchema
        Public Factor As WinBioBiometricType
        Public DatabaseId As Guid
        Public DataFormat As Guid
        Public Attributes As WinBioDatabaseFlag
        <MarshalAs(UnmanagedType.ByValTStr, SizeConst:=256)>
        Public FilePath As String
        <MarshalAs(UnmanagedType.ByValTStr, SizeConst:=256)>
        Public ConnectionString As String
    End Structure


    <StructLayout(LayoutKind.Sequential, CharSet:=CharSet.Unicode)>
    Public Structure WinBioUnitSchema
        Public UnitId As Integer
        Public PoolType As WinBioPoolType
        Public BiometricFactor As WinBioBiometricType
        Public SensorSubType As WinBioSensorSubType
        Public Capabilities As WinBioCapabilitySensor
        <MarshalAs(UnmanagedType.ByValTStr, SizeConst:=256)>
        Public DeviceInstanceId As String
        <MarshalAs(UnmanagedType.ByValTStr, SizeConst:=256)>
        Public Description As String
        <MarshalAs(UnmanagedType.ByValTStr, SizeConst:=256)>
        Public Manufacturer As String
        <MarshalAs(UnmanagedType.ByValTStr, SizeConst:=256)>
        Public Model As String
        <MarshalAs(UnmanagedType.ByValTStr, SizeConst:=256)>
        Public SerialNumber As String
        Public FirmwareVersion As WinBioVersion
    End Structure

    Public Structure WinBioVersion
        Public MajorVersion As Integer
        Public MinorVersion As Integer

        Public Overrides Function ToString() As String
            Return String.Format("{0}.{1}", MajorVersion, MinorVersion)
        End Function
    End Structure



End Module
