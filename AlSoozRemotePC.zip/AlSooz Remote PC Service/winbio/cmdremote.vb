﻿Imports System.Text
Imports System.Threading

Module cmdremote

    Public ReadOnly DatabaseId As Guid = Guid.Parse("BC7263C3-A7CE-49F3-8EBF-D47D74863CC6")
    Public _session As WinBioSessionHandle
    Public _unitId As Integer

    Public identity_Global As WinBioIdentity
    Friend fingerNames() As String = [Enum].GetNames(GetType(WinBioBiometricSubType))


    Friend Sub cancelLastBio()
        Try
            WinBio.Cancel(_session)
        Catch ex As Exception
        End Try

    End Sub

    Friend Function deleteBioFinger(fingerIndex As Integer) As String
        Dim strb As New StringBuilder()
        Try

            WinBio.DeleteTemplate(_session, _unitId, identity_Global, fingerIndex)

            strb.Append("Deleted Finger Successfully")
        Catch ex As WinBioException

            strb.Append("Err: ")
            strb.Append(ex.Message)
        End Try

        Return strb.ToString

    End Function

    Friend Function loadBio() As String
        Dim strb As New StringBuilder()

        Try

            Dim units = WinBio.EnumBiometricUnits(WinBioBiometricType.Fingerprint)
            strb.Append("Found ").Append(units.Length).Append(" Fingerprint Sensor")

            If units.Length = 0 Then
                strb.Append("Error: Fingerprint sensor not found!")
                Return strb.ToString
            End If

            Dim unit = units(0)
            _unitId = unit.UnitId
            strb.Append("Using unit id: ").Append(_unitId)
            strb.Append("Device instance id: ").Append(unit.DeviceInstanceId)
            strb.Append("Using database: ").Append(DatabaseId)

            If WinBioConfiguration.DatabaseExists(DatabaseId) = False Then
                strb.Append(InitialStart())
            Else
                strb.Append(OpenBiometricSession())
            End If
        Catch ex As Exception
            strb.Append("Err: ")
            strb.Append(ex.Message)
        End Try

        ' biofrm.Log(strb.ToString())

        Return strb.ToString
    End Function

    Friend Function addEnrollment(fingerIndex As Integer)
        Dim strb As New StringBuilder()
        Try
            Dim pthread As New Thread(Sub()
                                          Dim strb2 As New StringBuilder()
                                          Try
                                              strb2.Append(AddEnrollment(_session, _unitId, fingerIndex))

                                          Catch ex As WinBioException
                                              strb2.Append(ex.Message)
                                          End Try
                                          processPendingUDPCommand(strb2.ToString())
                                      End Sub)
            pthread.Start()
        Catch ex As Exception
            strb.Append("Err: ")
            strb.Append(ex.Message)
        End Try
        Return strb.ToString
    End Function

    Private Function AddEnrollment(ByVal session As WinBioSessionHandle, ByVal unitId As Integer, ByVal subType As WinBioBiometricSubType) As WinBioIdentity
        Dim strb As New StringBuilder()
        Dim identity As WinBioIdentity = Nothing
        Try
            Dim swipes = 1
            strb.Append("Beginning enrollment of : ").Append(swipes).Append(" of 4")
            processPendingUDPCommand(strb.ToString())
            strb.Clear()
            RequestFocus()
            WinBio.EnrollBegin(session, subType, unitId)
            Dim code = WinBioErrorCode.MoreData


            While code <> WinBioErrorCode.Ok
                Dim rejectDetail As WinBioRejectDetail
                code = WinBio.EnrollCapture(session, rejectDetail)

                Select Case code
                    Case WinBioErrorCode.MoreData
                        strb.Append("Swipe ").Append(swipes).Append(" of 4  was good.")
                    Case WinBioErrorCode.BadCapture
                        strb.Append("Swipe ").Append(swipes).Append(" of 4 was bad: ").Append(rejectDetail)
                    Case WinBioErrorCode.Ok
                        strb.Append("Enrollment completed with ").Append(swipes).Append(" swipes")
                    Case Else
                        Throw New WinBioException(code, "Enrollment failed")
                End Select

                ' biofrm.Log(strb.ToString())
                processPendingUDPCommand(strb.ToString())
                strb.Clear()
                swipes += 1
            End While



            strb.Append("Committing enrollment..")
            processPendingUDPCommand(strb.ToString())
            strb.Clear()
            Dim isNewTemplate = WinBio.EnrollCommit(session, identity)
            ReleaseFocus()
            strb.Append(If(isNewTemplate, "New template committed.", "Template already existing."))
            processPendingUDPCommand(strb.ToString())
            strb.Clear()
            identity_Global = identity
        Catch ex As Exception
            strb.Append("Err: ")
            strb.Append(ex.Message)
            processPendingUDPCommand(strb.ToString())
            strb.Clear()
        End Try

        Return identity
    End Function

    Friend Function identifyUserSID()
        Dim strb As New StringBuilder()
        Try
            Dim pthread As New Thread(Sub()
                                          Dim strb2 As New StringBuilder()
                                          strb2.Append("Identifying user...")
                                          processPendingUDPCommand(strb2.ToString)
                                          Try

                                              Dim subFactor As WinBioBiometricSubType
                                              Dim rejectDetail As WinBioRejectDetail
                                              RequestFocus()
                                              WinBio.Identify(_session, identity_Global, subFactor, rejectDetail)

                                              strb2.Append("Identity: ").Append(fingerNames(Val(subFactor))).Append(" _ ").Append(identity_Global.ToString)

                                          Catch ex As WinBioException
                                              strb2.Append(ex.Message)
                                          End Try
                                          ReleaseFocus()
                                          processPendingUDPCommand(strb2.ToString)
                                      End Sub)

            pthread.Start()
        Catch ex As Exception
            strb.Append("Err: ")
            strb.Append(ex.Message)
        End Try

        Return strb.ToString


    End Function

    Friend Function locateSensor() As String
        Dim strb As New StringBuilder()
        Try
            Dim pthread As New Thread(Sub()
                                          Dim strb2 As New StringBuilder()
                                          processPendingUDPCommand("Locating sensor...")

                                          Try
                                              RequestFocus()
                                              Dim unitId = WinBio.LocateSensor(_session)

                                              strb2.Append("Sensor located: Fingerprint sensor id ").Append(unitId)
                                          Catch ex As WinBioException
                                              strb2.Append("Err: ")
                                              strb2.Append(ex.Message)
                                          End Try
                                          ReleaseFocus()
                                          processPendingUDPCommand(strb2.ToString)
                                      End Sub)
            pthread.Start()
        Catch ex As Exception
            strb.Append("Err: ")
            strb.Append(ex.Message)
        End Try

        Return strb.ToString

    End Function

    Public Function InitialStart() As String

        Dim strb As New StringBuilder()

        Try

            'Dim databases = WinBio.EnumDatabases(WinBioBiometricType.Fingerprint)
            'strb.Append("Found ").Append(databases.Length).Append(" databases")

            'For i = 0 To databases.Length - 1
            '    strb.Append("DatabaseId ").Append(i).Append(" : ").Append(databases(i).DatabaseId)
            'Next

            If WinBioConfiguration.DatabaseExists(DatabaseId) Then
                strb.Append("Removing database: ").Append(DatabaseId)
                WinBioConfiguration.RemoveDatabase(DatabaseId)
            End If

            strb.Append("Creating database: ").Append(DatabaseId)
            WinBioConfiguration.AddDatabase(DatabaseId, _unitId)
            strb.Append("Adding sensor to the pool: ").Append(_unitId)
            WinBioConfiguration.AddUnit(DatabaseId, _unitId)

            ' RestartService("WbioSrvc", 5000, ServiceMode.Restart)

            strb.Append("Successfully recreated database.")
            OpenBiometricSession()
            strb.Append("Session Opened.")
        Catch ex As Exception
            strb.Append("Err: ")
            strb.Append(ex.Message)
        End Try

        Return strb.ToString

    End Function

    Friend Function RequestFocus() As String
        Try
            WinBio.AcquireFocus(_session)
            Return "Focus Acquired"
        Catch ex As Exception
        End Try
        Return "No Focus"
    End Function

    Friend Function ReleaseFocus() As String
        Try
            WinBio.ReleaseFocus(_session)
            Return "Focus Released"
        Catch ex As Exception
        End Try
        Return "err Released"
    End Function

    Private Function OpenBiometricSession() As String
        Dim strb As New StringBuilder()

        Try
            _session = WinBio.OpenSession(WinBioBiometricType.Fingerprint, WinBioPoolType.System, WinBioSessionFlag.Raw, Nothing, WinBioDatabaseId.[Default])
            strb.Append("Session opened: " & _session.Value.ToString)
        Catch ex As Exception
            strb.Append("Err: ")
            strb.Append(ex.Message)
        End Try

        Return strb.ToString
    End Function

    Friend Function CloseBiometricSession() As String
        Dim strb As New StringBuilder()
        Try
            WinBio.CloseSession(_session)
            strb.Append("Session Closed: " & _session.Value.ToString)
        Catch ex As Exception
            strb.Append("Err: ")
            strb.Append(ex.Message)
        End Try

        Return strb.ToString
    End Function
End Module
