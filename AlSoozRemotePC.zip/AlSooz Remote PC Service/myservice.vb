﻿
Imports System.ServiceProcess


Public Class myservice
    Inherits ServiceBase

    Sub New()
        CanHandleSessionChangeEvent = True
        Me.ServiceName = Gbl_Txt_ServiceName
    End Sub


    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        MyBase.Dispose(disposing)
    End Sub

    Protected Overrides Sub OnShutdown()
        OnStop()
        MyBase.OnShutdown()
    End Sub

    '  Private UsersSession As New List(Of String)

    Protected Overrides Sub OnSessionChange(changeDescription As SessionChangeDescription)
        MyBase.OnSessionChange(changeDescription)

        Try

            Dim UserSessionInfo As UserSessionInfoClass = getUserSessionInfo(changeDescription.SessionId)
            Try
                writeLogLine(UserSessionInfo.userName & " :SessionChanged: " & changeDescription.Reason.ToString)

            Catch ex As Exception
                Try
                    writeLogLine("SessionChanged: " & changeDescription.Reason.ToString)

                Catch ex2 As Exception
                    writeLogLine("SessionChanged: No Info ")
                End Try

            End Try

            If changeDescription.Reason = SessionChangeReason.SessionLogon Then

                'Dim processes As Process() = Process.GetProcessesByName("AlSoozRemoteScreenKeyboardMouse")

                runServiceStart(UserSessionInfo)

                'End If

            ElseIf changeDescription.Reason = SessionChangeReason.ConsoleConnect Then

                'Try
                '    UsersSession.Remove(UserSessionInfo.userName)
                'Catch ex As Exception
                'End Try

                runServiceStart(UserSessionInfo)

            ElseIf changeDescription.Reason = SessionChangeReason.SessionLock Then

                runServiceStart(UserSessionInfo)

            ElseIf changeDescription.Reason = SessionChangeReason.SessionUnlock Then

                runServiceStart(UserSessionInfo)

                'ElseIf changeDescription.Reason = SessionChangeReason.SessionLogoff Then

                'ElseIf changeDescription.Reason = SessionChangeReason.ConsoleDisconnect Then

            End If

        Catch ex As Exception
        End Try
    End Sub

    Private isUDPStarted As Boolean = False

    Private Sub runServiceStart(ByVal UserSessionInfo As UserSessionInfoClass)
        '    If UsersSession.IndexOf(UserSessionInfo.userName) < 0 Then

        If isUDPStarted = False Then
            StartUDPListener()
            isUDPStarted = True
        End If

        If OpenProcessAsSystemforActiveDesktop(Gbl_Txt_EXE_TargetApp_Path, "winlogon") Then
            ' writeLogLine("App Started from Service: " & UserSessionInfo.userName)
            '  UsersSession.Add(UserSessionInfo.userName)
        End If

        'Else

        '     writeLogLine("Service runServiceStart err: UserSessionInfo Found: " & UserSessionInfo.userName & " _ " & UsersSession.Count)
        'End If

        ' Try

        ' writeLogLine(getCurrentWinStationName())

        'If Not OpenProcessAsSystemforActiveDesktop(Gbl_Txt_EXE_TargetApp_Path, "winlogon") Then
        '    writeLogLine("winlogon not Found 1")

        '    Try
        '        Threading.Thread.Sleep(5000)
        '        If Not OpenProcessAsSystemforActiveDesktop(Gbl_Txt_EXE_TargetApp_Path, "winlogon") Then
        '            writeLogLine("winlogon not Found 2")
        '        End If
        '    Catch ex As Exception

        '    End Try
        'End If


        ''"default" , "disconnect"

        '' Dim DesktopNames As List(Of String) = EnumDesktopsAll()
        '' Dim WinStationsNames As List(Of String) = EnumWinStationsAll()

        ' Catch ex As Exception
        ' writeLogLine("Service Error: " & ex.Message)
        ' End Try
    End Sub


    Protected Overrides Sub OnContinue()

        'writeLogLine("Service OnContinue Event")

        MyBase.OnContinue()
    End Sub
    Protected Overrides Sub OnStart(ByVal args() As String)

        ' UsersSession.Clear()
        ' writeLogLine("Service OnStart Event")
        Dim p As New Threading.Thread(Sub()
                                          Try
                                              Threading.Thread.Sleep(5000)

                                              ' If UsersSession.Count = 0 Then
                                              Dim UserSessionInfo As UserSessionInfoClass = getUserSessionInfo(WTSGetActiveConsoleSessionId())
                                                  runServiceStart(UserSessionInfo)

                                              'End If

                                          Catch ex As Exception
                                              ' writeLogLine("Service OnStart Err: UserSessionInfo: " & ex.Message)
                                          End Try
                                      End Sub)

        p.Start()
        ' will not invoke if PC shutdown
        ' will invoke only if the PC is restarted

    End Sub

    Protected Overrides Sub OnStop()
        Try
            isServerThreadOn = False
            ' UsersSession.Clear()
            stopUDPListener()
            ' writeLogLine("Service OnStop Event")
            ' writeLogLine("Service Stopped")
        Catch ex As Exception
        End Try

    End Sub


End Class
