﻿Imports System.Net
Imports System.Net.Sockets
Imports System.Text

Module socketUDP

    Friend isServerThreadOn As Boolean = True

    Private Gbl_UDP_PortSend As Integer = 29151

    Private Gbl_UDP_PortReceiv As Integer = 29150

    Private UDPConnectionReceiv As UdpClient = Nothing
    Private UDPClientReceiv As IPEndPoint = Nothing

    Private UDPConnectionSend As UdpClient = Nothing
    Private UDPClientSend As IPEndPoint = Nothing

    Friend Sub stopUDPListener()
        isServerThreadOn = False

        Try
            UDPConnectionReceiv.Close()
        Catch ex As Exception
        End Try

        Try
            p.Abort()
        Catch ex As Exception
        End Try
    End Sub


    Private p As Threading.Thread

    Public Sub StartUDPListener()

        isServerThreadOn = True

        UDPConnectionSend = New UdpClient()

        UDPConnectionSend.Client.SetSocketOption(SocketOptionLevel.Socket, SocketOptionName.ReuseAddress, True)

        UDPClientSend = New IPEndPoint(IPAddress.Parse("127.0.0.1"), Gbl_UDP_PortSend)

        ' UDPClientSend_ScreenSaver = New IPEndPoint(IPAddress.Parse("127.0.0.1"), Gbl_UDP_PortSend_ScreenSaver)


        p = New Threading.Thread(Sub()

                                     Dim strb As New StringBuilder
                                     Try

                                         If IsNothing(UDPClientReceiv) Then UDPClientReceiv = New IPEndPoint(IPAddress.Parse("127.0.0.1"), Gbl_UDP_PortReceiv)

                                         If IsNothing(UDPConnectionReceiv) Then
                                             UDPConnectionReceiv = New UdpClient()
                                             UDPConnectionReceiv.Client.SetSocketOption(SocketOptionLevel.Socket, SocketOptionName.ReuseAddress, True)

                                             UDPConnectionReceiv.Client.Bind(UDPClientReceiv)
                                         End If

                                         While isServerThreadOn

                                             ' strb.Clear()

                                             Dim data As Byte() = UDPConnectionReceiv.Receive(UDPClientReceiv)

                                             Dim datarec As String = Encoding.UTF8.GetString(data)

                                             processUDPCommand(datarec)

                                             ' strb.Append(vbCrLf).Append("Receive from: ").Append(Client1.Address.ToString)
                                             '  strb.Append(vbCrLf).Append("Received data:").Append(datarec) 
                                             ' biofrm.Log(strb.ToString)

                                             'If datarec <> "ok" Then sendUDPToServer("ok")

                                         End While


                                     Catch ex As Exception
                                         'strb.Clear()
                                         'strb.Append(vbCrLf).Append("Err: ").Append(ex.Message)
                                         'processUDPCommand(strb.ToString())
                                     End Try

                                     '  processUDPCommand("UDP Exited")
                                 End Sub)

        p.Start()

    End Sub


    Public Sub sendUDPToUIApp(ByVal dataToSend As String)

        Dim strb As New StringBuilder
        Try

            'strb.Append(vbCrLf).Append("Sending: ").Append(dataToSend)
            '  biofrm.Log(strb.ToString())
            'strb.Clear()

            UDPConnectionSend.Send(Encoding.UTF8.GetBytes(dataToSend), dataToSend.Length, UDPClientSend)

        Catch ex As Exception
            ' strb.Append(vbCrLf).Append("Err: ").Append(ex.Message)
            ' biofrm.Log(strb.ToString)
        End Try


    End Sub


    Private Sub processUDPCommand(ByVal Cmd_Data As String)


        If Cmd_Data.StartsWith("CMD_StartDesktopApp:") Then

            Dim p As New Threading.Thread(Sub()
                                              Try
                                                  Threading.Thread.Sleep(2000)
                                                  OpenProcessAsSystemforActiveDesktop(Gbl_Txt_EXE_TargetApp_Path, "winlogon")
                                              Catch ex As Exception
                                              End Try
                                          End Sub)

            p.Start()
        ElseIf Cmd_Data.StartsWith("desktopSwitchEvent:") Then
            Try
                If Cmd_Data.Split(":")(1) = "default" Then
                    If Not gbl_IsDesktop_Default_Started Then
                        gbl_IsDesktop_Default_Started = True
                        ' OpenProcessAsSystemforActiveDesktop(Gbl_Txt_EXE_TargetApp_Path, "default")

                    End If

                Else

                End If

            Catch ex As Exception
            End Try

        ElseIf Cmd_Data.StartsWith("sendsas:") Then
            Try

                Send_CNTL_ALT_DEL(False)

            Catch ex As Exception
            End Try

        ElseIf Cmd_Data.StartsWith("WS_ClientApp_Update|") Then
            Try

                App_DownloadUpdatedClient(Cmd_Data.Split("|")(1))

            Catch ex As Exception
            End Try

        Else
            Try
                '  writeLogLine(Cmd_Data)
            Catch ex As Exception
            End Try

        End If


    End Sub


End Module
