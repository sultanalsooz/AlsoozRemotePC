﻿Imports System.IO
Imports System.Net


Module Mod_Common

    Friend Gbl_Txt_ServiceName As String = "AlSoozRemotePCService"
    Friend Gbl_Txt_ServiceNameWithSpaces As String = "AlSooz Remote PC Service"
    Friend Gbl_Txt_FolderPath As String = "C:\Program Files\AlSooz Remote PC\"
    Friend Gbl_Txt_EXE_Service_Path As String = Gbl_Txt_FolderPath & "AlSoozRemotePCService.exe"

    Friend Gbl_Txt_MainApp_Name As String = "AlSoozRemotePC.exe"
    Friend gbl_EXEUpdateFilename As String = "AlSoozRemotePC_update.exe"

    Friend Gbl_Txt_EXE_TargetApp_Path As String = Gbl_Txt_FolderPath & Gbl_Txt_MainApp_Name

    Friend Gbl_Txt_EXE_UpdateApp_Path As String = Gbl_Txt_FolderPath & gbl_EXEUpdateFilename

    Friend Gbl_Txt_LogFile_Path As String = "C:\ProgramData\AlSoozRemotePC\Srvlog.txt"

    Friend gbl_IsDesktop_Default_Started As Boolean = False


    Friend Sub writeLogLine(ByVal txt As String)
        'Dim strb As New StringBuilder
        'strb.Append(Now.ToShortTimeString)
        'strb.Append(" - ")
        'strb.Append(txt)
        'strb.Append(vbCrLf)
        'Try
        '    My.Computer.FileSystem.WriteAllText(Gbl_Txt_LogFile_Path, strb.ToString, True)
        'Catch ex As Exception
        'End Try

    End Sub

    Friend Sub App_DownloadUpdatedClient(ByVal Url_Exe As String)
        Dim p As New Threading.Thread(Sub()
                                          App__DeleteUpdateClientFile()

                                          Try
                                              Using wc As New WebClient
                                                  wc.DownloadFile(Url_Exe, Gbl_Txt_EXE_UpdateApp_Path)
                                              End Using

                                              UpdateApp()
                                          Catch ex As Exception
                                          End Try

                                          Try
                                              Threading.Thread.Sleep(500)
                                          Catch ex As Exception
                                          End Try
                                          OpenProcessAsSystemforActiveDesktop(Gbl_Txt_EXE_TargetApp_Path, "winlogon")

                                      End Sub)
        p.Start()
    End Sub


    Private Sub UpdateApp()
        Dim isLoopContinue As Boolean = True
        Dim loopRetries As Integer = 0
        Dim loopRetriesLimit As Integer = 15
        Dim newFileCreated As Boolean = False
        Do While isLoopContinue
            Try
                Threading.Thread.Sleep(2500)
                If My.Computer.FileSystem.FileExists(Gbl_Txt_EXE_UpdateApp_Path) Then
                    Dim fInfo As New FileInfo(Gbl_Txt_EXE_UpdateApp_Path)
                    If fInfo.Length > 100000 Then

                        If My.Computer.FileSystem.FileExists(Gbl_Txt_EXE_TargetApp_Path) AndAlso newFileCreated = False Then
                            My.Computer.FileSystem.DeleteFile(Gbl_Txt_EXE_TargetApp_Path)
                        End If
                        If My.Computer.FileSystem.FileExists(Gbl_Txt_EXE_TargetApp_Path) = False Then
                            My.Computer.FileSystem.CopyFile(Gbl_Txt_EXE_UpdateApp_Path, Gbl_Txt_EXE_TargetApp_Path)
                            newFileCreated = True
                        End If
                        If My.Computer.FileSystem.FileExists(Gbl_Txt_EXE_TargetApp_Path) AndAlso newFileCreated Then
                            App__DeleteUpdateClientFile()
                            Return
                        End If
                    End If
                End If
            Catch ex As Exception
            End Try

            If loopRetries > loopRetriesLimit Then
                isLoopContinue = False
            Else
                loopRetries += 1
            End If
        Loop

    End Sub

    Friend Sub App__DeleteUpdateClientFile()
        Try
            If My.Computer.FileSystem.FileExists(Gbl_Txt_EXE_UpdateApp_Path) Then
                My.Computer.FileSystem.DeleteFile(Gbl_Txt_EXE_UpdateApp_Path)
            End If
        Catch ex As Exception
        End Try
    End Sub


End Module
