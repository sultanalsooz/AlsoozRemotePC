﻿Imports System.Runtime.InteropServices

Module Mod_SessionInfo

    <DllImport("kernel32.dll")>
    Public Function WTSGetActiveConsoleSessionId() As UInteger
    End Function

    <DllImport("Wtsapi32.dll")>
    Public Function WTSQuerySessionInformation(ByVal hServer As IntPtr, ByVal sessionId As Int32, ByVal wtsInfoClass As WTS_INFO_CLASS, <Out> ByRef ppBuffer As IntPtr, <Out> ByRef pBytesReturned As Int32) As Boolean
    End Function
    <DllImport("Wtsapi32.dll")>
    Public Sub WTSFreeMemory(ByVal pointer As IntPtr)
    End Sub

    Public Enum WTS_INFO_CLASS
        WTSInitialProgram
        WTSApplicationName
        WTSWorkingDirectory
        WTSOEMId
        WTSSessionId
        WTSUserName
        WTSWinStationName
        WTSDomainName
        WTSConnectState
        WTSClientBuildNumber
        WTSClientName
        WTSClientDirectory
        WTSClientProductId
        WTSClientHardwareId
        WTSClientAddress
        WTSClientDisplay
        WTSClientProtocolType
        WTSIdleTime
        WTSLogonTime
        WTSIncomingBytes
        WTSOutgoingBytes
        WTSIncomingFrames
        WTSOutgoingFrames
        WTSClientInfo
        WTSSessionInfo
    End Enum


    Public Enum WTS_CONNECTSTATE_CLASS
        WTSActive
        WTSConnected
        WTSConnectQuery
        WTSShadow
        WTSDisconnected
        WTSIdle
        WTSListen
        WTSReset
        WTSDown
        WTSInit
    End Enum

    <StructLayout(LayoutKind.Sequential)>
    Private Structure WTS_SESSION_INFO
        Public SessionID As Int32
        <MarshalAs(UnmanagedType.LPStr)>
        Public pWinStationName As String
        Public State As WTS_CONNECTSTATE_CLASS
    End Structure

    Friend Class UserSessionInfoClass
        Friend userName As String = "na"
        Friend domainName As String = "na"
    End Class

    Function getUserSessionInfo(ByVal sessionId As Int32) As UserSessionInfoClass
        Dim buffer As IntPtr
        Dim length As Integer
        Dim UserSessionInfo As New UserSessionInfoClass

        Dim server As IntPtr = IntPtr.Zero ' OpenServer(ServerName)
        Try

            If WTSQuerySessionInformation(server, sessionId, WTS_INFO_CLASS.WTSUserName, buffer, length) AndAlso length > 1 Then
                UserSessionInfo.userName = Marshal.PtrToStringAnsi(buffer)
                WTSFreeMemory(buffer)

                If WTSQuerySessionInformation(server, sessionId, WTS_INFO_CLASS.WTSDomainName, buffer, length) AndAlso length > 1 Then
                    UserSessionInfo.domainName = Marshal.PtrToStringAnsi(buffer)
                    WTSFreeMemory(buffer)
                End If
            End If
        Catch ex As Exception

        End Try
        Return UserSessionInfo
    End Function


End Module









