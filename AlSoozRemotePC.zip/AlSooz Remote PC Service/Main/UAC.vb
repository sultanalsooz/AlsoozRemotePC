﻿Imports System.Runtime.ConstrainedExecution
Imports System.Runtime.InteropServices
Imports System.Text


Module UAC


    <StructLayout(LayoutKind.Sequential)>
    Public Structure SECURITY_ATTRIBUTES
        Public Length As Integer
        Public lpSecurityDescriptor As IntPtr
        Public bInheritHandle As Boolean
    End Structure


    <StructLayout(LayoutKind.Sequential)>
    Public Structure PROCESS_INFORMATION
        Public hProcess As IntPtr
        Public hThread As IntPtr
        Public dwProcessId As Integer
        Public dwThreadId As Integer
    End Structure

    <StructLayout(LayoutKind.Sequential, CharSet:=CharSet.Unicode)>
    Public Structure STARTUPINFO
        Public cb As Int32
        Public lpReserved As String
        Public lpDesktop As String
        Public lpTitle As String
        Public dwX As Int32
        Public dwY As Int32
        Public dwXSize As Int32
        Public dwYSize As Int32
        Public dwXCountChars As Int32
        Public dwYCountChars As Int32
        Public dwFillAttribute As Int32
        Public dwFlags As Int32
        Public wShowWindow As Int16
        Public cbReserved2 As Int16
        Public lpReserved2 As IntPtr
        Public hStdInput As IntPtr
        Public hStdOutput As IntPtr
        Public hStdError As IntPtr
    End Structure

    Public Enum TOKEN_TYPE
        TokenPrimary = 1
        TokenImpersonation = 2
    End Enum

    Public Enum SECURITY_IMPERSONATION_LEVEL
        SecurityAnonymous = 0
        SecurityIdentification = 1
        SecurityImpersonation = 2
        SecurityDelegation = 3
    End Enum

    <DllImport("advapi32.dll", SetLastError:=True, CharSet:=CharSet.Auto)>
    Private Function CreateProcessAsUser(ByVal hToken As IntPtr, ByVal lpApplicationName As String, ByVal lpCommandLine As String, ByRef lpProcessAttributes As SECURITY_ATTRIBUTES, ByRef lpThreadAttributes As SECURITY_ATTRIBUTES, ByVal bInheritHandles As Boolean, ByVal dwCreationFlags As UInteger, ByVal lpEnvironment As IntPtr, ByVal lpCurrentDirectory As String, ByRef lpStartupInfo As STARTUPINFO, <Out> ByRef lpProcessInformation As PROCESS_INFORMATION) As Boolean
    End Function


    <DllImport("advapi32.dll", CharSet:=CharSet.Auto, SetLastError:=True)>
    Private Function OpenProcessToken(ByVal ProcessHandle As IntPtr, ByVal DesiredAccess As Integer, ByRef TokenHandle As IntPtr) As Boolean
    End Function

    <DllImport("advapi32.dll", CharSet:=CharSet.Auto, SetLastError:=True)>
    Private Function DuplicateTokenEx(ByVal hExistingToken As IntPtr, ByVal dwDesiredAccess As UInteger, ByRef lpTokenAttributes As SECURITY_ATTRIBUTES, ByVal ImpersonationLevel As SECURITY_IMPERSONATION_LEVEL, ByVal TokenType As TOKEN_TYPE, <Out> ByRef phNewToken As IntPtr) As Boolean
    End Function

    <DllImport("user32.dll", CharSet:=CharSet.Auto, SetLastError:=True)>
    Private Function GetUserObjectInformation(ByVal hObj As IntPtr, ByVal nIndex As Integer, ByVal pvInfo As StringBuilder, ByVal nLength As UInteger, ByRef lpnLengthNeeded As UInteger) As Boolean
    End Function


    <DllImport("user32.dll", CharSet:=CharSet.Auto)>
    Public Function EnumDesktops(ByVal hwinsta As IntPtr, ByVal lpEnumFunc As EnumDesktopDelegate, ByVal lParam As IntPtr) As Boolean
    End Function
    Public Delegate Function EnumDesktopDelegate(<MarshalAs(UnmanagedType.LPTStr)> ByVal DesktopName As String, ByVal lParam As IntPtr) As Boolean

    Public Declare Auto Function GetThreadDesktop Lib "user32.dll" (ByVal threadId As Integer) As IntPtr
    Public Declare Auto Function OpenInputDesktop Lib "user32.dll" (ByVal flags As Integer, <MarshalAs(UnmanagedType.Bool)> ByVal inherit As Boolean, ByVal desiredAccess As Integer) As IntPtr
    Public Declare Auto Function CreateDesktop Lib "user32.dll" (ByVal desktop As String, ByVal device As String, ByVal devmode As IntPtr, ByVal flags As Integer, ByVal desiredAccess As Integer, ByVal lpsa As IntPtr) As IntPtr
    Public Declare Auto Function SetThreadDesktop Lib "user32.dll" (ByVal desktop As IntPtr) As <MarshalAs(UnmanagedType.Bool)> Boolean
    Public Declare Auto Function SwitchDesktop Lib "user32.dll" (ByVal desktop As IntPtr) As <MarshalAs(UnmanagedType.Bool)> Boolean
    Public Declare Auto Function CloseDesktop Lib "user32.dll" (ByVal desktop As IntPtr) As <MarshalAs(UnmanagedType.Bool)> Boolean

    <DllImport("user32.dll")>
    Private Function OpenDesktop(ByVal lpszDesktop As String, ByVal dwFlags As Integer, ByVal fInderit As Boolean, ByVal dwDesiredAccess As Integer) As IntPtr
    End Function

    <DllImport("kernel32.dll", SetLastError:=True)>
    Private Function CloseHandle(ByVal hSnapshot As IntPtr) As Boolean
    End Function


    <DllImport("kernel32.dll")>
    Private Function OpenProcess(ByVal dwDesiredAccess As UInteger, ByVal bInheritHandle As Boolean, ByVal dwProcessId As UInteger) As IntPtr
    End Function

    <ReliabilityContract(Consistency.WillNotCorruptState, Cer.MayFail)>
    <DllImport("user32", CharSet:=CharSet.Unicode, SetLastError:=True)>
    Private Function GetProcessWindowStation() As IntPtr
    End Function


    <DllImport("user32.dll", CharSet:=CharSet.Auto, SetLastError:=True)>
    Public Function EnumWindowStations(ByVal lpEnumFunc As EnumWinStationsDelegate, ByVal lParam As IntPtr) As Boolean
    End Function
    Public Delegate Function EnumWinStationsDelegate(<MarshalAs(UnmanagedType.LPTStr)> ByVal DesktopName As String, ByVal lParam As IntPtr) As Boolean


    <ReliabilityContract(Consistency.WillNotCorruptState, Cer.MayFail)>
    <DllImport("user32", CharSet:=CharSet.Unicode, SetLastError:=True)>
    Public Function CloseWindowStation(ByVal hWinsta As IntPtr) As Boolean
    End Function

    <ReliabilityContract(Consistency.WillNotCorruptState, Cer.MayFail)>
    <DllImport("user32", CharSet:=CharSet.Unicode, SetLastError:=True)>
    Public Function OpenWindowStation(<MarshalAs(UnmanagedType.LPTStr)> ByVal lpszWinSta As String,
    <MarshalAs(UnmanagedType.Bool)> ByVal fInherit As Boolean, ByVal dwDesiredAccess As ACCESS_MASK) As IntPtr
    End Function

    <DllImport("user32.dll", SetLastError:=True)>
    Public Function SetProcessWindowStation(ByVal hWinSta As IntPtr) As Boolean
    End Function

    Private Declare Function GetCurrentProcessId Lib "kernel32" () As UInteger

    Public Enum ACCESS_MASK
        MAXIMUM_ALLOWED = &H2000000
    End Enum


    Private WinStationNames As New List(Of String)
    Public Function EnumWinStationsProc(
          ByVal WinStationName As String,
          ByVal lParam As IntPtr
        ) As Boolean

        WinStationNames.Add(WinStationName)
        'writeLogLine("DesktopName: " & DesktopName)

        Return True
    End Function

    Public Function EnumWinStationsAll() As List(Of String)
        Try

            Dim delgateEnum As New EnumWinStationsDelegate(AddressOf EnumWinStationsProc)

            EnumWindowStations(delgateEnum, IntPtr.Zero)

        Catch ex As Exception
        End Try


        'hWnsta = OpenWindowStation("winsta0", False, ACCESS_MASK.MAXIMUM_ALLOWED)

        'SetProcessWindowStation(hWnsta)

        'Dim pp As New Threading.Thread(Sub()
        '                                   Try
        '                                       Do While isContinuePPThread
        '                                           Thread.Sleep(3000)
        '                                           Dim UserDesktopName As String = GetCurrentDesktopName()
        '                                           writeLogLine("UserDesktopName: " & UserDesktopName)
        '                                       Loop
        '                                   Catch ex As Exception
        '                                       writeLogLine("LoopError: " & ex.Message)
        '                                   End Try
        '                                   Try
        '                                       CloseWindowStation(hWnsta)
        '                                   Catch ex As Exception
        '                                   End Try


        '                               End Sub)

        'pp.Start()

        Return WinStationNames
    End Function

    Private desktopNames As New List(Of String)
    Public Function EnumDesktopsProc(
          ByVal DesktopName As String,
          ByVal lParam As IntPtr
        ) As Boolean

        desktopNames.Add(DesktopName)
        ' writeLogLine("DesktopName: " & DesktopName)

        Return True
    End Function

    Public Function EnumDesktopsAll() As List(Of String)
        Try
            Dim winStation As IntPtr = OpenWindowStation("winsta0", False, ACCESS_MASK.MAXIMUM_ALLOWED)

            Dim delgateEnum As New EnumDesktopDelegate(AddressOf EnumDesktopsProc)

            EnumDesktops(winStation, delgateEnum, IntPtr.Zero)

            CloseWindowStation(winStation)
        Catch ex As Exception
        End Try

        Return desktopNames
    End Function


    Public Const TOKEN_DUPLICATE As Integer = &H2
    Public Const CREATE_NEW_CONSOLE As Integer = &H10
    Public Const HIGH_PRIORITY_CLASS As Integer = &H80


    Public Function OpenProcessAsSystemforActiveDesktop(ByVal applicationName As String, ByVal UserDesktopName As String) As Boolean
        Try
            Dim winlogonPid As UInteger = GetCurrentProcessId()
            Dim hUserTokenDup As IntPtr = IntPtr.Zero, hPToken As IntPtr = IntPtr.Zero, hProcess As IntPtr = IntPtr.Zero
            Dim procInfo As New PROCESS_INFORMATION()

            Dim dwSessionId As UInteger = 0

            Try
                dwSessionId = WTSGetActiveConsoleSessionId()
            Catch ex As Exception
                ' writeLogLine("Service WTSGetActiveConsoleSessionId Err: dwSessionId Not found ")
                Return False
            End Try


            Dim processes As Process() = Process.GetProcessesByName("winlogon")

            ' writeLogLine("processes.length: " & processes.Length)
            If processes.Length = 0 Then
                ' writeLogLine("Service OpenProcessAs Err: winlogon Not found ")
                Return False
            End If

            Dim isfound As Boolean = False
            For Each p As Process In processes

                If CUInt(p.SessionId) = dwSessionId Then
                    winlogonPid = CUInt(p.Id)
                    isfound = True
                End If
            Next

            If isfound = False Then
                'writeLogLine("Service OpenProcessAs Err: winlogonPid Not found ")
                Return False
            End If

            hProcess = OpenProcess(ACCESS_MASK.MAXIMUM_ALLOWED, False, winlogonPid)

            If Not OpenProcessToken(hProcess, TOKEN_DUPLICATE, hPToken) Then
                'writeLogLine("Service OpenProcessAs Err: OpenProcessToken")
                CloseHandle(hProcess)
                Return False
            End If

            Dim sa As SECURITY_ATTRIBUTES = New SECURITY_ATTRIBUTES()
            sa.Length = Marshal.SizeOf(sa)

            If Not DuplicateTokenEx(hPToken, ACCESS_MASK.MAXIMUM_ALLOWED, sa, CInt(SECURITY_IMPERSONATION_LEVEL.SecurityImpersonation), CInt(TOKEN_TYPE.TokenPrimary), hUserTokenDup) Then
                ' writeLogLine("Service OpenProcessAs Err: DuplicateTokenEx")
                CloseHandle(hProcess)
                CloseHandle(hPToken)
                Return False
            End If

            Dim si As STARTUPINFO = New STARTUPINFO()
            si.cb = CInt(Marshal.SizeOf(si))
            si.lpDesktop = "winsta0\" & UserDesktopName

            Dim dwCreationFlags As UInteger = HIGH_PRIORITY_CLASS Or CREATE_NEW_CONSOLE
            Dim result As Boolean = CreateProcessAsUser(hUserTokenDup, Nothing, applicationName, sa, sa, False, dwCreationFlags, IntPtr.Zero, Nothing, si, procInfo)

            CloseHandle(hProcess)
            CloseHandle(hPToken)
            CloseHandle(hUserTokenDup)

            If result = False Then
                ' writeLogLine("Service OpenProcessAs Err: CreateProcessAsUser")
            End If
            Return result
        Catch ex As Exception
            ' writeLogLine("Exception: " & ex.Message)

            Return False
        End Try
    End Function


    Private Declare Sub SendSAS Lib "SAS.DLL" (ByVal fAsUser As Boolean)
    Friend Sub Send_CNTL_ALT_DEL(ByVal isCaller As Boolean)

        SendSAS(isCaller)
    End Sub


    Private Const UOI_NAME As Integer = 2

    Friend Function getCurrentWinStationName() As String
        Dim hWnsta As IntPtr = GetProcessWindowStation()
        Dim str As String = ""
        Try
            Dim lenNeeded As UInteger

            GetUserObjectInformation(hWnsta, UOI_NAME, Nothing, 0, lenNeeded)

            Dim buffer As New StringBuilder

            GetUserObjectInformation(hWnsta, UOI_NAME, buffer, lenNeeded, lenNeeded)

            str = buffer.ToString

        Catch ex As Exception
            str = ex.Message
        End Try
        'SetProcessWindowStation(hWnsta)

        CloseWindowStation(hWnsta)

        Return str
    End Function
End Module
