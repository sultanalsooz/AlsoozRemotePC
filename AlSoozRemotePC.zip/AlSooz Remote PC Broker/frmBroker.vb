﻿Public Class frmBroker

    Private gbl_processObj As Process
    Private InstallProcessErr As Boolean

    Private Gbl_InstallSerivce_Path_User As String = ""


    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        Dim Gbl_FolderPath_User As String = "C:\ProgramData\AlSoozRemotePC\"

        Gbl_InstallSerivce_Path_User = Gbl_FolderPath_User & "\AlSoozRemotePCService.exe"

        InstallServiceWithUAC()
    End Sub

    Friend Sub InstallServiceWithUAC()
        InstallProcessErr = False
        gbl_processObj = New Process
        Try

            If My.Computer.FileSystem.FileExists(Gbl_InstallSerivce_Path_User) Then

                Dim psi As New ProcessStartInfo

                With psi
                    .UseShellExecute = True
                    .FileName = Gbl_InstallSerivce_Path_User
                    .Arguments = "/i"
                    .WindowStyle = ProcessWindowStyle.Normal
                    .Verb = "runas" ' for admin
                End With

                gbl_processObj.StartInfo = psi
                gbl_processObj.EnableRaisingEvents = True

                'AddHandler ps.OutputDataReceived, AddressOf ProcessOutputHandler

                AddHandler gbl_processObj.Exited, New EventHandler(AddressOf ProcessExitedHandler)

                Dim err As String = ""
                Try
                    gbl_processObj.Start()
                Catch ex As Exception
                    err = ex.Message
                End Try

                If err.Length > 1 Then
                    InstallProcessErr = True
                    MsgBox("Error occurred, service was not installed. " & err)

                End If

            Else
                InstallProcessErr = True
                MsgBox("File Not Found")

            End If

        Catch ex As Exception
            InstallProcessErr = True

            MsgBox("Error: " & ex.Message)
        End Try

        App_Close("err")
    End Sub

    Private Sub ProcessExitedHandler(sendingProcess As Object, ByVal e As System.EventArgs)

        Threading.Thread.Sleep(500)
        App_Close("ok")

    End Sub

    Private Sub App_Close(ByVal ExitString As String)

        If ExitString = "ok" Then

        Else

        End If

        Me.Close()
    End Sub
End Class
